<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zanthium</title>
</head>
<body>
    <script>window.top.location.href="User/index.php";</script>
</body>
</html>