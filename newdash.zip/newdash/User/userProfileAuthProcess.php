<?php
include("loginCheck.php");

if (isset($_POST['profileUpdate'])) {
    $memberId = $_POST['memberId'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $emailId = $_POST['emailId'];
    $countryId = $_POST['countryId'];
    $d = date("Y-m-d H:i:s");
    mysqli_query($con, "UPDATE meddolic_user_details SET name='$name',email_id='$emailId',phone='$phone',countryId='$countryId' WHERE member_id='$memberId'"); ?>
    <script>
        alert("Profile Updated Successfully!!!");
        window.top.location.href = "userProfileAuth";
    </script>
<?php }

if (isset($_POST['addWalletAddress'])) {
    $currencyId = $_POST['currencyId'];
    $memberId = $_POST['memberId'];
    $walletAddress = $_POST['walletAddress'];
    $trnPassword = $_POST['trnPassword'];
    $d = date("Y-m-d H:i:s");
    $todayDate = date("Y-m-d");


    // $queryCheck=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_details WHERE member_id='$memberId' AND trnPassword='$trnPassword'");
    // $valCheck=mysqli_fetch_array($queryCheck);
    // if($valCheck[0]==0) { 
?>
    // <script>
        //       alert("Incorrect Transaction Password!!!");
        //       window.top.location.href='walletAddressAdd';
        //     
    </script>
    // <?php
        //     exit;
        // }
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_wallet_address_details (`currency_id`,`member_id`,`walletAddress`,`addDate`) VALUES ('$currencyId','$memberId','$walletAddress','$d')");
        if ($queryIn) {  ?>
        <script>
            alert('Wallet Address Added Successfully');
            window.top.location.href = "walletAddressAdd";
        </script>
    <?php
            exit;
        } else { ?>
        <script>
            alert('Wallet Address Not Added...Try Again');
            window.top.location.href = "walletAddressAdd";
        </script>
    <?php
            exit;
        }
    }

    if (isset($_POST['addUPIAddress'])) {
        $memberId = $_POST['memberId'];
        $upiAddress = $_POST['upiAddress'];
        $d = date("Y-m-d H:i:s");
        $todayDate = date("Y-m-d");

        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_upi_address_details (`member_id`,`upiAddress`,`addDate`) VALUES ('$memberId','$upiAddress','$d')");
        if ($queryIn) {  ?>
        <script>
            alert('UPI Address Added Successfully');
            window.top.location.href = "upiAdd";
        </script>
    <?php
            exit;
        } else { ?>
        <script>
            alert('UPI Address Not Added...Try Again');
            window.top.location.href = "upiAdd";
        </script>
    <?php
            exit;
        }
    }

    if (isset($_POST['changeLogin'])) {
        $memberId = $_POST['memberId'];
        $password = $_POST['password'];
        $password1 = $_POST['password1'];
        $password2 = $_POST['password2'];
        $d = date("Y-m-d H:i:s");

        if ($password2 != $password1) { ?>
        <script>
            alert("New Login passwords do not match!!!");
            window.top.location.href = 'changePassword';
        </script>
    <?php
            exit;
        }
        $result = mysqli_query($con, "SELECT count(*) FROM meddolic_user_details WHERE member_id='$memberId' AND password='$password'");
        $val = mysqli_fetch_array($result);
        if ($val[0] == 0) { ?>
        <script>
            alert("Incorrect Current Login password!!!");
            window.top.location.href = 'changePassword';
        </script>
    <?php
            exit;
        }

        $result1 = mysqli_query($con, "UPDATE meddolic_user_details SET password='$password1' WHERE member_id='$memberId'");
        if ($result1) {
            unset($_SESSION['user_member_id']);
            unset($_SESSION['member_user_id']);
            unset($_SESSION['member_password']); ?>
        <script>
            alert("Login Password Updated Successfully!!!\nNow please login again with new password. ");
            window.top.location.href = 'changePassword';
        </script>
    <?php
        }
    }
    if (isset($_POST['changeTrn'])) {
        $memberId = $_POST['memberId'];
        $password = $_POST['trnPassword'];
        $password1 = $_POST['trnPassword1'];
        $password2 = $_POST['trnPassword2'];
        $d = date("Y-m-d H:i:s");
        if ($password2 != $password1) { ?>
        <script>
            alert("New Transaction passwords and Confirm Transaction Password do not match!!!");
            window.top.location.href = 'trnPassword';
        </script>
    <?php
            exit;
        }

        $result = mysqli_query($con, "SELECT COUNT(*) FROM meddolic_user_details WHERE member_id='$memberId' AND trnPassword='$password'");
        $val = mysqli_fetch_array($result);
        if ($val[0] == 0) { ?>
        <script>
            alert("Incorrect Current Transaction password!!!");
            window.top.location.href = 'trnPassword';
        </script>
    <?php
            exit;
        }

        $result1 = mysqli_query($con, "UPDATE meddolic_user_details SET trnPassword='$password1' WHERE member_id='$memberId'");
        if ($result1) { ?>
        <script>
            alert("Transaction Password Updated Successfully!!!");
            window.top.location.href = 'trnPassword';
        </script>
<?php
        }
    } ?>
    <?php
include("../connection.php"); // Or your DB connection file

if (isset($_POST['bankUpdate'])) {
    $memberId  = $_POST['memberId'];
    $acName    = trim($_POST['acName']);
    $ifsc      = trim($_POST['ifsc']);
    $bank      = trim($_POST['bank']);
    $branch    = trim($_POST['branch']);
    $accountNo = trim($_POST['accountNo']);
    $panNo     = strtoupper(trim($_POST['panNo'])); // PAN should always be uppercase
    $d         = date("Y-m-d H:i:s");

    // Check if bank details already exist to prevent duplicate update
    $check = mysqli_query($con, "SELECT * FROM meddolic_user_details WHERE member_id='$memberId' AND acName IS NOT NULL");
    if (mysqli_num_rows($check) > 0) {
        echo "<script>
                alert('Bank details already submitted and cannot be changed.');
                window.top.location.href = 'bankDetails';
              </script>";
        exit;
    }

    // Update query
    $update = mysqli_query($con, "UPDATE meddolic_user_details SET 
        acName = '$acName',
        ifsc = '$ifsc',
        bank = '$bank',
        branch = '$branch',
        accountNo = '$accountNo',
        panNo = '$panNo'
        WHERE member_id = '$memberId'
    ");

    if ($update) {
        echo "<script>
                alert('Bank details updated successfully.');
                window.top.location.href = 'bankDetails';
              </script>";
    } else {
        echo "<script>
                alert('Failed to update bank details. Please try again.');
                window.top.location.href = 'bankDetails';
              </script>";
    }
}
?>
<?php include("../close-connection.php"); ?>