<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
</head>
<?php
$queryConfig=mysqli_query($con,"SELECT minTransfer FROM meddolic_config_misc_setting");
    $valConfig=mysqli_fetch_assoc($queryConfig);
    $minTransfer=$valConfig['minTransfer'];
   ?>
  

<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Menu.php');
require_once('Include/Header.php'); ?>

<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

<h2>wallet</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">Withdrawal</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                <tr>
                <th>#</th>
                            <th>UserId</th>
                            <th>Name</th>
                            <th>Income Wallet</th>
                            <th>Purchase Wallet</th>
                </tr>
              </thead>
              <tbody>
              <?php 
                $count=0;
                $querySelf=mysqli_query($con,"SELECT name,user_id,wallet,fundWallet FROM meddolic_user_details WHERE member_id='$memberId'");
                while($valSelf=mysqli_fetch_assoc($querySelf)){
                  $count++; ?>
                <tr>
                  <td><?= $count?></td>
                  <td><?= $valSelf['user_id']?></td>
                  <td><?= $valSelf['name']?></td>
                  <td><span class="badge badge-success"> <?= $valSelf['wallet']?> $</span></td>
                  <td><span class="badge badge-success"> <?= $valSelf['fundWallet']?> $</span></td>
                  
                </tr>
                <?php } ?>
                            </tbody>
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>