<?php 
include("loginCheck.php");
if(isset($_POST['addFundNow'])){
  $loginMemberId=mysqli_real_escape_string($con,$_POST['loginMemberId']);
  $investmentAmount=mysqli_real_escape_string($con,$_POST['requestFund']);
  $currencyId=mysqli_real_escape_string($con,$_POST['currencyId']);

  $d=date("Y-m-d H:i:s");
  $todayDate=date("Y-m-d");
  
    

  $queryOld=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_invest_purchase_details WHERE memberId='$loginMemberId' AND actionType=2 AND nextPayOpen=0");
  $valOld=mysqli_fetch_array($queryOld);
  if($valOld[0]>0){ ?>
      <script>
          alert("Your Previous Request is on Pending!!!");
          window.top.location.href="fundRequest";
      </script>
      <?php
      exit;
  }
//   echo 'asda';
  $queryDetails=mysqli_query($con,"SELECT member_id,name,phone,email_id,user_id,sponser_id FROM meddolic_user_details WHERE member_id='$loginMemberId'");
  $valDetails=mysqli_fetch_assoc($queryDetails);
  $memberId=$valDetails['member_id'];
  $name=$valDetails['name'];
  $phone=$valDetails['phone'];
  $emailId=$valDetails['email_id'];
  $userId=$valDetails['user_id'];
  $sponserId=$valDetails['sponser_id'];

  $queryCoin=mysqli_query($con,"SELECT currencyCode FROM meddolic_config_currency_list WHERE currency_id='$currencyId'");
  $valCoin=mysqli_fetch_assoc($queryCoin);
  $currencyCode=$valCoin['currencyCode'];

  $addCharge=$investmentAmount*1/100;
  $newInvestAmount=$investmentAmount+$addCharge;

  //Payment Gateway Code Starts//    
  $orderId="TG".time().$memberId."AF".rand(0000,9999);
  $packageName="New Add Order SUNTRADE GLOBAL ";
  $queryTemp=mysqli_query($con,"INSERT INTO meddolic_user_invest_purchase_details (`memberId`,`loginMemberId`,`name`,`phone`,`emailId`,`addDate`,`orderId`,`packagePrice`,`actionType`) VALUES ('$memberId','$loginMemberId','$name','$phone','$emailId','$d','$orderId','$investmentAmount',2)");
  $tempId=$con->insert_id;
  //Test Url -: https://api-sandbox.nowpayments.io/v1/payment
  //Live Url -: https://api.nowpayments.io/v1/payment
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://api.nowpayments.io/v1/payment',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>'{
    "price_amount": "'.$newInvestAmount.'",
    "price_currency": "USDTTRC20",
    "pay_currency": "'.$currencyCode.'",
    "ipn_callback_url": "https://suntradeglobal.com/returnNowPaymentApi",
    "order_id": "'.$orderId.'",
    "order_description": "'.$packageName.'"
  }',
    CURLOPT_HTTPHEADER => array(
      'x-api-key: FMJMKE9-TV346S4-J7MS9N1-XSB8D74',
      'Content-Type: application/json'
    ),
  ));

  $returnResponse = curl_exec($curl);
  $paymentData=json_decode($returnResponse, true);

//   print_r($paymentData);
  $paymentId = $paymentData['payment_id'];
  $paymentStatus = $paymentData['payment_status'];
  $payAddress = $paymentData['pay_address'];
  $priceAmount = $paymentData['price_amount'];
  $priceCurrency = $paymentData['price_currency'];
  $payAmount = $paymentData['pay_amount'];
  $payCurrency = $paymentData['pay_currency'];
  $amountReceived = $paymentData['amount_received'];
  $returnOrderId = $paymentData['order_id'];
  $createdAt = $paymentData['created_at'];
  $updatedAt = $paymentData['updated_at'];
  $purchaseId = $paymentData['purchase_id'];

  mysqli_query($con,"UPDATE meddolic_user_invest_purchase_details SET paymentId='$paymentId',paymentStatus='$paymentStatus',payAddress='$payAddress',priceAmount='$priceAmount',priceCurrency='$priceCurrency',payAmount='$payAmount',payCurrency='$payCurrency',amountReceived='$amountReceived',createdTime='$createdAt',updateTime='$updatedAt',purchaseId='$purchaseId' WHERE orderId='$returnOrderId'");
  curl_close($curl);
  //Payment Gateway Code Ends// ?>
  <script>
     window.top.location.href="fundRequestSuccessNew?orderId=<?=$returnOrderId?>";
  </script>
<?php } ?>
<?php include("../close-connection.php"); ?>