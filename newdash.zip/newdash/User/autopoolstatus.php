<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

    <?php require_once('Include/Menu.php');
    ?>



    <!-- Header -->
    <!-- <header class="header position-fixed">
        <div class="row">
            <div class="col-auto">
                <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
            </div>
            <div class="col text-right d-flex" style=" justify-content: space-between">
                <div class="user-small d-flex align-items-center">
                    <h6 class="mb-1"> <?= $userId ?>(<?= $userName ?>)</h6>
                </div>
                <div class="logo-small m-0">
                    <img src="" alt="" />
                </div>
            </div>

        </div>
    </header> -->
    <style>
        .card {
            margin-bottom: 20px;
        }
    </style>

    <!--#INCLUDE file="header.asp"-->
    <main class="h-100">
        <div class="dashboard-body-part">
            <div class="container-full">
                <!-- Content Header (Page header) -->


                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="card-header">
                            <h5 style='color:#ffffff'>My Pool Team</h5>
                        </div>
                        <style>
                            .form-control-sm {
                                padding: 0.25rem 1.5rem !important;
                            }
                        </style>
                        <div class="card crd0">
                            <div class="card-body">
                                <div class="dt-ext table-responsive">
                                    <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>User ID</th>
                                                <th>Name</th>
                                                <!-- <th>Pool Name</th> -->
                                                <th>Pool No.</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            function totalInvest($con, $memberId)
                                            {
                                                $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'");
                                                $valInvest = mysqli_fetch_array($queryInvest);
                                                if ($valInvest[0] != "") {
                                                    return $valInvest[0];
                                                } else {
                                                    echo "0.00";
                                                }
                                            }
                                           $count=0;
                                    $queryPool=mysqli_query($con,"SELECT a.entryId,a.poolId,a.poolLevel,a.entryDate,b.user_id,b.name FROM meddolic_user_pool_entry_details a, meddolic_user_details b, meddolic_config_pool_list c WHERE a.memberId='$memberId' AND a.memberId=b.member_id AND a.poolId=c.poolId AND a.poolStatus=1 ORDER BY a.entryId ASC");
                                    while($valPool=mysqli_fetch_array($queryPool)){
                                          $count++; ?>
                                    <tr>
                                        <td><?=$count?></td>
                                        <td><?=$valPool['user_id']?></td>
                                        <td><?=$valPool['name']?></td>
                                        <!-- <td> <?=$valPool['poolName']?></td> -->
                                        <td>Pool <?=$valPool['poolId']?></td>
                                     
                                        <td><a href="myPoolTeamStatus?userId=<?=$memberId?>&entryId=<?=$valPool['entryId']?>&poolId=<?=$valPool['poolId']?>" class="btn btn-primary btn-sm">More</a></td>
                                    </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
            <!-- /.row -->
            </section>
            <!-- /.content -->

        </div>
        </div>
        </div>
        <?php require_once('Include/Footer.php'); ?>

</body>


</html>