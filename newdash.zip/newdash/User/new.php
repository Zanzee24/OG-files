<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1">

<?php
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>


<body>


    <!-- PAGE -->
    <div class="page">

        <!-- MAIN-CONTENT -->

        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <!-- Start:: row-1 -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card custom-card">
                            <div class="top-left"></div>
                            <div class="top-right"></div>
                            <div class="bottom-left"></div>
                            <div class="bottom-right"></div>
                            <div class="card-body">
                                <h2>Support</h2>
                                <div class="mb-3">
                                    <label for="form-text" class="form-label fs-14 text-dark"> Subject</label>
                                   <select class="form-control" required id="subjectId" name="subjectId">
                                  <option value=""> Select One </option>
                                   </select>
                                </div>
                                <div class="mb-3">
                                <label for="form-text" class="form-label fs-14 text-dark"> Priority</label>
                                   <select class="form-control" required id="subjectId" name="subjectId">
                                  <option value=""> Select One </option>
                                   </select>
                                </div>
                                <div class="form-check mb-3">
                                    <label class="col-md-12">Message</label>
                              <div class="col-md-12">
                                <textarea class="form-control" cols="20" data-val="true" data-val-required="Message is Required" id="ticketMessage" name="ticketMessage" placeholder="Enter Message" rows="2"></textarea>
                                <span class="field-validation-valid" data-valmsg-for="msg" data-valmsg-replace="true"></span>
                              </div>
                                </div>
                                <button class="btn btn-primary" type="submit">Submit</button>
                                <button class="btn btn-success" type="submit">Cancel</button>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="top-left"></div>
                        <div class="top-right"></div>
                        <div class="bottom-left"></div>
                        <div class="bottom-right"></div>
                        <div class="card-header">
                            <div class="card-title">
                                All Outbox Tickets
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Ticket No</th>
                                            <th>Subject</th>
                                            <th>Message</th>
                                            <th>Priority</th>
                                            <th>Raise Date</th>
                                            <th>Last Update</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="top-left"></div>
                        <div class="top-right"></div>
                        <div class="bottom-left"></div>
                        <div class="bottom-right"></div>
                        <div class="card-header">
                            <div class="card-title">
                                All Inbox Tickets
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">

                                <table class="table text-nowrap">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Subject</th>
                                            <th>Message</th>
                                            <th>Date</th>
                                        </tr>
                                    </thead>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <?php include 'Include/footer.php'; ?>

</body>

</html><!-- This code use for render base file -->