<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>
<body class="bg-theme">	<!-- Wrapper -->
	<div class="wrapper">
		<div class="page-wrapper">
			<div class="page-content-wrapper">
				<div class="page-content">
					<!-- Breadcrumb -->
					<div class="page-breadcrumb d-none d-md-flex align-items-center mb-3">
						<div class="breadcrumb-title pr-3">Auto Pool Income</div>
					</div>
                    

					<!-- Content -->
					<div class="user-profile-page">
						<div class="card radius-15">
							<div class="card-body">

	<h4 class="card-title">Auto Pool Income</h4>

									<!-- History Tab -->
										<div class="card shadow-none border mb-0 radius-15">
											<div class="card-body">
												                

                
												<div class="card">
													<div class="card-body">
														<div class="table-responsive">
															<table id="example2" class="table table-striped table-bordered" style="width:100%">
                                                                  
															 <thead>
                      <tr>
                        <th>#</th>
                        <th>UserId</th>
                        <th>Name</th>
                        <th>Pool Income </th>
                        <th>Pool Level</th>
                        <th>Date</th>
                        <th>Status</th>

                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $count = 0;
                      $queryLevel = mysqli_query($con, "SELECT a.release_date,a.Status,a.amount,a.poolLevel,b.name,b.user_id FROM meddolic_user_matrix_income_release2 a, meddolic_user_details b, meddolic_config_matrix_income c WHERE a.member_Id=b.member_id AND a.member_Id='$memberId'  AND a.childId=c.matrixId AND a.childId=1 ORDER BY a.release_date DESC");
                      while ($valLevel = mysqli_fetch_assoc($queryLevel)) {
                        $count++; ?>
                        <tr>
                          <td>
                            <?= $count ?>
                          </td>
                          <td><?= $valLevel['user_id'] ?></td>
                          <td><?= $valLevel['name'] ?></td>
                          <td><span class="badge bg-success"><i
                                class="fa fa-inr"></i><?= $valLevel['amount'] ?></span></td>

                          <td>Level <?= $valLevel['poolLevel'] ?></td>
                          <td><i class="fa fa-clock-o"></i><?= date("d-m-Y H:i:s", strtotime($valLevel['release_date'])) ?>
                          </td>
                          <td>
                            <?php if ($valLevel['Status'] == 1)
                              echo "<span class='badge badge-success'>RELEASED</span>";
                            else if ($valLevel['releaseStatus'] == 0)
                              echo "<span class='badge badge-danger'>HOLD</span>"; ?>
                          </td>
                        </tr>
                      <?php } ?>
                    </tbody>
															</table>
														</div>
														<!-- If using DataTables plugin, pagination and buttons will auto-render -->
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- End History -->
								</div> <!-- End Tabs -->
							</div>
						</div>
					</div>

				</div> <!-- page-content -->
			</div> <!-- page-content-wrapper -->
		</div> <!-- page-wrapper -->
	</div> <!-- wrapper -->

</div>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>




</html>