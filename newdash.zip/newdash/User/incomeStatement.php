<!DOCTYPE html>
<html lang="en">
<?php 
require_once("loginCheck.php");
require_once("Include/Head.php");
require_once("Include/Header.php");
require_once("Include/Menu.php");

date_default_timezone_set("Asia/Kolkata");

// Default values
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : '';
$from_date = isset($_GET['from_date']) ? $_GET['from_date'] : date("d-m-Y");
$to_date = isset($_GET['to_date']) ? $_GET['to_date'] : date("d-m-Y");

$from_date_sql = date("Y-m-d", strtotime($from_date));
$to_date_sql = date("Y-m-d", strtotime($to_date));
?>
<head>

  <!-- jQuery + jQuery UI for Datepicker -->
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>

  <style>
    .badge-success { background-color: #28a745; color: white; padding: 5px; }
    .badge-danger { background-color: #dc3545; color: white; padding: 5px; }
  </style>
</head>


<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">Income History</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">History</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
  <form method="GET">
                  <div class="form-row">
                    <div class="col-md-3 mb-2">
                      <input class="form-control" type="text" name="user_id" placeholder="Enter User ID" value="<?= htmlspecialchars($user_id) ?>">
                    </div>
                    <div class="col-md-3 mb-2">
                      <input type="text" name="from_date" id="from_date" class="form-control" placeholder="From Date" value="<?= $from_date ?>">
                    </div>
                    <div class="col-md-3 mb-2">
                      <input type="text" name="to_date" id="to_date" class="form-control" placeholder="To Date" value="<?= $to_date ?>">
                    </div>
                    <div class="col-md-2 mb-2">
                      <input type="submit" class="btn btn-primary w-100" value="Search">
                    </div>
                  </div>
                </form>
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                      <tr>
                        <th>#</th>
                        <th>User ID</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Income Type</th>
                        <th>Transaction Type</th>
                        <th>Remark</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $query = "SELECT b.user_id, a.date_time, a.amount, a.deb_cr, c.statement_type, c.wallet_remark
                                FROM meddolic_user_wallet_statement a
                                JOIN meddolic_user_details b ON a.member_id = b.member_id
                                JOIN meddolic_config_wallet_statement_type c ON a.wallet_statement_id = c.wallet_statement_id
                                WHERE DATE(a.date_time) BETWEEN '$from_date_sql' AND '$to_date_sql'";

                      if (!empty($user_id)) {
                          $safe_user_id = mysqli_real_escape_string($con, $user_id);
                          $query .= " AND b.user_id = '$safe_user_id'";
                      }

                      $query .= " ORDER BY a.date_time DESC";

                      $result = mysqli_query($con, $query);
                      $count = 0;

                      while ($row = mysqli_fetch_assoc($result)) {
                          $count++;
                          $is_credit = ($row['deb_cr'] == 2);
                          ?>
                          <tr>
                            <td><?= $count ?></td>
                            <td><?= htmlspecialchars($row['user_id']) ?></td>
                            <td>
                              <span class="badge <?= $is_credit ? 'badge-success' : 'badge-danger' ?>">
                                <?= $row['amount'] ?> ₹
                              </span>
                            </td>
                            <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($row['date_time'])) ?></td>
                            <td><?= htmlspecialchars($row['statement_type']) ?></td>
                            <td>
                              <span class="badge <?= $is_credit ? 'badge-success' : 'badge-danger' ?>">
                                <?= $is_credit ? "Credit" : "Debit" ?>
                              </span>
                            </td>
                            <td><?= htmlspecialchars($row['wallet_remark']) ?></td>
                          </tr>
                          <?php
                      }
                      ?>
                    </tbody>
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>

  <script>
    $(function () {
      $("#from_date, #to_date").datepicker({
        dateFormat: "dd-mm-yy",
        changeMonth: true,
        changeYear: true,
        maxDate: 0
      });
    });
  </script>
</body>

</html>
 