<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

    <?php require_once('Include/Menu.php');
    ?>



    <!-- Header -->
    <header class="header position-fixed">
        <div class="row">
            <div class="col-auto">
                <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
            </div>
            <div class="col text-right">
                <div class="logo-small">
                    <img src="assets/img/logo.png" alt="" style=" height:50px; " />
                </div>
            </div>

        </div>
    </header>

    <main class="h-100">
        <div class="content-wrapper">
            <div class="container-full">
                <!-- Content Header (Page header) -->


                <!-- Main content -->
                <section class="content">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-dark" style='color:#000'>Suntrade Profit </h6>
                    </div>
                    <div class="row">
                        <div class="card crd0">
                            <div class="card-body">
                                <div class="dt-ext table-responsive">
                                    <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>User Id</th>
                                                <th>Name</th>
                                                <th>Amount</th>
                                                <th>Income Day</th>
                                                <th>Release Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryDeal = mysqli_query($con, "SELECT a.cashbackIncome,a.dateTime,b.user_id,b.name FROM meddolic_user_invest_income a, meddolic_user_details b WHERE a.summaryId='$_GET[summary_id]' AND a.memberId=b.member_id ORDER BY a.dateTime ASC");
                                            while ($valDeal = mysqli_fetch_assoc($queryDeal)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valDeal['user_id'] ?></td>
                                                    <td><?= $valDeal['name'] ?></td>
                                                    <td><span class="badge badge-success"><i class="fa fa-usd"></i> <?= $valDeal['cashbackIncome'] ?></span></td>
                                                    <td><?= $count ?> Day</td>
                                                    <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valDeal['dateTime'])); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <!-- /.row -->
        </section>
        <!-- /.content -->

        </div>
        </div>
        </div>
        <?php require_once('Include/Footer.php'); ?>

</body>


</html>