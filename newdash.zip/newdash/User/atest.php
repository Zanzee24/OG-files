<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log'); 

require_once("loginCheck.php");
require_once('authIncomeFunction.php');

    $querySlab = mysqli_query($con, "SELECT user_id,date_time FROM meddolic_user_details ORDER by member_id ASC");
   while($valSlab = mysqli_fetch_assoc($querySlab)){
    $user_id = $valSlab['user_id'];
    $d = $valSlab['date_time'];

    $queryDetails = mysqli_query($con, "SELECT a.member_id,a.sponser_id,a.topup_flag,b.currentReward,b.activation_date,b.topup_flag AS sponserTop FROM meddolic_user_details a, meddolic_user_details b WHERE a.user_id='$user_id' AND a.sponser_id=b.member_id");
    $valDetails = mysqli_fetch_assoc($queryDetails);
    $memberId = $valDetails['member_id'];
    $sponserId = $valDetails['sponser_id'];
    $topupFlag = $valDetails['topup_flag'];
    $currentReward = $valDetails['currentReward'];
    $nextReward = $currentReward + 1;
    $sponserTop = $valDetails['sponserTop'];
    $spActDate = $valDetails['activation_date'];

$packageId=1;
$investAmount=1000;
$loginMemberId=$memberId;
    //Activation Code Start//
    if ($topupFlag == 0) {
        mysqli_query($con, "UPDATE meddolic_user_details SET topup_flag=1,activation_date='$d' WHERE member_id='$memberId'");
        mysqli_query($con, "UPDATE meddolic_user_child_ids SET topup_status=1,topup_date='$d' WHERE child_id='$memberId'");
    }
    $queryPartner = mysqli_query($con, "INSERT INTO meddolic_user_invest_history (memberId,sponserId,loginMemberId,investAmount,dateTime) VALUES ('$memberId','$sponserId','$loginMemberId','$investAmount','$d')");
    $investId = $con->insert_id;
   
    mysqli_query($con, "UPDATE meddolic_user_details SET fundWallet=fundWallet-'$investAmount' WHERE member_id='$loginMemberId'");
    mysqli_query($con, "UPDATE meddolic_user_details SET currentPackage='$packageId' WHERE member_id='$memberId'");

    mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (member_id,wallet_statement_id,deb_cr, amount,date_time,trn_id) VALUES ('$loginMemberId',8,1,'$investAmount','$d','$investId')");
    //Fund Debit Code End
     releaseLevelIncome($con, $memberId, $packageId, $investAmount, $d);
}
echo "DONE";
    // echo "<script>alert('Congratulation...Package Purchased Successfully!!!');window.top.location.href='authActiveUser';</script>";
 ?>
<?php include("../close-connection.php"); ?>