<!DOCTYPE html>
<html lang="en">
<?php require_once("loginCheck.php");
require_once("Include/Head.php");
require_once("Include/Header.php"); ?>
<?php
   $orderId=$_GET['orderId'];
  $queryTrn=mysqli_query($con,"SELECT priceAmount,priceCurrency,payAmount,payCurrency,amountReceived,paymentId,paymentStatus,payAddress,createdTime,updateTime,purchaseId FROM meddolic_user_invest_purchase_details WHERE memberId='$memberId' AND orderId='$orderId'");
  $valTrn=mysqli_fetch_assoc($queryTrn);
  $priceAmount=$valTrn['priceAmount'];
  $priceCurrency=$valTrn['priceCurrency'];
  $payAmount=$valTrn['payAmount'];
  $payCurrency=$valTrn['payCurrency'];
  $amountReceived=$valTrn['amountReceived'];
  $paymentId=$valTrn['paymentId'];
  $paymentStatus=$valTrn['paymentStatus'];
  $payAddress=$valTrn['payAddress'];
  $createdTime=$valTrn['createdTime'];
  $updateTime=$valTrn['updateTime'];
  $purchaseId=$valTrn['purchaseId']; ?>
  
  
<style>
  #qrCode {
    background-color: white;
    padding: 1rem;
    width: 100%;
    max-width: fit-content;
    margin-bottom: 1rem;
  }

  #qrCode>* {
    width: 100%;
  }
</style>

<div class="card mb-4">
  <div class="card-body">
  <section class="content-header">
    <h5>Fund Request</h5>

  </section>
  <section class="content">
    <div class="row">
      <div class="col-xl-6 col-lg-12">
        <div class="box">
          <div class="box-header"><span class="badge badge-success">Request Id -: <?=$orderId?></span></div>
          <div class="box-body">
            <div class="col-xl-12 col-lglg-4 col-md-12 col-sm-4 col-12">
              <label class="control-label">To pay, send exact amount of <?=$payCurrency?> to the given address</label>
              <label class="control-label">Amount : <strong><?= $payAmount?></strong> <?=$payCurrency?></label>
              <p><label style="font-size:16px;">Payment Address -: <span class='badge badge-primary' style="font-weight: 600;" id="qrstatus"></span></label></p>
                <div class="row">
                  <div class="col-md-10">
                    <div class="form-group">
                      <input type="text" class="form-control pull-right" id="payAddress" value="<?=$payAddress?>"  readonly style="display: inline-block;" >
                    </div>
                  </div>
                  <div class="col-md-2">
                    <div class="form-group">
                      <a onclick="copyPayAddress()" style="display: inline-block;" href="javascript:;" class="btn btn-success btn-sm" ><i class="zoom fa fa-copy " style="color:white;"></i> Copy</a>
                    </div>
                  </div>
                </div>
              <br>
              <label class="control-label">QR Code</label>
              <div id="qrCode"></div>
              <!--<img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=<?=$payAddress?>&choe=UTF-8" /><br/>-->
               <!--<img src="https://quickchart.io/qr?text=<?=$payAddress?>&choe=UTF-8" /><br/>-->
            </div>
            <p><label class="control-label">1. Fund will be deposited after Network confirmations.</label></p>
            <p><label class="control-label">2. Wait for sometime to receive fund. <br></label></p>
          </div>
      </div>
      </div>
    </div>
  </section>
</div>
     </div>
<script src="qrcode.min.js"></script>
<script>
  new QRCode(document.getElementById("qrCode"), "<?= $payAddress ?>");
</script>
<?php require_once('Include/Footer.php');?>
<script>
jQuery(document).ready(function(){
  setInterval(function(){
    var orderId ="<?=$orderId; ?>";
    $.ajax({
      type: "POST",
      url: 'fundRequestPaymentAjaxProcess',
      data: { orderId : orderId },
      cache: false,
        success: function(data){
        // alert(data);
        var resData=jQuery.parseJSON(data);
        if(resData.status=="finished"){
            var url = "addFundPaySuccess?orderId=<?= $orderId?>";
            window.location.href=url;
        }
        if(resData.status=="confirming"){
          jQuery('#qrstatus').text("(Payment Partially Confirmed)")
        }
        if(resData.status=="expired"){
          jQuery('#qrstatus').text("(Payment Expired)")
        }                         
        if(resData.status=="refunded"){
          jQuery('#qrstatus').text("(Payment Refunded)")
        }                         
        if(resData.status=="failed"){
          jQuery('#qrstatus').text("(Payment Failed)")
        }
        if(resData.status=="partially_paid"){
          jQuery('#qrstatus').text("(Payment Partially Paid)")
        }
        if(resData.status=="sending"){
          jQuery('#qrstatus').text("(Payment Sending)")
        }                       
        if(resData.status=="confirmed"){
          jQuery('#qrstatus').text("(Payment Confirmed)")
        }
        if(resData.status=="waiting"){
          jQuery('#qrstatus').text("(Payment Waiting)")
        }
        var current_addr="<?= $payAddress?>";
        if(current_addr !=resData.address){
          location.reload();
        }
      }
    });
  }, 10000);
});
function copyPayAddress(){
  var copyText = document.getElementById("payAddress");
  copyText.select();
  document.execCommand("Copy");
  alert("Pay Address Copied Successfully!!!");
}
var d = document.getElementById("Fund");
  d.className += " active";
var d = document.getElementById("fundRequest");
  d.className += " active";
</script>
</body>

</html>