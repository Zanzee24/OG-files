<?php 
ob_start();
error_reporting(E_ALL ^ E_NOTICE);
include("loginCheck.php");
clearstatcache(); 
ini_set('memory_limit', '-1');
ini_set('max_execution_time', 1300); //300 seconds = 5 minutes
if($_GET['tempId']!=""){
  $tempId=$_GET['tempId'];
  $d=date("Y-m-d H:i:s");
  $todayDate=date("Y-m-d");

  $queryTemp=mysqli_query($con,"SELECT memberId,packagePrice,orderId,payCurrency,payAmount FROM meddolic_user_invest_purchase_details WHERE tempId='$tempId'");
  $valTemp=mysqli_fetch_assoc($queryTemp);
  $memberId=$valTemp['memberId'];
  $packagePrice=$valTemp['packagePrice'];
  $orderId=$valTemp['orderId'];
  $payCurrency=$valTemp['payCurrency'];
  $payAmount=$valTemp['payAmount'];
  $packageName="New Add Order Unitrax Re Gen";

  
  //Payment Gateway Code Starts//
  
  $curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://api.nowpayments.io/v1/payment',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS =>'{
    "price_amount": "'.$packagePrice.'",
    "price_currency": "trx",
    "pay_currency": "'.$payCurrency.'",
    "ipn_callback_url": "https://suntradeglobal.com/returnNowPaymentApi",
    "order_id": "'.$orderId.'",
    "order_description": "'.$packageName.'"
  }',
    CURLOPT_HTTPHEADER => array(
      'x-api-key: FA1RF6K-H3ZMV3P-K31ZZ1B-1K7NCYX',
      'Content-Type: application/json'
    ),
  ));

  $returnResponse = curl_exec($curl);
  $paymentData=json_decode($returnResponse, true);
  $paymentId = $paymentData['payment_id'];
  $paymentStatus = $paymentData['payment_status'];
  $payAddress = $paymentData['pay_address'];
  $priceAmount = $paymentData['price_amount'];
  $priceCurrency = $paymentData['price_currency'];
  $payAmount = $paymentData['pay_amount'];
  $payCurrency = $paymentData['pay_currency'];
  $amountReceived = $paymentData['amount_received'];
  $returnOrderId = $paymentData['order_id'];
  $createdAt = $paymentData['created_at'];
  $updatedAt = $paymentData['updated_at'];
  $purchaseId = $paymentData['purchase_id'];

  $queryUpdate=mysqli_query($con,"UPDATE meddolic_user_invest_purchase_details SET paymentId='$paymentId',paymentStatus='$paymentStatus',payAddress='$payAddress',priceAmount='$priceAmount',priceCurrency='$priceCurrency',payAmount='$payAmount',payCurrency='$payCurrency',amountReceived='$amountReceived',createdTime='$createdAt',updateTime='$updatedAt',purchaseId='$purchaseId' WHERE orderId='$returnOrderId' AND tempId='$tempId'");
  curl_close($curl);

  if($queryUpdate) { ?>
    <script>
      alert("Payment Address Re-Generated Successfully");
      window.top.location.href='fundHistoryDetails?orderId=<?=$orderId?>';
    </script>
  <?php } } ?>
<?php include("../close-connection.php"); ?>