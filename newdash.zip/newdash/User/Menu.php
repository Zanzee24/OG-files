<script type="3ba1fef3e0959c9c5b03dcd0-text/javascript">
        document.getElementById("search_mobile").addEventListener("click", function() {
  document.getElementById("form").classList.toggle("open");
});

    </script>
<style>
.tree_box {
background: #021d9780;
-webkit-box-shadow: 0 2px 28px rgb(0 0 0 / 10%);
box-shadow: 0 2px 28px rgb(0 0 0 / 10%);
border-radius: 14px;
padding: 18px;
display: flex;
place-content: space-between;
position: relative;
margin-bottom: 30px;
}

      .tree____ {
display: grid;
grid-template-columns: auto auto auto auto auto;
width: 100%;
}
      .tree____ .bx {
background: #0039ff;
width: 90%;
min-height: 60px;
margin: 8px;
display: flex;
place-content: center;
place-items: center;
              flex-direction: column;
              border-radius: 20px;
}
    .missed_alert{
                   border-radius: 20px;
    }
    .bx span {
   font-size: 18px;
    font-weight: 700;
}
      .aTag{
         text-decoration: none !important;
          color: white !important;
      }
      .bx.active {
        background: #4a40e1;
      }
.b_action {
display: flex;
flex-direction: column;
place-content: space-between;
place-items: center;
}

    .b_action h5 {
font-size: 30px;
font-weight: 900;
}
    .b_action button {
background: #4b00f9;
border: 0px;
padding: 12px 40px;
border-radius: 14px;
text-transform: uppercase;
font-weight: 700;
letter-spacing: 1px;
}

    @media(max-width:480px){
        .page-title {
    display: none;
}
        .box-static {
    /* max-width: 170px; */
    min-height: 102px;
        }
        .d-flex_one {
    flex-direction: row !important;
}
/*
        .np_mobile {
    padding: 0px 7px;
}
*/

        .bx.active {
    background: #4b00f9 !important;
}
        .tree____ .bx {
    background: #0039ff;
    padding: 10px;
    width: 95%;
    min-height: 97px;
}
        .bx span {
    font-size: 20px;
    font-weight: 900;
}
        .user_detail h4 {
    font-size: 20px;
    font-weight: 900;
    margin: 0;
    padding-bottom: 5px;
}
        .user_detail p {
    color: white;
    margin: 0px;
}
        .db_box .image {
    margin-right: 10px;
    margin-bottom: 3px !important;
}
        .box-static {
    margin-bottom: 12px;
}
        .box-static .box-data h4 {
    color: white;
    font-size: 20px;
    font-weight: 900;
}
        .user_detail {
    width: 100%;
   
}
    }

     a.setting {
    position: absolute;
    right: 33px;
    top: 26px;
}
.sing-font
{
  font-size: 17px !important;
}
.id-font{
  color: rgba(64,106,255,var(--tw-text-opacity)) !important;
font-weight: normal !important;
font-size: 1.25rem !important;
--tw-text-opacity: 1 !important;
font-family: Rubik !important;
}
  </style>
<style>
  .main_page {
      width: 100%;
      min-height: 190px;
      background-image: url(wallet_big_min.png);
      border-radius: 20px;
      padding: 16px 20px;
      background-position: right;
      background-repeat: no-repeat;
      background-size: 540px;
            background-color: #6a35f5;
  }

      .action_area a {
      background: #4b00fb;
      padding: 10px 26px;
      border-radius: 20px;
      text-decoration: none;
  }
      .action_area{
    padding-top:20px;
  }
  .main_page h4 {
      font-size: 40px;
      font-weight: 900;
      margin: 0px;
      padding-bottom: 10px;
  }
      .idsearch form .input-group {
      display: flex;
  }
      .idsearch {
      padding-bottom: 20px;
  }
      .content {
      padding: 20px 15px
  }
   .content h5 {
      font-size: 38px;
      font-weight: 900;
  }
      .box-title {
      font-size: 17px;
      font-weight: 700;
      color: white;
  }
      .idsearch form .input-group input[type=text] {
      margin-right: 40px;
      background: #18191a;
      border-radius: 20px;
      border: 0px;
      min-height: 44px;
  }
      .idsearch form .input-group input[type=submit] {
              border-radius: 20px;
      }
      .sing-font
      {
        font-size: 17px !important;
      }

      .icon_animate{
          width:38px;
          margin-right: 7px;
          animation: heartbeat 1.9s infinite;
      }

  @keyframes heartbeat
  {
    0%
    {
      transform: scale( .75 );
    }
    20%
    {
      transform: scale( 1 );
    }
    40%
    {
      transform: scale( .75 );
    }
    60%
    {
      transform: scale( 1 );
    }
    80%
    {
      transform: scale( .75 );
    }
    100%
    {
      transform: scale( .75 );
    }
  }

      svg.fill-current.text-dark-pink.w-5.h-5 {
      width: 30px;
      margin-right: 4px;
  }

  .bg-green-200 {
      background-color: rgba(44,255,78,.2);
      width: 30px;
      height: 30px;
      padding: 7px;
      margin-right: 10px;
  }
  .rounded-full {
      border-radius: 9999px;
  }
  .justify-center {
      justify-content: center;
  }
  .items-center {
      align-items: center;
  }
  .flex-shrink-0 {
      flex-shrink: 0;
  }

      .bg-white-100 {
      background: #181616;
      width: 30px;
      height: 30px;
      display: flex;
      place-content: center;
      margin-right: 10px;
  }

      .w-5 {
      width: 1.25rem;
  }

  .h-5 {
      height: 1.25rem;
  }
  </style>

<!-- //// SIDE BAR -->


<div class="page-container row-fluid container">

<div class="page-sidebar fixedscroll" style="border-radius: 5px;" >

<div class="page-sidebar-wrapper" id="main-menu-wrapper">
<ul class='wraplist'>
<li class='menusection'>Main</li>
<li class="open">
<a href="index.php">
<i class="fa fa-th-large"></i>
<span class="title">Dashboard</span>
</a>
</li>

<li class="">
<a href="profile.php">
<i class="fa fa-user"></i>
<span class="title">Update Profile</span>
</a>
</li>


<li class="">
<a href="partners.php">
<i class="fa fa-users"></i>
<span class="title">Partners</span>
</a>
</li>
<li class="">
<a href="stats.php">
<i class="fa fa-crosshairs"></i>
<span class="title">Stats</span>
</a>
</li>
<li class="">
<a href="information.php">
<i class="fa fa-bookmark"></i>
<span class="title">Information</span>
</a>
</li>


<li class="">
<a href="composeMail.php">
<i class="fa fa-support"></i>
<span class="title">Support</span>
</a>
</li>


<!-- <li class="">
<a href="amazing_members.php">
<i class="fa fa-star"></i>
<span class="title">Amazing Members</span>
</a>
</li> -->

<li class="">
<a href="royalty_members.php">
<i class="fa fa-trophy"></i>
<span class="title">Royalty Members</span>
</a>
</li>

<li class="">
<a href="#">
<i class="fa fa-sign-out"></i>
<span class="title">Logout</span>
</a>
</li>

</ul>
</div>

</div>