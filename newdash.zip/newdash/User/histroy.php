<!DOCTYPE html>
<html lang="en">
<?php
require_once ('loginCheck.php');
require_once ('Include/Head.php');
require_once ('Include/Header.php');
require_once ('Include/Menu.php');

date_default_timezone_set('Asia/Kolkata');

// Default values
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : '';
$from_date = isset($_GET['from_date']) ? $_GET['from_date'] : date('d-m-Y');
$to_date = isset($_GET['to_date']) ? $_GET['to_date'] : date('d-m-Y');

$from_date_sql = date('Y-m-d', strtotime($from_date));
$to_date_sql = date('Y-m-d', strtotime($to_date));
?>
<head>
  <title>Transaction History</title>

  <!-- jQuery + jQuery UI for Datepicker -->
  <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>

  <style>
    .badge-success { background-color: #28a745; color: white; padding: 5px; }
    .badge-danger { background-color: #dc3545; color: white; padding: 5px; }
  </style>
</head>
        
<body class="bg-theme">    <!-- Wrapper -->
    <div class="wrapper">
        <!-- Page Content -->
        <div class="page-wrapper">
            <div class="page-content-wrapper">
                <div class="page-content">

                    <!-- Breadcrumb -->
                    <div class="page-breadcrumb d-none d-md-flex align-items-center mb-3">
                        <div class="breadcrumb-title pr-3">Tables</div>
                    </div>

                    <!-- DataTable Card -->
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title">
                                <h4 class="mb-0">DataTable Import</h4>
                            </div>
                            <hr/>

                            <!-- DataTable Buttons & Search -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <!-- Buttons will be auto-injected here -->
                                </div>
                                <div class="col-md-6 text-right">
                                    <div id="example2_filter" class="dataTables_filter">
                                        <label>Search:
                                            <input type="search" class="form-control form-control-sm" placeholder="" aria-controls="example2">
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <!-- Table -->
                            <div class="table-responsive">
                                <table id="example2" class="table table-striped table-bordered" style="width:100%">
                                     <thead>
                      <tr>
                        <th>#</th>
                        <th>User ID</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Income Type</th>
                        <th>Transaction Type</th>
                        <th>Remark</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
$query = "SELECT b.user_id, a.date_time, a.amount, a.deb_cr, c.statement_type, c.wallet_remark
                                FROM meddolic_user_wallet_statement a
                                JOIN meddolic_user_details b ON a.member_id = b.member_id
                                JOIN meddolic_config_wallet_statement_type c ON a.wallet_statement_id = c.wallet_statement_id
                                WHERE DATE(a.date_time) BETWEEN '$from_date_sql' AND '$to_date_sql'";

if (!empty($user_id)) {
    $safe_user_id = mysqli_real_escape_string($con, $user_id);
    $query .= " AND b.user_id = '$safe_user_id'";
}

$query .= ' ORDER BY a.date_time DESC';

$result = mysqli_query($con, $query);
$count = 0;

while ($row = mysqli_fetch_assoc($result)) {
    $count++;
    $is_credit = ($row['deb_cr'] == 2);
    ?>
                          <tr>
                            <td><?= $count ?></td>
                            <td><?= htmlspecialchars($row['user_id']) ?></td>
                            <td>
                              <span class="badge <?= $is_credit ? 'badge-success' : 'badge-danger' ?>">
                                <?= $row['amount'] ?> $
                              </span>
                            </td>
                            <td><i class="fa fa-clock-o"></i> <?= date('d-m-Y H:i:s', strtotime($row['date_time'])) ?></td>
                            <td><?= htmlspecialchars($row['statement_type']) ?></td>
                            <td>
                              <span class="badge <?= $is_credit ? 'badge-success' : 'badge-danger' ?>">
                                <?= $is_credit ? 'Credit' : 'Debit' ?>
                              </span>
                            </td>
                            <td><?= htmlspecialchars($row['wallet_remark']) ?></td>
                          </tr>
                          <?php
}
?>
                    </tbody>
                                    
                                </table>
                            </div>
                        </div>
                    </div>

                </div> <!-- end .page-content -->
            </div> <!-- end .page-content-wrapper -->
        </div> <!-- end .page-wrapper -->

        <!-- Overlay -->
        <div class="overlay toggle-btn-mobile"></div>

        <!-- Back To Top Button -->
        <a href="javascript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>

        <!-- Footer -->
        <div class="footer">
            <p class="mb-0">Billionaire Club @2020 | Developed By : 
                <a href="" target="_blank">Billionaire Club</a>
            </p>
        </div>
    </div> <!-- end wrapper -->

    <!-- Switcher -->
    <div class="switcher-wrapper">
        <div class="switcher-btn"><i class='bx bx-cog bx-spin'></i></div>
        <div class="switcher-body">
            <h5 class="mb-0 text-uppercase">Theme Customizer</h5>
            <hr/>
            <p class="mb-0">Gaussian Texture</p>
            <hr>
            <ul class="switcher">
                <li id="theme1"></li>
                <li id="theme2"></li>
                <li id="theme3"></li>
                <li id="theme4"></li>
                <li id="theme5"></li>
                <li id="theme6"></li>
            </ul>
            <hr>
            <p class="mb-0">Gradient Background</p>
            <hr>
            <ul class="switcher">
                <li id="theme7"></li>
                <li id="theme8"></li>
                <li id="theme9"></li>
                <li id="theme10"></li>
                <li id="theme11"></li>
                <li id="theme12"></li>
            </ul>
        </div>
    </div>

    <!-- JS Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>

    <!-- DataTables JS -->
    <script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.colVis.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

    <!-- App JS -->
    <script src="assets/js/app.js"></script>

    <!-- Initialize DataTable -->
    <script>
        $(document).ready(function() {
            var table = $('#example2').DataTable({
                dom: 'Bfrtip',
                buttons: ['copy', 'excel', 'pdf', 'print', 'colvis'],
                pageLength: 10
            });
            table.buttons().container().appendTo('.col-md-6:eq(0)');
        });
    </script>
</body>

</html>
 