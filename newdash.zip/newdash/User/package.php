<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1">

<?php
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>


<body>


    <!-- PAGE -->
    <div class="page">

        <!-- MAIN-CONTENT -->

        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <!-- Start:: row-1 -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card custom-card">
                            <div class="top-left"></div>
                            <div class="top-right"></div>
                            <div class="bottom-left"></div>
                            <div class="bottom-right"></div>
                            <div class="card-body">
                                <h2>Activation</h2>
                                <div class="d-sm-flex flex-wrap align-items-start gap-5 p-2 border-bottom-0">
                                    <form class="row g-3 mt-0">
                                        <div class="col-md-6">
                                            <label class="form-label">UserId </label>
                                            <input type="text" class="form-control" placeholder="ZT12414"
                                                aria-label="First name">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label"> Name</label>
                                            <input type="text" class="form-control" placeholder="Ansdfd"
                                                aria-label="Last name">
                                        </div>
                                        <div class="col-md-6">
                                            <label>Fund Wallet </label>
                                                        <input type="text" name="fundWallet" class="form-control">
                                        </div>
                                       
                                        <div class="col-md-4">
                                            <label for="inputState" class="form-label">Select Package *</label>
                                            <select id="inputState" class="form-select">
                                                <option selected>Choose...</option>
                                                <option>...</option>
                                            </select>
                                        </div>
                                        
                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" id="gridCheck3">
                                                <label class="form-check-label" for="gridCheck3">
                                                    Check me out
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary">Active Now</button>
                                        </div>
                                    </form>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>




                <?php include 'Include/footer.php'; ?>

</body>

</html><!-- This code use for render base file -->