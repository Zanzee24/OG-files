<?php
include("loginCheck.php");

if (isset($_POST['walletWithdraw'])) {
	$memberId = $_POST['memberId'];
	$withdraw_amount = $_POST['withdrawAmount'];
	// $minimumPayout=$_POST['minimumWithdraw'];
	$trnPassword = $_POST['trnPassword'];
	$paymentId = $_POST['paymentId'];
	$upiId = $_POST['upiId'];


	$d = date("Y-m-d H:i:s");
	$todayDate = date('Y-m-d');

	$query = mysqli_query($con, "SELECT topup_flag FROM meddolic_user_details WHERE member_id='$memberId'");
	$val = mysqli_fetch_array($query);

	if ($val[0] == 0) { ?>
		<script>
			alert("Your account is not Active.");
			history.go(-1);
		</script>
	<?php
		exit;
	}
	$otp = $_POST['otp'];
	$sessionOtp = $_SESSION['withdrawal_otp'];

	// Remove it from session
	unset($_SESSION['withdrawal_otp']);

	if ($otp != $sessionOtp) { ?>
		<script>
			alert("Incorrect OTP");
			history.go(-1);
		</script>
	<?php
		exit;
	}


	$result = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_wallet_withdrawal_crypto WHERE member_id='$memberId' AND CAST(withdrawal_date AS date)='$todayDate' AND (released=1 OR released=0)");
	$val = mysqli_fetch_array($result);
	if ($val[0] >= 10) { ?>
		<script>
			alert("The Maximun Withdraw Limit Reached today");
			history.go(-1);
		</script>
	<?php
		exit;
	}

	$queryWallet = mysqli_query($con, "SELECT wallet FROM meddolic_user_details WHERE member_id='$memberId'");
	$valWallet = mysqli_fetch_array($queryWallet);
	$currentWallet = $valWallet[0];
	if ($currentWallet < $withdraw_amount) { ?>
		<script>
			alert("Insufficient Balance in Your Wallet To Withdraw");
			history.go(-1);
		</script>
	<?php
		exit;
	}


	$queryCheck = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where trnPassword='$trnPassword'");
	$valCheck = mysqli_fetch_array($queryCheck);
	if ($valCheck[0] == 0) { ?>
		<script>
			alert("Incorrect Transaction Password!!!");
			history.go(-1);
		</script>
	<?php
		exit;
	}
	$orderId = rand(11101, 99999) . date('s') . date('h');

	$queryConfig = mysqli_query($con, "SELECT withdrawCharge FROM meddolic_config_misc_setting");
	$valConfig = mysqli_fetch_assoc($queryConfig);
	$withdrawCharge = $valConfig['withdrawCharge'];

	$Charge = $withdraw_amount * $withdrawCharge / 100;
	$netAmount = $withdraw_amount - $Charge;

	$queryIn = mysqli_query($con, "INSERT INTO meddolic_user_wallet_withdrawal_crypto (`member_id`,`payout_date`,`date_time`,`withdrawCharge`,`amount`,`netAmount`,`orderid`,`paymentId`,`upiId`) VALUES ('$memberId','$todayDate','$d','$withdrawCharge','$withdraw_amount','$netAmount','$orderId','$paymentId','$upiId')");
	$lastWithdraw = $con->insert_id;

	mysqli_query($con, "UPDATE meddolic_user_details SET wallet=wallet-'$withdraw_amount' WHERE member_id='$memberId'");

	mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`,`date_time`,`trn_id`) VALUES ('$memberId',11,1,'$withdraw_amount','$d','$lastWithdraw')"); ?>
	<script>
		alert("Wallet Withdraw Successfully");
		window.top.location.href = "walletWithdraw";
	</script>
<?php } ?>
<?php include("../close-connection.php"); ?>