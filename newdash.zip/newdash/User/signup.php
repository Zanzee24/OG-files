<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-toggled="close" data-vertical-style="default" data-card-style="style1" data-card-background="background1">

<?php
require_once('Include/Head.php');
?>

<body class="bg-white">



    <div class="row authentication mx-0">
        <div class="col-xxl-6 col-xl-6 col-lg-7 d-xl-block d-none px-0">
            <div class="authentication-cover bg-primary">
                <div class="authentication-cover-image">
                    <div class="text-start">
                        <h1 class="text-fixed-white mb-1 fw-medium">Welcome!</h1>
                        <p class="text-fixed-white mb-1">Let's get Started with our product just sign up with simple process and make your requirements .There are many variations of passages of Lorem Ipsum available.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-6 col-xl-6 col-lg-12">
            <div class="row justify-content-center align-items-center h-100">
                <div class="col-xxl-6 col-xl-9 col-lg-6 col-md-6 col-sm-8 col-12">
                    <div class="card custom-card shadow-none my-4">
                        <div class="top-left"></div>
                        <div class="top-right"></div>
                        <div class="bottom-left"></div>
                        <div class="bottom-right"></div>
                        <div class="card-body p-5">
                            <div class="mb-3 d-flex justify-content-center">
                                <a href="index.php">
                                    <img src="assets/assets/images/brand-logos/logo.png" alt="logo" class="desktop-dark " style="width: 100px; height: 100px;">
                                </a>
                            </div>
                            <p class="h5 mb-2 text-center">Sign Up</p>
                            <p class="mb-4 text-muted op-7 fw-normal text-center fs-14">Welcome! Begin by creating your account.</p>

                            <div class="text-center my-3 authentication-barrier">
                                <span>OR</span>
                            </div>
                            <div class="row gy-3">

                                    <div class="form-group">
                                        <label for="sponser_id">Sponsor ID</label>
                                        <input class="form-control" name="sponser_id1" disabled value="">
                                        <input type="hidden" name="sponser_id" value="">
                                    </div>
                                    <div class="form-group">
                                        <label for="sponsorName">Sponsor Name</label>
                                        <input class="form-control" disabled value="" placeholder="Sponsor Name">
                                    </div>

                                   
                                    <div class="form-group">
                                        <label for="name">Full Name</label>
                                        <input type="text" class="form-control" placeholder="Enter your Name" name="name" required>
                                        <input type="hidden" name="goodFile" value="<?= $newToken ?>">
                                    </div>

                                    <div class="form-group">
                                        <label for="emailId">Email</label>
                                        <input type="email" class="form-control" placeholder="Enter your Email" name="emailId" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="legPosition">Select Country</label>
                                        <select class="form-control" required id="M_COUNTRY" name="countryId" style="height:50px;width: 101%;">
                                            <option value="">Select Country</option>

                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Mobile Number</label>
                                        <input type="number" class="form-control" placeholder="Enter your Mobile Number" name="phone" required>
                                    </div>
                                    


                                    <div class="form-check mt-3">
                                        <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                                        <label class="form-check-label text-muted fw-normal fs-14" for="defaultCheck1">
                                            By creating a account you agree to our <a href="" class="text-success"><u>Terms & Conditions</u></a> and <a class="text-success"><u>Privacy Policy</u></a>
                                        </label>
                                    </div>
                                    
                            
                        </div>
                        <div class="d-grid mt-4">
                            <button class="btn btn-primary">Create Account</button>
                        </div>
                        <div class="text-center">
                            <p class="text-muted mt-3 mb-0">Already have an account? <a href="login.php" class="text-primary">Sign In</a></p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>


    <!-- SCRIPTS -->

    <!-- BOOTSTRAP JS -->
    <script src="https://php.spruko.com/scifi/scifi/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Swiper JS -->
    <script src="https://php.spruko.com/scifi/scifi/assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- Internal Authentication JS -->
    <script src="https://php.spruko.com/scifi/scifi/assets/js/authentication.js"></script>

    <!-- Show Password JS -->
    <script src="https://php.spruko.com/scifi/scifi/assets/js/show-password.js"></script>


    <!-- END SCRIPTS -->

</body>

</html>

<!-- This code use for render base file -->