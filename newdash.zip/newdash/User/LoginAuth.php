
<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
	<title>Billionaire Club</title>
	<!--favicon-->
	<link rel="icon" href="assets/favicon.png" type="image/png" />
	<!-- loader-->
	<link href="assets/assets/css/pace.min.css" rel="stylesheet" />
	<script src="assets/assets/js/pace.min.js"></script>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="assets/assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600&family=Roboto&display=swap" />
	<!-- Icons CSS -->
	<link rel="stylesheet" href="assets/assets/css/icons.css" />
	<!-- App CSS -->
	<link rel="stylesheet" href="assets/assets/css/app.css" />
</head>

<body class="bg-theme bg-theme1">
	<!-- wrapper -->
	<div class="wrapper">
  <div class="section-authentication-login d-flex align-items-center justify-content-center">
    <div class="row">
      <div class="col-12 col-lg-10 mx-auto">
        <div class="card radius-15">
          <div class="row no-gutters">
            <!-- Left side (Form) -->
            <div class="col-lg-6">
              <div class="card-body p-md-5">
                <div class="text-center">
                  <img src="assets/img/logo.png" width="80" alt="Logo">
                  <h3 class="mt-4 font-weight-bold">Welcome Back</h3>
                </div>

                <!-- Google Login Button -->
                <!-- <div class="input-group shadow-sm rounded mt-5">
                  <div class="input-group-prepend">
                    <span class="input-group-text cursor-pointer"><i class='bx bxl-google'></i></span>
                  </div>
                  <input type="button" class="form-control" value="Log in with Google">
                </div> -->

                <!-- Separator -->
                <div class="login-separater text-center">
                  <span> LOGIN</span>
                  <hr />
                </div>

                <!-- Login Form -->
                <form method="post" action="con-login">
                  <!-- User ID Field -->
                  <div class="form-group mt-4">
                    <input 
                      type="text" 
                      class="form-control" 
                      id="inputUserId" 
                      name="login[userid]" 
                      placeholder="User ID" 
                      required
                      value="<?php if(isset($_COOKIE['memberUserId'])) { echo htmlspecialchars($_COOKIE['memberUserId']); } ?>">
                  </div>

                  <!-- Password Field -->
                  <div class="form-group">
                    <input 
                      type="password" 
                      class="form-control" 
                      name="login[password]" 
                      id="inputPassword" 
                      placeholder="Enter Password" 
                      required
                      onkeypress="return catchEnter(event)"
                      value="<?php if(isset($_COOKIE['memberPassKey'])) { echo htmlspecialchars($_COOKIE['memberPassKey']); } ?>">
                    <p class="tx-success tx-12 d-block mg-t-10">
                      Forgot Password? <a href="authPassRecovery.php">Click Here..!</a>
                    </p>
                  </div>

                  <!-- Submit Buttons -->
                  <button type="button" class="btn btn-warning btn-block" id="loginSubmit" onclick="LoginValidate()">Sign In</button>
                  <button type="button" disabled style="display: none;" class="btn btn-warning btn-block w-100 loadingMore">Validating Data...</button>
                </form>

                <hr>

                <!-- Sign Up Link -->
                <div class="text-center">
                  <p class="mb-0">Don't have an account? <a href="../authUserRegister.php">Sign up</a></p>
                </div>
              </div>
            </div>

            <!-- Right side (Image) -->
            <div class="col-lg-6">
              <img src="assets/assets/images/login-frent-img.jpg" class="card-img login-img h-100" alt="Login Image">
            </div>
          </div> <!-- end row -->
        </div>
      </div>
    </div>
  </div>
</div>
 <script src="assets/f1/lib/jquery/jquery.js"></script>
    <script src="assets/f1/lib/popper.js/popper.js"></script>
    <script src="assets/f1/lib/bootstrap/bootstrap.js"></script>
    <script src="custom.js"></script>
	<!-- end wrapper -->
</body>

