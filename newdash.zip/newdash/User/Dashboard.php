
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
<?php
$todayDate = date('Y-m-d');
$d = date('Y-m-d H:i:s');
$queryGe = mysqli_query($con, "SELECT member_id,wallet,topup_flag,activation_date,fundWallet,date_time,sponser_id FROM meddolic_user_details WHERE user_id='$userId'");
$valGe = mysqli_fetch_assoc($queryGe);
$memberId = $valGe['member_id'];
$incomeWallet = $valGe['wallet'];
$topupFlag = $valGe['topup_flag'];
$fundWallet = $valGe['fundWallet'];
$activationDate = $valGe['activation_date'];
$joinDate = $valGe['date_time'];
$sponser_id = $valGe['sponser_id'];

if ($topupFlag == 1) {
    $queryRank = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'  AND investStatus=1 ORDER BY investAmount DESC LIMIT 1");
    $valRank = mysqli_fetch_array($queryRank);
    $investPrice = $valRank[0];
} else {
    $investPrice = 'NA';
}

$querySponser = mysqli_query($con, "SELECT user_id FROM meddolic_user_details WHERE member_id='$sponser_id'");
$valSponser = mysqli_fetch_array($querySponser);
$Sponser = $valSponser['user_id'];
$querySponser = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE sponser_id='$memberId'");
$valSponser = mysqli_fetch_array($querySponser);
$totalSponser = $valSponser[0];

$queryReferral = mysqli_query($con, "SELECT SUM(referralIncome) FROM meddolic_user_sponsor_income WHERE memberId='$memberId'");
$valReferral = mysqli_fetch_array($queryReferral);
$referralIncome = $valReferral[0];

$queryLevel = mysqli_query($con, "SELECT SUM(levelIncome) FROM meddolic_user_level_income WHERE memberId='$memberId'");
$valLevel = mysqli_fetch_array($queryLevel);
$levelIncome = $valLevel[0];

$queryRoyalty = mysqli_query($con, "SELECT SUM(royaltyIncome) FROM meddolic_user_royalty_income WHERE memberId='$memberId' AND royaltyStatus=1");
$valRoyalty = mysqli_fetch_array($queryRoyalty);
$royaltyIncome = $valRoyalty[0];

$querycto = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_cto_transfer_history WHERE receiver_member_id='$memberId' AND status=1");
$valcto = mysqli_fetch_array($querycto);
$ctoIncome = $valcto[0];

$queryRoyalcto = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_royal_cto_transfer_history WHERE receiver_member_id='$memberId' AND status=1");
$valRoyalcto = mysqli_fetch_array($queryRoyalcto);
$royalctoIncome = $valRoyalcto[0];

$queryRoi = mysqli_query($con, "SELECT SUM(cashbackIncome) FROM meddolic_user_invest_income WHERE memberId='$memberId' AND status=1");
$valRoi = mysqli_fetch_array($queryRoi);
$roiIncome = $valRoi[0];

// $queryReward = mysqli_query($con, "SELECT SUM(rewardIncome) FROM meddolic_user_invest_income WHERE memberId='$memberId'AND status=1");
// $valReward = mysqli_fetch_array($queryReward);
// $rewardIncome = $valReward[0];

$queryAutopool = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_matrix_income_release2 WHERE member_Id='$memberId'AND status=1");
$valAutopool = mysqli_fetch_array($queryAutopool);
$autopoolIncome1 = $valAutopool[0];

$queryAutopool = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_matrix_income_release3 WHERE member_Id='$memberId'AND status=1");
$valAutopool = mysqli_fetch_array($queryAutopool);
$autopoolIncome3 = $valAutopool[0];

$queryAutopool = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_matrix_income_release4 WHERE member_Id='$memberId'AND status=1");
$valAutopool = mysqli_fetch_array($queryAutopool);
$autopoolIncome4 = $valAutopool[0];

$totalIncome = $referralIncome + $levelIncome + $rewardIncome ;

$queryWithdraw = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_wallet_withdrawal_crypto WHERE member_id='$memberId' AND (released=1 OR released=0)");
$valWithdraw = mysqli_fetch_array($queryWithdraw);
$totalWithdraw = $valWithdraw[0];

$queryTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND level<=10");
$valTeam = mysqli_fetch_array($queryTeam);
$totalTeam = $valTeam[0];

$queryDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=1");
$valDirect = mysqli_fetch_array($queryDirect);
$activeSponser = $valDirect[0];

$queryInDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=0");
$valInDirect = mysqli_fetch_array($queryInDirect);
$inActiveSponser = $valInDirect[0];

$queryActveTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=1 AND level<=10");
$valActveTeam = mysqli_fetch_array($queryActveTeam);
$activeTeam = $valActveTeam[0];

$queryInActiveTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=0 AND level<=10");
$valInActiveTeam = mysqli_fetch_array($queryInActiveTeam);
$inActiveTeam = $valInActiveTeam[0];

$queryNews = mysqli_query($con, "SELECT news,newStatus FROM meddolic_config_news_list WHERE newsId=1");
$valNews = mysqli_fetch_assoc($queryNews);

$queryTotalBusiness = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId  IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$memberId')");
$valTotalBusiness = mysqli_fetch_array($queryTotalBusiness);
$totalBusiness = $valTotalBusiness[0];


$queryTotalCapping = mysqli_query($con, " SELECT SUM(returnCap * totalInvest) AS totalCapping FROM meddolic_user_invest_summary WHERE memberId = '$memberId'");
$valTotalCapping = mysqli_fetch_array($queryTotalCapping);
$totalCapping = $valTotalCapping[0];

$queryTotalInvest = mysqli_query($con, " SELECT SUM(totalInvest) AS totalInvest FROM meddolic_user_invest_summary WHERE memberId = '$memberId'");
$valTotalInvest = mysqli_fetch_array($queryTotalInvest);
$totalInvest = $valTotalInvest[0];

$RemainingCapping = $totalCapping - $totalIncome;


$primaryBus = 0;
$secondaryBus = 0;

$queryBus = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE sponser_id='$memberId' ORDER BY activation_date ASC");
while ($valDirect = mysqli_fetch_assoc($queryBus)) {
    $directId = $valDirect['member_id'];

    $querySelf = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$directId'");
    $valSelf = mysqli_fetch_array($querySelf);

    $queryDown = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$directId' AND topup_status=1)");
    $valDown = mysqli_fetch_array($queryDown);
    $netBusiness = $valSelf[0] + $valDown[0];
    $totalBus += $netBusiness;
    $items[] = $netBusiness;
}
if ($items) {
    $primaryBus = max($items);
    $secondaryBus = $totalBus - $primaryBus;
}
?>
</head>
<body class="bg-theme">
    <!-- wrapper -->
    <section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h1 class="title">Dashboard</h1>

                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <section class="box nobox marginBottom0">
                <div class="content-body">
                    <div class="row">
                        <div class="col-lg-5 col-sm-6 col-xs-12">
                            <div class="d-flex r5_counter db_box has-gradient-to-right-bottom d-flex_one">
                                <div class="image">
                                    <img src="assets/img/logo.png" alt="user-image" class="img-circle img-inline user_dummy">
                                </div>
                                <div class="user_detail">
                                    <h4><?= $userId ?></h4>
                                    <p>Name: <span><?= $userName ?></span></p>                                    
                                    <p>Email Id:
                                        <span><?= $emailId ?></span>
                                    </p>
                                    <p>Sponser Id:
                                        <span><?= $Sponser ?></span>
                                    </p>
                                    <p>Package:
                                        <span><?= $investPrice ?></span>
                                    </p>
                                    <p >Status:
                    
                        <?php if ($topupFlag == 1): ?>
                            <span class="badge rounded-pill bg-success px-3 py-2">ACTIVE</span>
                        <?php else: ?>
                            <span class="badge rounded-pill bg-danger px-3 py-2">IN-ACTIVE</span>
                        <?php endif; ?>
                        </p>
                                    <p>Activation At:
                                        <span><?= $activationDate ?></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <style>
                            .clipboard2 {
                                color: #204ff5;
                                width: 90%;
                                font-size: 1.5rem;
                                font-weight: 700;
                            }

                            .wallet_logo {
                                width: 150px;
                                opacity: 10%;
                                filter: grayscale(100%);
                            }

                            @media (max-width: 470px) {
                                .clipboard2 {
                                    color: #204ff5;
                                    width: 100%;
                                    font-size: 1.2rem;
                                    font-weight: 500;
                                }

                                .wallet_logo {
                                    width: 100%;
                                }


                            }
                        </style>
                        <div class="col-lg-7 col-sm-6 col-xs-12">
                            <div class="r5_counter db_box has-gradient-to-right-bottom">
                                <h5 class="box-title">Personal link</h5>
                                <span>
                                   <input type="text" value="https://billionaireclub.world/authUserRegister?affiliateCode=<?= $userId ?>" class="clipboard2 black_inp"> <a href="javascript:void(0);" onclick="copyLink('https://billionaireclub.world/authUserRegister?affiliateCode=<?= $userId ?>');"><i class="fa fa-copy text-dark"></i></a>
                                </span>
                                
                                <div class="stats d-flex place-content-around border-top">
                                    <span>Share your referral link.
                                </span> <a href="https://billionaireclub.world/authUserRegister?affiliateCode=<?= $userId ?>" class="link_btn">Copy or Share</a>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                        <style>
                            .box-static.width-full .chart__ {
                                overflow: hidden;
                            }


                            .box-static.width-full svg {
                                position: absolute;
                                right: 0;
                                bottom: -50px;
                            }

                            .box-static.width-full .chart__ {
                                overflow: hidden;
                                position: absolute;
                                width: 200px;
                                height: 200px;
                                bottom: 0;
                                right: 0;
                                border-radius: 9%;
                            }

                            .box-static.width-full .chart-img {
                                overflow: hidden;
                                position: absolute;
                               
                                bottom: 5px;
                                right: 0;
                                border-radius: 9%;
                                padding: 10px;
                            }

                            .box-static.width-full {
                                place-items: baseline;
                                padding-left: 20px;
                                position: relative;
                            }


                            .status-complete {
                                border: 1px solid #fff;
                                border-radius: 12px;
                                padding: 4px;
                                font-size: 13px;
                                background:linear-gradient(to right, #25caf3, #d5193c);
                                color: white;
                                white-space: nowrap;
                            }
                        </style>
                        <div class="col-lg-6 col-md-6 col-xs-12">
                            <div class="box-static width-full">
                                <div class="leftt">
                                    <div class="box-title">Total Fund &nbsp <div class="mytooltip">
                                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                                            <span class="tooltiptextright">Total amount received to your wallet </span>
                                        </div>
                                    </div>
                                    <div class="box-data">
                                        <h4>
                                           <?= isset($incomeWallet) ? $incomeWallet : '0.00'; ?>
                                        </h4>
                                    </div>
                                    <!-- <div class="static">
                                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                                        0.00                                    </div> -->
                                </div>
                                <div class="chart__">
                                    <svg id="chart" width="200" height="200" viewBox="0 0 1000 500"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M 0,499.33900692746477 C 10.600000000000001,495.44416161425875 31.8,485.4117960071894 53,479.8647803614346 C 74.2,474.3177647156798 84.8,482.03389124844983 106,471.6039286986907 C 127.2,461.1739661489316 137.8,442.80768629492593 159,427.71496761263904 C 180.2,412.62224893035216 190.8,400.57257043454433 212,396.1403352872562 C 233.2,391.7081001399681 243.8,405.8055360232623 265,405.5537918761985 C 286.2,405.3020477291347 296.8,402.4704195018447 318,394.88161455193733 C 339.2,387.29280960203 349.8,380.01960887491043 371,367.6097671266617 C 392.2,355.199925378413 402.8,333.86736367141185 424,332.83240581069373 C 445.2,331.7974479499756 455.8,356.74234292272564 477,362.4349778230711 C 498.2,368.1276127234166 508.8,365.3311188344002 530,361.2955803124212 C 551.2,357.2600417904422 561.8,351.43069463479327 583,342.2572852131762 C 604.2,333.08387579155914 614.8,349.20144327135995 636,315.42853320433585 C 657.2,281.65562313731175 667.8,186.41232240492783 689,173.3927348780557 C 710.2,160.3731473511836 720.8,238.4361995056343 742,250.3305955699753 C 763.2,262.22499163431627 773.8,243.67790687892688 795,232.86471519976055 C 816.2,222.05152352059423 826.8,220.95441641395553 848,196.26463717414362 C 869.2,171.57485793433173 879.8,134.12486679178784 901,109.4158190007011 C 922.2,84.70677120961437 932.8,56.23286437564735 954,72.71939821871 C 975.2,89.20593206177264 996.4,168.02267021655348 1007,191.84848821601435,L 1000 500,L 0 500Z"
                                            fill="#444cf71a" />
                                        <path
                                            d="M 0,499.33900692746477 C 10.600000000000001,495.44416161425875 31.8,485.4117960071894 53,479.8647803614346 C 74.2,474.3177647156798 84.8,482.03389124844983 106,471.6039286986907 C 127.2,461.1739661489316 137.8,442.80768629492593 159,427.71496761263904 C 180.2,412.62224893035216 190.8,400.57257043454433 212,396.1403352872562 C 233.2,391.7081001399681 243.8,405.8055360232623 265,405.5537918761985 C 286.2,405.3020477291347 296.8,402.4704195018447 318,394.88161455193733 C 339.2,387.29280960203 349.8,380.01960887491043 371,367.6097671266617 C 392.2,355.199925378413 402.8,333.86736367141185 424,332.83240581069373 C 445.2,331.7974479499756 455.8,356.74234292272564 477,362.4349778230711 C 498.2,368.1276127234166 508.8,365.3311188344002 530,361.2955803124212 C 551.2,357.2600417904422 561.8,351.43069463479327 583,342.2572852131762 C 604.2,333.08387579155914 614.8,349.20144327135995 636,315.42853320433585 C 657.2,281.65562313731175 667.8,186.41232240492783 689,173.3927348780557 C 710.2,160.3731473511836 720.8,238.4361995056343 742,250.3305955699753 C 763.2,262.22499163431627 773.8,243.67790687892688 795,232.86471519976055 C 816.2,222.05152352059423 826.8,220.95441641395553 848,196.26463717414362 C 869.2,171.57485793433173 879.8,134.12486679178784 901,109.4158190007011 C 922.2,84.70677120961437 932.8,56.23286437564735 954,72.71939821871 C 975.2,89.20593206177264 996.4,168.02267021655348 1007,191.84848821601435"
                                            fill="none" stroke="#444cf7" stroke-width="4px" />
                                        <g>
                                        </g>
                                    </svg>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-xs-6 np_mobile">
                            <div class="box-static">
                                <div class="box-title">Active <br>User &nbsp
                                    <div class="mytooltip"><i class="fa fa-question-circle" aria-hidden="true"></i>
                                        <span class="tooltiptextleft">Total user of your referral active </span>
                                    </div>
                                </div>
                                <div class="box-data">
                                    <h4><?= isset($activeSponser) ? $activeSponser : '00'; ?></h4>
                                </div>
                                <div class="static">
                                    <i class="fa fa-long-arrow-up" aria-hidden="true"></i> 0                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-3 col-xs-6 np_mobile">
                            <div class="box-static">
                                <div class="box-title">Non-Active <br>Users &nbsp
                                    <div class="mytooltip"><i class="fa fa-question-circle" aria-hidden="true"></i>
                                        <span class="tooltiptext">Total number of your referral user non-active</span>
                                    </div>
                                </div>
                                <div class="box-data">
                                    <h4><?= isset($inActiveSponser) ? $inActiveSponser : '00'; ?></h4>
                                </div>
                                <div class="static">
                                    <i class="fa fa-long-arrow-up" aria-hidden="true"></i> 0                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-2 col-xs-12   " style="display:block">
                            <div class="box-static">
                                <div class="box-title">Total <br>Users &nbsp
                                    <div class="mytooltip"><i class="fa fa-question-circle" aria-hidden="true"></i>
                                        <span class="tooltiptextleft">Total user of your referral</span>
                                    </div>
                                </div>
                                <div class="box-data">
                                    <h4><?= isset($totalSponser) ? $totalSponser : '00'; ?></h4>
                                        
                                </div>
                                <div class="static">
                                    <i class="fa fa-long-arrow-up" aria-hidden="true"></i> 0.0&nbsp;%
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class="clearfix"></div>


        
        <div class="row">
          <div class="col-md-5 col-sm-6 d1v"  >
 
                <div class="box-static width-full">
                    <div class="box-title">Total Earnings &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">Total earning of your all income </span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($totalIncome) ? $totalIncome : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
                
                <div class="box-static width-full">
                    <div class="box-title">Direct Income &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">Total income of you referral  </span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($referralIncome) ? $referralIncome : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
                <div class="box-static width-full">
                    <div class="box-title">Re-Topup Income &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">Total Re-topup income your </span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($referralIncome) ? $referralIncome : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
                <div class="box-static width-full">
                    <div class="box-title">Rank Reward &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">your rank and Achive reward </span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($rewardIncome) ? $rewardIncome : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
            </div>
            <div class="col-md-5 col-sm-6 d1v">
                <div class="box-static width-full">
                    <div class="box-title">Purchase Wallet &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">Total fund of you add by fund requste </span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($fundWallet) ? $fundWallet : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
                <div class="box-static width-full">
                    <div class="box-title">Total Withdrawal &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">Total number of you withdrawal</span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($totalWithdraw) ? $totalWithdraw : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
 
                <div class="box-static width-full">
                    <div class="box-title">Level Income &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">Total income of you achive levels </span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($levelIncome) ? $levelIncome : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
                <div class="box-static width-full">
                    <div class="box-title">Club Income &nbsp <div class="mytooltip">
                            <i class="fa fa-question-circle" aria-hidden="true"></i>
                            <span class="tooltiptextleft">Total income of your clubs </span>
                        </div>
                    </div>
                    <div class="box-data">
                        <h4><?= isset($levelIncome) ? $levelIncome : '0.00'; ?></h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0                    </div>
                </div>
            </div>
            <!-- <div class="col-md-11 d1v">
                <div class="box-static width-full">
                    <div class="box-title"><br><br>
                        Billionaire Club Package <br><br>
                    </div>
                    <div class="clipboard">
                        
                    <hr style="color:#ffffff">
                    <div class="box-title">
                        Activat New Package
                    </div>
                    <div class="box-data">
                        <h4>
                            250.00                        </h4>
                    </div>
                    <div class="static">
                        <i class="fa fa-long-arrow-up" aria-hidden="true"></i>
                        0.00                    </div>
                    <br><br>
                </div>
            </div> -->
        </div>

    </div>
</section>



<?php require_once('Include/Footer.php');?>


        
        
								    <!-- end wrapper -->
    <!--start switcher-->
    
    <!--end switcher-->
    <!-- JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/assets/js/jquery.min.js"></script>
    <script src="assets/assets/js/popper.min.js"></script>
    <script src="assets/assets/js/bootstrap.min.js"></script>
    <!--plugins-->
    <script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
    <script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
    <script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
    <!-- Vector map JavaScript -->
    <script src="assets/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="assets/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="assets/assets/plugins/vectormap/jquery-jvectormap-in-mill.js"></script>
    <script src="assets/assets/plugins/vectormap/jquery-jvectormap-us-aea-en.js"></script>
    <script src="assets/assets/plugins/vectormap/jquery-jvectormap-uk-mill-en.js"></script>
    <script src="assets/assets/plugins/vectormap/jquery-jvectormap-au-mill.js"></script>
    <script src="assets/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
    <script src="assets/assets/js/index.js"></script>
    <!-- App JS -->
    <script src="assets/assets/js/app.js"></script>
    <script>
        new PerfectScrollbar('.dashboard-social-list');
        new PerfectScrollbar('.dashboard-top-countries');
    </script>
</body>

<!-- <script>
    'undefined' === typeof _trfq || (window._trfq = []);
    'undefined' === typeof _trfd && (window._trfd = []), _trfd.push({
        'tccl.baseHost': 'secureserver.net'
    }, {
        'ap': 'cpsh-oh'
    }, {
        'server': 'p3plzcpnl509132'
    }, {
        'dcenter': 'p3'
    }, {
        'cp_id': '10399385'
    }, {
        'cp_cl': '8'
    }) // Monitoring performance to make your website faster. If you want to opt-out, please contact web hosting support.
</script>
<script src='https://img1.wsimg.com/traffic-assets/assets/js/tccl.min.js'></script> -->


</html>