<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
<?php
$todayDate = date('Y-m-d');
$d = date('Y-m-d H:i:s');
$queryGe = mysqli_query($con, "SELECT member_id,wallet,topup_flag,activation_date,fundWallet,date_time FROM meddolic_user_details WHERE user_id='$userId'");
$valGe = mysqli_fetch_assoc($queryGe);
$memberId = $valGe['member_id'];
$incomeWallet = $valGe['wallet'];
$topupFlag = $valGe['topup_flag'];
$fundWallet = $valGe['fundWallet'];
$activationDate = $valGe['activation_date'];
$joinDate = $valGe['date_time'];
// $sponser_id = $valGe['sponser_id'];

if ($topupFlag == 1) {
    $queryRank = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'  AND investStatus=1 ORDER BY investAmount DESC LIMIT 1");
    $valRank = mysqli_fetch_array($queryRank);
    $investPrice = $valRank[0];
} else {
    $investPrice = 'NA';
}

$querySponser = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE sponser_id='$memberId'");
$valSponser = mysqli_fetch_array($querySponser);
$totalSponser = $valSponser[0];

$queryReferral = mysqli_query($con, "SELECT SUM(referralIncome) FROM meddolic_user_sponsor_income WHERE memberId='$memberId'");
$valReferral = mysqli_fetch_array($queryReferral);
$referralIncome = $valReferral[0];

$queryLevel = mysqli_query($con, "SELECT SUM(levelIncome) FROM meddolic_user_level_income WHERE memberId='$memberId'");
$valLevel = mysqli_fetch_array($queryLevel);
$levelIncome = $valLevel[0];

$queryRoyalty = mysqli_query($con, "SELECT SUM(royaltyIncome) FROM meddolic_user_royalty_income WHERE memberId='$memberId' AND royaltyStatus=1");
$valRoyalty = mysqli_fetch_array($queryRoyalty);
$royaltyIncome = $valRoyalty[0];

$querycto = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_cto_transfer_history WHERE receiver_member_id='$memberId' AND status=1");
$valcto = mysqli_fetch_array($querycto);
$ctoIncome = $valcto[0];

$queryRoyalcto = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_royal_cto_transfer_history WHERE receiver_member_id='$memberId' AND status=1");
$valRoyalcto = mysqli_fetch_array($queryRoyalcto);
$royalctoIncome = $valRoyalcto[0];

$queryRoi = mysqli_query($con, "SELECT SUM(cashbackIncome) FROM meddolic_user_invest_income WHERE memberId='$memberId' AND status=1");
$valRoi = mysqli_fetch_array($queryRoi);
$roiIncome = $valRoi[0];

// $queryReward = mysqli_query($con, "SELECT SUM(rewardIncome) FROM meddolic_user_reward_income WHERE memberId='$memberId'");
// $valReward = mysqli_fetch_array($queryReward);
// $rewardIncome = $valReward[0];

$queryAutopool = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_matrix_income_release2 WHERE member_Id='$memberId'AND status=1");
$valAutopool = mysqli_fetch_array($queryAutopool);
$autopoolIncome1 = $valAutopool[0];

$queryAutopool = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_matrix_income_release3 WHERE member_Id='$memberId'AND status=1");
$valAutopool = mysqli_fetch_array($queryAutopool);
$autopoolIncome3 = $valAutopool[0];

$queryAutopool = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_matrix_income_release4 WHERE member_Id='$memberId'AND status=1");
$valAutopool = mysqli_fetch_array($queryAutopool);
$autopoolIncome4 = $valAutopool[0]; 

$totalIncome = $referralIncome + $levelIncome + $rewardIncome + $autopoolIncome1 + $autopoolIncome2 +$autopoolIncome3;

$queryWithdraw = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_wallet_withdrawal_crypto WHERE member_id='$memberId' AND (released=1 OR released=0)");
$valWithdraw = mysqli_fetch_array($queryWithdraw);
$totalWithdraw = $valWithdraw[0];

$queryTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND level<=10");
$valTeam = mysqli_fetch_array($queryTeam);
$totalTeam = $valTeam[0];

$queryDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=1");
$valDirect = mysqli_fetch_array($queryDirect);
$activeSponser = $valDirect[0];

$queryInDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=0");
$valInDirect = mysqli_fetch_array($queryInDirect);
$inActiveSponser = $valInDirect[0];

$queryActveTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=1 AND level<=10");
$valActveTeam = mysqli_fetch_array($queryActveTeam);
$activeTeam = $valActveTeam[0];

$queryInActiveTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=0 AND level<=10");
$valInActiveTeam = mysqli_fetch_array($queryInActiveTeam);
$inActiveTeam = $valInActiveTeam[0];

$queryNews = mysqli_query($con, "SELECT news,newStatus FROM meddolic_config_news_list WHERE newsId=1");
$valNews = mysqli_fetch_assoc($queryNews);

$queryTotalBusiness = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId  IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$memberId')");
$valTotalBusiness = mysqli_fetch_array($queryTotalBusiness);
$totalBusiness = $valTotalBusiness[0];


$queryTotalCapping = mysqli_query($con, " SELECT SUM(returnCap * totalInvest) AS totalCapping FROM meddolic_user_invest_summary WHERE memberId = '$memberId'");
$valTotalCapping = mysqli_fetch_array($queryTotalCapping);
$totalCapping = $valTotalCapping[0];

$queryTotalInvest = mysqli_query($con, " SELECT SUM(totalInvest) AS totalInvest FROM meddolic_user_invest_summary WHERE memberId = '$memberId'");
$valTotalInvest = mysqli_fetch_array($queryTotalInvest);
$totalInvest = $valTotalInvest[0];

$RemainingCapping = $totalCapping - $totalIncome;


$primaryBus = 0;
$secondaryBus = 0;

$queryBus = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE sponser_id='$memberId' ORDER BY activation_date ASC");
while ($valDirect = mysqli_fetch_assoc($queryBus)) {
    $directId = $valDirect['member_id'];

    $querySelf = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$directId'");
    $valSelf = mysqli_fetch_array($querySelf);

    $queryDown = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$directId' AND topup_status=1)");
    $valDown = mysqli_fetch_array($queryDown);
    $netBusiness = $valSelf[0] + $valDown[0];
    $totalBus += $netBusiness;
    $items[] = $netBusiness;
}
if ($items) {
    $primaryBus = max($items);
    $secondaryBus = $totalBus - $primaryBus;
}
?>
</head>

<body class="body-scroll" data-page="index">
    <?php require_once('Include/Menu.php');
    ?>
    <!-- Header -->
    <header class="header position-fixed">
        <div class="row">
            <div class="col-auto">
                <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
            </div>
            <!-- <img src="assets/favicon.png" alt=""> -->
        </div>
    </header>



    <style>
        .bg-theme,
        .modal-backdrop {
            background: linear-gradient(310deg, #3c63e2, #060542) !important;
            background: #fff;
        }

        .bg1-theme {
            background: linear-gradient(310deg, #3c63e2, #060542) !important;
            background: #fff;
        }

        .bg-opac11 {
            background-color: rgb(211 224 222) !important;
        }

        .theme-bg1 {
            background-color: #fff;
        }

        .bg-theme11 {
            background-color: #20bf55;
            background-image: linear-gradient(315deg, #20bf55 0%, #01baef 74%);
        }

        .bg-theme11 {
            background-color: #0080d8d6 !important;
        }

        .mySlides {
            display: none;
        }

        .slier img {
            height: 400px;
        }

        .slier {
            margin-bottom: 20px;
        }

        .im1 {
            WIDTH: 190PX;
            HEIGHT: AUTO;
        }

        .p1 {
            font-size: 18px !important;
            font-weight: bold;
        }

        @media(max-width:600px) {
            .lkjhgvb {
                font-size: 10px;
            }

            .slier img {
                height: 250px;
            }

            .im1 {
                WIDTH: 95px;
                HEIGHT: AUTO;
                margin-top: 27px;
                margin-left: -27px;
            }

            .p1 {
                font-size: 10px !important;
                font-weight: bold;
            }
        }

        .header:after {
            content: "";
            position: absolute;
            height: 100% !important;
            width: 100% !important;
            top: 0;
            left: 0;
            border-radius: 0 0 var(--finwallapp-rounded) var(--finwallapp-rounded);
            background:linear-gradient(310deg, #0dcaf0, #03222f);
            box-shadow: 0px 3px 10px rgb(0 0 0 / 10%);
            -moz-box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
            -webkt-box-shadow: 0px 3px 10px rgba(0, 0, 0, 0.1);
            z-index: 0;
            opacity: 0;
        }

        .avatar.avatar-60 {
            line-height: 60px;
            height: 45px;
            width: 45px;
        }

        .avatar.avatar-40 {
            line-height: 40px;
            height: 40px;
            width: 40px;
            margin-left: -18px;
        }

        .reff {
            border: solid 5px #00000045 !important;
            border-radius: 20px !important;
            box-shadow: 0 2px 5px rgb(0 0 0 / 10%) !important;
            padding: 0 !important;
            margin: 0 !important;

        }
    </style>
    <!-- Begin page -->
    <main style="min-height: 398px; padding-top: 5.7125px !important; padding-bottom: 120px; background: linear-gradient(310deg, #0dcaf0, #03222f);" >
        <!-- Header -->
        <header class="header position-fixed">
            <div class="row">
                <div class="col-auto">
                    <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                        <i class="bi bi-list"></i>
                    </a>
                </div>
                <div class="col text-right">
                    <div class="logo-small">
                        <img src="assets/img/logo.png" alt="" style=" height:50px; " />
                    </div>
                </div>

            </div>
        </header>
        <!-- main page content -->
        <!--<div class="main-container container">
           balance --
            <div class="slier">
			<div class="w3-content w3-section">
  <img class="mySlides" src="../Content/1.jpeg" style="width:100%">
  <img class="mySlides" src="../Content/2.jpg" style="width:100%">
  <img class="mySlides" src="./Content/3.jpg" style="width:100%">
</div>
<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>

			</div>-->

        <style>
            body {
                background: linear-gradient(310deg, #0dcaf0, #03222f);
                background-size: contain;
            }

            .bs-example {
                margin: 20px;
            }

            /* Some custom styles to beautify this example */

            .hide-modal {
                width: 250px;
                position: absolute;
                margin: 0 auto;
                right: 0;
                left: 0;
                bottom: 20px;
                z-index: 9999;
            }

            .navbar-brand {
                width: 100%;
            }

            @media only screen and (max-width: 992px) {
                .log {
                    width: 50%;
                    margin-top: 3%;
                    color: #fff;
                }
            }
        </style>


        <div class="content-wrapper">
            <div class="container-full">
                <!-- Content Header (Page header) -->
                <!-- Main content -->


               <section class="content">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-10">

                <!-- Row for side-by-side cards -->
                <div class="row g-4">

                    <!-- User Profile Card (Left) -->
                    <div class="col-12 col-md-12">
                        <div class="card shadow-sm h-100">
                            <div class="card-header  text-white">
                                <h5 class="mb-0">User Profile</h5>
                            </div>
                            <div class="card-body">

                                <!-- User Info -->
                                <div class="row mb-3">
                                    <div class="col-6 text-muted">User ID:</div>
                                    <div class="col-6 text-end"><?= $userId ?></div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6 text-muted">Name:</div>
                                    <div class="col-6 text-end"><?= $userName ?></div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6 text-muted">Email-ID:</div>
                                    <div class="col-6 text-end">
                                        <a href="mailto:<?= $emailId ?>" class="text-decoration-none"><?= $emailId ?></a>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6 text-muted">Package:</div>
                                    <div class="col-6 text-end">
                                        <span class="badge bg-success"><?= $investPrice ?></span>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6 text-muted">Status:</div>
                                    <div class="col-6 text-end">
                                        <?php if ($topupFlag == 1): ?>
                                            <span class="badge bg-success">ACTIVE</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">IN-ACTIVE</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6 text-muted">Sponsor ID:</div>
                                    <div class="col-6 text-end"><?= $sponser_id ?></div>
                                </div>
                                <div class="row">
                                    <div class="col-6 text-muted">Active Date:</div>
                                    <div class="col-6 text-end"><?= $activationDate ?></div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <!-- Account Scanner Card (Right) -->
                    <!-- <div class="col-12 col-md-4">
                        <div class="card shadow-sm h-100">
                            <div class="card-header bg-secondary text-white text-center">
                                <h5 class="mb-0">Account Scanner</h5>
                            </div>
                            <div class="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                <p class="text-muted mb-2">User ID: <?= $userId ?></p>
                                <img src="assets/img/qr.png" class="img-fluid" style="max-width: 200px;" alt="Logo">
                            </div>
                        </div>
                    </div> -->

                </div>

            </div>
        </div>
    </div>
</section>


            </div>

        </div><br>
        <!--<div class="lkjhgvb" style="text-align: center;
    font-weight: bold;">
        <a href="https://t.me/+DKTCcDGTwh0wODRl" style="color:#113098"><i class="fa fa-telegram" aria-hidden="true"
                style="color:#113098;margin-right:10px;font-size: 14px;"></i>Telegram : https://t.me/+DKTCcDGTwh0wODRl
        </a>
    </div>-->
        </div>
        <br>
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body pb-0">
                        <div class="row justify-content-between gx-0 mx-0 pb-3">
                            <div class="col-auto text-center">
                                <a href="authActiveUser"
                                    class="avatar avatar-60 p-1 shadow-sm rounded-15 bg-opac mb-2">
                                    <div class="icons bg-warning text-dark rounded-12 bg-opac1">
                                        <i class="bi bi-patch-plus size-22"></i>
                                    </div>
                                </a>
                                <p class="size-10 headd">ID Activation</p>
                            </div>
                            <!-- <div class="col-auto text-center">
                                <a href="walletWithdraw" class="avatar avatar-60 p-1 shadow-sm rounded-15 bg-opac mb-2">
                                    <div class="icons bg-warning text-dark rounded-12 bg-opac1">
                                        <i class="bi bi-cash-stack size-22"></i>
                                    </div>
                                </a>
                                <p class="size-10 headd">ID Registrtion</p>
                            </div> -->
                            <div class="col-auto text-center">
                                <a href="walletWithdraw" class="avatar avatar-60 p-1 shadow-sm rounded-15 bg-opac mb-2">
                                    <div class="icons bg-warning text-dark rounded-12 bg-opac1">
                                        <i class="bi bi-cash-stack size-22"></i>
                                    </div>
                                </a>
                                <p class="size-10 headd"> WITHDRAW</p>
                            </div>
                            <div class="col-auto text-center">
                                <a href="myLevelTeam" class="avatar avatar-60 p-1 shadow-sm rounded-15 bg-opac mb-2">
                                    <div class="icons bg-warning text-dark rounded-12 bg-opac1">
                                        <i class="fa fa-users size-22"></i>
                                    </div>
                                </a>
                                <p class="size-10 headd">My Team</p>
                            </div>
                            <div class="col-auto text-center">
                                <a href="fundRequest" class="avatar avatar-60 p-1 shadow-sm rounded-15 bg-opac mb-2">
                                    <div class="icons bg-warning text-dark rounded-12 bg-opac1">
                                        <i class="bi bi-receipt-cutoff size-22"></i>
                                    </div>
                                </a>
                                <p class="size-10 headd">ADD FUND</p>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- income expense-->
        <!-- <div class="row mb-4">
            <div class="col-6">
                <a href="incomeStatement">
                    <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd mb-0">TOTAL EARNINGS</p>

                                </div>
                                <p style="font-size:12px;" class="textt">
                                    <?= isset($totalIncome) ? $totalIncome : '0.00'; ?>$
                                </p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-6">
                <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                    <div class="icons bg-warning text-dark rounded-12">
                                        <i class="bi bi-wallet2"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <p class="size-10 headd mb-0">PURCHASE WALLET</p>

                            </div>
                            <p class="textt" style="font-size:12px;">
                                <?= isset($fundWallet) ? $fundWallet : '0.00'; ?>$
                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row mb-4">
            <div class="col-6">
                <a href="walletWithdraw">
                    <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-arrow-up-right"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd mb-0">Total Withdrawal</p>


                                </div>
                                <p style="font-size:12px;" class="textt">
                                    <?= isset($totalWithdraw) ? $totalWithdraw : '0.00'; ?>$
                                </p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <a href="#">
                    <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-arrow-up-right"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd mb-0">Total Buisness</p>


                                </div>
                                <p style="font-size:12px;" class="textt">
                                    <?= isset($totalBusiness) ? $totalBusiness : '0.00'; ?>$
                                </p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="row mb-4"> -->
            <!-- <div class="col-6">
                <a href="#">
                    <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-arrow-up-right"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd mb-0">Total Capping</p>


                                </div>
                                <p style="font-size:12px;" class="textt">
                                    <?= isset($totalCapping) ? $totalCapping : '0.00'; ?>$
                                </p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <a href="#">
                    <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-arrow-up-right"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd mb-0">Remaining Capping</p>


                                </div>
                                <p style="font-size:12px;" class="textt">
                                    <?= isset($RemainingCapping) ? $RemainingCapping  : '0.00'; ?>$
                                </p>
                            </div>
                        </div>
                    </div>
                </a>
            </div> -->
        </div>
        <!-- service provider -->

        <!-- rewards withdraw -->
        <!-- categories list -->
        <div class="row mb-2">
        </div>
        <div class="row mb-4 ">
    <!-- Card Template -->
    <div class="col-6 col-md-3 mb-2">
        <a href="myReferral" class="text-decoration-none text-dark">
            <div class=" ">
                <div class="card card-body d-flex align-items-center">
                    <div class="me-3">
                        <div class="avatar avatar-40 p-1 bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center">
                            <i class="fa fa-user fa-lg" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 text-truncate">
                        <p class="mb-1 fw-semibold text-muted lh-sm text-wrap">
                            <span class="d-none d-sm-inline">Non-Active Referrals</span>
                            <span class="d-sm-none">Non-Active<br>Referrals</span>
                        </p>
                        <p class="mb-0 fw-bold fs-6"><?= isset($inActiveSponser) ? $inActiveSponser : '0'; ?></p>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-6 col-md-3 mb-2">
        <a href="myReferral" class="text-decoration-none text-dark">
            <div class=" ">
                <div class="card card-body d-flex align-items-center">
                    <div class="me-3">
                        <div class="avatar avatar-40 p-1 bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center">
                            <i class="fa fa-user fa-lg" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 text-truncate">
                        <p class="mb-1 fw-semibold text-muted lh-sm text-wrap">
                            <span class="d-none d-sm-inline">Active Referrals</span>
                            <span class="d-sm-none">Active<br>Referrals</span>
                        </p>
                        <p class="mb-0 fw-bold fs-6"><?= isset($activeSponser) ? $activeSponser : '0'; ?></p>
                    </div>
                  </div>
                 </div>
                 </a>
               </div>

    <div class="col-6 col-md-3">
        <a href="levelactive" class="text-decoration-none text-dark">
            <div class="  ">
                <div class="card card-body d-flex align-items-center">
                    <div class="me-3">
                        <div class="avatar avatar-40 p-1 bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center">
                            <i class="fa fa-user fa-lg" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 text-truncate">
                        <p class="mb-1 fw-semibold text-muted lh-sm text-wrap">
                            <span class="d-none d-sm-inline">Total Active IDS</span>
                            <span class="d-sm-none">Total Active<br>IDS</span>
                        </p>
                        <p class="mb-0 fw-bold fs-6"><?= isset($activeTeam) ? $activeTeam : '0'; ?></p>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-6 col-md-3">
        <a href="levelactive" class="text-decoration-none text-dark">
            <div class="  ">
                <div class="card card-body d-flex align-items-center">
                    <div class="me-3">
                        <div class="avatar avatar-40 p-1 bg-warning text-dark rounded-circle d-flex align-items-center justify-content-center">
                            <i class="fa fa-user fa-lg" aria-hidden="true"></i>
                        </div>
                    </div>
                    <div class="flex-grow-1 text-truncate">
                        <p class="mb-1 fw-semibold text-muted lh-sm text-wrap">
                            <span class="d-none d-sm-inline">Total Non-Active IDS</span>
                            <span class="d-sm-none">Total Non-Active<br>IDS</span>
                        </p>
                        <p class="mb-0 fw-bold fs-6"><?= isset($inActiveTeam) ? $inActiveTeam : '0'; ?></p>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>

        <!-- <div class="row mb-4">
            <div class="col-6">
                <a href="myLevelTeam">
                    <div class="card "
                        style="height:90px;  ">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="fa fa-users size-22"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Not Active Team</p>
                                    <p class="size-10 headd">
                                        <?= isset($inActiveTeam) ? $inActiveTeam : '0'; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-6">
                <a href="myLevelTeam">
                    <div class="card "
                        style="height:90px; ">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-info rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="fa fa-users size-22"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Total Team</p>
                                    <p class="size-10 headd">
                                        <?= isset($activeTeam) ? $activeTeam : '0'; ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>


        </div> -->

        <div class="row mb-4">

            <!--<div class="col-6">
            <div class="card bg-theme" style="height:90px;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto">
                            <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                <div class="icons bg-danger text-dark rounded-12">
                                    <i class="fa fa-money size-22"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col align-self-center ps-0">
                            </a>
                            <p class="size-10 headd">TODAY<br>INCOME</p>
                            <p class="size-10 headd">0.00 $</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>-->
            <!-- <div class="col-12">
                <div class="card " style="height:90px;">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                    <div class="icons bg-warning text-dark rounded-12">
                                        <i class="bi bi-cash-stack size-22"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <p class="size-10 headd">TOTAL <br>INCOME</p>
                                <p class="size-10 headd">
                                    <?= isset($incomeWallet) ? $incomeWallet : '0.00'; ?>$
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
        <!--<div class="row mb-4">
        <div class="col-6">
            <div class="card bg-theme" style="height:90px;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto">
                            <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                <div class="icons bg-warning text-dark rounded-12">
                                    <i class="fa fa-credit-card size-22"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col align-self-center ps-0">
                            <p class="size-10 headd">FUND <br>WALLET</p>

                            <p class="size-10 headd">0.00 </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="card bg-theme" style="height:90px;">
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto">
                            <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                <div class="icons bg-warning text-dark rounded-12">
                                    <i class="fa fa-bar-chart size-22" aria-hidden="true"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col align-self-center ps-0">
                            <p class="size-10 headd">PACKAGE <br>REVENUE</p>
                            <p class="size-10 headd">0.00 </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>-->
        <!------------------------------Income 25$ Start------------------------------------------>
        <!-- <div class="row mb-4">
           <div class="col-12">
                <a href="#">
                    <div class="card" style="height:90px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="fa fa-line-chart" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Total Investment</p>
                                    <p class="size-10 headd">
                                        <?= isset($totalInvest) ? $totalInvest : '0.00'; ?>$
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div> -->
        <!-- income expense-->
        <!-- <div class="row mb-4">
            <div class="col-6">
                <a href="referralIncome">
                    <div class="card" style="height:90px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="fa fa-line-chart" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Direct <br> Income</p>
                                    <p class="size-10 headd">
                                        <?= isset($referralIncome) ? $referralIncome : '0.00'; ?>$
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <a href="levelIncome">
                    <div class="card" style="height:90px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="fa fa-database" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Level <br>Income </p>
                                    <p class="size-10 headd">
                                        <?= isset($levelIncome) ? $levelIncome : '0.00'; ?>$
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div> -->
        <div class="row mb-4">
            <div class="col-6">
                <a href="incomeStatement">
                    <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd mb-0">Total Earning</p>

                                </div>
                                <p style="font-size:12px;" class="textt">
                                    <?= isset($totalIncome) ? $totalIncome : '0.00'; ?> ₹

                                </p>
                            </div>
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-6">
                <div class="card" style="height: 120px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                    <div class="icons bg-warning text-dark rounded-12">
                                        <i class="bi bi-wallet2"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <p class="size-10 headd mb-0"> Total Purchage Amount</p>

                            </div>
                            <p class="textt" style="font-size:12px;">
                                <?= isset($fundWallet) ? $fundWallet : '0.00'; ?> ₹

                            </p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="row mb-4">
            <div class="col-6 mb-2">
                <a href="SilverPlan">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Auto Pool I</p>
                                    <p class="size-10 headd"> <?= isset($autopoolIncome1) ? $autopoolIncome1 : '0.00'; ?> ₹</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6 mb-2">
                <a href="GoldPlan">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Auto Pool II</p>
                                    <p class="size-10 headd"> <?= isset($autopoolIncome2) ? $autopoolIncome2: '0.00'; ?> ₹</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <a href="DiamondPlan">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Auto Pool III</p>
                                    <p class="size-10 headd"> <?= isset($autopoolIncome3) ? $autopoolIncome3 : '0.00'; ?> ₹</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
<div class="col-6">
                <a href="levelIncome">
                    <div class="card" style="height:90px; box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-danger rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="fa fa-database" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Level <br>Income </p>
                                    <p class="size-10 headd">
                                        <?= isset($levelIncome) ? $levelIncome : '0.00'; ?> ₹
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <!-- <div class="col-6">
                <a href="rewardIncome">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Reward Income</p>
                                    <p class="size-10 headd"> <?= isset($rewardIncome) ? $rewardIncome : '0.00'; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div> -->
        </div>


        <div class="row mb-4">
            <!-- <div class="col-6">
                <a href="ctoIncome">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">CTO Income</p>
                                    <p class="size-10 headd"> <?= isset($ctoIncome) ? $ctoIncome : '0.00'; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6">
                <a href="royalctoIncome">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Royal CTO Income</p>
                                    <p class="size-10 headd"> <?= isset($royalctoIncome) ? $royalctoIncome : '0.00'; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div> -->
        </div>
        
         <div class="row mb-4">
           <!-- <div class="col-6">
                <a href="depositeIncome">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Strong Leg</p>
                                    <p class="size-10 headd"> <?= isset($primaryBus) ? $primaryBus : '0.00'; ?> </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
             <div class="col-6">
                <a href="royaltyIncome">
                    <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-auto">
                                    <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                        <div class="icons bg-warning text-dark rounded-12">
                                            <i class="bi bi-wallet2"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col align-self-center ps-0">
                                    <p class="size-10 headd">Other Leg</p>
                                    <p class="size-10 headd"> <?= isset($secondaryBus) ? $secondaryBus : '0.00'; ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div> -->
        </div>
        
        
        
        <div class="row mb-4">
            <!--<div class="col-6">-->
            <!--    <a href="royaltyIncome">-->
            <!--        <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">-->
            <!--            <div class="card-body">-->
            <!--                <div class="row">-->
            <!--                    <div class="col-auto">-->
            <!--                        <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">-->
            <!--                            <div class="icons bg-warning text-dark rounded-12">-->
            <!--                                <i class="bi bi-wallet2"></i>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                    </div>-->
            <!--                    <div class="col align-self-center ps-0">-->
            <!--                        <p class="size-10 headd">Other Leg</p>-->
            <!--                        <p class="size-10 headd"> <?= isset($secondaryBus) ? $secondaryBus : '0.00'; ?></p>-->
            <!--                    </div>-->
            <!--                </div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </a>-->
            <!--</div>-->
            <!-- <div class="col-6">
                <div class="card" style="height:90px;box-shadow: 0 6px 6px rgb(0 0 0 / 20%) !important;">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-auto">
                                <div class="avatar avatar-40 p-1 shadow-sm shadow-success rounded-15">
                                    <div class="icons bg-warning text-dark rounded-12">
                                        <i class="bi bi-wallet2"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col align-self-center ps-0">
                                <p class="size-10 headd">Available Fund</p>
                                <p class="size-10 headd">
                                    <?= isset($fundWallet) ? $fundWallet : '0.00'; ?>$
                                </p>
                            </div>


                        </div>
                    </div>
                </div>
            </div> -->

        </div>

        <!------------------------------Income 25$ End-------------------------------------------->


        <!------------------------------Income 50$ Start------------------------------------------>

        <!------------------------------Income 50$ End-------------------------------------------->

        <!-- offers banner -->
        <div class="row mb-4">
            <div class="col-12 col-md-12 col-lg-12">
                <div class="col-lg-12 col-xs-12">
                    <div class="form-group" align="center"
                        style="font-size: 18px;font-weight: 600;background:  #03222fa7 !important;color: #fff;margin-top: 21px;border-radius: 15px;padding: 10px;">
                        <label style="color:#000000;">Referral URL</label>
                        <input id="referralCone" type="hidden" readonly
                            value="https://Billionaire Club.live/authUserRegister?affiliateCode=<?= $userId ?>">
                        <a style="display: inline-block;margin-top: 1px;font-weight: bold;padding: 3px 8px;border-radius: 5px;color: #fff;"
                            href="javascript:void(0)" onclick="copyLink()" class="btn btn-sm btn-success waves-effect">
                            <i class="fa fa-copy"></i>
                            <span>Copy </span>
                        </a>
                        <a style="display: inline-block;margin-top: 1px;font-weight: bold;padding: 3px 8px;border-radius: 5px;color: #fff;"
                            target="_blank"
                            href="https://api.whatsapp.com/send?phone=&amp;text=https://Billionaire Club.live/authUserRegister?affiliateCode=<?= $userId ?>"
                            class="btn btn-sm btn-success waves-effect">
                            <i class="fa fa-whatsapp"></i>
                            <span>Whatsapp</span>
                        </a>
                        <a style="display: inline-block;margin-top: 1px;font-weight: bold;padding: 3px 8px;border-radius: 5px;color: #fff;"
                            target="_blank"
                            href="http://www.facebook.com/sharer/sharer.php?u=https://Billionaire Club.live/authUserRegister?affiliateCode=<?= $userId ?>"
                            class="btn btn-sm btn-primary waves-effect">
                            <i class="fa fa-facebook-f"></i>
                            <span>Facebook</span>
                        </a>
                        <a style="display: inline-block;margin-top: 1px;font-weight: bold;padding: 3px 8px;border-radius: 5px;color: #fff;"
                            target="_blank"
                            href="https://telegram.me/share/url?url=https://Billionaire Club.live/authUserRegister?affiliateCode=<?= $userId ?>"
                            class="btn btn-sm btn-primary waves-effect">
                            <i class="fa fa-telegram"></i>
                            <span>Telegram</span></a>
                    </div>
                </div>
            </div>
        </div>


        <!-- main page content ends -->
        <!-- Blogs -->
        <!-- <div class="row mb-3">
            <div class="col">
                <h6 class="title">News </h6>
            </div>
        </div> -->
        <button type="button" id="modalShow" style="display:none;" data-bs-toggle="modal"
            data-bs-target="#welcomeNotice" class="btn btn-primary">Show</button>
        <?php $queryConfig = mysqli_query($con, "SELECT dashboardImage,imageStatus FROM meddolic_config_misc_setting");
        $valConfig = mysqli_fetch_assoc($queryConfig); ?>
        <!-- <div id="welcomeNotice" class="modal animated fadeInLeft custo-fadeInLeft" role="dialog">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button class="btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <center><img src="../<?= $valConfig['dashboardImage'] ?>" width="100%"></center>
                    </div>
                </div>
            </div>
        </div> -->
    </main>
    <?php require_once('Include/Footer.php'); ?>
    <script>
        function copyLink() {
            var link = $("#referralCone").val();
            var tempInput = document.createElement("input");
            tempInput.style = "position: absolute; left: -1000px; top: -1000px";
            tempInput.value = link;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand("copy");
            alert('Referral Link Copied Successfully');
        }

        function popMsg() {
            <?php if ($valConfig['imageStatus'] == 1) { ?>
                $('#modalShow').click();
            <?php } ?>
        }
        window.load = popMsg();

        function myFunction1() {
            copyToClipboard(document.getElementById("link1"));
            hideCopy1(document.getElementById("btnCopied2"), document.getElementById("btnCopyToClibord2"));
            btnCopied2.style.display = "inline-block";
            btnCopyToClibord2.style.display = "none";
        };

        function myFunction2() {
            copyToClipboard(document.getElementById("link2"));
            hideCopy1(document.getElementById("btnCopied2"), document.getElementById("btnCopyToClibord2"));
            btnCopied2.style.display = "inline-block";
            btnCopyToClibord2.style.display = "none";
        };
    </script>

    <script>
        document.getElementById("btnCopyToClibord").addEventListener("click", function() {
            copyToClipboard(document.getElementById("sponserlink"));
            hideCopyButton();
        });

        function copyToClipboard(elem) {
            elem.disabled = false;
            var targetId = "_hiddenCopyText_";
            var isInput = elem.tagName === "INPUT" || elem.tagName === "TEXTAREA";
            var origSelectionStart, origSelectionEnd;
            if (isInput) {
                // can just use the original source element for the selection and copy
                target = elem;
                origSelectionStart = elem.selectionStart;
                origSelectionEnd = elem.selectionEnd;
            } else {
                // must use a temporary form element for the selection and copy
                target = document.getElementById(targetId);
                if (!target) {
                    var target = document.createElement("textarea");
                    target.style.position = "absolute";
                    target.style.left = "-9999px";
                    target.style.top = "0";
                    target.id = targetId;
                    document.body.appendChild(target);
                }
                target.textContent = elem.textContent;

            }
            // select the content
            var currentFocus = document.activeElement;
            target.focus();
            target.setSelectionRange(0, target.value.length);

            // copy the selection
            var succeed;
            try {
                succeed = document.execCommand("copy");
            } catch (e) {
                succeed = false;
            }
            // restore original focus
            if (currentFocus && typeof currentFocus.focus === "function") {
                currentFocus.focus();
            }

            if (isInput) {
                // restore prior selection
                elem.setSelectionRange(origSelectionStart, origSelectionEnd);
            } else {
                // clear temporary content
                target.textContent = "";
            }
            elem.disabled = true;
            //alert("Copied");
            return succeed;
        }

        function hideCopyButton() {
            hideCopy(document.getElementById("btnCopied1"), document.getElementById("btnCopyToClibord1"));
        }

        function hideCopiedButton() {

            hideCopied(document.getElementById("btnCopyToClibord"), document.getElementById("btnCopied"));
        }

        function hideCopy(btnCopied1, btnCopyToClibord1) {

            btnCopied1.style.display = "inline-block";
            btnCopyToClibord1.style.display = "none";
        }

        function hideCopy1(btnCopied2, btnCopyToClibord2) {

            btnCopied2.style.display = "inline-block";
            btnCopyToClibord2.style.display = "none";
        }

        function hideCopied(btnCopyToClibord, btnCopied) {

            btnCopied.style.display = "none";
            btnCopyToClibord.style.display = "inline-block";

        }
    </script>

    <script>
        $(document).ready(function() {
            // Show modal on page load
            $("#myModal").modal('show');

            // Hide modal on button click
            $(".hide-modal").click(function() {
                $("#myModal").modal('hide');
            });
        });
    </script>
</body>

</html>