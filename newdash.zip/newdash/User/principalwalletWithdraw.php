<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

  <?php require_once('Include/Menu.php');
  ?>

  <!-- Header -->
  <header class="header position-fixed">
    <div class="row">
      <div class="col-auto">
        <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
          <i class="bi bi-list"></i>
        </a>
      </div>
      <div class="col text-right">
        <div class="logo-small">
          <img src="assets/img/logo.png" alt="" style=" height:50px; " />
        </div>
      </div>

    </div>
  </header>

  <main class="h-100">
    <div class="content-wrapper">
      <div class="container-full">
        <!-- Content Header (Page header) -->


        <!-- Main content -->
        <section class="content">
          <div class="card-header py-3">
            <h6 >Principal Withdraw Request </h6>
          </div>
          <br>
          <div class="row">
            <div class="col-sm-12">
              <div class="card crd0">
                <div class="card-body">
                  <form class="theme-form" action="principalwalletWithdrawProccess" method="post">
                    <div class="mb-3">
                      <label>UserId </label>
                      <input type="text" name="user_id" class="form-control" placeholder="e.g. john12345" readonly
                        value="<?= $userId ?>">
                      <input type="hidden" name="memberId" value="<?= $memberId ?>">
                      <input type="hidden" name="goodFile" value="<?= $newToken ?>">
                      <!-- <input type="hidden" name="withdrawCharge" value="<?= $withdrawCharge ?>"> -->
                      <!-- <input type="hidden" name="minimumWithdraw" value="<?= $minimumWithdraw ?>"> -->
                    </div>
                    <div class="mb-3">
                      <label>Name </label>
                      <input type="text" name="name" class="form-control" placeholder="e.g. John Doe" readonly
                        value="<?= $userName ?>">
                    </div>
                    <div class="mb-3">
                      <label>Income Wallet </label>
                      <input type="text" class="form-control" value="<?= $incomeWallet ?>" readonly>
                    </div>
                    <div class="mb-3">
                      <label>Fund Wallet </label>
                      <input type="text" class="form-control" value="<?= $fundWallet ?>" readonly>
                    </div>
                    <div class="mb-3">
                      <label>Select wallet</label>
                      <select class="form-control" name="paymentId" id="paymentId">
                        <option value="">Select Withdrawl In</option>
                        <?php $queryWallet = mysqli_query($con, "SELECT a.payment_id,a.walletAddress,b.currencyName FROM meddolic_user_wallet_address_details a, meddolic_config_currency_list b WHERE a.member_id='$memberId' AND a.currency_id=b.currency_id AND a.status=1  ORDER BY a.addDate DESC");
                        while ($valWallet = mysqli_fetch_assoc($queryWallet)) { ?>
                          <option value="<?= $valWallet['payment_id'] ?>">
                            <?= $valWallet['currencyName'] ?> [
                            <?= $valWallet['walletAddress'] ?> ]
                          </option>
                        <?php } ?>
                      </select>
                    </div>

                    <div class="mb-3">
                      <label>Select UPI</label>
                      <select class="form-control" name="upiId" id="upiId">
                        <option value="">Select UPI In</option>
                        <?php $queryUpi = mysqli_query($con, "SELECT payment_id,upiAddress FROM meddolic_user_upi_address_details  WHERE member_id='$memberId' AND status=1  ORDER BY addDate DESC");
                        while ($valUpi = mysqli_fetch_assoc($queryUpi)) { ?>
                          <option value="<?= $valUpi['payment_id'] ?>">
                            [ <?= $valUpi['upiAddress'] ?> ]</option>
                        <?php } ?>
                      </select>
                    </div>

                    <!-- <div class="mb-3">
                      <label>Withdraw Amount (
                        <?= $minimumWithdraw ?> $) *
                      </label>
                      <input type="number" name="withdrawAmount" class="form-control"
                        placeholder="Enter Withdraw Amount" required onkeypress="return onlynum(event)">
                    </div> -->
                    <div class="mb-3" style="display: flex; gap: 1rem; align-items: end;">
                      <div style="flex: 1;">
                        <label>Enter OTP</label>
                        <input type="text" name="otp" class="form-control" placeholder="Enter OTP" required>
                      </div>
                      <button type="button" id="getOtp" class="btn btn-primary" style="height: fit-content;">Get
                        OTP</button>
                    </div>
                    <div class="mb-3">
                      <label>Transaction Password *</label>
                      <input type="password" name="trnPassword" class="form-control"
                        placeholder="e.g. Transaction Password" required="">
                    </div>
                    <div class="">
                      <button class="btn btn-primary" data-bs-original-title="" title="Withdraw" name="walletWithdraw"
                        value="withdraw">Withdraw Request</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <br>
          <div class="row">
            <div class="card crd0">
              <div class="card-header">
                <h5>Principal Withdraw Request Report</h5>
              </div>
              <div class="card-body">
                <div class="dt-ext table-responsive">
                  <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>User Id</th>
                        <th>Amount</th>
                        <!-- <th>Charge</th> -->
                        <th>Net Amount</th>
                        <th>Order Id</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action Date</th>
                        <th>Remark</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $count = 0;
                      $queryWithdraw = mysqli_query($con, "SELECT a.*,b.user_id FROM meddolic_user_wallet_withdrawal_crypto a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.member_id=b.member_id AND payment_id=1 ORDER BY a.id DESC");
                      while ($valWithdraw = mysqli_fetch_assoc($queryWithdraw)) {
                        $count++; ?>
                        <tr>
                          <td>
                            <?= $count; ?>
                          </td>
                          <td>
                            <?= $valWithdraw['user_id'] ?>
                          </td>
                          <td><span class="badge badge-danger"><i class="fa-solid fa-sterling-sign"></i>
                              <?= $valWithdraw['amount'] ?> ₹
                            </span></td>
                          <!-- <td><span class="badge badge-danger"><i class="fa-solid fa-sterling-sign"></i> <?= $valWithdraw['withdrawCharge'] ?></span></td> -->
                          <td><span class="badge badge-success"><i class="fa-solid fa-sterling-sign"></i>
                              <?= $valWithdraw['netAmount'] ?> ₹
                            </span></td>
                          <td>
                            <?= $valWithdraw['orderid'] ?>
                          </td>
                          <td><i class="fa-regular fa-clock"></i>
                            <?= $valWithdraw['date_time'] ?>
                          </td>
                          <td>
                            <?php if ($valWithdraw['released'] == 0)
                              echo "<span class='badge badge-primary'>PENDING</span>";
                            else if ($valWithdraw['released'] == 1)
                              echo "<span class='badge badge-success'>RELEASED</span>";
                            else if ($valWithdraw['released'] == 2)
                              echo "<span class='badge badge-warning'>PROCESSING</span>";
                            else if ($valWithdraw['released'] == 3)
                              echo "<span class='badge badge-danger'>REJECTED</span>"; ?>
                          </td>
                          <td>
                            <?= $valWithdraw['payment_date'] ?>
                          </td>
                          <td>
                            <?= $valWithdraw['remarks'] ?>
                          </td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
          <!-- /.row -->
        </section>
        <!-- /.content -->

      </div>
    </div>
    </div>
    <!-- Footer -->
    <!-- <footer class="footer" style="background:#00bcd4;">
      <div class="container">
        <ul class="nav nav-pills nav-justified">
          <li class="nav-item">
            <a class="nav-link active" href="index">
              <span>
                <i class="nav-icon bi bi-house"></i>
                <span class="nav-text">Home</span>
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="EditProfile" style="color:#000;">
              <span>
                <i class="nav-icon bi-person-circle"></i>
                <span class="nav-text">Profile</span>
              </span>
            </a>
          </li>
          <li class="nav-item centerbutton">
            <button type="button" class="nav-link" data-bs-toggle="modal" data-bs-target="#menumodal"
              id="centermenubtn">
              <span class="theme-radial-gradient">
                <i class="bi bi-grid size-22" style="color:#000;"></i>
              </span>
            </button>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="changePassword" style="color:#000;">
              <span>
                <i class="nav-icon bi-file-earmark-lock"></i>
                <span class="nav-text">Change Password</span>
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" style="color:#000;">
              <span>
                <i class="nav-icon bi bi-file-earmark-text"></i>
                <span class="nav-text">Edit Account</span>
              </span>
            </a>
          </li>

        </ul>
      </div>
    </footer> -->

    <script>
      const getOtpButton = document.getElementById('getOtp');

      getOtpButton.addEventListener('click', async () => {
        const memberId = <?= $memberId ?>;

        const data = await fetch('ajaxCalls/sendOtpAjax.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `memberId=${encodeURIComponent(memberId)}`
        }).then(res => res.text());

        console.log(data);

        if (data.trim() == "success") {
          alert("OTP sent successfully");
        } else {
          alert("Failed to send OTP");
        }
      });
    </script>



    <?php require_once('Include/Footer.php'); ?>


</body>


</html>