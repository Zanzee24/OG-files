<?php require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');

?>

<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">Reward Income</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        
                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">Reward</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
              <tr>
                <th>Sr No.</th>
                <th>User Id</th>
                <th>Name</th>
                <th>Reward ID</th>
                <th>Reward Income</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php

              $count = 0;
              $queryLevel = mysqli_query($con, "SELECT b.name,b.user_id,a.dateTime,a.salaryIncome,a.salaryId FROM meddolic_user_salary_income a, meddolic_user_details b WHERE a.memberId=b.member_id AND  a.memberId='$memberId' ORDER BY a.dateTime desc");
              while ($valLevel = mysqli_fetch_assoc($queryLevel)) {
                $count++; ?>
                <tr>
                  <td><?= $count ?></td>
                  <td><?= $valLevel['user_id'] ?></td>
                  <td><?= $valLevel['name'] ?></td>
                  <td>Reward <?= $valLevel['salaryId'] ?></td>
                  <td><i class ="fa fa-inr"> <?= $valLevel['salaryIncome'] ?> </i></td>
                  <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y ", strtotime($valLevel['dateTime'])) ?></td>
                </tr>
              <?php } ?>
            </tbody>
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>