<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1">

<?php
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>


<body>


    <!-- PAGE -->
    <div class="page">

        <!-- MAIN-CONTENT -->

        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <!-- Start:: row-1 -->

                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="top-left"></div>
                        <div class="top-right"></div>
                        <div class="bottom-left"></div>
                        <div class="bottom-right"></div>
                        <div class="card-header">
                            <div class="card-title">
                                My Referrls
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
    <table class="table text-nowrap table-striped-columns">
        <thead>
            <tr>
                <th scope="col">ID</th>
                <th scope="col">Date</th>
                <th scope="col">Customer</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">2022R-01</th>
                <td>27-010-2022</td>
                <td>Moracco</td>
                <td>
                    <button class="btn btn-sm btn-danger btn-wave">
                        <i class="fa-solid fa-trash align-middle me-2 d-inline-block"></i>Delete
                    </button>
                </td>
            </tr>
            <tr>
                <th scope="row">2022R-02</th>
                <td>28-10-2022</td>
                <td>Thornton</td>
                <td>
                    <button class="btn btn-sm btn-danger btn-wave">
                        <i class="fa-solid fa-trash align-middle me-2 d-inline-block"></i>Delete
                    </button>
                </td>
            </tr>
            <tr>
                <th scope="row">2022R-03</th>
                <td>22-10-2022</td>
                <td>Larry Bird</td>
                <td>
                    <button class="btn btn-sm btn-danger btn-wave">
                        <i class="fa-solid fa-trash align-middle me-2 d-inline-block"></i>Delete
                    </button>
                </td>
            </tr>
            <tr>
                <th scope="row">2022R-04</th>
                <td>29-09-2022</td>
                <td>Erica Sean</td>
                <td>
                    <button class="btn btn-sm btn-danger btn-wave">
                        <i class="fa-solid fa-trash align-middle me-2 d-inline-block"></i>Delete
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</div>
                        </div>
                    </div>
                </div>
            </div>



            <?php include 'Include/footer.php'; ?>

</body>

</html><!-- This code use for render base file -->