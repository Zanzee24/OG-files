<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
// require_once('Include/Footer.php');



?>
</head>


<body class="body-scroll" data-page="index">
    <!-- Header -->
    <!-- Header -->
    <header class="header position-fixed">
        <div class="row">
            <div class="col-auto">
                <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
            </div>
            <div class="col text-right">
                <div class="logo-small">
                    <img src="assets/img/logo.png" alt="" style=" height:50px; " />
                </div>
            </div>

        </div>
    </header>


    <div class="page-body" style="margin-top: 86px;">

        <div class="container-fluid">
            <h5 >UPI Address</h5>
            <div class="row">
                <div class="col-sm-12 col-xl-12 xl-100">
                    <div class="card">
                        <div class="card-body">
                            <form class="form theme-form" action="userProfileAuthProcess" method="POST">
                                <div class="row">
                                    <div class="form-group col-md-4 col-sm-6">
                                        <div class="form-group">
                                            <label>UPI Address *</label>
                                            <input class="form-control" name="upiAddress" id="upiAddress"
                                                type="text" required placeholder="Enter UPI Address">
                                            <input type="hidden" name="memberId" value="<?= $memberId ?>" />
                                        </div>
                                    </div>

                                    <div class="card-footer text-end">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button type="submit" name="addUPIAddress"
                                                class="btn btn-primary col-md-2 col-sm-3">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <div class='card' style='margin-top: 23px; margin-bottom:75px'>
        <div class="table-panel">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table id="example" class="table table-bordered table-custom table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>UPI Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $count = 0;
                                $queryWallet = mysqli_query($con, "SELECT payment_id,upiAddress,addDate FROM meddolic_user_upi_address_details WHERE member_id='$memberId' AND status=1 ORDER BY addDate DESC");
                                while ($valWallet = mysqli_fetch_assoc($queryWallet)) {
                                    $count++; ?>
                                    <tr>
                                        <td>
                                            <?= $count ?>
                                        </td>
                                        
                                        <td>
                                            <?= $valWallet['upiAddress'] ?>
                                        </td>
                                        <td><a href="javascript:void(0)" class="btn btn-danger btn-sm"
                                                onclick="deleteUPIAddress(<?= $valWallet['payment_id'] ?>)"><i class="fa fa-trash"></i> Delete</a></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>


    </section>


    </div>

    </div>

    <?php require_once('Include/Footer.php'); ?>

</body>


</html>
<script>
    function deleteUPIAddress(payment_id) {
        if (payment_id != '') {
            if (confirm('Are you sure to Delete this UPI Address?')) {
                arguments
                $.ajax({
                    type: 'POST',
                    url: 'ajaxCalls/deleteUPIAddressAjax',
                    data: {
                        payment_id: payment_id,
                    },
                    success: function(data) {
                        // console.log(data);
                        if (data == true) {
                            alert('UPI Address Deleted Successfully');
                            window.location.reload();
                        }
                    }
                });
            }
        }
    }
    $(document).ready(function() {

        $("#userid").keyup(function() {
            var userid = $('#userid').val();

            $.ajax({

                type: "POST",
                url: "refree.php",
                data: {
                    "userid": userid
                },
                success: function(response) {
                    if (response) {
                        var Username = document.getElementById('username');
                        Username.value = response;
                        $('#username').css({
                            "color": "#1ea8e7",
                            "font-weight": "bold"
                        });
                        $("#register_btn").show();
                    } else {
                        $(".ll1").show();
                        var Username = document.getElementById('username');
                        Username.value = "Invalid Userid";
                        $('#username').css({
                            "color": "#ff0000",
                            "font-weight": "bold"
                        });
                        $("#register_btn").hide();
                    }
                }
            });

        });
    });
</script>