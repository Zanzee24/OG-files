<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
</head>

    <!--#INCLUDE file="header.asp"-->
    <main class="h-100">
        <div class="content-wrapper">
            <div class="container-full">
                <!-- Content Header (Page header) -->


                <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <div class="col-12">

                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-dark">Fund Transfer History</h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="example" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>Sno.</th>
                                                    <th>Date</th>
                                                    <th>Time</th>
                                                    <th>Userid</th>
                                                    <th>Name</th>
                                                    <th>Amount</th>
                                                </tr>
                                            </thead>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </section>
                <!-- /.content -->

            </div>
        </div>
        </div>
        <!-- Footer -->
        <footer class="footer" style="background:#00bcd4;">
            <div class="container">
                <ul class="nav nav-pills nav-justified">
                    <li class="nav-item">
                        <a class="nav-link active" href="index">
                    <span>
                        <i class="nav-icon bi bi-house"></i>
                        <span class="nav-text">Home</span>
                    </span>
                </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="EditProfile" style="color:#000;">
                    <span>
                        <i class="nav-icon bi-person-circle"></i>
                        <span class="nav-text">Profile</span>
                    </span>
                </a>
                    </li>
                    <li class="nav-item centerbutton">
                        <button type="button" class="nav-link" data-bs-toggle="modal" data-bs-target="#menumodal" id="centermenubtn">
                    <span class="theme-radial-gradient">
                        <i class="bi bi-grid size-22" style="color:#000;"></i>
                    </span>
                </button>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="changePassword" style="color:#000;">
                    <span>
                        <i class="nav-icon bi-file-earmark-lock"></i>
                        <span class="nav-text">Change Password</span>
                    </span>
                </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" style="color:#000;">
                    <span>
                        <i class="nav-icon bi bi-file-earmark-text"></i>
                        <span class="nav-text">Edit Account</span>
                    </span>
                </a>
                    </li>

                </ul>
            </div>
        </footer>




        <!-- Required jquery and libraries -->
        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/vendor/bootstrap-5/js/bootstrap.bundle.min.js"></script>

        <!-- Customized jquery file  -->
        <script src="assets/js/main.js"></script>
        <script src="assets/js/color-scheme.js"></script>

        <!-- PWA app service registration and works -->
        <script src="assets/js/pwa-services.js"></script>

        <!-- Chart js script -->
        <script src="assets/vendor/chart-js-3.3.1/chart.min.js"></script>

        <!-- Progress circle js script -->
        <script src="assets/vendor/progressbar-js/progressbar.min.js"></script>

        <!-- swiper js script -->
        <script src="assets/vendor/swiperjs-6.6.2/swiper-bundle.min.js"></script>

        <!-- page level custom script -->
        <script src="assets/js/app.js"></script>

</body>


</html>