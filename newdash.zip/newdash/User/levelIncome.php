<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>

<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">Level Income</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                      <tr>
                        <th>#</th>
                        <th>UserId</th>
                        <th>Level Income</th>
                        <th>Level</th>
                        <th>Level Percent</th>
                        <th>Date</th>
                        <!-- <th>Income From</th>
                        <th>Child Name</th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $count = 0;
                      $queryLevel = mysqli_query($con, "SELECT a.levelPercent,a.dateTime,a.levelIncome,b.name,b.user_id,a.level FROM meddolic_user_level_income a, meddolic_user_details b WHERE a.memberId=b.member_id AND memberId=$memberId ORDER BY a.dateTime DESC");
                      while ($valLevel = mysqli_fetch_assoc($queryLevel)) {
                        $count++; ?>
                        <tr>
                          <td> <?= $count ?> </td>
                          <td> <?= $valLevel['user_id'] ?> </td>
                          <td><span class="badge badge-success"><?= $valLevel['levelIncome'] ?> ₹</span></td>
                          <td>Level <?= $valLevel['level'] ?></td>
                          <td> <?= $valLevel['levelPercent'] ?></td>
                          <td><i class="fa fa-clock-o"></i><?= date("d-m-Y H:i:s", strtotime($valLevel['dateTime'])) ?></td>
                          <!-- <td><?= $valLevel['childID'] ?></td>
                        <td><?= $valLevel['childName'] ?></td> -->
                        </tr>
                      <?php } ?>
                    </tbody>
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>