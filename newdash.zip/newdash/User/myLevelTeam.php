<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Menu.php');
require_once('Include/Header.php'); ?>

<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">My Team</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">Level</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Level Number.</th>
                                                <th>Total Member</th>
                                                <th>Total Buisness</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            for ($level = 1; $level <= 9; $level++) {
                                                // Query total members at the current level
                                                $queryMember = mysqli_query($con, "SELECT COUNT(1) AS totalMember FROM meddolic_user_child_ids WHERE member_id='$memberId' AND level='$level'");
                                                $valMember = mysqli_fetch_array($queryMember);

                                                // Query total business (investment) for the current level
                                                $queryBusiness = mysqli_query($con, "SELECT SUM(investAmount) AS totalBusiness FROM meddolic_user_invest_history WHERE memberId IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$memberId' AND level='$level')");
                                                $valBusiness = mysqli_fetch_array($queryBusiness);

                                                $totalMembers = isset($valMember['totalMember']) ? $valMember['totalMember'] : 0;
                                                $totalBusiness = isset($valBusiness['totalBusiness']) ? number_format($valBusiness['totalBusiness'], 2) : '0.00';

                                            ?>
                                                <tr>
                                                    <td><?= $level ?></td>
                                                    <td>Level <?= $level ?></td>
                                                    <td><i class="fa fa-user"></i> <?= $totalMembers ?></td>
                                                    <td><i class="fa fa-usd-sign"></i> <?= $totalBusiness ?> $</td>
                                                    <td>
                                                        <a href="levelTeamDetails?MemberID=<?= $memberId ?>&LevelID=<?= $level ?>" class="btn btn-primary">More</a>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>