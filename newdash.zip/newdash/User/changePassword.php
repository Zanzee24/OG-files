<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
</head>


<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

<h2>Change Password</h2>


                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        <div class="col-lg-12 col-xs-12">
            <section class="box">
                <div class="content-body">
                                 <form class="form-horizontal" role="form" action="userProfileAuthProcess" method="post">
                                                    <div class="form-group">
                                                        <label class="control-label col-sm-3" for="first-name">Current Password:</label>
                                                        <div class="col-sm-12">
                                                        <input type="password" name="password" id="currentPass" class="form-control" placeholder="Current Login Password" data-rule-required="true" />
                                                            <input type="hidden" name="memberId" value="<?=$memberId?>" >
                                                        </div>
                                                    </div>



                                                    <div class="form-group">
                                                        <label class="control-label col-sm-3" for="new_pass">New Password :</label>
                                                        <div class="col-sm-12">
                                                        <input type="password" name="password1" id="loginPassword" class="form-control" placeholder="Enter Password" data-rule-required="true" onkeyup="matchPassword('loginPassword','confirmLoginPassword','loginPasswordErrorMsg','loginJoin')"  />
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label class="control-label col-sm-3" for="new_pass">Confirm New Password :</label>
                                                        <div class="col-sm-12">
                                                        <input type="password" id="confirmLoginPassword" placeholder="Confirm Password" class="form-control" data-rule-required="true"onkeyup="matchPassword('loginPassword','confirmLoginPassword','loginPasswordErrorMsg','loginJoin')" name="password2"  />
                                                        </div>
                                                    </div>


                                                    <div class="form-group">
                                                        <div class="col-lg-12" align="center">
                                                            <button type="submit" name="changeLogin" class="btn btn-success btn-lg" name="Submit">Update</button>
                                                        </div>
                                                    </div>
                                                </form>
                    </div>



</div>
</div>
</section>


<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>