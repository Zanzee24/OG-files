<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

  <?php require_once('Include/Menu.php');
  ?>



  <!-- Header -->
  <!--<header class="header position-fixed">-->
  <!--  <div class="row">-->
  <!--    <div class="col-auto">-->
  <!--      <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">-->
  <!--        <i class="bi bi-list"></i>-->
  <!--      </a>-->
  <!--      <img src="assets/img/logo.png" class="img-fluid" style="width:40%">-->
  <!--    </div>-->
  <!--    <div class="col text-center">-->

  <!--    </div>-->
  <!--    <div class="col-auto">-->

  <!--    </div>-->
  <!--  </div>-->
  <!--</header>-->
  <style>
    .card {
      margin-bottom: 20px;
    }
  </style>

  <!--#INCLUDE file="header.asp"-->
  <main class="h-100">
    <div class="content-wrapper">
      <div class="container-full">
        <!-- Content Header (Page header) -->


        <!-- Main content -->
        <section class="content">
          <div class="card-header">

            <h4 class="card-title text-dark">Gold ID Active History</h4>
          </div>
          <div class="row">
            <div class="card crd0">
              <div class="card-body">
                <div class="dt-ext table-responsive">
                  <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>UserId</th>
                        <th>Name</th>
                        <th>Level Plan</th>
                        <!-- <th>Join Date</th> -->
                        <th>Account Status</th>
                        <th>Active Date</th>
                        <th>Total Invest</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      function totalInvest($con, $memberId)
                      {
                        $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'");
                        $valInvest = mysqli_fetch_array($queryInvest);
                        if ($valInvest[0] != "") {
                          return $valInvest[0];
                        } else {
                          echo "0.00";
                        }
                      }
                      $count = 0;
                      $queryTeam = mysqli_query($con, "SELECT a.member_id,a.user_id,a.name,a.date_time,a.activation_date,a.topup_flag FROM meddolic_user_details a, meddolic_user_child_ids b WHERE a.member_id=b.child_id AND b.member_id='$memberId' AND b.level>=4 ORDER BY b.date_time DESC");
                      while ($valTeam = mysqli_fetch_assoc($queryTeam)) {
                        $count++; ?>
                        <tr>
                          <td><?= $count ?></td>
                          <td><?= $valTeam['user_id'] ?></td>
                          <td><?= $valTeam['name'] ?></td>
                          <td>Gold Plan </td>
                          <!-- <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTeam['date_time'])); ?></td> -->
                          <td><?php if ($valTeam['topup_flag'] == 1) echo "<span class='badge badge-success'>Active</span>";
                              else echo "<span class='badge badge-danger'>In-Active</span>"; ?></td>
                          <td><?= $valTeam['activation_date'] ?></td>
                          <td><span class="badge badge-success"> <?= totalInvest($con, $valTeam['member_id']) ?>₹</span></td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

      </div>
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->

    </div>
    </div>
    </div>
    <?php require_once('Include/Footer.php'); ?>

</body>


</html>