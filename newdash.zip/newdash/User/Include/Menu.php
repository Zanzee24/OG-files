 <aside class="app-sidebar sticky" id="sidebar">

     <div class="top-left"></div>
     <div class="top-right"></div>
     <div class="bottom-left"></div>
     <div class="bottom-right"></div>
     <!-- Start::main-sidebar-header -->
     <div class="main-sidebar-header">
         <a href="index.php" class="header-logo">
             <img src="assets/assets/images/brand-logos/desktop-logo.png" alt="logo" class="desktop-logo">
             <img src="assets/assets/images/brand-logos/toggle-dark.png" alt="logo" class="toggle-dark">
             <img src="assets/assets/images/brand-logos/desktop-dark.png" alt="logo" class="desktop-dark">
             <img src="assets/assets/images/brand-logos/toggle-logo.png" alt="logo" class="toggle-logo">
         </a>
     </div>
     <!-- End::main-sidebar-header -->

     <!-- Start::main-sidebar -->
     <div class="main-sidebar" id="sidebar-scroll">

         <!-- Start::nav -->
         <nav class="main-menu-container nav nav-pills flex-column sub-open">
             <div class="slide-left" id="slide-left">
                 <svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                     <path d="M13.293 6.293 7.586 12l5.707 5.707 1.414-1.414L10.414 12l4.293-4.293z"></path>
                 </svg>
             </div>
             <ul class="main-menu">

                 <!-- Start::slide -->
                 <li class="slide">
                     <a href="index.php" class="side-menu__item">
                         <svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" viewBox="0 0 256 256">
                             <rect width="256" height="256" fill="none" />
                             <path d="M152,208V160a8,8,0,0,0-8-8H112a8,8,0,0,0-8,8v48a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V115.54a8,8,0,0,1,2.62-5.92l80-75.54a8,8,0,0,1,10.77,0l80,75.54a8,8,0,0,1,2.62,5.92V208a8,8,0,0,1-8,8H160A8,8,0,0,1,152,208Z" opacity="0.2" />
                             <path d="M152,208V160a8,8,0,0,0-8-8H112a8,8,0,0,0-8,8v48a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V115.54a8,8,0,0,1,2.62-5.92l80-75.54a8,8,0,0,1,10.77,0l80,75.54a8,8,0,0,1,2.62,5.92V208a8,8,0,0,1-8,8H160A8,8,0,0,1,152,208Z" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                         </svg>
                         <span class="side-menu__label">Dashboard</span>
                     </a>
                 </li>
                 <li class="slide">
                     <a href="profile.php" class="side-menu__item">
                         <svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" viewBox="0 0 256 256">
                             <rect width="256" height="256" fill="none" />
                             <path d="M128,32A96,96,0,0,0,63.8,199.38h0A72,72,0,0,1,128,160a40,40,0,1,1,40-40,40,40,0,0,1-40,40,72,72,0,0,1,64.2,39.37A96,96,0,0,0,128,32Z" opacity="0.2" />
                             <circle cx="128" cy="120" r="40" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <path d="M63.8,199.37a72,72,0,0,1,128.4,0" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="200 128 224 152 248 128" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="8 128 32 104 56 128" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <path d="M32,104v24a96,96,0,0,0,174,56" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <path d="M224,152V128A96,96,0,0,0,50,72" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                         </svg>
                         <span class="side-menu__label">Profile</span>
                     </a>
                 </li>
                 <li class="slide">
                     <a href="package.php" class="side-menu__item">
                         <svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" viewBox="0 0 256 256">
                             <rect width="256" height="256" fill="none" />
                             <path d="M216,96v96a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V96Z" opacity="0.2" />
                             <rect x="24" y="56" width="208" height="40" rx="8" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <path d="M216,96v96a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V96" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <line x1="104" y1="136" x2="152" y2="136" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                         </svg>
                         <span class="side-menu__label">Purchase Package</span>
                     </a>
                 </li>
                 <li class="slide has-sub">
                     <a href="javascript:void(0);" class="side-menu__item">
                         <svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" viewBox="0 0 256 256">
                             <rect width="256" height="256" fill="none" />
                             <polygon points="32 80 128 136 224 80 128 24 32 80" opacity="0.2" />
                             <polyline points="32 176 128 232 224 176" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="32 128 128 184 224 128" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polygon points="32 80 128 136 224 80 128 24 32 80" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                         </svg>
                         <span class="side-menu__label">Fund Manager</span>
                         <i class="fa fa-chevron-right side-menu__angle"></i>
                     </a>
                     <ul class="slide-menu child1">
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">Add Fund</a>
                         </li>
                         <li class="slide">
                             <a href="fund.php" class="side-menu__item">Add Fund</a>
                         </li>
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">Fund Transfer</a>
                         </li>
                         <li class="slide">
                             <a href="Fundtrans.php" class="side-menu__item">Fund Transfer</a>
                         </li>

                     </ul>
                 </li>
                 <li class="slide has-sub">
                     <a href="javascript:void(0);" class="side-menu__item">
                         <svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" viewBox="0 0 256 256">
                             <rect width="256" height="256" fill="none" />
                             <path d="M128,36a92,92,0,1,0,92,92A92.1,92.1,0,0,0,128,36Z" opacity="0.2" />
                             <line x1="128" y1="64" x2="128" y2="192" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="104 40 128 64 152 40" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="104 216 128 192 152 216" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <line x1="72.57" y1="96" x2="183.43" y2="160" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="40 104 72.57 96 64 64" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="192 192 183.43 160 216 152" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <line x1="72.57" y1="160" x2="183.43" y2="96" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="64 192 72.57 160 40 152" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="216 104 183.43 96 192 64" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                         </svg>
                         <span class="side-menu__label">Team And Network</span>
                         <i class="fa fa-chevron-right side-menu__angle"></i>
                     </a>
                     <ul class="slide-menu child1">
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">Referral Team</a>
                         </li>
                         <li class="slide">
                             <a href="myReferral.php" class="side-menu__item">Referral Team</a>
                         </li>
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">Level Team</a>
                         </li>
                         <li class="slide">
                             <a href="levelactive.php" class="side-menu__item">Level Team</a>
                         </li>

                     </ul>
                 </li>
                 <li class="slide has-sub">
                     <a href="javascript:void(0);" class="side-menu__item">
                         <svg xmlns="http://www.w3.org/2000/svg" class="side-menu__icon" viewBox="0 0 256 256">
                             <rect width="256" height="256" fill="none" />
                             <rect x="152" y="40" width="56" height="168" opacity="0.2" />
                             <polyline points="48 208 48 136 96 136" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <line x1="224" y1="208" x2="32" y2="208" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="96 208 96 88 152 88" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                             <polyline points="152 208 152 40 208 40 208 208" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16" />
                         </svg>
                         <span class="side-menu__label">Financial Reports</span>
                         <i class="fa fa-chevron-right side-menu__angle"></i>
                     </a>
                     <ul class="slide-menu child1">
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">Direct Income</a>
                         </li>
                         <li class="slide">
                             <a href="referralIncome.php" class="side-menu__item">Direct Income</a>
                         </li>
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">Level Income</a>
                         </li>
                         <li class="slide">
                             <a href="level.php" class="side-menu__item">Level Income</a>
                         </li>
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">History</a>
                         </li>
                         <li class="slide">
                             <a href="history.php" class="side-menu__item">History</a>
                         </li>

                     </ul>
                 </li>
                 <li class="slide has-sub">
                     <a href="javascript:void(0);" class="side-menu__item">
                         <svg  class="side-menu__icon " width="24px" height="24px"version="1.1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                             <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                             <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                             <g id="SVGRepo_iconCarrier">
                                 <path d="M6 8H10"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                 <path d="M20.8333 9H18.2308C16.4465 9 15 10.3431 15 12C15 13.6569 16.4465 15 18.2308 15H20.8333C20.9167 15 20.9583 15 20.9935 14.9979C21.5328 14.965 21.9623 14.5662 21.9977 14.0654C22 14.0327 22 13.994 22 13.9167V10.0833C22 10.006 22 9.96726 21.9977 9.9346C21.9623 9.43384 21.5328 9.03496 20.9935 9.00214C20.9583 9 20.9167 9 20.8333 9Z"  stroke-width="1.5"></path>
                                 <path d="M20.965 9C20.8873 7.1277 20.6366 5.97975 19.8284 5.17157C18.6569 4 16.7712 4 13 4L10 4C6.22876 4 4.34315 4 3.17157 5.17157C2 6.34315 2 8.22876 2 12C2 15.7712 2 17.6569 3.17157 18.8284C4.34315 20 6.22876 20 10 20H13C16.7712 20 18.6569 20 19.8284 18.8284C20.6366 18.0203 20.8873 16.8723 20.965 15"  stroke-width="1.5"></path>
                                 <path d="M17.9912 12H18.0002"   stroke-linecap="round" stroke-linejoin="round"></path>
                             </g>
                         </svg>
                         <span class="side-menu__label">Wallet</span>
                         <i class="fa fa-chevron-right side-menu__angle"></i>
                     </a>
                     <ul class="slide-menu child1">
                         <li class="slide side-menu__label1">
                             <a href="javascript:void(0)">Withdrawl</a>
                         </li>
                         <li class="slide">
                             <a href="wallet.php" class="side-menu__item">Withdrawl</a>
                         </li>

                     </ul>
                 </li>
                 <!-- End::slide -->



                 <!-- Start::slide -->
                 <li class="slide">
                     <a href="support.php" class="side-menu__item">
                         <svg width="24px" height="24px" class="side-menu__icon " viewBox="0 0 512 512" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000">
                             <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                             <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                             <g id="SVGRepo_iconCarrier">
                                 <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                     <g id="support" fill="#ffffff" transform="translate(42.666667, 42.666667)">
                                         <path d="M379.734355,174.506667 C373.121022,106.666667 333.014355,-2.13162821e-14 209.067688,-2.13162821e-14 C85.1210217,-2.13162821e-14 45.014355,106.666667 38.4010217,174.506667 C15.2012632,183.311569 -0.101643453,205.585799 0.000508304259,230.4 L0.000508304259,260.266667 C0.000508304259,293.256475 26.7445463,320 59.734355,320 C92.7241638,320 119.467688,293.256475 119.467688,260.266667 L119.467688,230.4 C119.360431,206.121456 104.619564,184.304973 82.134355,175.146667 C86.4010217,135.893333 107.307688,42.6666667 209.067688,42.6666667 C310.827688,42.6666667 331.521022,135.893333 335.787688,175.146667 C313.347976,184.324806 298.68156,206.155851 298.667688,230.4 L298.667688,260.266667 C298.760356,283.199651 311.928618,304.070103 332.587688,314.026667 C323.627688,330.88 300.801022,353.706667 244.694355,360.533333 C233.478863,343.50282 211.780225,336.789048 192.906491,344.509658 C174.032757,352.230268 163.260418,372.226826 167.196286,392.235189 C171.132153,412.243552 188.675885,426.666667 209.067688,426.666667 C225.181549,426.577424 239.870491,417.417465 247.041022,402.986667 C338.561022,392.533333 367.787688,345.386667 376.961022,317.653333 C401.778455,309.61433 418.468885,286.351502 418.134355,260.266667 L418.134355,230.4 C418.23702,205.585799 402.934114,183.311569 379.734355,174.506667 Z M76.8010217,260.266667 C76.8010217,269.692326 69.1600148,277.333333 59.734355,277.333333 C50.3086953,277.333333 42.6676884,269.692326 42.6676884,260.266667 L42.6676884,230.4 C42.6676884,224.302667 45.9205765,218.668499 51.2010216,215.619833 C56.4814667,212.571166 62.9872434,212.571166 68.2676885,215.619833 C73.5481336,218.668499 76.8010217,224.302667 76.8010217,230.4 L76.8010217,260.266667 Z M341.334355,230.4 C341.334355,220.97434 348.975362,213.333333 358.401022,213.333333 C367.826681,213.333333 375.467688,220.97434 375.467688,230.4 L375.467688,260.266667 C375.467688,269.692326 367.826681,277.333333 358.401022,277.333333 C348.975362,277.333333 341.334355,269.692326 341.334355,260.266667 L341.334355,230.4 Z"> </path>
                                     </g>
                                 </g>
                             </g>
                         </svg><span class="side-menu__label">Support</span> </a>
                 </li>
                 <li class="slide">
                     <a href="login.php" class="side-menu__item">
                         <svg height="24px" width="24px" version="1.1" id="Layer_1" class="side-menu__icon " xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512 512" xml:space="preserve" fill="none">
                             <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                             <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                             <g id="SVGRepo_iconCarrier">
                                 <g transform="translate(1 1)">
                                     <g>
                                         <path style="fill:#7b8191;" d="M378.429,383c-2.743,0-4.571-0.914-6.4-2.743c-3.657-3.657-3.657-9.143,0-12.8l109.714-109.714 c3.657-3.657,9.143-3.657,12.8,0s3.657,9.143,0,12.8L384.829,380.257C383,382.086,381.171,383,378.429,383z"></path>
                                         <path style="fill:#7b8191;" d="M488.143,273.286H186.429c-5.486,0-9.143-3.657-9.143-9.143s3.657-9.143,9.143-9.143h301.714 c5.486,0,9.143,3.657,9.143,9.143S493.629,273.286,488.143,273.286z"></path>
                                     </g>
                                     <polygon style="fill:#7b8191;" points="131.571,501.857 332.714,501.857 332.714,8.143 131.571,8.143 "></polygon>
                                     <polygon style="fill:#7b8191;" points="21.857,501.857 223,501.857 223,8.143 21.857,8.143 "></polygon>
                                     <polygon style="fill:#7b8191;" points="49.286,501.857 305.286,501.857 305.286,8.143 49.286,8.143 "></polygon>
                                     <g>
                                         <path style="fill:#ffffff;" d="M378.429,373.857c-2.743,0-4.571-0.914-6.4-2.743c-3.657-3.657-3.657-9.143,0-12.8L481.743,248.6 c3.657-3.657,9.143-3.657,12.8,0s3.657,9.143,0,12.8L384.829,371.114C383,372.943,381.171,373.857,378.429,373.857z"></path>
                                         <path style="fill:#ffffff;" d="M488.143,264.143c-2.743,0-4.571-0.914-6.4-2.743L372.029,151.686c-3.657-3.657-3.657-9.143,0-12.8 c3.657-3.657,9.143-3.657,12.8,0L494.543,248.6c3.657,3.657,3.657,9.143,0,12.8C492.714,263.229,490.886,264.143,488.143,264.143z "></path>
                                         <path style="fill:#ffffff;" d="M488.143,264.143H186.429c-5.486,0-9.143-3.657-9.143-9.143c0-5.486,3.657-9.143,9.143-9.143 h301.714c5.486,0,9.143,3.657,9.143,9.143C497.286,260.486,493.629,264.143,488.143,264.143z"></path>
                                         <path style="fill:#ffffff;" d="M332.714,511H21.857c-5.486,0-9.143-3.657-9.143-9.143V8.143C12.714,2.657,16.371-1,21.857-1 h310.857c5.486,0,9.143,3.657,9.143,9.143v192c0,5.486-3.657,9.143-9.143,9.143c-5.486,0-9.143-3.657-9.143-9.143V17.286H31 v475.429h292.571V309.857c0-5.486,3.657-9.143,9.143-9.143c5.486,0,9.143,3.657,9.143,9.143v192 C341.857,507.343,338.2,511,332.714,511z"></path>
                                     </g>
                                 </g>
                             </g>
                         </svg> <span class="side-menu__label">Logout</span>
                     </a>
                 </li>
                 <!-- End::slide -->

             </ul>
             <div class="slide-right" id="slide-right"><svg xmlns="http://www.w3.org/2000/svg" fill="#7b8191" width="24" height="24" viewBox="0 0 24 24">
                     <path d="M10.707 17.707 16.414 12l-5.707-5.707-1.414 1.414L13.586 12l-4.293 4.293z"></path>
                 </svg></div>
         </nav>
         <!-- End::nav -->

     </div>
     <!-- End::main-sidebar -->

 </aside>