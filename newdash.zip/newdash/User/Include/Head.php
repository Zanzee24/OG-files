<!DOCTYPE html>
<head>

        <!-- Meta Data -->
		<meta charset="UTF-8">
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="Description" content="SciFi - PHP Premium Bootstrap 5 Admin Dashboard Template">
        <meta name="Author" content="Spruko Technologies Private Limited">
        <meta name="keywords" content="dashboard, dashboard template, php my admin, php admin dashboard, php admin template, php, admin panel, php dashboard, php backend, php admin, template admin, admin, bootstrap dashboard, admin panel template, bootstrap dashboard, bootstrap 5 admin template">
        
        <!-- TITLE -->
		<title>Zanthium</title>

        <!-- FAVICON -->
        <link rel="icon" href="assets/assets/images/brand-logos/favicon.png" type="image/x-icon">

        <!-- BOOTSTRAP CSS -->
	    <link  id="style" href="assets/assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- ICONS CSS -->
        <link href="assets/assets/css/icons.css" rel="stylesheet">
        
        <!-- STYLES CSS -->
        <link href="assets/assets/css/styles.css" rel="stylesheet">

        <!-- MAIN JS -->
        <script src="assets/assets/js/main.js"></script>

        
        <!-- NODE WAVES CSS -->
        <link href="assets/assets/libs/node-waves/waves.min.css" rel="stylesheet"> 

        <!-- SIMPLEBAR CSS -->
        <link rel="stylesheet" href="assets/assets/libs/simplebar/simplebar.min.css">

        <!-- COLOR PICKER CSS -->
        <link rel="stylesheet" href="assets/assets/libs/flatpickr/flatpickr.min.css">
        <link rel="stylesheet" href="assets/assets/libs/@simonwep/pickr/themes/nano.min.css">

        <!-- CHOICES CSS -->
        <link rel="stylesheet" href="assets/assets/libs/choices.js/public/assets/assets/styles/choices.min.css">

        <!-- CHOICES JS -->
        <script src="assets/assets/libs/choices.js/public/assets/assets/scripts/choices.min.js"></script>
        
        <!-- Jsvector Maps -->
        <link rel="stylesheet" href="assets/assets/libs/jsvectormap/css/jsvectormap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
<!-- FAVICON -->

        <!-- BOOTSTRAP CSS -->
	    <link  id="style" href="https://php.spruko.com/scifi/scifi/assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- ICONS CSS -->
        <link href="https://php.spruko.com/scifi/scifi/assets/css/icons.css" rel="stylesheet">
        
        <!-- STYLES CSS -->
        <link href="https://php.spruko.com/scifi/scifi/assets/css/styles.css" rel="stylesheet">

        <!-- MAIN JS -->
        <script src="https://php.spruko.com/scifi/scifi/assets/js/main.js"></script>

        
        <!-- NODE WAVES CSS -->
        <link href="https://php.spruko.com/scifi/scifi/assets/libs/node-waves/waves.min.css" rel="stylesheet"> 

        <!-- SIMPLEBAR CSS -->
        <link rel="stylesheet" href="https://php.spruko.com/scifi/scifi/assets/libs/simplebar/simplebar.min.css">

        <!-- COLOR PICKER CSS -->
        <link rel="stylesheet" href="https://php.spruko.com/scifi/scifi/assets/libs/flatpickr/flatpickr.min.css">
        <link rel="stylesheet" href="https://php.spruko.com/scifi/scifi/assets/libs/@simonwep/pickr/themes/nano.min.css">

        <!-- CHOICES CSS -->
        <link rel="stylesheet" href="https://php.spruko.com/scifi/scifi/assets/libs/choices.js/public/assets/styles/choices.min.css">

        <!-- CHOICES JS -->
        <script src="https://php.spruko.com/scifi/scifi/assets/libs/choices.js/public/assets/scripts/choices.min.js"></script>
        
        <!-- Jsvector Maps -->
        <link rel="stylesheet" href="https://php.spruko.com/scifi/scifi/assets/libs/jsvectormap/css/jsvectormap.min.css">


	</head>
