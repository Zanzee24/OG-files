<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
</head>
<?php
$queryConfig=mysqli_query($con,"SELECT minTransfer FROM meddolic_config_misc_setting");
    $valConfig=mysqli_fetch_assoc($queryConfig);
    $minTransfer=$valConfig['minTransfer'];
   ?>

<body class="body-scroll" data-page="index">

  <?php require_once('Include/Menu.php');
?>



  <!-- Header -->
  <header class="header position-fixed">
            <div class="row">
                <div class="col-auto">
                    <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
                </div>
                <div class="col text-right">
                    <div class="logo-small">
                        <img src="assets/img/logo.png" alt="" style=" height:50px; " />
                    </div>
                </div>

            </div>
        </header>
        
  <main class="h-100">
    <div class="content-wrapper">
      <div class="container-full">
        <!-- Content Header (Page header) -->
        <!-- Main content -->
        <section class="content">

          <!-- Basic Forms -->
          <div class="box">
            <div class="col-12">

              <!-- /.box-header -->
              <div class="box-body">
                <div class="box-header with-border">
                  <h4 class="box-title">Fund Transfer</h4>
                </div>
                <br>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="card crd0">
                      <div class="card-body">
                        <form class="theme-form" action="fundTransferProcess" method="post">
                          <div class="mb-3">
                            <label>UserId </label>
                            <input type="text" name="sponser_id" id="sponser_id" class="form-control"
                              placeholder="e.g. xxxxxxxxxx" onblur="sponser_valid(this.value)" required>
                            <input type="hidden" name="loginMemberId" value="<?=$memberId?>">
                          </div>
                          <div class="mb-3">
                            <label>Name </label>
                            <input type="text" id="sponser_name" class="form-control" placeholder="e.g. John Doe"
                              disabled="">
                          </div>
                          <div class="mb-3">
                            <label>Fund Wallet ( In $ ) *</label>
                            <input type="text" id="current_wallet" name="current_wallet" class="form-control" readonly
                              value="<?=$fundWallet?>">
                            <input type="hidden" name="minTransfer" readonly value="<?=$minTransfer?>">
                            <input type="hidden" name="maxTransfer" readonly value="<?=$maxTransfer?>">
                          </div>
                          <div class="mb-3">
                            <label>Amount To Transfer *</label>
                            <input type="number" id="transferAmount" name="amount" class="form-control"
                              placeholder="e.g. Transfer Amount" onkeypress="return onlynum(event)">
                          </div>


                          <!-- <div class="mb-3">
                            <label>Transaction Password *</label>
                            <input type="password" name="trnPassword" class="form-control"
                              placeholder="e.g. Transaction Password" required="">
                          </div> -->
                          <div class="">
                            <button type="submit" class="btn btn-primary" data-bs-original-title="" name="fundTransfer"
                              value="Transfer">Transfer</button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-6" id="paymentDetails" style="display: none;"></div>
                </div>
                <br>
                <div class="row">
                  <div class="card crd0">
                    <div class="card-header">
                      <h6>Fund Transfer History <span class="badge badge-success">$</span></h6>
                    </div>
                    <div class="table-panel">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="table-responsive">
                            <table id="example" class="table table-bordered table-custom table-hover ">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  <th>SenderId</th>
                                  <th>Sender Name</th>
                                  <th>ReceiverId</th>
                                  <th>Receiver Name</th>
                                  <th>Transfer Amount</th>
                                  <th>Transfer Date</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php 
                            $count=0;
                            $queryTransfer=mysqli_query($con,"SELECT a.amount,a.date_time,b.user_id AS senderId,b.name AS senderName,c.user_id AS receiverId,c.name AS receiverName FROM meddolic_user_fund_transfer_history a, meddolic_user_details b, meddolic_user_details c WHERE a.sender_member_id='$memberId' AND a.sender_member_id=b.member_id AND a.receiver_member_id=c.member_id ORDER BY a.date_time DESC");
                            while($valTransfer=mysqli_fetch_assoc($queryTransfer)){
                            $count++; ?>
                                <tr>
                                  <td>
                                    <?= $count ?>
                                  </td>
                                  <td>
                                    <?=$valTransfer['senderId']?>
                                  </td>
                                  <td>
                                    <?=$valTransfer['senderName']?>
                                  </td>
                                  <td>
                                    <?=$valTransfer['receiverId']?>
                                  </td>
                                  <td>
                                    <?=$valTransfer['receiverName']?>
                                  </td>
                                  <td><span class="badge badge-danger">
                                      <?= $valTransfer['amount']?> $
                                    </span></td>
                                  <td><i class="fa fa-clock-o"></i>
                                    <?= date("d-m-Y H:i:s", strtotime($valTransfer['date_time']))?>
                                  </td>
                                </tr>
                                <?php } ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>


        </section>

      </div>

    </div>
    <!-- Footer -->
    <footer class="footer" style="background:#00bcd4;">
      <div class="container">
        <ul class="nav nav-pills nav-justified">
          <li class="nav-item">
            <a class="nav-link active" href="index">
              <span>
                <i class="nav-icon bi bi-house"></i>
                <span class="nav-text">Home</span>
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="EditProfile" style="color:#000;">
              <span>
                <i class="nav-icon bi-person-circle"></i>
                <span class="nav-text">Profile</span>
              </span>
            </a>
          </li>
          <li class="nav-item centerbutton">
            <button type="button" class="nav-link" data-bs-toggle="modal" data-bs-target="#menumodal"
              id="centermenubtn">
              <span class="theme-radial-gradient">
                <i class="bi bi-grid size-22" style="color:#000;"></i>
              </span>
            </button>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="changePassword" style="color:#000;">
              <span>
                <i class="nav-icon bi-file-earmark-lock"></i>
                <span class="nav-text">Change Password</span>
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" style="color:#000;">
              <span>
                <i class="nav-icon bi bi-file-earmark-text"></i>
                <span class="nav-text">Edit Account</span>
              </span>
            </a>
          </li>

        </ul>
      </div>
    </footer>


    <?php require_once('Include/Footer.php');?>
    <script>
      function cancelFundRequest(orderId, tempId) {
        if (tempId != "") {
          if (confirm('Are you sure to Cancel this Add Fund Request?')) {
            $.ajax({
              type: "POST",
              url: 'ajaxCalls/cancelFundRequestAjax',
              data: { tempId: tempId, orderId: orderId },
              cache: false,
              success: function (data) {
                // alert(data);
                if (data) {
                  alert('Add Fund Request Cancel Successfully');
                  location.reload();
                }
              }
            });
          }
        }
      }
    </script>
</body>


</html>