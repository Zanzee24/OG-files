<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); 
    // require_once('Include/Footer.php');


  
    ?>
</head>


<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

<h2>Wallet Address</h2>


                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        <div class="col-lg-12 col-xs-12">
            <section class="box">
                <div class="content-body">
                                  <form class="form theme-form" action="userProfileAuthProcess" method="POST">
                                <div class="row">
                                    <div class="form-group col-md-4 col-sm-6">
                                        <label>Select Currency *</label>
                                        <select class="form-control" name="currencyId" required id="currencyId">
                                            <option value=""> Select One </option>
                                            <?php $queryCoin=mysqli_query($con,"SELECT * FROM meddolic_config_currency_list WHERE status=1 ORDER BY currencyName ASC");
                                    while($valCoin=mysqli_fetch_assoc($queryCoin)){ ?>
                                            <option value="<?=$valCoin['currency_id']?>">
                                                <?=$valCoin['currencyName']?>
                                            </option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4 col-sm-6">
                                        <div class="form-group">
                                            <label>Wallet Address *</label>
                                            <input class="form-control" name="walletAddress" id="walletAddress"
                                                type="text" required placeholder="Enter Wallet Address">
                                            <input type="hidden" name="memberId" value="<?=$memberId?>" />
                                        </div>
                                    </div>

                                    <!-- <div class="form-group col-md-4 col-sm-6">
                                        <div class="form-group">
                                            <label>Transaction Password *</label>
                                            <input type="password" name="trnPassword" class="form-control"
                                                placeholder="e.g. Transaction Password" required="">
                                        </div>
                                    </div> -->

                                    <!-- <div class="form-group col-md-4 col-sm-6">
                                <div class="form-group">
                                    <label>Email Verification *</label>
                                     <input placeholder="Verification Code" name="emailOtp" required type="text" class="form-control">
                                   
                                </div> 
                            </div>  
                            <div class="col-md-12">
                                <div class="form-group">
                                    <button style="margin-top:33px;padding:6px 20px 10px 20px; white-space: nowrap ;" type="button" class="btn  btn-primary  col-md-2 col-sm-3" id="emailBtn">
                                        <div class="v-btn__content" onclick="addressVerifyOTP('<?=$userId?>','<?=$emailId?>')">Send OTP <span id="count" style="visibility:hidden;">00 S</span></div>
                                    </button>  
                                </div>
                            </div>  -->

                                    <div class="card-footer text-end">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button type="submit" name="addWalletAddress"
                                                class="btn btn-primary col-md-2 col-sm-3">Save</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                    </div>

<div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">History</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
 <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Currency Name</th>
                                    <th>Wallet Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                            $count=0;
                            $queryWallet=mysqli_query($con,"SELECT a.payment_id,a.walletAddress,a.addDate,b.currencyName FROM meddolic_user_wallet_address_details a, meddolic_config_currency_list b WHERE a.member_id='$memberId' AND a.currency_id=b.currency_id AND a.status=1 ORDER BY a.addDate DESC");
                            while($valWallet=mysqli_fetch_assoc($queryWallet)){ 
                              $count++; ?>
                                <tr>
                                    <td>
                                        <?= $count?>
                                    </td>
                                    <td>
                                        <?= $valWallet['currencyName']?>
                                    </td>
                                    <td>
                                        <?= $valWallet['walletAddress']?>
                                    </td>
                                    <td><a href="javascript:void(0)" class="btn btn-danger btn-sm"
                                            onclick="deleteWalletAddress(<?=$valWallet['payment_id']?>)"><i class="fa fa-trash"></i> Delete</a></td>
                                </tr>
                                <?php } ?>
                            </tbody>
</table>
</div>
</div>

</div>
</div>
</section>


<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>
<script>
    function deleteWalletAddress(payment_id) {
    if (payment_id != '') {
      if (confirm('Are you sure to Delete this Wallet Address?')) {
        arguments
        $.ajax({
          type: 'POST',
          url: 'ajaxCalls/deleteWalletAddressAjax',
          data: {
            payment_id: payment_id,
          },
          success: function(data) {
            // console.log(data);
            if (data == true) {
              alert('Wallet Address Deleted Successfully');
              window.location.reload();
            }
          }
        });
      }
    }
  }
    $(document).ready(function () {

        $("#userid").keyup(function () {
            var userid = $('#userid').val();

            $.ajax({

                type: "POST",
                url: "refree.php",
                data: {
                    "userid": userid
                },
                success: function (response) {
                    if (response) {
                        var Username = document.getElementById('username');
                        Username.value = response;
                        $('#username').css({
                            "color": "#1ea8e7",
                            "font-weight": "bold"
                        });
                        $("#register_btn").show();
                    } else {
                        $(".ll1").show();
                        var Username = document.getElementById('username');
                        Username.value = "Invalid Userid";
                        $('#username').css({
                            "color": "#ff0000",
                            "font-weight": "bold"
                        });
                        $("#register_btn").hide();
                    }
                }
            });

        });
    });
</script>