<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>
<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                                <h2 class="card-title ">Level <?= $_GET['LevelID'] ?> View</h2>


                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
       

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                      <tr>
                        <th>#</th>
                        <th>UserId</th>
                        <th>Name</th>
                        <th>Join Date</th>
                        <th>Account Status</th>
                        <th>Active Date</th>
                        <th>Total Invest</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      function totalInvest($con, $memberId)
                      {
                        $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'");
                        $valInvest = mysqli_fetch_array($queryInvest);
                        if ($valInvest[0] != "") {
                          return $valInvest[0];
                        } else {
                          echo "0.00";
                        }
                      }
                      $count = 0;
                      $queryTeam = mysqli_query($con, "SELECT a.member_id,a.user_id,a.name,a.date_time,a.activation_date,a.topup_flag FROM meddolic_user_details a, meddolic_user_child_ids b WHERE a.member_id=b.child_id AND b.member_id='$memberId' AND b.level='$_GET[LevelID]' ORDER BY b.date_time DESC");
                      while ($valTeam = mysqli_fetch_assoc($queryTeam)) {
                        $count++; ?>
                        <tr>
                          <td><?= $count ?></td>
                          <td><?= $valTeam['user_id'] ?></td>
                          <td><?= $valTeam['name'] ?></td>
                          <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTeam['date_time'])); ?></td>
                          <td><?php if ($valTeam['topup_flag'] == 1) echo "<span class='badge badge-success'>Active</span>";
                              else echo "<span class='badge badge-danger'>In-Active</span>"; ?></td>
                          <td><?= $valTeam['activation_date'] ?></td>
                          <td><span class="badge badge-success"> <?= totalInvest($con, $valTeam['member_id']) ?>$</span></td>
                        </tr>
                      <?php } ?>
                    </tbody>
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>