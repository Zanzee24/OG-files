<!DOCTYPE html>
<html lang="en">
<?php 
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');

// Fetch user data
$queryProfile = mysqli_query($con, "SELECT date_time,sponser_id,countryId,name,user_id,email_id,phone FROM meddolic_user_details WHERE user_id='$userId'");
$valProfile = mysqli_fetch_assoc($queryProfile);
$dateTime = $valProfile['date_time'];
$sponserId = $valProfile['sponser_id'];
$countryId = $valProfile['countryId'];
$name = $valProfile['name'];
$user_id = $valProfile['user_id'];
$email_id = $valProfile['email_id'];
$phone = $valProfile['phone'];

// Get country name
$countryName = '';
if ($countryId != '') {
    $queryCountry = mysqli_query($con, "SELECT countryName FROM meddolic_config_country_list WHERE country_id='$countryId'");
    $valCountry = mysqli_fetch_assoc($queryCountry);
    $countryName = $valCountry['countryName'];
}

// Get sponsor user id
$sponserUserId = '';
if ($sponserId != '') {
    $querySponser = mysqli_query($con, "SELECT user_id FROM meddolic_user_details WHERE member_id='$sponserId'");
    $valSponser = mysqli_fetch_assoc($querySponser);
    $sponserUserId = $valSponser['user_id'];
}
?>
</head>

<body class="body-scroll" data-page="index">

<!-- Header -->
<header class="header position-fixed">
    <div class="row">
        <div class="col-auto">
            <a href="javascript:void(0)" class="btn btn-light btn-44 menu-btn">
                <i class="bi bi-list"></i>
            </a>
        </div>
        <div class="col text-right">
            <div class="logo-small">
                <img src="assets/img/logo.png" alt="" style="height:50px;" />
            </div>
        </div>
    </div>
</header>

<main class="h-100">
    <div class="content-wrapper">
        <div class="container-full">
            <section class="content">
                <div class="box">
                    <div class="col-12">
                        <div class="box-header with-border">
                            <h4 style='padding-left:20px' class="text-black">MY I-CARD</h4>
                        </div>
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12 mb-3 text-right">
                                    <button class="btn btn-primary" id="downloadIcardBtn">
                                        <i class="fa fa-download me-1"></i> Download I-Card
                                    </button>
                                </div>

                                <div class="col-md-12 d-flex justify-content-center">
                                    <div id="icardArea" class="card icard-modern">
                                        <div class="card-body">
                                            <!-- <div class="bg-top-left"></div>
                                            <div class="bg-top-right"></div>
                                            <div class="bg-bottom"></div> -->

                                            <img src="assets/img/logo.png" alt="logo" class="logo-img" />

                                            <div class="profile-pic-wrapper">
                                                <img src="assets/img/user.png" alt="Profile image" />
                                            </div>
                                            <div class="name"><?= $name ?> </div>
                                            <div class="info-list">
                                                <div class="d-flex">
                                                    <div class="info-label">ID</div>
                                                    <div class="info-value">: <?= $user_id ?> </div>
                                                </div>
                                                <div class="d-flex">
                                                    <div class="info-label">Phone</div>
                                                    <div class="info-value">: <?= $phone ?> </div>
                                                </div>
                                                <div class="">
                                                    <div class="info-label">Email :</div>
                                                    <div class="info-value"> <?= $email_id ?> </div>
                                                </div>
                                                <div class="d-flex mt-2">
                                                    <div class="info-label">Sponsor</div>
                                                    <div class="info-value">: <?= $sponserUserId ?> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Spacer -->
                                <div class="col-md-12 mt-4"></div>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</main>

<?php require_once('Include/Footer.php'); ?>

<!-- ID Card Styles -->
<style>
.id-card {
    position: relative;
    width: 320px;
    height: 510px;
    box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.3);
    overflow: hidden;
    background: white;
    padding: 6rem 2rem 3rem 2rem;
    text-align: center;
}
.bg-top-left, .bg-top-right, .bg-bottom {
    position: absolute;
    z-index: 1;
}
.bg-top-left {
    top: 0; left: 0; width: 180px; height: 180px;
    background-color: #032c3a;
    border-bottom-right-radius: 100% 100%;
}
.bg-top-right {
    top: 0; right: 0; width: 140px; height: 140px;
    background-color: #054152;
    border-bottom-left-radius: 100% 100%;
}
.bg-bottom {
    bottom: 0; left: 0; width: 100%; height: 80px;
    background-color: #09182eff;
    border-top-left-radius: 100% 100%;
    border-top-right-radius: 100% 100%;
}
.logo-img {
    position: absolute;
    top: 1rem;
    left: 1rem;
    width: 60px;
    z-index: 5;
}
.profile-pic-wrapper {
    width: 128px;
    border-radius: 50%;
    height: 128px;
    border: 4px solid #ffff00;
    margin: 0 auto;
    background: white;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.15);
    z-index: 3;
}
.profile-pic-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.name {
    margin-top: 1.5rem;
    font-weight: 700;
    font-size: 1.125rem;
    color: #ffffffff;
    position: relative;
    z-index: 3;
}
.info-list {
    margin-top: 3%;
    font-weight: 600;
    font-size: 0.875rem;
    color: #ffffffff;
    text-align: left;
    z-index: 3;
    position: relative;
}
.info-list .d-flex {
    margin-bottom: 0.75rem;
}
.info-label {
    flex: 0 0 25%;
}
.info-value {
    flex: 1;
}
</style>

<!-- Download Button Script -->
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<script>
document.getElementById('downloadIcardBtn').addEventListener('click', function () {
    var icard = document.getElementById('icardArea');
    html2canvas(icard).then(function (canvas) {
        var link = document.createElement('a');
        link.download = 'my-icard.png';
        link.href = canvas.toDataURL();
        link.click();
    });
});
</script>


</body>
</html>
