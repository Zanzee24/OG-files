
<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1" >

    <?php 
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>


    <body>

       
        <!-- PAGE -->
        <div class="page">

            <!-- MAIN-CONTENT -->
            
        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <!-- Start:: row-1 -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card custom-card">
                            <div class="top-left"></div>
                            <div class="top-right"></div>
                            <div class="bottom-left"></div>
                            <div class="bottom-right"></div>
                            <div class="card-body">
                                <div class="d-sm-flex flex-wrap align-items-start gap-5 p-2 border-bottom-0">
                                    <div>
                                        <div class="d-flex align-items-center gap-2 mb-4">
                                            <div class="lh-1">
                                                <span class="avatar avatar-xxl online me-3">
                                                    <img src="https://php.spruko.com/scifi/scifi/assets/images/faces/22.jpg" alt="">
                                                </span>
                                            </div>
                                            <div class="flex-fill main-profile-info">
                                                <div class="d-flex align-items-center justify-content-between mb-1">
                                                    <h5 class="fw-medium mb-1">Anthony Richel</h5>
                                                </div>
                                                <p class="mb-1 text-muted op-7">Managing Director(M.D)</p>
                                                <p class="fs-12 mb-0 op-5">
                                                    <span class=""><i class="ri-map-pin-line me-1 d-inline-block"></i>Suite 456,New York,</span> 
                                                    <span> USA</span> 
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="ms-auto">
                                        <a href="profile-settings.php" class="btn btn-outline-primary"><i class="ri-settings-3-line me-1 d-inline-block"></i>Profile Settings</a>
                                    </div> -->
                                </div>
                                
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- End:: row-1 -->

                <!-- Start::row-2 -->
                <div class="row">
                    <div class="col-xxl-9 col-xl-12">
                        <div class="row">
                            
                                   
                        <div class="col-xl-9">
                            
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="row mt-4 justify-content-center">
                                        <div class="col-md-3">
                                         
                                            <div class="nav flex-column nav-pills me-3 tab-style-7" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                                <h6 class="fw-medium mb-3 text-info  fs-12 pb-1 d-inline-block">
                                                    Profile Settings
                                                </h6>
                                                <button class="nav-link text-start active" id="main-profile-tab" data-bs-toggle="pill" data-bs-target="#main-profile" type="button" role="tab" aria-controls="main-profile" aria-selected="true"><i class="fa fa-user-pen  me-2 align-middle d-inline-block"></i>Profile Info</button>
                                                <button class="nav-link text-start" id="man-password-tab" data-bs-toggle="pill" data-bs-target="#man-password" type="button" role="tab" aria-controls="man-password" aria-selected="false" tabindex="-1"><i class="fa fa-key me-2 align-middle d-inline-block"></i>Change Password</button>
                                                <button class="nav-link text-start" id="main-security-tab" data-bs-toggle="pill" data-bs-target="#main-security" type="button" role="tab" aria-controls="main-security" aria-selected="false" tabindex="-1"><i class="fa fa-lock me-2 align-center d-inline-block"></i>Change Transaction Password</button>
                                                <button class="nav-link text-start" id="main-contacts-tab" data-bs-toggle="pill" data-bs-target="#main-contacts" type="button" role="tab" aria-controls="main-contacts" aria-selected="false" tabindex="-1"><i class="fa fa-wallet me-2 align-middle d-inline-block"></i>Add Wallet Address</button>
                                            </div>
                                        </div>
                                        <div class="col-md-9">
                                            <div class="tab-content" id="v-pills-tabContent">
                                                <div class="tab-pane show active" id="main-profile" role="tabpanel" tabindex="0" aria-labelledby="main-profile-tab">
                                                    <div class="mb-4 d-sm-flex align-items-center gap-1 flex-wrap">
                                                        <span class="mb-0 me-3 avatar avatar-xxl">
                                                            <img src="https://php.spruko.com/scifi/scifi/assets/images/faces/22.jpg" alt="" class="profile-img">
                                                            <span class="badge bg-primary avatar-badge cursor-pointer">
                                                                <input type="file" name="photo" class="position-absolute w-100 op-0 profile-change">
                                                                <i class="fa fa-camera"></i>
                                                            </span>
                                                        </span>
                                                        <div class="">
                                                            <div class="fw-medium lh-1"> Anthony Richel</div>
                                                            <div class="fs-12 text-muted">@anthonyrich144</div>
                                                        </div>
                                                        <div class="ms-auto">
                                                            <div class="d-flex gap-2">
                                                                <div class="upload-btn-wrapper">
                                                                    <button class="btn btn-primary-light"><i class="fa fa-upload me-2 d-inline-block"></i>Upload Photo</button>
                                                                    <input type="file" class="profile-change" name="myfile" />
                                                                </div>
                                                                <button class="btn btn-danger-light"><i class="fa fa-x me-2 d-inline-block"></i>Delete Photo</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row gy-4 mb-4">
                                                        <div class="col-xl-6">
                                                            <label for="first-name" class="form-label">First Name :</label>
                                                            <input type="text" class="form-control" id="first-name" placeholder="First Name">
                                                        </div>
                                                        <div class="col-xl-6">
                                                            <label for="last-name" class="form-label">Last Name :</label>
                                                            <input type="text" class="form-control" id="last-name" placeholder="Last Name">
                                                        </div>
                                                        <div class="col-xl-12">
                                                            <label for="user-name" class="form-label">User Name :</label>
                                                            <input type="text" class="form-control" id="user-name" placeholder="Anthony Richel">
                                                        </div>
                                                    </div>
                                                    <div class="row mb-4">
                                                        <h6 class="fw-medium mb-3">
                                                            About Information :
                                                        </h6>
                                                        
                                                        <div class="col-xl-12 mb-4">
                                                            <label for="language" class="form-label">Language :</label>
                                                            <select class="form-control" name="language" data-trigger id="language" multiple>
                                                            <option value="Choice 1" selected>English</option>
                                                            <option value="Choice 2">French</option>
                                                            <option value="Choice 3">Arabic</option>
                                                            <option value="Choice 4">Hindi</option>
                                                            </select>
                                                        </div>
                                                        <div class="col-xl-12">
                                                            <label class="form-label">Country :</label>
                                                            <select class="form-control" data-trigger name="country-select" id="country-select">
                                                                <option value="Choice 1">Usa</option>
                                                                <option value="Choice 2">Australia</option>
                                                                <option value="Choice 3">Dubai</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="man-password" role="tabpanel" tabindex="0" aria-labelledby="man-password-tab">
                                                    <div>
                                                        <p class="fs-12 text-muted"><i class="fa fa-info me-2 align-middle d-inline-block text-info"></i>Password should be min of <b class="text-success">8 digits<sup>*</sup></b>,atleast <b class="text-success">One Capital letter<sup>*</sup></b> and <b class="text-success">One Special Character<sup>*</sup></b> included.</p>
                                                        <div class="mb-2">
                                                            <label for="current-password" class="form-label">Current Password</label>
                                                            <input type="password" class="form-control" id="current-password" placeholder="Current Password">
                                                        </div>
                                                        <div class="mb-2">
                                                            <label for="new-password" class="form-label">New Password</label>
                                                            <input type="password" class="form-control" id="new-password" placeholder="New Password">
                                                        </div>
                                                        <div class="mb-4">
                                                            <label for="confirm-password" class="form-label">Confirm Password</label>
                                                            <input type="password" class="form-control" id="confirm-password" placeholder="Confirm PAssword">
                                                        </div>
                                                        <div class="btn-list">
                                                            <button class="btn btn-primary">Change Password</button>
                                                            <button class="btn btn-primary-light">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="main-security" role="tabpanel" aria-labelledby="main-security-tab" tabindex="0">
                                                   <div>
                                                        <p class="fs-12 text-muted"><i class="fa fa-info me-2 align-middle d-inline-block text-info"></i>Password should be min of <b class="text-success">8 digits<sup>*</sup></b>,atleast <b class="text-success">One Capital letter<sup>*</sup></b> and <b class="text-success">One Special Character<sup>*</sup></b> included.</p>
                                                        <div class="mb-2">
                                                            <label for="current-password" class="form-label">Current Transaction Password</label>
                                                            <input type="password" class="form-control" id="current-password" placeholder="Current Password">
                                                        </div>
                                                        <div class="mb-2">
                                                            <label for="new-password" class="form-label">New Transaction Password</label>
                                                            <input type="password" class="form-control" id="new-password" placeholder="New Password">
                                                        </div>
                                                        <div class="mb-4">
                                                            <label for="confirm-password" class="form-label">Confirm Transaction Password</label>
                                                            <input type="password" class="form-control" id="confirm-password" placeholder="Confirm PAssword">
                                                        </div>
                                                        <div class="btn-list">
                                                            <button class="btn btn-primary">Change Password</button>
                                                            <button class="btn btn-primary-light">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="main-contacts" role="tabpanel" aria-labelledby="main-contacts-tab" tabindex="0">
                                                    <div class="row">
                                    <div class="form-group col-md-4 col-sm-6">
                                        <label>Select Currency *</label>
                                        <select class="form-control" name="currencyId" required id="currencyId">
                                            <option value=""> Select One </option>
                                            <option value=""> USD </option>
                                            <option value=""> INR One </option>
                                           
                                        </select>
                                    </div>
                                    <div class="form-group col-md-4 col-sm-6">
                                        <div class="form-group">
                                            <label>Wallet Address *</label>
                                            <input class="form-control" name="walletAddress" id="walletAddress"
                                                type="text" required placeholder="Enter Wallet Address">
                                            <input type="hidden" name="memberId" value="<?=$memberId?>" />
                                        </div>
                                    </div>

                                    
                                </div>
                                                </div>
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-footer text-end">
                                    <div class="btn-list">
                                        <button class="btn btn-primary">Save Changes</button>
                                        <button class="btn btn-primary-light">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                   
             
                    <div class="col-xxl-3 col-xl-12">
                        <div class="card custom-card">
                            <div class="top-left"></div>
                            <div class="top-right"></div>
                            <div class="bottom-left"></div>
                            <div class="bottom-right"></div>
                            <div class="card-header">
                                <div class="card-title">
                                    Personal Info
                                </div>
                            </div>
                            <div class="card-body">
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <div class="me-2 fw-medium">
                                                Name :
                                            </div>
                                            <span class="fs-12 text-muted">Anthony Richel</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <div class="me-2 fw-medium">
                                                Email :
                                            </div>
                                            <span class="fs-12 text-muted">jameslucas457@gmail.com</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <div class="me-2 fw-medium">
                                                Phone :
                                            </div>
                                            <span class="fs-12 text-muted">+(222) 222-4251</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <div class="me-2 fw-medium">
                                                Designation :
                                            </div>
                                            <span class="fs-12 text-muted">Managing Director</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <div class="me-2 fw-medium">
                                                Age :
                                            </div>
                                            <span class="fs-12 text-muted">27</span>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-flex flex-wrap align-items-center">
                                            <div class="me-2 fw-medium">
                                                Experience :
                                            </div>
                                            <span class="fs-12 text-muted">15 Years</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <!--End::row-2 -->

            </div>
        </div>
        <!-- End::app-content -->


            <!-- END MAIN-CONTENT -->

            <!-- SEARCH-MODAL -->
            
                      
            <!-- END SEARCH-MODAL -->

          

           <?php include 'Include/footer.php'; ?>

    </body>
</html><!-- This code use for render base file -->