
<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-toggled="close" data-vertical-style="default" data-card-style="style1" data-card-background="background1" >

    <head>

        <!-- Meta Data -->
		<meta charset="UTF-8">
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="Description" content="SciFi - PHP Premium Bootstrap 5 Admin Dashboard Template">
        <meta name="Author" content="Spruko Technologies Private Limited">
        <meta name="keywords" content="dashboard, dashboard template, php my admin, php admin dashboard, php admin template, php, admin panel, php dashboard, php backend, php admin, template admin, admin, bootstrap dashboard, admin panel template, bootstrap dashboard, bootstrap 5 admin template">
        
        <!-- TITLE -->
		<title>Zanthium </title>

        <!-- FAVICON -->
        <link rel="icon" href="assets/assets/images/brand-logos/logo.png" type="image/x-icon">

        <!-- BOOTSTRAP CSS -->
	    <link  id="style" href="https://php.spruko.com/scifi/scifi/assets/libs/bootstrap/css/bootstrap.min.css" rel="stylesheet">

        <!-- ICONS CSS -->
        <link href="https://php.spruko.com/scifi/scifi/assets/css/icons.css" rel="stylesheet">
        
        <!-- STYLES CSS -->
        <link href="https://php.spruko.com/scifi/scifi/assets/css/styles.css" rel="stylesheet">

        <!-- MAIN JS -->
        <script src="https://php.spruko.com/scifi/scifi/assets/js/authentication-main.js"></script>

        



	</head>

    <body class="bg-white">

        

            <div class="row authentication mx-0">
                <div class="col-xxl-6 col-xl-6 col-lg-7 d-xl-block d-none px-0">
                    <div class="authentication-cover bg-primary">
                        <div class="authentication-cover-image">
                            <div class="text-start">
                                <h1 class="text-fixed-white mb-1 fw-medium">Welcome!</h1>
                                <p class="text-fixed-white mb-1">Let's get Started with our product just sign up with simple process and make your requirements .There are many variations of passages of Lorem Ipsum available.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-6 col-xl-6 col-lg-12">
                    <div class="row justify-content-center align-items-center h-100">
                        <div class="col-xxl-6 col-xl-9 col-lg-6 col-md-6 col-sm-8 col-12">
                            <div class="card custom-card shadow-none my-4">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body p-5">
                                    <div class="mb-3 d-flex justify-content-center">
                                        <a href="index.php">
                                            <img src="assets/assets/images/brand-logos/logo.png" alt="logo" class="desktop-dark " style="width: 100px; height: 100px;">
                                        </a>
                                    </div>
                                    <p class="h5 mb-2 text-center">Sign In</p>
                                    <p class="mb-4 text-muted op-7 fw-normal text-center">Welcome back Anthony !</p>
                                    
                                    <div class="text-center my-3 authentication-barrier">
                                        <span>OR</span>
                                    </div>
                                    <div class="row gy-3">
                                        <div class="col-xl-12">
                                            <label for="signin-username" class="form-label text-default">User Name</label>
                                            <input type="text" class="form-control" id="signin-username" placeholder="user name">
                                        </div>
                                        <div class="col-xl-12 mb-2">
                                            <label for="signin-password" class="form-label text-default d-block">Password<a href="Changepass.php" class="float-end text-danger">Forget password ?</a></label>
                                            <div class="position-relative">
                                                <input type="password" class="form-control create-password-input" id="signin-password" placeholder="password">
                                                <a href="javascript:void(0);" class="show-password-button text-muted" onclick="createpassword('signin-password',this)" id="button-addon2"></a>
                                            </div>
                                            <div class="mt-2">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                                                    <label class="form-check-label text-muted fw-normal" for="defaultCheck1">
                                                        Remember password ?
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-grid mt-4">
                                        <a href="index.php" class="btn btn-primary">Sign In</a>
                                    </div>
                                    <div class="text-center">
                                        <p class="text-muted mt-3 mb-0">Dont have an account? <a href="signup.php" class="text-primary">Sign Up</a></p>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        <!-- SCRIPTS -->

        <!-- BOOTSTRAP JS -->
        <script src="https://php.spruko.com/scifi/scifi/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>

        
        <!-- Swiper JS -->
        <script src="https://php.spruko.com/scifi/scifi/assets/libs/swiper/swiper-bundle.min.js"></script>

        <!-- Internal Authentication JS -->
        <script src="https://php.spruko.com/scifi/scifi/assets/js/authentication.js"></script>
        
        <!-- Show Password JS -->
        <script src="https://php.spruko.com/scifi/scifi/assets/js/show-password.js"></script>


        <!-- END SCRIPTS -->

	</body>
</html>

<!-- This code use for render base file -->