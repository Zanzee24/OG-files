<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Billionaire Club  | FORGET PASSWORD</title>
    <link rel="icon" href="../User/assets/favicon.png" type="image/x-icon">


    <link href="assets/f1/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="assets/f1/lib/Ionicons/css/ionicons.css" rel="stylesheet">

    <link rel="stylesheet" href="assets/f1/css/style.css">
    <link rel="stylesheet" href="assets/assets/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600&family=Roboto&display=swap" />
	<!-- Icons CSS -->
	<link rel="stylesheet" href="assets/assets/css/icons.css" />
	<!-- App CSS -->
	<link rel="stylesheet" href="assets/assets/css/app.css" />
</head>
<?php require('../conection.php');
error_reporting(1);
unset($_SESSION['passTokenSet']);
$randToken=rand(1111,9999).time().date('s');
$_SESSION['passTokenSet']=md5($randToken); ?>
<body class="bg-theme bg-theme1">
	<!-- wrapper -->
	<div class="wrapper">
		<div class="authentication-forgot d-flex align-items-center justify-content-center">
			<div class="card shadow-lg forgot-box">
				<div class="card-body p-md-5">
					<div class="text-center">
						<img src="assets/img/logo.png" width="140" alt="" />
					</div>
					<h4 class="mt-5 font-weight-bold text-white">Forgot Password?</h4>
					<p class="">Enter your registered email ID to reset the password</p>
					<div class="form-group mt-5">
						<!-- <form method="post" action="con-login"> -->
						<form method="post" action="">
                <div class="form-group">
                <input type="text" class="form-control" id="inputUserId" name="inputUserId" placeholder="Enter User Id" required value="<?php if(isset($_COOKIE["memberUserId"])) { echo $_COOKIE["memberUserId"]; }?>"  />
                </div>
                <div class="form-group">
                <input id="inputEmailId" name="inputEmailId" class="form-control mb-4" type="email" placeholder="Enter Your Email Id Email Id" >
                   
                </div>
                <button  class="btn btn-light btn-lg btn-block radius-30" type="button" id="passSubmit" onclick="forgotPassValidate('<?=$_SESSION['passTokenSet']?>')">Reset </button>
            </form>
					</div>
					 <a href="LoginAuth.php" class="btn btn-link btn-block"><i class='bx bx-arrow-back mr-1'></i>Back to Login</a>
				</div>
			</div>
		</div>
	</div>
	<!-- end wrapper -->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<!--Password show & hide js -->
	<script>
		$(document).ready(function () {
			$("#show_hide_password a").on('click', function (event) {
				event.preventDefault();
				if ($('#show_hide_password input').attr("type") == "text") {
					$('#show_hide_password input').attr('type', 'password');
					$('#show_hide_password i').addClass("bx-hide");
					$('#show_hide_password i').removeClass("bx-show");
				} else if ($('#show_hide_password input').attr("type") == "password") {
					$('#show_hide_password input').attr('type', 'text');
					$('#show_hide_password i').removeClass("bx-hide");
					$('#show_hide_password i').addClass("bx-show");
				}
			});
		});
	</script>


    <script src="assets/f1/lib/jquery/jquery.js"></script>
    <script src="assets/f1/lib/popper.js/popper.js"></script>
    <script src="assets/f1/lib/bootstrap/bootstrap.js"></script>
      <script src="custom.js"></script>

      </body>
</html>