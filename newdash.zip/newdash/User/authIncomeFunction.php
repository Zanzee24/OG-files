<?php
function totalUserInvest($con, $memberId)
{
  $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'");
  $valInvest = mysqli_fetch_array($queryInvest);
  if ($valInvest[0] != "") {
    return $valInvest[0];
  } else {
    return "0.00";
  }
}

function totalLevelInvest($con, $memberId, $level)
{
  $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$memberId' AND level='$level')");
  $valInvest = mysqli_fetch_array($queryInvest);
  if ($valInvest[0] != "") {
    return $valInvest[0];
  } else {
    return "0.00";
  }
}
//Wallet Add & Statement Add Code Starts//
function incomeEntry($con, $memberId, $trnId, $incomeAmount, $statementId, $d)
{
  mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (member_id,wallet_statement_id,deb_cr,amount,date_time,trn_id) VALUES ('$memberId','$statementId',2,'$incomeAmount','$d','$trnId')");
  mysqli_query($con, "UPDATE meddolic_user_details SET wallet=wallet+'$incomeAmount' WHERE member_id='$memberId'");
}
//Wallet Add & Statement Add Code Ends//

//Matrix Placeholder Code Start
function matrixPlaceSet($con, $memberId, $d)
{
  $query_main = mysqli_query($con, "SELECT placeholderId,legPosition,topup_flag FROM meddolic_user_details WHERE member_id='$memberId'");
  $val_main = mysqli_fetch_array($query_main);
  $parentId = $val_main[0];
  $legPosition = $val_main[1];
  $topup_flag = $val_main[2];
  $level = 1;
  while ($parentId && $level <= 100) {
    mysqli_query($con, "INSERT INTO meddolic_user_matrix_team (`memberId`,`childId`,`legPosition`,`level`,`dateTime`) VALUES ('$parentId',$memberId,'$legPosition','$level','$d')");

    $queryMain = mysqli_query($con, "SELECT placeholderId,legPosition FROM meddolic_user_details WHERE member_id='$parentId'");
    $valMain = mysqli_fetch_array($queryMain);
    $parentId = $valMain[0];
    $legPosition = $valMain[1];
    $level++;
  }
}
function matrixTree($con, $memberId, $d)
{
  $queryTree = mysqli_query($con, "SELECT member_id,sponser_id FROM meddolic_user_details WHERE member_id='$memberId'");
  while ($valTree = mysqli_fetch_array($queryTree)) {
    $member_id = $valTree['member_id'];
    $sponser_id = $valTree['sponser_id'];
    $position = 0;
    $parent_id[] = 1;
    unset($parent_id);
    $parent_id[0] = $sponser_id;
    while ($parent_id[$position]) {
      //Leg 1 for Left Code
      $queryInner = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE placeholderId='$parent_id[$position]' AND legPosition=2");
      $valInner = mysqli_fetch_array($queryInner);
      if ($valInner[0] == 0) {
        mysqli_query($con, $queryInner = "UPDATE meddolic_user_details SET placeholderId='$parent_id[$position]',legPosition=2 WHERE member_id='$member_id'");
        matrixPlaceSet($con, $member_id, $d);
        break;
      } else {
        $queryInner = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE placeholderId='$parent_id[$position]' AND legPosition=2");
        $valInner = mysqli_fetch_array($queryInner);
        $parent_id[sizeof($parent_id)] = $valInner[0];
      }
      // Leg 1 For Left Code End

      // Leg 2 For Right Code Start
      $queryInner = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE placeholderId='$parent_id[$position]' AND legPosition=3");
      $valInner = mysqli_fetch_array($queryInner);
      if ($valInner[0] == 0) {
        mysqli_query($con, $queryInner = "UPDATE meddolic_user_details SET placeholderId='$parent_id[$position]',legPosition=3 WHERE member_id='$member_id'");
        matrixPlaceSet($con, $member_id, $d);
        break;
      } else {
        $queryInner = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE placeholderId='$parent_id[$position]' AND legPosition=3");
        $valInner = mysqli_fetch_array($queryInner);
        $parent_id[sizeof($parent_id)] = $valInner[0];
      }
      //Leg 2 For Right Code End
      $position++;
    }
  }
}
//Placeholder set here End

// Level income start
function releaseLevelIncome($con, $memberId, $packageId, $investAmount, $d)
{
  $queryMain = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.sponser_id=b.member_id");
  $valMain = mysqli_fetch_assoc($queryMain);
  $parentId = $valMain['sponser_id'];
  $topupFlag = $valMain['topup_flag'];


  $level = 1;
  while ($parentId && $level <= 5) {
    if ($topupFlag == 1) {
      $queryConfig = mysqli_query($con, "SELECT levelPercent FROM meddolic_config_level_income WHERE level='$level'");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $levelPercent = $valConfig['levelPercent'];

      $levelIncome = 100;
      $incomeWallteEntery = 0;
      
      if ($level != 3) {
        $incomeWallteEntery = 1;
      } else {
        $queryCount = mysqli_query($con, "SELECT Count(1) FROM meddolic_user_level_income WHERE memberId='$parentId' AND level=3");
        $valCount = mysqli_fetch_array($queryCount);
        $countIncome = $valCount[0];

        if ($countIncome > 10) {
          $incomeWallteEntery = 1;
          $queryMatrix = mysqli_query($con, "SELECT Count(1) FROM meddolic_user_level_income1 WHERE memberId='$parentId' AND level=1");
          $valMatrix = mysqli_fetch_array($queryMatrix);
          $countMatrix = $valMatrix[0];

          if ($countMatrix == 0) {
            $investAmount = 1000;
            $packageId = 1;
             Matrix1Income($con, $parentId, $packageId, $investAmount, $d);
          }
        } else {
          $incomeWallteEntery = 0;
        }

      }
      if ($incomeWallteEntery == 1) {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income (memberId,levelIncome,level,levelPercent,dateTime) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d')");
        $investInId = $con->insert_id;
        incomeEntry($con, $parentId, $investInId, $levelIncome, 1, $d);
      } else {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income (memberId,levelIncome,level,levelPercent,dateTime,status) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d',0)");
      }
    }
    $querylevel = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$parentId' AND a.sponser_id=b.member_id");
    $valLevel = mysqli_fetch_assoc($querylevel);
    $parentId = $valLevel['sponser_id'];
    $topupFlag = $valLevel['topup_flag'];
    $level++;
  }
}
// Level Income End 

// matrix income 1  here
function Matrix1Income($con, $memberId, $packageId, $investAmount, $d)
{
  $queryMain = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.sponser_id=b.member_id");
  $valMain = mysqli_fetch_assoc($queryMain);
  $parentId = $valMain['sponser_id'];
  $topupFlag = $valMain['topup_flag'];


  $level = 1;
  while ($parentId && $level <= 5) {
    if ($topupFlag == 1) {
      $queryConfig = mysqli_query($con, "SELECT levelPercent FROM meddolic_config_level_income WHERE level='$level'");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $levelPercent = $valConfig['levelPercent'];
      $levelIncome = 1000;
      $incomeWallteEntery = 0;
      
      if ($level != 3) {
        $incomeWallteEntery = 1;
      } else {
        $queryCount = mysqli_query($con, "SELECT Count(1) FROM meddolic_user_level_income1 WHERE memberId='$parentId' AND level=3");
        $valCount = mysqli_fetch_array($queryCount);
        $countIncome = $valCount[0];

        if ($countIncome > 10) {
          $incomeWallteEntery = 1;
          $queryMatrix = mysqli_query($con, "SELECT Count(1) FROM meddolic_user_level_income2 WHERE memberId='$parentId' AND level=1");
          $valMatrix = mysqli_fetch_array($queryMatrix);
          $countMatrix = $valMatrix[0];

          if ($countMatrix == 0) {
            $investAmount = 10000;
            $packageId = 2;
             Matrix2Income($con, $parentId, $packageId, $investAmount, $d);
          }
        } else {
          $incomeWallteEntery = 0;
        }

      }
      if ($incomeWallteEntery == 1) {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income1 (memberId,levelIncome,level,levelPercent,dateTime) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d')");
        $investInId = $con->insert_id;
        incomeEntry($con, $parentId, $investInId, $levelIncome, 1, $d);
      } else {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income1 (memberId,levelIncome,level,levelPercent,dateTime,status) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d',0)");
      }
    }
    $querylevel = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$parentId' AND a.sponser_id=b.member_id");
    $valLevel = mysqli_fetch_assoc($querylevel);
    $parentId = $valLevel['sponser_id'];
    $topupFlag = $valLevel['topup_flag'];
    $level++;
  }
}
// matrix income 1  END

// matrix income 2  here
function Matrix2Income($con, $memberId, $packageId, $investAmount, $d)
{
  $queryMain = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.sponser_id=b.member_id");
  $valMain = mysqli_fetch_assoc($queryMain);
  $parentId = $valMain['sponser_id'];
  $topupFlag = $valMain['topup_flag'];


  $level = 1;
  while ($parentId && $level <= 5) {
    if ($topupFlag == 1) {
      $queryConfig = mysqli_query($con, "SELECT levelPercent FROM meddolic_config_level_income WHERE level='$level'");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $levelPercent = $valConfig['levelPercent'];
      $levelIncome = 10000;
      
      $incomeWallteEntery = 0;
      
      if ($level != 3) {
        $incomeWallteEntery = 1;
      } else {
        $queryCount = mysqli_query($con, "SELECT Count(1) FROM meddolic_user_level_income2 WHERE memberId='$parentId' AND level=3");
        $valCount = mysqli_fetch_array($queryCount);
        $countIncome = $valCount[0];

        if ($countIncome > 10) {
          $incomeWallteEntery = 1;
          $queryMatrix = mysqli_query($con, "SELECT Count(1) FROM meddolic_user_level_income3 WHERE memberId='$parentId' AND level=1");
          $valMatrix = mysqli_fetch_array($queryMatrix);
          $countMatrix = $valMatrix[0];

          if ($countMatrix == 0) {
            $investAmount = 100000;
            $packageId = 3;
             Matrix3Income($con, $parentId, $packageId, $investAmount, $d);
          }
        } else {
          $incomeWallteEntery = 0;
        }

      }
      if ($incomeWallteEntery == 1) {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income2 (memberId,levelIncome,level,levelPercent,dateTime) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d')");
        $investInId = $con->insert_id;
        incomeEntry($con, $parentId, $investInId, $levelIncome, 1, $d);
      } else {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income2 (memberId,levelIncome,level,levelPercent,dateTime,status) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d',0)");
      }
    }
    $querylevel = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$parentId' AND a.sponser_id=b.member_id");
    $valLevel = mysqli_fetch_assoc($querylevel);
    $parentId = $valLevel['sponser_id'];
    $topupFlag = $valLevel['topup_flag'];

    $level++;
  }
}
// matrix income 2  END

// matrix income 3  here
function Matrix3Income($con, $memberId, $packageId, $investAmount, $d)
{
  $queryMain = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.sponser_id=b.member_id");
  $valMain = mysqli_fetch_assoc($queryMain);
  $parentId = $valMain['sponser_id'];
  $topupFlag = $valMain['topup_flag'];


  $level = 1;
  while ($parentId && $level <= 5) {
    if ($topupFlag == 1) {
      $queryConfig = mysqli_query($con, "SELECT levelPercent FROM meddolic_config_level_income WHERE level='$level'");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $levelPercent = $valConfig['levelPercent'];
      $levelIncome = 100000;
      $levelIncome = $investAmount * $levelPercent / 100;
      $incomeWallteEntery = 0;
    
        $incomeWallteEntery = 1;
    
      if ($incomeWallteEntery == 1) {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income3 (memberId,levelIncome,level,levelPercent,dateTime) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d')");
        $investInId = $con->insert_id;
        incomeEntry($con, $parentId, $investInId, $levelIncome, 1, $d);
      } else {
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income3 (memberId,levelIncome,level,levelPercent,dateTime,status) VALUES ('$parentId','$levelIncome','$level','$levelPercent','$d',0)");
      }
    }
    $querylevel = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$parentId' AND a.sponser_id=b.member_id");
    $valLevel = mysqli_fetch_assoc($querylevel);
    $parentId = $valLevel['sponser_id'];
    $topupFlag = $valLevel['topup_flag'];
    $level++;
  }
}
// matrix income 3  END