<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
</head>


<body class="body-scroll" data-page="index">

  <?php require_once('Include/Menu.php');
?>



  <!-- Header -->
  <header class="header position-fixed">
            <div class="row">
                <div class="col-auto">
                    <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
                </div>
                <div class="col text-right">
                    <div class="logo-small">
                        <img src="assets/logo.png" alt="" style=" height:50px; " />
                    </div>
                </div>

            </div>
        </header>
        
  <main class="h-100">
    <div class="content-wrapper">
      <div class="container-full">
        <!-- Content Header (Page header) -->
        <!-- Main content -->
        <section class="content">

          <!-- Basic Forms -->
          <div class="box">
            <div class="col-12">

              <!-- /.box-header -->
              <div class="box-body">
              
                
                <div class="row">
                  <div class="card crd0">
                    <div class="card-header">
                      <h6>CTO Income History  </h6>
                    </div>
                    <div class="table-panel">
                      <div class="row">
                        <div class="col-lg-12">
                          <div class="table-responsive">
                            <table id="example" class="table table-bordered table-custom table-hover ">
                              <thead>
                                <tr>
                                  <th>#</th>
                                  
                                  <th>User Id</th>
                                  <th> Name</th>
                                  <th> Amount</th>
                                  <th> Date</th>
                                </tr>
                              </thead>
                              <tbody>
                                <?php 
                            $count=0;
                            $queryTransfer=mysqli_query($con,"SELECT a.amount,a.date_time,b.user_id ,b.name FROM meddolic_user_cto_transfer_history a, meddolic_user_details b WHERE a.receiver_member_id='$memberId' AND  a.receiver_member_id=b.member_id ORDER BY a.date_time DESC");
                            while($valTransfer=mysqli_fetch_assoc($queryTransfer)){
                            $count++; ?>
                                <tr>
                                  <td>
                                    <?= $count ?>
                                  </td>
                                  <td>
                                    <?=$valTransfer['user_id']?>
                                  </td>
                                  <td>
                                    <?=$valTransfer['name']?>
                                  </td>
                                
                                  <td><span class="badge badge-danger">
                                      <?= $valTransfer['amount']?> $
                                    </span></td>
                                  <td><i class="fa fa-clock-o"></i>
                                    <?= date("d-m-Y H:i:s", strtotime($valTransfer['date_time']))?>
                                  </td>
                                </tr>
                                <?php } ?>
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>


        </section>

      </div>

    </div>
    <!-- Footer -->
    <footer class="footer" style="background:#00bcd4;">
      <div class="container">
        <ul class="nav nav-pills nav-justified">
          <li class="nav-item">
            <a class="nav-link active" href="index">
              <span>
                <i class="nav-icon bi bi-house"></i>
                <span class="nav-text">Home</span>
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="EditProfile" style="color:#000;">
              <span>
                <i class="nav-icon bi-person-circle"></i>
                <span class="nav-text">Profile</span>
              </span>
            </a>
          </li>
          <li class="nav-item centerbutton">
            <button type="button" class="nav-link" data-bs-toggle="modal" data-bs-target="#menumodal"
              id="centermenubtn">
              <span class="theme-radial-gradient">
                <i class="bi bi-grid size-22" style="color:#000;"></i>
              </span>
            </button>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="changePassword" style="color:#000;">
              <span>
                <i class="nav-icon bi-file-earmark-lock"></i>
                <span class="nav-text">Change Password</span>
              </span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#" style="color:#000;">
              <span>
                <i class="nav-icon bi bi-file-earmark-text"></i>
                <span class="nav-text">Edit Account</span>
              </span>
            </a>
          </li>

        </ul>
      </div>
    </footer>


    <?php require_once('Include/Footer.php');?>
    <script>
      function cancelFundRequest(orderId, tempId) {
        if (tempId != "") {
          if (confirm('Are you sure to Cancel this Add Fund Request?')) {
            $.ajax({
              type: "POST",
              url: 'ajaxCalls/cancelFundRequestAjax',
              data: { tempId: tempId, orderId: orderId },
              cache: false,
              success: function (data) {
                // alert(data);
                if (data) {
                  alert('Add Fund Request Cancel Successfully');
                  location.reload();
                }
              }
            });
          }
        }
      }
    </script>
</body>


</html>