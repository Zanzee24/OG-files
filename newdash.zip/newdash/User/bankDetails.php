<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

    <?php require_once('Include/Menu.php');
?>
 <?php
    $queryProfile=mysqli_query($con,"SELECT date_time,sponser_id,bank,branch,accountNo,acName,ifsc,countryId,panNo FROM meddolic_user_details WHERE user_id='$userId'");
    $valProfile=mysqli_fetch_assoc($queryProfile);
    $dateTime=$valProfile['date_time'];
    $sponserId=$valProfile['sponser_id'];
    $bank=$valProfile['bank'];
    $branch=$valProfile['branch'];
    $accountNo=$valProfile['accountNo'];
    $acName=$valProfile['acName'];
    $ifsc=$valProfile['ifsc'];
    $countryId=$valProfile['countryId'];
    $panNo=$valProfile['panNo'];

  if($countryId!=''){
    $queryCountry=mysqli_query($con,"SELECT countryName FROM meddolic_config_country_list WHERE country_id='$countryId'");
    $valCountry=mysqli_fetch_assoc($queryCountry);
    $countryName=$valCountry['countryName'];
  } ?>


    <!-- Header -->
    <header class="header position-fixed">
        <div class="row">
            <div class="col-auto">
                <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
                <!--<img src="assets/logo.png" class="img-fluid" style="width:40%">-->
            </div>
            <div class="col text-center">

            </div>
            <div class="col-auto">

            </div>
        </div>
    </header>


    <main class="h-100">
   
        <!-- Header -->
        <header class="header position-fixed">
            <div class="row">
                <div class="col-auto">
                    <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
                </div>
                <div class="col text-right">
                    <div class="logo-small">
                        <img src="assets/img/logo.png" alt="" style=" height:50px; " />
                    </div>
                </div>

            </div>
        </header>
        <div class="content-wrapper">
            <div class="container-full">
                <!-- Content Header (Page header) -->
                <!-- Main content -->
                <section class="content">

                    <!-- Basic Forms -->
                    <div class="box">
                        <div class="col-12">

                            <!-- /.box-header -->
                            <div class="box-body"><div class="box-header with-border">
                                            <h4 class="box-title">Bank Details</h4>
                                        </div><br>
                                        <div class="row">
      <div class="col-sm-12 col-xl-6 xl-100">
        <div class="card crd0">
          <div class="card-body">
            
            <div class="tab-content" id="icon-tabContent">
              <div class="tab-pane fade active show" id="bankDetails" role="tabpanel" aria-labelledby="bankDetailsTab">
                <form class="form theme-form" action="userProfileAuthProcess" method="POST">
                  <div class="card-body">
                    <div class="row">
                      <div class="col">
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Account Holder Name *</label>
                          <div class="col-sm-6">
                          <input type="text" class="form-control" required value="<?= $acName?>" name="acName" placeholder="Enter Account Holder Name" required <?php if($acName!='') echo 'readonly' ?> >
                            <input type="hidden" name="memberId" value="<?=$memberId?>">
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">IFSC Code *</label>
                          <div class="col-sm-6">
                          <input type="text" class="form-control"  required value="<?= $ifsc?>" name="ifsc" placeholder="Enter IFSC Code" required <?php if($ifsc!='') echo 'readonly' ?> >
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Bank Name *</label>
                          <div class="col-sm-6">
                          <input type="text" class="form-control"  required value="<?= $bank?>" name="bank" placeholder="Enter Bank Name" required <?php if($bank!='') echo 'readonly' ?> >
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Branch *</label>
                          <div class="col-sm-6">
                          <input type="text" class="form-control" required value="<?= $branch?>" name="branch" placeholder="Enter Branch" required <?php if($branch!='') echo 'readonly' ?> >
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">A/C No. *</label>
                          <div class="col-sm-6">
                          <input type="number" class="form-control" required value="<?= $accountNo?>" placeholder="Enter A/C No." name="accountNo" onkeypress="return onlynum(event)" required <?php if($accountNo!='') echo 'readonly' ?> >
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Pan No. *</label>
                          <div class="col-sm-6">
                          <input type="text" class="form-control" required value="<?= $panNo?>" placeholder="Enter PAN No." name="panNo"  required style="text-transform: uppercase;"<?php if($panNO!='') echo 'readonly' ?> >
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                                    <div class="card-footer text-end">
                    <div class="col-sm-9 offset-sm-3">
                      <button class="btn btn-primary" type="submit" data-bs-original-title="" title="Update" name="bankUpdate">Update</button>
                    </div>
                  </div>
                                  </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
                            </div>

                        </div>

                    </div>


                </section>

            </div>

        </div>
        <?php require_once('Include/Footer.php');?>

</body>


</html>
<script>
    $(document).ready(function() {

        $("#userid").keyup(function() {
            var userid = $('#userid').val();

            $.ajax({

                type: "POST",
                url: "refree.php",
                data: {
                    "userid": userid
                },
                success: function(response) {
                    if (response) {
                        var Username = document.getElementById('username');
                        Username.value = response;
                        $('#username').css({
                            "color": "#1ea8e7",
                            "font-weight": "bold"
                        });
                        $("#register_btn").show();
                    } else {
                        $(".ll1").show();
                        var Username = document.getElementById('username');
                        Username.value = "Invalid Userid";
                        $('#username').css({
                            "color": "#ff0000",
                            "font-weight": "bold"
                        });
                        $("#register_btn").hide();
                    }
                }
            });

        });
    });
</script>