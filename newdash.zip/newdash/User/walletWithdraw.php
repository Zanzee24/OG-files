<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>

<
<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                                <h2 >Withdrawal</h2>


                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        <div class="col-lg-12 col-xs-12">
            <section class="box">
                <div class="content-body">
                                  <form class="theme-form" action="walletWithdrawProcess" method="post">
                    <div class="mb-3">
                      <label>UserId </label>
                      <input type="text" name="user_id" class="form-control" placeholder="e.g. john12345" readonly
                        value="<?= $userId ?>">
                      <input type="hidden" name="memberId" value="<?= $memberId ?>">
                      <input type="hidden" name="goodFile" value="<?= $newToken ?>">
                      <!-- <input type="hidden" name="withdrawCharge" value="<?= $withdrawCharge ?>"> -->
                      <!-- <input type="hidden" name="minimumWithdraw" value="<?= $minimumWithdraw ?>"> -->
                    </div>
                    <div class="mb-3">
                      <label>Name </label>
                      <input type="text" name="name" class="form-control" placeholder="e.g. John Doe" readonly
                        value="<?= $userName ?>">
                    </div>
                    <div class="mb-3">
                      <label>Income Wallet </label>
                      <input type="text" class="form-control" value="<?= $incomeWallet ?>" readonly>
                    </div>
                    <div class="mb-3">
                      <label>Select wallet</label>
                      <select class="form-control" name="paymentId" id="paymentId">
                        <option value="">Select Withdrawl In</option>
                        <?php $queryWallet = mysqli_query($con, "SELECT a.payment_id,a.walletAddress,b.currencyName FROM meddolic_user_wallet_address_details a, meddolic_config_currency_list b WHERE a.member_id='$memberId' AND a.currency_id=b.currency_id AND a.status=1  ORDER BY a.addDate DESC");
                        while ($valWallet = mysqli_fetch_assoc($queryWallet)) { ?>
                          <option value="<?= $valWallet['payment_id'] ?>">
                            <?= $valWallet['currencyName'] ?> [
                            <?= $valWallet['walletAddress'] ?> ]
                          </option>
                        <?php } ?>
                      </select>
                    </div>

                    <div class="mb-3">
                      <label>Select UPI</label>
                      <select class="form-control" name="upiId" id="upiId">
                        <option value="">Select UPI In</option>
                        <?php $queryUpi = mysqli_query($con, "SELECT payment_id,upiAddress FROM meddolic_user_upi_address_details  WHERE member_id='$memberId' AND status=1  ORDER BY addDate DESC");
                        while ($valUpi = mysqli_fetch_assoc($queryUpi)) { ?>
                          <option value="<?= $valUpi['payment_id'] ?>">
                            [ <?= $valUpi['upiAddress'] ?> ]</option>
                        <?php } ?>
                      </select>
                    </div>

                  <div class="mb-3">
                      <label>Withdraw Amount (Minimum: 50$ ) *</label>
                      <input type="number" name="withdrawAmount" class="form-control"
                        placeholder="Enter Withdraw Amount" required 
                        onkeypress="return onlynum(event)" min="20">
                    </div>
                    <!-- <div class="mb-3" style="display: flex; gap: 1rem; align-items: end;">
                      <div style="flex: 1;">
                        <label>Enter OTP</label>
                        <input type="text" name="otp" class="form-control"
                          placeholder="Enter OTP" required>
                      </div>
                      <button type="button" id="getOtp" class="btn btn-primary" style="height: fit-content;">Get OTP</button>
                    </div> -->
                    <div class="mb-3">
                      <label>Transaction Password *</label>
                      <input type="password" name="trnPassword" class="form-control"
                        placeholder="e.g. Transaction Password" required="">
                    </div>
                    <div class="">
                      <button class="btn btn-primary" data-bs-original-title="" title="Withdraw" name="walletWithdraw"
                        value="withdraw">Withdraw</button>
                    </div>
                  </form>
                    </div>

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">Withdrawal Reports</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                      <tr>
                        <th>#</th>
                        <th>User Id</th>
                        <th>Amount</th>
                        <!-- <th>Charge</th> -->
                        <th>Net Amount</th>
                        <th>Order Id</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action Date</th>
                        <th>Remark</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $count = 0;
                      $queryWithdraw = mysqli_query($con, "SELECT a.*,b.user_id FROM meddolic_user_wallet_withdrawal_crypto a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.member_id=b.member_id ORDER BY a.id DESC");
                      while ($valWithdraw = mysqli_fetch_assoc($queryWithdraw)) {
                        $count++; ?>
                        <tr>
                          <td>
                            <?= $count; ?>
                          </td>
                          <td>
                            <?= $valWithdraw['user_id'] ?>
                          </td>
                          <td><span class="badge badge-danger"><i class="fa-solid fa-sterling-sign"></i>
                              <?= $valWithdraw['amount'] ?> ₹
                            </span></td>
                          <!-- <td><span class="badge badge-danger"><i class="fa-solid fa-sterling-sign"></i> <?= $valWithdraw['withdrawCharge'] ?></span></td> -->
                          <td><span class="badge badge-success"><i class="fa-solid fa-sterling-sign"></i>
                              <?= $valWithdraw['netAmount'] ?> ₹
                            </span></td>
                          <td>
                            <?= $valWithdraw['orderid'] ?>
                          </td>
                          <td><i class="fa-regular fa-clock"></i>
                            <?= $valWithdraw['date_time'] ?>
                          </td>
                          <td>
                            <?php if ($valWithdraw['released'] == 0) echo "<span class='badge badge-primary'>PENDING</span>";
                            else if ($valWithdraw['released'] == 1) echo "<span class='badge badge-success'>RELEASED</span>";
                            else if ($valWithdraw['released'] == 2) echo "<span class='badge badge-warning'>PROCESSING</span>";
                            else if ($valWithdraw['released'] == 3) echo "<span class='badge badge-danger'>REJECTED</span>"; ?>
                          </td>
                          <td>
                            <?= $valWithdraw['payment_date'] ?>
                          </td>
                          <td>
                            <?= $valWithdraw['remarks'] ?>
                          </td>
                        </tr>
                      <?php } ?>
                    </tbody>
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>

    <script>
      const getOtpButton = document.getElementById('getOtp');

      getOtpButton.addEventListener('click', async () => {
        const memberId = <?= $memberId ?>;

        const data = await fetch('ajaxCalls/sendOtpAjax.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `memberId=${encodeURIComponent(memberId)}`
        }).then(res => res.text());

        console.log(data);

        if (data.trim() == "success") {
          alert("OTP sent successfully");
        } else {
          alert("Failed to send OTP");
        }
      });
    </script>



    

</body>


</html>