
<?php 
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>

        <!--  -->
       <section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">Profile </h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        <div class="col-lg-12 col-xs-12">
            <section class="box">
                <div class="content-body">
                                        <form action="userProfileAuthProcess" method="POST">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="form-group col-md-4 col-sm-6">
                                                                <label>Name*</label>
                                                                <input class="form-control" data-val="true"
                                                                    data-val-regex="Please enter only alphabets"
                                                                    data-val-regex-pattern="^[a-zA-Z\s]+$"
                                                                    data-val-required="Name is Required" id="Memb_Name"
                                                                    name="name" placeholder="Name" required type="text"
                                                                    value="<?=$userName?>" />
                                                                <input type="hidden" name="memberId"
                                                                    value="<?=$memberId?>">
                                                            </div>
                                                            <!-- <div class="form-group col-md-4 col-sm-6">
                                <label>Country*</label>
                                <input type="text"  name="name" class="form-control" data-rule-required="true" value="" disabled/>
                            </div> -->
                                                            <div class="form-group col-md-4 col-sm-6">
                                                                <label>Mobile*</label>
                                                                <input type="text" name="phone" class="form-control"
                                                                    maxlength="10" data-rule-required="true"
                                                                    data-rule-digits="true" data-rule-minlength="10"
                                                                    data-rule-maxlength="10" required
                                                                    data-val-required="Mobile No is Required" id="MobNo"
                                                                    placeholder="Mobile Number" value="<?=$phone?>"
                                                                    <?php if($phone!="" ) echo "" ?> onkeypress="return
                                                                onlynum(event)"/>
                                                            </div>

                                                            <div class="form-group col-md-4 col-sm-6">
                                                                <label>Email ID*</label>
                                                                <input type="email" id="EmailID" data-val="true"
                                                                    data-val-regex="Enter Valid Email Id" readonly
                                                                    class="form-control"
                                                                    data-val-regex-pattern="^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,6})$"
                                                                    data-val-required="Email Id is Required"
                                                                    name="emailId" placeholder="Email ID" type="email"
                                                                    value="<?=$email_id?>" <?php if($email_id!="" )
                                                                    echo "" ?> />
                                                            </div>
                                                            <!-- <div class="form-group col-md-4 col-sm-6">
                                <label>Gender*</label>
                                <select name="gender" id="gender" class="form-control" data-rule-required="true" >
                                    <option value="">Select</option>
                                    <option value="male" >Male</option>
                                    <option value="female" >Female</option>
                                </select>
                            </div> -->
                                                            <div class="form-group col-md-4 col-sm-6">
                                                                <label>Country*</label>
                                                                <select class="form-control" required id="M_COUNTRY"
                                                                    name="countryId">
                                                                    <option value="">Select Country</option>
                                                                    <?php $queryCountry="SELECT * FROM meddolic_config_country_list WHERE status=1 ORDER BY countryName ASC";
                                    $resultCountry=mysqli_query($con,$queryCountry);
                                    while($valCountry=mysqli_fetch_assoc($resultCountry)){ ?>
                                                                    <option value="<?=$valCountry['country_id']?>" <?php
                                                                        if($valCountry['country_id']==$countryId)
                                                                        echo "selected" ; ?> >
                                                                        <?=$valCountry['countryName']?>
                                                                    </option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                            <div class="col-md-12">
                                                                <button type="submit" name="profileUpdate" id="submit"
                                                                    value="Save"
                                                                    class="btn btn-primary col-md-2 col-sm-3">Save</button>
                                                            </div>
                                                </form>

                    </div>
                </div>
            </section>

            <?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>