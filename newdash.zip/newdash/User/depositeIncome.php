<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

  <?php require_once('Include/Menu.php');
  ?>



  <!-- Header -->
  <header class="header position-fixed">
    <div class="row">
      <div class="col-auto">
        <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
          <i class="bi bi-list"></i>
        </a>
      </div>
      <div class="col text-right">
        <div class="logo-small">
          <img src="assets/logo.png" alt="" style=" height:50px; " />
        </div>
      </div>

    </div>
  </header>

  <main class="h-100">
    <div class="content-wrapper">
      <div class="container-full">
        <!-- Content Header (Page header) -->


        <!-- Main content -->
        <section class="content">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-dark" style='color:#000'>Suntrade Profit</h6>
          </div>
          <div class="row">
            <div class="card crd0">
              <div class="card-body">
                <div class="dt-ext table-responsive">
                  <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>UserId</th>
                        <th>Name</th>
                        <th>ROI Income </th>
                        <th>Released Date</th>
                        <th>Status</th>
                        <th>Action</th>

                      </tr>
                    </thead>
                    <tbody>
                      <?php

                      function roiReceived($con, $memberId, $summaryId)
                      {
                        $query = mysqli_query($con, "SELECT sum(cashbackIncome) from meddolic_user_invest_income WHERE summaryId='$summaryId' AND status=1");
                        $val1 = mysqli_fetch_array($query);
                        $total = $val1[0];
                        if ($total != "") {
                          echo "<span class='badge badge-success'><i class='fa fa-usd'></i> " . $total . "</span>";
                        } else {
                          echo "<span class='badge badge-danger'><i class='fa fa-usd'></i> 0.00</span>";
                        }
                      }

                      $count = 0;
                      $queryPool = mysqli_query($con, "SELECT a.summaryId,a.createDate,a.summaryStatus,b.user_id,b.name FROM meddolic_user_invest_summary a, meddolic_user_details b WHERE a.memberId=b.member_id AND a.memberId='$memberId'   ORDER BY a.createDate DESC");
                      while ($valPool = mysqli_fetch_assoc($queryPool)) {
                        $count++; ?>
                        <tr>
                          <td><?= $count ?></td>
                          <td><?= $valPool['user_id'] ?></td>
                          <td><?= $valPool['name'] ?></td>
                          <td><span class="badge badge-success fa fa-usd"> <?= roiReceived($con, $memberId, $valPool['summaryId']) ?></span> </td>
                          <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valPool['createDate'])) ?></td>
                          <td><?php if ($valPool['summaryStatus'] == 1) echo "<span class='badge badge-success'>RELEASED</span>";
                              else if ($valPool['summaryStatus'] == 2) echo "<span class='badge badge-danger'>FLUSHED</span>"; ?></td>
                          <td><a href="depositeIncomeDetails?summary_id=<?= $valPool['summaryId'] ?>" class="btn btn-success btn-xs"><i class="fa fa-eye"></i> More </a></td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
    <!-- /.row -->
    </section>
    <!-- /.content -->

    </div>
    </div>
    </div>
    <?php require_once('Include/Footer.php'); ?>

</body>


</html>