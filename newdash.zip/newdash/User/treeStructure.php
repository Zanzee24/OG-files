<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
    <link href="binaryTree/assets/plugins/jquery-ui/themes/base/minified/jquery-ui.min.css" rel="stylesheet" />
    <link href="binaryTree/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
    <link href="binaryTree/assets/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="binaryTree/assets/css/animate.min.css" rel="stylesheet" />
    <link href="binaryTree/assets/css/style.min.css" rel="stylesheet" />
    <link href="binaryTree/assets/plugins/gritter/css/jquery.gritter.css" rel="stylesheet" />
    <link href="binaryTree/assets/css/custom/bineryTooltip.css" rel="stylesheet" />
<?php 
  if($_GET){
    $userId1=$_GET['userId'];
  } else {
    $userId1=$userId;
  } ?>

<body class="body-scroll" data-page="index">
    <!-- Header -->
    <header class="header position-fixed">
            <div class="row">
                <div class="col-auto">
                    <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
                </div>
                <div class="col text-right">
                    <div class="logo-small">
                        <img src="assets/img/logo.png" alt="" style=" height:50px; " />
                    </div>
                </div>

            </div>
        </header>

    <main class="h-100">

    <?php 
            $queryNew=mysqli_query($con,"SELECT member_id FROM meddolic_user_details WHERE user_id='$userId1'");
            $valNew=mysqli_fetch_assoc($queryNew);
            $member_id1=$valNew['member_id']?>
            <?php 
function sponserID($con,$sponserId){
  $querySponser=mysqli_query($con,"SELECT user_id FROM meddolic_user_details WHERE member_id='$sponserId'");
  $valSponser=mysqli_fetch_array($querySponser); 
  echo $valSponser['user_id'];
}
function carryTeam($user_id,$con){
  $queryUser=mysqli_query($con,"SELECT member_id,name,user_id FROM meddolic_user_details WHERE user_id='$user_id'");
  $valUser=mysqli_fetch_array($queryUser); 
  $member_id=$valUser['member_id'];

  // Left Active Team
  $queryLAct=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$member_id' AND legPosition=2 AND topup_status=1");
  $valLAct=mysqli_fetch_array($queryLAct);
  $leftActTeam=$valLAct[0];
  
  // Right Active Team
  $queryRAct=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$member_id' AND legPosition=3 AND topup_status=1");
  $valRAct=mysqli_fetch_array($queryRAct);
  $rightActTeam=$valRAct[0];

   // Left In-Active Team
  $queryLInAct=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$member_id' AND legPosition=2 AND topup_status=0");
  $valLInAct=mysqli_fetch_array($queryLInAct);
  $leftInActTeam=$valLInAct[0];
  
  // Right In-Active Team
  $queryRInAct=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$member_id' AND legPosition=3 AND topup_status=0");
  $valRInAct=mysqli_fetch_array($queryRInAct);
  $rightInActTeam=$valRInAct[0];
  
  echo "Active Team: ".$leftActTeam." ( L ) - ".$rightActTeam." ( R ) <br>";
  echo "In-Active Team: ".$leftInActTeam." ( L ) - ".$rightInActTeam." ( R ) <br>";
} ?>
<div class="content-wrapper">
    <div class="container-full">
        <section class="content">
            <div class="box">
                <div class="col-12">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-12 col-md-12 col-lg-12 ">
                                <div class="card p-3 bg-light" style="font-size:16px;">
                                    <div class="card-body">
                                    <div class="flrr" style="width: 1100px" >
    <div class="panel panel-inverse">
        <div class="panel-body">
            <div id="transformIt" style="padding: 20px;">
                <?php 
                    //   $member_id=$_GET['member_id'];
                      $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id FROM meddolic_user_details WHERE member_id='$member_id1'");
                      $parent_id1=0;
                      $parent_id2=0;
                      $parent_id3=0;
                      $parent_id4=0;
                      $parent_id5=0;
                      $parent_id6=0;
                      $parent_id7=0;
                      if($val=mysqli_fetch_array($result)){
                        $parent_id1=$val['member_id']; ?>
                <div class="binery-background">
                    <div style="width: 80px; height: 120px; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                        <!-- Binary TOOLTIP -->
                        <div class="binery-tooltip">
                            <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                <div class="gritter-top"></div>
                                <div class="gritter-item">
                                    <div class="gritter-with-image">
                                        <span class="gritter-title">
                                            <?= $val['user_id'];?></span>
                                        <p>User Id:
                                            <?= $val['user_id'];?><br />
                                            Sponser Id:
                                            <?php sponserID($con,$val['sponser_id'])?><br />
                                            Joining Date:
                                            <?= $val['date_time'];?><br />
                                            Activation Date:
                                            <?= $val['activation_date'];?><br />
                                            Account Status :
                                            <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                            <?php carryTeam($val['user_id'],$con);?>
                                        </p>
                                    </div>
                                    <div style="clear:both"></div>
                                </div>
                                <div class="gritter-bottom">
                                </div>
                            </div>
                        </div>
                        <!-- //BINARY TOOLTIP -->
                        <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                        <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id']?>"><?= $val['user_id']?></a></h4>
                    </div>
                </div>
                <?php } ?>
                <!-- Child Level 1 -->
                <div>
                    <?php 
                        $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id1' and legPosition=2");
                        if($val=mysqli_fetch_array($result)){
                          $parent_id2=$val['member_id']; ?>
                    <div class="col-xs-6 binery-background ">
                        <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                            <!-- Binary TOOLTIP -->
                            <div class="binery-tooltip">
                                <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                    <div class="gritter-top"></div>
                                    <div class="gritter-item">
                                        <div class="gritter-with-image">
                                            <span class="gritter-title">
                                                <?= $val['user_id'];?></span>
                                            <p>User Id:
                                                <?= $val['user_id'];?><br />
                                                Sponser Id:
                                                <?php sponserID($con,$val['sponser_id'])?><br />
                                                Joining Date:
                                                <?= $val['date_time'];?><br />
                                                Activation Date:
                                                <?= $val['activation_date'];?><br />
                                                Account Status :
                                                <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                <?php carryTeam($val['user_id'],$con);?>
                                            </p>
                                        </div>
                                        <div style="clear:both"></div>
                                    </div>
                                    <div class="gritter-bottom">
                                    </div>
                                </div>
                            </div>
                            <!-- //BINARY TOOLTIP -->
                            <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                            <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                    <?= $val['user_id'];?></a></h4>
                        </div>
                    </div>
                    <?php }  else { ?>
                    <div class="col-xs-6 binery-background ">
                        <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                            <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                        </div>
                    </div>
                    <?php } ?>
                    <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id1' and legPosition=3");
                            if($val=mysqli_fetch_array($result)){
                              $parent_id3=$val['member_id'];
                              
                            ?>
                    <div class="col-xs-6 binery-background ">
                        <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                            <!-- Binary TOOLTIP -->
                            <div class="binery-tooltip">
                                <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                    <div class="gritter-top"></div>
                                    <div class="gritter-item">
                                        <div class="gritter-with-image">
                                            <span class="gritter-title">
                                                <?= $val['user_id'];?></span>
                                            <p>User Id:
                                                <?= $val['user_id'];?><br />
                                                Sponser Id:
                                                <?php sponserID($con,$val['sponser_id'])?><br />
                                                Joining Date:
                                                <?= $val['date_time'];?><br />
                                                Activation Date:
                                                <?= $val['activation_date'];?><br />
                                                Account Status :
                                                <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                <?php carryTeam($val['user_id'],$con);?>
                                            </p>
                                        </div>
                                        <div style="clear:both"></div>
                                    </div>
                                    <div class="gritter-bottom">
                                    </div>
                                </div>
                            </div>
                            <!-- //BINARY TOOLTIP -->
                            <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                            <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                    <?= $val['user_id'];?></a></h4>
                        </div>
                    </div>
                    <?php } 
                               else
                               {
                                ?>
                    <div class="col-xs-6 binery-background ">
                        <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                            <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                        </div>
                    </div>
                    <?php
                               }
                               ?>
                    <div class="clearfix"></div>
                </div>
                <!--//Child Level 1 -->
                <!-- Child Level 2 -->
                <div>
                    <div class="col-xs-6">
                        <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id2' and legPosition=2");
                            if($val=mysqli_fetch_array($result))
                              {
                                 $parent_id4=$val['member_id'];
                              
                            ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <!-- Binary TOOLTIP -->
                                <div class="binery-tooltip">
                                    <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                        <div class="gritter-top"></div>
                                        <div class="gritter-item">
                                            <div class="gritter-with-image">
                                                <span class="gritter-title">
                                                    <?= $val['user_id'];?></span>
                                                <p>User Id:
                                                    <?= $val['user_id'];?><br />
                                                    Sponser Id:
                                                    <?php sponserID($con,$val['sponser_id'])?><br />
                                                    Joining Date:
                                                    <?= $val['date_time'];?><br />
                                                    Activation Date:
                                                    <?= $val['activation_date'];?><br />
                                                    Account Status :
                                                    <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                    <?php carryTeam($val['user_id'],$con);?>
                                                </p>
                                            </div>
                                            <div style="clear:both"></div>
                                        </div>
                                        <div class="gritter-bottom">
                                        </div>
                                    </div>
                                </div>
                                <!-- //BINARY TOOLTIP -->
                                <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                        <?= $val['user_id'];?></a></h4>
                            </div>
                        </div>
                        <?php } 
                               else
                               {
                                ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <!-- Binary TOOLTIP -->
                                <div class="binery-tooltip">
                                    <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                        <div class="gritter-top"></div>
                                        <div class="gritter-item">
                                            <div class="gritter-with-image">
                                                <span class="gritter-title"></span>
                                            </div>
                                            <div style="clear:both"></div>
                                        </div>
                                        <div class="gritter-bottom">
                                        </div>
                                    </div>
                                </div>
                                <!-- //BINARY TOOLTIP -->
                                <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                            </div>
                        </div>
                        <?php
                               }
                               ?>
                        <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id2' and legPosition=3");
                            if($val=mysqli_fetch_array($result))
                              {
                                 $parent_id5=$val['member_id'];
                              
                            ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <!-- Binary TOOLTIP -->
                                <div class="binery-tooltip">
                                    <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                        <div class="gritter-top"></div>
                                        <div class="gritter-item">
                                            <div class="gritter-with-image">
                                                <span class="gritter-title">
                                                    <?= $val['user_id'];?></span>
                                                <p>User Id:
                                                    <?= $val['user_id'];?><br />
                                                    Sponser Id:
                                                    <?php sponserID($con,$val['sponser_id'])?><br />
                                                    Joining Date:
                                                    <?= $val['date_time'];?><br />
                                                    Activation Date:
                                                    <?= $val['activation_date'];?><br />
                                                    Account Status :
                                                    <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                    <?php carryTeam($val['user_id'],$con);?>
                                                </p>
                                            </div>
                                            <div style="clear:both"></div>
                                        </div>
                                        <div class="gritter-bottom">
                                        </div>
                                    </div>
                                </div>
                                <!-- //BINARY TOOLTIP -->
                                <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                        <?= $val['user_id'];?></a></h4>
                            </div>
                        </div>
                        <?php } 
                               else
                               {
                                ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                            </div>
                        </div>
                        <?php
                               }
                               ?>
                        <div class="clearfix"></div>
                    </div>
                    <div class="col-xs-6">
                        <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id3' and legPosition=2");
                            if($val=mysqli_fetch_array($result))
                              {
                                 $parent_id6=$val['member_id'];
                              
                            ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <!-- Binary TOOLTIP -->
                                <div class="binery-tooltip">
                                    <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                        <div class="gritter-top"></div>
                                        <div class="gritter-item">
                                            <div class="gritter-with-image">
                                                <span class="gritter-title">
                                                    <?= $val['user_id'];?></span>
                                                <p>User Id:
                                                    <?= $val['user_id'];?><br />
                                                    Sponser Id:
                                                    <?php sponserID($con,$val['sponser_id'])?><br />
                                                    Joining Date:
                                                    <?= $val['date_time'];?><br />
                                                    Activation Date:
                                                    <?= $val['activation_date'];?><br />
                                                    Account Status :
                                                    <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                    <?php carryTeam($val['user_id'],$con);?>
                                                </p>
                                            </div>
                                            <div style="clear:both"></div>
                                        </div>
                                        <div class="gritter-bottom">
                                        </div>
                                    </div>
                                </div>
                                <!-- //BINARY TOOLTIP -->
                                <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                        <?= $val['user_id'];?></a></h4>
                            </div>
                        </div>
                        <?php } 
                               else
                               {
                                ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                            </div>
                        </div>
                        <?php
                               }
                               ?>
                        <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id3' and legPosition=3");
                            if($val=mysqli_fetch_array($result))
                              {
                                 $parent_id7=$val['member_id'];
                              
                            ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <!-- Binary TOOLTIP -->
                                <div class="binery-tooltip">
                                    <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                        <div class="gritter-top"></div>
                                        <div class="gritter-item">
                                            <div class="gritter-with-image">
                                                <span class="gritter-title">
                                                    <?= $val['user_id'];?></span>
                                                <p>User Id:
                                                    <?= $val['user_id'];?><br />
                                                    Sponser Id:
                                                    <?php sponserID($con,$val['sponser_id'])?><br />
                                                    Joining Date:
                                                    <?= $val['date_time'];?><br />
                                                    Activation Date:
                                                    <?= $val['activation_date'];?><br />
                                                    Account Status :
                                                    <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                    <?php carryTeam($val['user_id'],$con);?>
                                                </p>
                                            </div>
                                            <div style="clear:both"></div>
                                        </div>
                                        <div class="gritter-bottom">
                                        </div>
                                    </div>
                                </div>
                                <!-- //BINARY TOOLTIP -->
                                <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                        <?= $val['user_id'];?></a></h4>
                            </div>
                        </div>
                        <?php } 
                               else
                               {
                                ?>
                        <div class="col-xs-6 binery-background ">
                            <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                            </div>
                        </div>
                        <?php
                               }
                               ?>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <!--//Child Level 2 -->
                <!-- Child Level 3 -->
                <div>
                    <div class="col-xs-6">
                        <div class="col-xs-6">
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id4' and legPosition=2");
                            if($val=mysqli_fetch_array($result))
                              {
                            
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                            <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php } 
                               else
                               {
                                ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php
                               }
                               ?>
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id4' and legPosition=3");
                            if($val=mysqli_fetch_array($result))
                              {
                            
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                            <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php } 
                               else
                               {
                                ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php
                               }
                               ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="col-xs-6">
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id5' and legPosition=2");
                            if($val=mysqli_fetch_array($result)){
                          
                                 
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                            <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php } 
                               else
                               {
                                ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php
                               }
                               ?>
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id5' and legPosition=3");
                            if($val=mysqli_fetch_array($result))
                            {
                            
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                            <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php } 
                               else
                               {
                                ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php
                               }
                               ?>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <div class="col-xs-6">
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id6' and legPosition=2");
                            if($val=mysqli_fetch_array($result))
                            {
                            
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                            <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php } 
                               else
                               {
                                ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php
                               }
                               ?>
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id6' and legPosition=3");
                            if($val=mysqli_fetch_array($result))
                            {
                            
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                            <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php } 
                               else
                               {
                                ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php
                               }
                               ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="col-xs-6">
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id7' and legPosition=2");
                            if($val=mysqli_fetch_array($result))
                            {
                            
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id'];?>">
                                            <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php } 
                               else
                               {
                                ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php
                               }
                               ?>
                            <?php 
                            $result=mysqli_query($con,"SELECT member_id,name,user_id,date_time,topup_flag,activation_date,sponser_id from meddolic_user_details where placeholderId='$parent_id7' and legPosition=3");
                            if($val=mysqli_fetch_array($result))
                            {
                            
                            ?>
                            <div class="col-xs-6  ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <!-- Binary TOOLTIP -->
                                    <div class="binery-tooltip">
                                        <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" role="alert">
                                            <div class="gritter-top"></div>
                                            <div class="gritter-item">
                                                <div class="gritter-with-image">
                                                    <span class="gritter-title">
                                                        <?= $val['user_id'];?></span>
                                                    <p>User Id:
                                                        <?= $val['user_id'];?><br />
                                                        Sponser Id:
                                                        <?php sponserID($con,$val['sponser_id'])?><br />
                                                        Joining Date:
                                                        <?= $val['date_time'];?><br />
                                                        Activation Date:
                                                        <?= $val['activation_date'];?><br />
                                                        Account Status :
                                                        <?php if($val['topup_flag']==1) echo "Active";else echo "In-Active";?><br />
                                                        <?php carryTeam($val['user_id'],$con);?>
                                                    </p>
                                                </div>
                                                <div style="clear:both"></div>
                                            </div>
                                            <div class="gritter-bottom">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- //BINARY TOOLTIP -->
                                    <img <?php if($val['topup_flag']==1) echo "src='binaryTree/assets/img/silver.png'" ; else echo "src='binaryTree/assets/img/0.JPG'"; ?> class="img-circle img-responsive">
                                    <h4 class="text-center"><a target="_parent" href="treeStructure?userId=<?= $val['user_id']?>"> <?= $val['user_id'];?></a></h4>
                                </div>
                            </div>
                            <?php }  else { ?>
                            <div class="col-xs-6 ">
                                <div style="width: 80px; height: auto; position : relative;background-color: transparent;margin-top: 10px;" class="center-block binary-item">
                                    <img src="binaryTree/assets/img/inactive-user.jpg" class="img-circle img-responsive ">
                                </div>
                            </div>
                            <?php  } ?>
                        </div>
                    </div>
                </div>
                <!-- //Child level 3 -->
            </div>
            <!-- //Binery Tree -->
        </div>
    </div>
</div>  
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <?php require_once('Include/Footer.php');?>
</body>
</html>