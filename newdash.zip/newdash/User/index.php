
<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1" >

    <?php include 'Include/Head.php'; ?>
    <?php include 'Include/Header.php'; ?>
    <?php include 'Include/Menu.php'; ?>

    <body>

        <!-- SWITCHER -->
        
   
        <!-- END LOADER -->

        <!-- PAGE -->
        <div class="page">

            

            

            <!-- MAIN-CONTENT -->
            
            <!-- Start::app-content -->
            <div class="main-content app-content">
                <div class="container-fluid">

                    <!-- Start:: row-1 -->
                    <div class="row">
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">TOTAL EARNINGS</span> 
                                            <h4 class="text-fixed-white mb-0">13,278<span class="text-success fs-12 ms-2 fw-semibold d-inline-block"><i class="fa-solid fa-up-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="new-issues"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">PURCHASE WALLET</span> 
                                            <h4 class="text-fixed-white mb-0">29,912<span class="text-danger fs-12 ms-2 fw-semibold"><i class="fa-solid fa-down-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="completed-issues"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">TOTAL WITHDRAWAL</span> 
                                            <h4 class="text-fixed-white mb-0">1,214<span class="text-success fs-12 ms-2 fw-semibold d-inline-block"><i class="fa-solid fa-up-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="pending-issues"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">TOTAL BUSINESS</span> 
                                            <h4 class="text-fixed-white mb-0">563<span class="text-success fs-12 ms-2 fw-semibold d-inline-block"><i class="fa-solid fa-up-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="unresolved-issues"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">TOTAL CAPPING</span> 
                                            <h4 class="text-fixed-white mb-0">13,278<span class="text-success fs-12 ms-2 fw-semibold d-inline-block"><i class="fa-solid fa-up-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="unresolved-issues"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">REMAINING CAPPING</span> 
                                            <h4 class="text-fixed-white mb-0">29,912<span class="text-danger fs-12 ms-2 fw-semibold"><i class="fa-solid fa-down-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="completed-issues"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">TOTAL TEAM</span> 
                                            <h4 class="text-fixed-white mb-0">1,214<span class="text-success fs-12 ms-2 fw-semibold d-inline-block"><i class="fa-solid fa-up-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="pending-issues"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="text-fixed-white fs-11">TOTAL REFERRALS</span> 
                                            <h4 class="text-fixed-white mb-0">563<span class="text-success fs-12 ms-2 fw-semibold d-inline-block"><i class="fa-solid fa-up-long"></i>0.25%</span></h4>  
                                        </div>
                                        <div class="dropdown"> 
                                            <a aria-label="anchor" href="javascript:void(0);" data-bs-toggle="dropdown" class="op-4"> 
                                                <i class="fa-solid fa-grip-vertical"></i>
                                            </a> 
                                            <ul class="dropdown-menu" role="menu"> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Day</a></li>
                                                <li><a class="dropdown-item" href="javascript:void(0);">Week</a></li> 
                                                <li><a class="dropdown-item" href="javascript:void(0);">Year</a></li> 
                                            </ul> 
                                        </div>
                                    </div>
                                    <div id="unresolved-issues"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="row">
                        <div class="col-xxl-12">
                            <div class="card custom-card border-0">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body p-0">
                                    <div class="row g-0 border border-dashed">
                                        <div class="col-xl-3 border-end border-inline-end-dashed">
                                            <div class="d-flex flex-wrap align-items-top p-4">
                                                <div class="me-3 lh-1">
                                                    <span class="avatar avatar-md bg-primary-transparent">
                                                        <i class="fa fa-box fs-18"></i>
                                                    </span>
                                                </div>
                                                <div class="flex-fill">
                                                    <h5 class="fw-medium mb-1">45,280</h5>
                                                    <p class="text-muted mb-0 fs-12">Total Products</p>
                                                </div>
                                                <div>
                                                    <span class="badge bg-success-transparent"><i
                                                        class="fa-solid fa-up-long align-middle me-1 d-inline-block"></i>1.31%</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 border-end border-inline-end-dashed">
                                            <div class="d-flex flex-wrap align-items-top p-4">
                                                <div class="me-3 lh-1">
                                                    <span class="avatar avatar-md bg-secondary-transparent">
                                                        <i class="fa fa-rocket fs-18"></i>
                                                    </span>
                                                </div>
                                                <div class="flex-fill">
                                                    <h5 class="fw-medium mb-1">10,500</h5>
                                                    <p class="text-muted mb-0 fs-12">Total Sales</p>
                                                </div>
                                                <div>
                                                    <span class="badge bg-danger-transparent"><i
                                                        class="fa-solid fa-down-long align-middle me-1"></i>1.14%</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 border-end border-inline-end-dashed">
                                            <div class="d-flex flex-wrap align-items-top p-4">
                                                <div class="me-3 lh-1">
                                                    <span class="avatar avatar-md bg-success-transparent">
                                                        <i class="fa fa-wallet fs-18"></i>
                                                    </span>
                                                </div>
                                                <div class="flex-fill">
                                                    <h5 class="fw-medium mb-1">$69,270</h5>
                                                    <p class="text-muted mb-0 fs-12">Income</p>
                                                </div>
                                                <div>
                                                    <span class="badge bg-success-transparent"><i
                                                        class="fa-solid fa-up-long align-middle me-1 d-inline-block"></i>2.58%</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3">
                                            <div class="d-flex flex-wrap align-items-top p-4">
                                                <div class="me-3 lh-1">
                                                    <span class="avatar avatar-md bg-warning-transparent">
                                                       <i class="fa-solid fa-truck-fast"></i>
                                                    </span>
                                                </div>
                                                <div class="flex-fill">
                                                    <h5 class="fw-medium mb-1">12,088</h5>
                                                    <p class="text-muted mb-0 fs-12">Total Orders</p>
                                                </div>
                                                <div>
                                                    <span class="badge bg-success-transparent"><i
                                                            class="fa-solid fa-up-long align-middle me-1 d-inline-block"></i>12.05%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                   
                    <!-- End:: row-1 -->
                      <div class="row">
                        <div class="col-xl-3 col-md-6">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="top-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="avatar bg-primary-transparent">
                                                <i class="fa fa-wallet fs-5"></i>
                                            </span>
                                        </div>
                                        <div id="total-revenue1"></div>
                                    </div>
                                    <h4 class="fw-semibold mb-2">$73,239</h4>
                                    <div class="d-flex align-items-center justify-content-between gap-1">
                                        <span class="">Total Revenue</span>
                                        <span class="badge bg-success-transparent"><i class="fa-solid fa-up-long me-1 align-middle"></i>+1.08%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="top-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="avatar bg-info-transparent">
                                                <i class="fa fa-users fs-5"></i>
                                            </span>
                                        </div>
                                        <div id="total-customers"></div>
                                    </div>
                                    <h4 class="fw-semibold mb-2">1,56,290</h4>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <span class="">Total Customers</span>
                                        <span class="badge bg-danger-transparent"><i class="fa-solid fa-down-long me-1 align-middle"></i>-0.56%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="top-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="avatar bg-success-transparent">
                                                <i class="fa fa-wave-square fs-5"></i>
                                            </span>
                                        </div>
                                        <div id="conversion-ratio"></div>
                                    </div>
                                    <h4 class="fw-semibold mb-2">16.87%</h4>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <span class="">Conversion Ratio</span>
                                        <span class="badge bg-success-transparent"><i class="fa-solid fa-up-long me-1 align-middle"></i>+4.63%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="top-right"></div>
                                <div class="card-body">
                                    <div class="mb-3 d-flex align-items-start justify-content-between">
                                        <div>
                                            <span class="avatar bg-danger-transparent">
                                                <i class="fa fa-briefcase fs-5"></i>
                                            </span>
                                        </div>
                                        <div id="total-deals"></div>
                                    </div>
                                    <h4 class="fw-semibold mb-2">$73,239</h4>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <span class="">Total Deals</span>
                                        <span class="badge bg-success-transparent"><i class="fa-solid fa-up-long me-1 align-middle"></i>+12.67%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="row">
                        <div class="col-xxl-2 col-md-4 col-sm-6">
                            <div class="card custom-card border border-primary bg-primary-transparent">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="text-center">
                                        <span class="avatar avatar-md bg-primary shadow-sm mb-2">
                                            <i class="fa fa-briefcase fs-16"></i>
                                        </span>
                                        <p class="fs-14 fw-medium mb-2">Total Sales</p>
                                        <div class="d-flex align-items-center justify-content-center flex-wrap">
                                            <h5 class="mb-0 fw-medium">15,800</h5>
                                            <span class="badge bg-success-transparent rounded-pill ms-1">+25.8%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-2 col-md-4 col-sm-6">
                            <div class="card custom-card border border-secondary bg-secondary-transparent">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="text-center">
                                        <span class="avatar avatar-md bg-secondary shadow-sm mb-2">
<i class="fa-solid fa-file-lines fs-16"></i>                                        </span>
                                        <p class="fs-14 fw-medium mb-2">Total Tax</p>
                                        <div class="d-flex align-items-center justify-content-center flex-wrap">
                                            <h5 class="mb-0 fw-medium">$12,650</h5>
                                            <span class="badge bg-success-transparent rounded-pill ms-1">+12.2%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-2 col-md-4 col-sm-6">
                            <div class="card custom-card border border-info bg-info-transparent">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="text-center">
                                        <span class="avatar avatar-md bg-info shadow-sm mb-2">
                                            <i class="fa fa-line-chart fs-16"></i>
                                        </span>
                                        <p class="fs-14 fw-medium mb-2">Total Expenses</p>
                                        <div class="d-flex align-items-center justify-content-center flex-wrap">
                                            <h5 class="mb-0 fw-medium">$7,566</h5>
                                            <span class="badge bg-danger-transparent rounded-pill ms-1">-3.21%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-2 col-md-4 col-sm-6">
                            <div class="card custom-card border border-warning bg-warning-transparent">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="text-center">
                                        <span class="avatar avatar-md bg-warning shadow-sm mb-2">
                                            <i class="fa-solid fa-money-check-dollar fs-16"></i>
                                        </span>
                                        <p class="fs-14 fw-medium mb-2">Sales Profit</p>
                                        <div class="d-flex align-items-center justify-content-center flex-wrap">
                                            <h5 class="mb-0 fw-medium">$7,474</h5>
                                            <span class="badge bg-success-transparent rounded-pill ms-1">+36.03%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-2 col-md-4 col-sm-6">
                            <div class="card custom-card border border-danger bg-danger-transparent">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="text-center">
                                        <span class="avatar avatar-md bg-danger shadow-sm mb-2">
                                            <i class="fa-solid fa-address-card fs-16"></i>
                                        </span>
                                        <p class="fs-14 fw-medium mb-2">Opex Ratio</p>
                                        <div class="d-flex align-items-center justify-content-center flex-wrap">
                                            <h5 class="mb-0 fw-medium">32%</h5>
                                            <span class="badge bg-success-transparent rounded-pill ms-1">+0.89%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-2 col-md-4 col-sm-6">
                            <div class="card custom-card border border-success bg-success-transparent">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-body">
                                    <div class="text-center">
                                        <span class="avatar avatar-md bg-success shadow-sm mb-2">
                                            <i class="fa fa-wallet fs-16"></i>
                                        </span>
                                        <p class="fs-14 fw-medium mb-2">Total Income</p>
                                        <div class="d-flex align-items-center justify-content-center flex-wrap">
                                            <h5 class="mb-0 fw-medium">$14,800</h5>
                                            <span class="badge bg-success-transparent rounded-pill ms-1">+7.45%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                    
                </div>
            </div>
            <!-- End::app-content -->


            <!-- END MAIN-CONTENT -->

            <!-- SEARCH-MODAL -->
            
            <div class="modal fade" id="header-responsive-search" tabindex="-1" aria-labelledby="header-responsive-search" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="input-group">
                                <input type="text" class="form-control border-end-0" placeholder="Search Anything ..."
                                    aria-label="Search Anything ..." aria-describedby="button-addon2">
                                <button class="btn btn-primary" type="button"
                                    id="button-addon2"><i class="bi bi-search"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>            
            <!-- END SEARCH-MODAL -->

            

            <!-- FOOTER -->
            
            
            <!-- END FOOTER -->

        </div>
        <!-- END PAGE-->

        <!-- SCRIPTS -->
        
      
    <?php include 'Include/footer.php'; ?>

    </body>
</html><!-- This code use for render base file -->