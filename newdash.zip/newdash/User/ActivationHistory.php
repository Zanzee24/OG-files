<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
</head>
<?php
$queryPackage = mysqli_query($con, "SELECT packageId,packageName,minInvest,maxInvest FROM meddolic_config_package_type WHERE packageStatus=1 ");
$valPackage = mysqli_fetch_assoc($queryPackage);
$packageId = $valPackage['packageId'];
$minInvest = $valPackage['minInvest'];
$maxInvest = $valPackage['maxInvest'];
?>


<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">Re-Topup Income</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">History</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>User Id</th>
                                                    <th>Name</th>
                                                    <th>Package Amount</th>
                                                    <th>Purchase Date</th>
                                                    <th>Purchase By</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $count = 0;
                                                $queryActive = mysqli_query($con, "SELECT a.investAmount,a.dateTime,b.user_id,b.name,c.user_id AS activerId,c.name AS activerName from meddolic_user_invest_history a, meddolic_user_details b, meddolic_user_details c WHERE (a.loginMemberId='$memberId' OR a.memberId='$memberId') AND a.memberId=b.member_id AND a.loginMemberId=c.member_id ORDER BY a.dateTime DESC");
                                                while ($valActive = mysqli_fetch_assoc($queryActive)) {
                                                    $count++; ?>
                                                    <tr>
                                                        <td><?= $count ?></td>
                                                        <td><?= $valActive['user_id'] ?></td>
                                                        <td><?= $valActive['name'] ?></td>
                                                        <td><span class='badge badge-success'> $

                                                                <?= $valActive['investAmount'] ?> </span></td>
                                                        <td><i class="fa fa-clock-o"></i>
                                                            <?= date("d-m-Y H:i:d", strtotime($valActive['dateTime'])); ?>
                                                        </td>
                                                        <td><?= $valActive['activerName'] . " (User ID:" . $valActive['activerId'] . ")"; ?>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
  
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>
<script>
    $(document).ready(function () {

        $("#userid").keyup(function () {
            var userid = $('#userid').val();

            $.ajax({

                type: "POST",
                url: "refree.php",
                data: {
                    "userid": userid
                },
                success: function (response) {
                    if (response) {
                        var Username = document.getElementById('username');
                        Username.value = response;
                        $('#username').css({
                            "color": "#1ea8e7",
                            "font-weight": "bold"
                        });
                        $("#register_btn").show();
                    } else {
                        $(".ll1").show();
                        var Username = document.getElementById('username');
                        Username.value = "Invalid Userid";
                        $('#username').css({
                            "color": "#ff0000",
                            "font-weight": "bold"
                        });
                        $("#register_btn").hide();
                    }
                }
            });

        });
    });
</script>