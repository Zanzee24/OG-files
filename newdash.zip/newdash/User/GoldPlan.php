<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

  <main class="h-100">
    <div class="dashboard-body-part">
      <div class="container-full">
        <!-- Content Header (Page header) -->


        <!-- Main content -->
        <section class="content">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-dark" >Auto Pool Income II - Gold Plan</h6>
          </div>
          <style>
            .form-control-sm {
              padding: 0.25rem 1.5rem !important;
            }
          </style>
          <div class="row">
            <div class="card crd0">
              <div class="card-body">
                <div class="dt-ext table-responsive">
                  <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>UserId</th>
                        <th>Name</th>
                        <th>Pool Income </th>
                        <th>Pool Level</th>
                        <th>Date</th>
                        <th>Status</th>

                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $count = 0;
                      $queryLevel = mysqli_query($con, "SELECT a.release_date,a.Status,a.amount,a.poolLevel,b.name,b.user_id FROM meddolic_user_matrix_income_release3 a, meddolic_user_details b, meddolic_config_matrix_income c WHERE a.member_Id=b.member_id AND a.member_Id='$memberId'  AND a.childId=c.matrixId AND a.childId=1 ORDER BY a.release_date DESC");
                      while ($valLevel = mysqli_fetch_assoc($queryLevel)) {
                        $count++; ?>
                        <tr>
                          <td>
                            <?= $count ?>
                          </td>
                          <td><?= $valLevel['user_id'] ?></td>
                          <td><?= $valLevel['name'] ?></td>
                          <td><span class="badge bg-success"><i
                                class="fa fa-inr"></i><?= $valLevel['amount'] ?></span></td>

                          <td>Level <?= $valLevel['poolLevel'] ?></td>
                          <td><i class="fa fa-clock-o"></i><?= date("d-m-Y H:i:s", strtotime($valLevel['release_date'])) ?>
                          </td>
                          <td>
                            <?php if ($valLevel['Status'] == 1)
                              echo "<span class='badge badge-success'>RELEASED</span>";
                            else if ($valLevel['releaseStatus'] == 0)
                              echo "<span class='badge badge-danger'>HOLD</span>"; ?>
                          </td>
                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
    <!-- /.row -->
    </section>
  </main>
    <?php require_once('Include/Footer.php'); ?>

</body>


</html>