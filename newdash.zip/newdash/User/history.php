<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1">

<?php
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>


<body>


    <!-- PAGE -->
    <div class="page">

        <!-- MAIN-CONTENT -->

        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <!-- Start:: row-1 -->

                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="top-left"></div>
                        <div class="top-right"></div>
                        <div class="bottom-left"></div>
                        <div class="bottom-right"></div>
                        <div class="card-header">
                            <div class="card-title">
                                My Referrls
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table text-nowrap">
                                    <thead>
                                        <tr>
                                            <th scope="col">Color</th>
                                            <th scope="col">Client</th>
                                            <th scope="col">State</th>
                                            <th scope="col">Quantity</th>
                                            <th scope="col">Total Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <th scope="row">Default</th>
                                            <td>Rita Book</td>
                                            <td><span class="badge bg-primary-transparent">Processed</span></td>
                                            <td>22</td>
                                            <td>$2,012</td>
                                        </tr>

                                        <tr class="table-primary">
                                            <th scope="row">Primary</th>
                                            <td>Rhoda Report</td>
                                            <td><span class="badge bg-primary">Processed</span></td>
                                            <td>22</td>
                                            <td>$4,254</td>
                                        </tr>
                                        <tr class="table-secondary">
                                            <th scope="row">Secondary</th>
                                            <td>Rita Book</td>
                                            <td><span class="badge bg-secondary">Processed</span></td>
                                            <td>26</td>
                                            <td>$1,234</td>
                                        </tr>
                                        <tr class="table-success">
                                            <th scope="row">Success</th>
                                            <td>Anne Teak</td>
                                            <td><span class="badge bg-success">Processed</span></td>
                                            <td>42</td>
                                            <td>$2,623</td>
                                        </tr>
                                        <tr class="table-danger">
                                            <th scope="row">Danger</th>
                                            <td>Dee End</td>
                                            <td><span class="badge bg-danger">Processed</span></td>
                                            <td>52</td>
                                            <td>$32,132</td>
                                        </tr>
                                        <tr class="table-warning">
                                            <th scope="row">Warning</th>
                                            <td>Lee Nonmi</td>
                                            <td><span class="badge bg-warning">Processed</span></td>
                                            <td>10</td>
                                            <td>$1,434</td>
                                        </tr>
                                        <tr class="table-info">
                                            <th scope="row">Info</th>
                                            <td>Lynne Gwistic</td>
                                            <td><span class="badge bg-info">Processed</span></td>
                                            <td>63</td>
                                            <td>$1,854</td>
                                        </tr>
                                        <tr class="table-light">
                                            <th scope="row">Light</th>
                                            <td>Fran Tick</td>
                                            <td><span class="badge bg-light text-dark">Processed</span></td>
                                            <td>05</td>
                                            <td>$823</td>
                                        </tr>
                                        <tr class="table-dark">
                                            <th scope="row">Dark</th>
                                            <td>Polly Pipe</td>
                                            <td><span class="badge bg-dark text-white">Processed</span></td>
                                            <td>35</td>
                                            <td>$1,832</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



            <?php include 'Include/footer.php'; ?>

</body>

</html><!-- This code use for render base file -->