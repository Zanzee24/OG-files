<?php require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');

?>
<main class="main-content">
<section class="section">
<div class="dashboard-body-part">
  <div class="mobile-page-header">
    <h5 class="title">Reward Income</h5>
  </div>
  <div class="row">
    <div class="card crd0">
      
      <div class="card-body">
        <div class="dt-ext table-responsive">
          <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
            <thead>
              <tr>
                <th>Sr No.</th>
                <th>User Id</th>
                <th>Name</th>
                <th>Reward ID</th>
                <th>Reward Income</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              <?php

              $count = 0;
              $queryLevel = mysqli_query($con, "SELECT b.name,b.user_id,a.dateTime,a.salaryIncome,a.salaryId FROM meddolic_user_salary_income a, meddolic_user_details b WHERE a.memberId=b.member_id AND  a.memberId='$memberId' ORDER BY a.dateTime desc");
              while ($valLevel = mysqli_fetch_assoc($queryLevel)) {
                $count++; ?>
                <tr>
                  <td><?= $count ?></td>
                  <td><?= $valLevel['user_id'] ?></td>
                  <td><?= $valLevel['name'] ?></td>
                  <td>Reward <?= $valLevel['salaryId'] ?></td>
                  <td><i class ="fa fa-inr"> <?= $valLevel['salaryIncome'] ?> </i></td>
                  <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y ", strtotime($valLevel['dateTime'])) ?></td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</section>
</main>
<?php require_once('Include/Footer.php') ?>