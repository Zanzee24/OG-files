<!DOCTYPE html>
<html lang="en">
<?php 
    require_once("loginCheck.php");
    require_once('Include/Head.php');
    require_once('Include/Header.php');
    require_once('Include/Menu.php'); ?>
</head>

<body class="body-scroll" data-page="index">

    <?php require_once('Include/Menu.php');
?>



    <!-- Header -->
    <header class="header position-fixed">
            <div class="row">
                <div class="col-auto">
                    <a href="javascript:void(0)" target="_self" class="btn btn-light btn-44 menu-btn">
                    <i class="bi bi-list"></i>
                </a>
                </div>
                <div class="col text-right">
                    <div class="logo-small">
                        <img src="assets/img/logo.png" alt="" style=" height:50px; " />
                    </div>
                </div>

            </div>
        </header>
    <style>
        .card {
            margin-bottom: 20px;
        }
    </style>

    <!--#INCLUDE file="header.asp"-->
    <main class="h-100">
        <div class="content-wrapper">
            <div class="container-full">
                <!-- Content Header (Page header) -->


                <!-- Main content -->
                <section class="content"> <div class="card-header">
                                    <h5 style='color:white'>My Team</h5>
                                </div>
                               
    <div class="row">
      <div class="card crd0">
        <div class="card-body">
          <div class="dt-ext table-responsive">
            <table class="table table-bordered table-hover display margin-top-10 w-p100" id="example">
              <thead>
                <tr>
                  <th>#</th>
                  <th>User Id</th>
                  <th>User Name</th>
                  <th>Email Id</th>
                  <th>Joining Date</th>
                  <th>Activation Date</th>
                  <th>Active/Inactive Status</th>
                  <th>Total Invest</th>
                </tr>
              </thead>
              <tbody>
              <?php
                function totalInvest($con,$memberId){
                  $queryInvest=mysqli_query($con,"SELECT SUM(investPrice) FROM meddolic_user_activation_details WHERE member_id='$memberId'");
                  $valInvest=mysqli_fetch_array($queryInvest);
                  if($valInvest[0]!=""){
                        return $valInvest[0];
                  }else{
                        echo "0.00";
                  }
                }
                $count=0;
                $queryTeam=mysqli_query($con,"SELECT a.member_id,a.user_id,a.name,a.email_id,a.phone,a.password,a.date_time,a.activation_date,a.topup_flag FROM meddolic_user_details a, meddolic_user_child_ids b WHERE CAST(a.date_time AS date) BETWEEN '$calDate' AND '$calDate1' AND b.member_id='$memberId' AND a.member_id=b.child_id order by b.date_time DESC");
                while($valTeam=mysqli_fetch_assoc($queryTeam)){
                $count++; ?>
                <tr>
                    <td><?= $count ?></td>
                    <td><?= $valTeam['user_id']?></td>
                    <td><?= $valTeam['name']?></td>
                    <td><?= $valTeam['email_id']?></td>
                    <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTeam['date_time']));?></td>
                    <td><?php if($valTeam['activation_date']!="") { ?><?= date("d-m-Y H:i:s", strtotime($valTeam['activation_date'])); } ?></td>
                    <td><?php if($valTeam['topup_flag']==1) echo "<span class='badge badge-success'>Active</span>";else echo "<span class='badge badge-danger'>In-Active</span>";?></td>
                    <td><span class="badge badge-success"> <?= totalInvest($con,$valTeam['member_id'])?></span></td>
                </tr>
                <?php  } ?>
                            </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>  
  </div>
</div>
                    <!-- /.row -->
                </section>
                <!-- /.content -->

            </div>
        </div>
        </div>
        <?php require_once('Include/Footer.php');?>

</body>


</html>