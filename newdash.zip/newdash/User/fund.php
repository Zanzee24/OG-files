<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1">

<?php
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>


<body>


    <!-- PAGE -->
    <div class="page">

        <!-- MAIN-CONTENT -->

        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <!-- Start:: row-1 -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card custom-card">
                            <div class="top-left"></div>
                            <div class="top-right"></div>
                            <div class="bottom-left"></div>
                            <div class="bottom-right"></div>
                            <div class="card-body">
                                <h2>Fund Request</h2>
                                <div class="d-sm-flex flex-wrap align-items-start gap-5 p-2 border-bottom-0">
                                    <form class="row g-3 mt-0">
                                        <div class="col-md-6">
                                            <label class="form-label">UserId </label>
                                            <input type="text" class="form-control" placeholder="ZT12414"
                                                aria-label="First name">
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label"> Fund Need</label>
                                            <input type="text" class="form-control" placeholder="Ansdfd"
                                                aria-label="Last name">
                                        </div>
                                        <div class="col-md-6">
                                            <label>Payment Slip*</label>
                                            <input type='file' name="transactionImage" required class="form-control" accept=".jpg, .png, .gif, .jpeg, .PNG, .GIF, .JPG, .JPEG" />
                                        </div>

                                        <div class="col-md-4">
                                            <label for="inputState" class="form-label">Payment Mode *</label>
                                            <select id="inputState" class="form-select">
                                                <option selected>Choose...</option>
                                                <option>...</option>
                                            </select>
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label"> Transaction ID</label>
                                            <input type="text" class="form-control" placeholder="Ansdfd"
                                                aria-label="Last name">
                                        </div>
                                        <div class="col-md-12">
                                            <label class="form-label"> Transaction Password</label>
                                            <input type="text" class="form-control" placeholder="Ansdfd"
                                                aria-label="Last name">
                                        </div>


                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary">Submit Now</button>
                                        </div>
                                    </form>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                   <div class="col-xl-12">
                            <div class="card custom-card">
                                <div class="top-left"></div>
                                <div class="top-right"></div>
                                <div class="bottom-left"></div>
                                <div class="bottom-right"></div>
                                <div class="card-header">
                                    <div class="card-title">
                                        History 
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        
                                         <table class="table text-nowrap">
        <thead>
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Created On</th>
                <th scope="col">Number</th>
                <th scope="col">Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">Mark</th>
                <td>21,Dec 2021</td>
                <td>+1234-12340</td>
                <td><span class="badge bg-outline-primary">Completed</span></td>
            </tr>
            <tr>
                <th scope="row">Monika</th>
                <td>29,April 2023</td>
                <td>+1523-12459</td>
                <td><span class="badge bg-outline-warning">Failed</span></td>
            </tr>
            <tr>
                <th scope="row">Madina</th>
                <td>30,Nov 2023</td>
                <td>+1982-16234</td>
                <td><span class="badge bg-outline-success">Successful</span></td>
            </tr>
            <tr>
                <th scope="row">Bhamako</th>
                <td>18,Mar 2023</td>
                <td>+1526-10729</td>
                <td><span class="badge bg-outline-secondary">Pending</span></td>
            </tr>
        </tbody>
    </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>



                <?php include 'include/footer.php'; ?>

</body>

</html><!-- This code use for render base file -->