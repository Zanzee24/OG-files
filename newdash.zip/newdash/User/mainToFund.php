<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>

<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">Fund Transfer</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        <div class="col-lg-12 col-xs-12">
            <section class="box">
                <div class="content-body">
                                   <form class="theme-form" action="mainToFundProcess" method="post">
                          <div class="mb-3">
                            <label>User ID -:</label>
                            <input type="text" name="sponser_id" id="sponser_id" class="form-control"
                              placeholder="e.g. xxxxxxxxxx" required value="<?=$userId?>" readonly>
                            <input type="hidden" name="loginMemberId" value="<?=$memberId?>">
                          </div>
                          <div class="mb-3">
                            <label>Name -: </label>
                            <input type="text" id="sponser_name" class="form-control" placeholder="e.g. John Doe"
                              disabled="" value="<?=$userName?>">
                          </div>
                          <div class="mb-3">
                            <label>Income Wallet -:</label>
                            <input type="text" class="form-control" value="<?=$incomeWallet?>" readonly>
                          </div>
                          <div class="mb-3">
                            <label>Purchase Wallet -:</label>
                            <input type="text" id="current_wallet" name="fundWallet" class="form-control" readonly
                              value="<?=$fundWallet?>">
                          </div>
                          <div class="mb-3">
                            <label>Amount To Transfer -:</label>
                            <input type="number" id="amount" name="amount" class="form-control"
                              placeholder="e.g. Transfer Amount" onkeypress="return onlynum(event)" required>
                          </div>
                          <!-- <div class="mb-3">
                            <label>Transaction Password *</label>
                            <input type="password" name="trnPassword" class="form-control"
                              placeholder="e.g. Transaction Password" required="">
                          </div> -->
                          <div class="">
                            <button class="btn btn-primary" data-bs-original-title="" title="Transfer"
                              name="fundTransfer" value="Transfer">Transfer</button>
                          </div>
                        </form>
                    </div>

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">History</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
                <th>#</th>
                <th>UserId</th>
                <th>Name</th>
                <th>Transfer Amount</th>
                <th>Transfer charge</th>
                  <th>Totel Amount</th>
                <th>Transfer Date</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $count = 0;
                 $queryTransfer =  mysqli_query($con,"SELECT a.user_id,a.name,b.transferAmount,b.transferCharge,b.depositAmount,b.transferDate FROM `meddolic_user_details` a ,`meddolic_user_income_wallet_transfer` b WHERE b.memberId = '$memberId' AND a.member_id = b.memberId ORDER BY b.transferDate DESC");
                while ($valTransfer = mysqli_fetch_assoc($queryTransfer)) {
                  $count++; ?>
                  <tr>
                    <td><?= $count ?></td>
                    <td><?= $valTransfer['user_id'] ?></td>
                    <td><?= $valTransfer['name'] ?></td>
                    <td><span class="badge badge-danger"><i class="fa fa-inr"></i> <?= $valTransfer['transferAmount'] ?></span></td>
                    <td><?= $valTransfer['transferCharge'] ?>%</td>
                    <td>$<?= $valTransfer['depositAmount'] ?></td>
                    <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTransfer['transferDate'])); ?></td>
                  </tr>
                <?php } ?>
              </tbody>
  
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>


</html>