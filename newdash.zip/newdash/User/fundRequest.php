<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Menu.php');
require_once('Include/Header.php'); ?>
<body class="bg-theme">	<!-- Wrapper -->
	
<section id="main-content" class=" ">
    <div class="wrapper main-wrapper row" style=''>
        <div class='col-xs-12'>
            <div class="page-title">
                <div class="pull-left">

                    <h2 class="rubik">Fund Request</h2>

                </div>
                
            </div>
        </div>
        
        <div class="clearfix"></div>
        <div class="col-lg-12 col-xs-12">
            <section class="box">
                <div class="content-body">
                                   <form class="theme-form" action="fundRequestBack" method="post" enctype="multipart/form-data" onsubmit="return confirm('Are You Sure to Submit?')">
            <div class="mb-3">
              <label>UserId </label>
              <input type="text" name="user_id" class="form-control" placeholder="e.g. john12345" readonly value="<?= $userId ?>">
              <input type="hidden" name="loginMemberId" value="<?= $memberId ?>">
              <input type="hidden" name="name" value="<?= $userName ?>">
            </div>
            <div class="mb-3">
              <label>Fund Need *</label>
              <input type="number" name="requestFund" class="form-control" placeholder="e.g. Fund Need" required onkeypress="return onlynum(event)">
            </div>
            <div class="mb-3">
              <label>Payment Mode*</label>
              <select class="form-control" name="payment_id" required onchange="showAddressQR(this.value)">
                        <option value=""> Select One </option>
                        <?php $queryMode = mysqli_query($con, "SELECT payment_id,paymentName FROM meddolic_config_payment_details WHERE status=1 ORDER BY payment_id ASC");
                        while ($valMode = mysqli_fetch_assoc($queryMode)) { ?>
                            <option value="<?= $valMode['payment_id'] ?>"> <?= $valMode['paymentName'] ?> </option>
                        <?php } ?>
                    </select>
            </div>
            <div class="mb-3">
              <label>Payment Slip*</label>
              <input type='file' name="transactionImage" required class="form-control" accept=".jpg, .png, .gif, .jpeg, .PNG, .GIF, .JPG, .JPEG" />
            </div>
            <div class="mb-3">
              <label>Transaction ID *</label>
              <textarea type="text" class="form-control" required placeholder="Transaction Hash" name="paymentHash"></textarea>
            </div>

            <div class="mb-3">
              <label>Transaction Password *</label>
              <input type="password" name="trnPassword" class="form-control" placeholder="e.g. Transaction Password" required>
            </div>
            <div class="">
              <button class="btn btn-primary" data-bs-original-title="" title="" name="fundRequest">Submit</button>
            </div>
          </form>

                    </div>

                    <div class="col-lg-12 col-xs-12">
<section class="box">
<header class="panel_header">
<h2 class="title pull-left">History</h2>

</header>
<div class="col-xs-12">
<div class="content-body">
<div class="row">
<div class="col-xs-12" style="    max-height: 635px;    overflow-x: hidden; overflow-y: scroll;">
<div class="table-responsive" data-pattern="priority-columns">
<table id="tech-companies-1" class="table table-small-font no-mb table-bordered table-striped">
<thead>
																	<tr>
																		<th>#</th>
																		<th>User ID</th>
																		<th>Name</th>
																		<th>Requested Amount</th>
																		<th>Request Date</th>
																		<th>Payment Date</th>
																		<th>Payment Mode</th>
																		<th>Transaction ID</th>
																		<th>Transaction Slip</th>
																		<th>Status</th>
																	</tr>
																</thead>
																<tbody>
																	<?php
																	$count = 0;
																	$queryRequest = mysqli_query($con, "
																		SELECT a.*, b.paymentName 
																		FROM meddolic_user_fund_request a
																		JOIN meddolic_config_payment_details b ON a.payment_id = b.payment_id
																		WHERE a.member_id = '$memberId'
																		ORDER BY a.date_time DESC
																	");
																	while ($valRequest = mysqli_fetch_array($queryRequest)) {
																		$count++;
																	?>
																		<tr>
																			<td><?= $count ?></td>
																			<td><?= $valRequest['user_id'] ?></td>
																			<td><?= $valRequest['name'] ?></td>
																			<td><i class="fa fa-inr"></i> <?= $valRequest['requestFund'] ?></td>
																			<td><i class="fa fa-clock-o"></i> <?= $valRequest['date_time'] ?></td>
																			<td><i class="fa fa-clock-o"></i> <?= $valRequest['paymentDate'] ?></td>
																			<td><?= $valRequest['paymentName'] ?></td>
																			<td><?= $valRequest['paymentHash'] ?></td>
																			<td>
																				<?php if (!empty($valRequest['transactionImage'])): ?>
																					<img src="<?= $valRequest['transactionImage'] ?>" alt="Slip" height="80" width="80">
																				<?php else: ?>
																					N/A
																				<?php endif; ?>
																			</td>
																			<td>
																				<?php
																				switch ($valRequest['status']) {
																					case 1:
																						echo "<span class='badge badge-success'>Approved</span>";
																						break;
																					case 2:
																						echo "<span class='badge badge-danger'>Rejected</span>";
																						break;
																					default:
																						echo "<span class='badge badge-warning'>Pending</span>";
																				}
																				?>
																			</td>
																		</tr>
																	<?php } ?>
																</tbody>
  
</table>
</div>
</div>

</div>
</div>
</section>

<?php require_once('Include/Footer.php');?>

	<!-- end wrapper -->
	<!--start switcher-->
	
	<!--end switcher-->
	<!-- JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="assets/assets/js/jquery.min.js"></script>
	<script src="assets/assets/js/popper.min.js"></script>
	<script src="assets/assets/js/bootstrap.min.js"></script>
	<!--plugins-->
	<script src="assets/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/assets/js/app.js"></script>
</body>
