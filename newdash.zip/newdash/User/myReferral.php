<!DOCTYPE html>
<html lang="en" dir="ltr" data-nav-layout="vertical" data-vertical-style="detached" data-toggled="detached-close" data-theme-mode="dark" data-header-styles="dark" data-menu-styles="dark" data-card-style="style1" data-card-background="background1">

<?php
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php'); ?>


<body>


    <!-- PAGE -->
    <div class="page">

        <!-- MAIN-CONTENT -->

        <!-- Start::app-content -->
        <div class="main-content app-content">
            <div class="container-fluid">

                <!-- Start:: row-1 -->

                <div class="col-xl-12">
                    <div class="card custom-card">
                        <div class="top-left"></div>
                        <div class="top-right"></div>
                        <div class="bottom-left"></div>
                        <div class="bottom-right"></div>
                        <div class="card-header">
                            <div class="card-title">
                                My Referrals
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
    <table class="table text-nowrap table-bordered">
        <thead>
            <tr>
                <th scope="col">User</th>
                <th scope="col">Status</th>
                <th scope="col">Email</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-xs me-2 online avatar-rounded">
                            <img src="https://php.spruko.com/scifi/scifi/assets/images/faces/13.jpg" alt="img">
                        </span>Sukuro Kim
                    </div>
                </th>
                <td><span class="badge bg-success-transparent">Active</span></td>
                <td>kimosukuro@gmail.com</td>
                <td>
                    <div class="hstack gap-2 flex-wrap">
                        <a href="javascript:void(0);" class="text-info fs-14 lh-1"><i
                                class="fa fa-pen"></i></a>
                        <a href="javascript:void(0);" class="text-danger fs-14 lh-1"><i
                                class="fa fa-x"></i></a>
                    </div>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-xs me-2 offline avatar-rounded">
                            <img src="https://php.spruko.com/scifi/scifi/assets/images/faces/6.jpg" alt="img">
                        </span>Hasimna
                    </div>
                </th>
                <td><span class="badge bg-light text-dark">Inactive</span></td>
                <td>hasimna2132@gmail.com</td>
                <td>
                    <div class="hstack gap-2 flex-wrap">
                        <a href="javascript:void(0);" class="text-info fs-14 lh-1"><i
                                class="fa fa-pen"></i></a>
                        <a href="javascript:void(0);" class="text-danger fs-14 lh-1"><i
                                class="fa fa-x"></i></a>
                    </div>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-xs me-2 online avatar-rounded">
                            <img src="https://php.spruko.com/scifi/scifi/assets/images/faces/15.jpg" alt="img">
                        </span>Peter Harvey Khan
                    </div>
                </th>
                <td><span class="badge bg-success-transparent">Active</span></td>
                <td>Peter Harveykhan421@gmail.com</td>
                <td>
                    <div class="hstack gap-2 flex-wrap">
                        <a href="javascript:void(0);" class="text-info fs-14 lh-1"><i
                                class="fa fa-pen"></i></a>
                        <a href="javascript:void(0);" class="text-danger fs-14 lh-1"><i
                                class="fa fa-x"></i></a>
                    </div>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <div class="d-flex align-items-center">
                        <span class="avatar avatar-xs me-2 online avatar-rounded">
                            <img src="https://php.spruko.com/scifi/scifi/assets/images/faces/5.jpg" alt="img">
                        </span>Samantha Julia
                    </div>
                </th>
                <td><span class="badge bg-success-transparent">Active</span></td>
                <td>julianasams143@gmail.com</td>
                <td>
                    <div class="hstack gap-2 flex-wrap">
                        <a href="javascript:void(0);" class="text-info fs-14 lh-1"><i
                                class="fa fa-pen"></i></a>
                        <a href="javascript:void(0);" class="text-danger fs-14 lh-1"><i
                                class="fa fa-x"></i></a>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
                        </div>
                    </div>
                </div>
            </div>



            <?php include 'Include/footer.php'; ?>

</body>

</html><!-- This code use for render base file -->