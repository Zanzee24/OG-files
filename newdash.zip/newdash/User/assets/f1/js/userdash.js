function referalId() {
    var referalID = $(".form-control.userdtl").val();
    $.ajax({
        url: 'actuser',
        type: "POST",
        data: {
            referalIDforonlyName: referalID
        },
        success: function(data) {
            if ($.trim(data) == "0") {
                $(".sponsor").text(" | Sponsor Not Found!");
                $("#sponsor").val('');
            } else {
                $("#sponsor").val(data);
                $(".sponsor").text(" Sponsor is : " + data);
            }
        }
    });
};

function activeUser() {
    var activeUsers = $(".form-control.actuser").val();
    $.ajax({
        url: 'actuser',
        type: "POST",
        data: {
            activeUser: activeUsers
        },
        success: function(data) {
            if ($.trim(data) == "0") {
                $(".sponsor").text("User Not Exist..!");
                $("#sponsonValid").val(0);
            } else if ($.trim(data) == "1") {
                $(".sponsor").text("User is already upgraded...!");
                $("#sponsonValid").val(0);
            } else {
                $(".sponsor").text(" User name is : " + data);
                $("#sponsonValid").val(1);
            }
        }
    });
};

function packageShow() {
    var packageID = $(".form-control.package").val();
    $.ajax({
        url: 'actuser',
        type: "POST",
        data: {
            packageID: packageID
        },
        success: function(data) {
            if ($.trim(data) == "0") {
                $("#input1").val(0);
            } else {
                $("#input1").val(data);
            }
        }
    });
}

function calc() {
    var textValue1 = document.getElementById('input1').value;
    var textValue2 = document.getElementById('input2').value;
    var balance = document.getElementById('myBal').value;
    var outval = (textValue1 * textValue2);
    var totAmt2 = ((outval * 50) / 100);
    if (balance >= totAmt2) {
        disc = totAmt2;
    } else {
        disc = balance;
    }
    document.getElementById('output').value = outval;
    document.getElementById('balance').value = disc;
    document.getElementById('payAmt').value = outval - disc;
};

function payamt() {
    var totAmt = document.getElementById('output').value;
    var balance = document.getElementById('myBal').value;
    var totAmt2 = ((totAmt * 50) / 100);
    if (balance >= totAmt2) {
        disc = totAmt2;
    } else {
        disc = balance;
    }
    document.getElementById('payAmt').value = totAmt - disc;
    document.getElementById('balance').value = disc;
}
var countDownDate = new Date("May 5, 2022 9:00:00").getTime();
var x = setInterval(function() {
    var now = new Date().getTime();
    var distance = countDownDate - now;
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    document.getElementById("Timer").innerHTML = " Topup your id before this time duration  " + days + ": Day " + hours + ": Hour " +
        minutes + ": Min " + seconds + ": Sec ";
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("Timer").innerHTML = "EXPIRED";
    }
}, 1000);