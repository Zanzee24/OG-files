<?php include 'Include/Head.php'; ?>
<?php include 'Include/Header.php'; ?>
<?php include 'Include/Menu.php'; ?>

<body>


<div class="app-content">

    <!-- Menu Navigation starts -->

        <main>
            <div class="container-fluid mt-3">
                <div class="row">
                    <div class="col-sm-6 col-lg-4 col-xxl-4 order--1-lg">
                        <div class="row">
                            <div class="col-12">
                                <div class="card orders-provided-card">
                                    <div class="card-body">
                                        <i class="ph-bold  ph-circle circle-bg-img"></i>
                                        <div>
                                            <p class="f-s-18 f-w-600 text-dark txt-ellipsis-1">INCOME WALLET </p>
                                            <h2 class="text-secondary-dark mb-0">$2.36k</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="card bg-primary-300 product-sold-card">
                                    <div class="card-body">
                                        <div>
                                            <h5 class="text-primary-dark f-w-600">TOTAL EARNINGS </h5>
                                            <p class="text-dark f-w-600 mb-0 mt-2 txt-ellipsis-1"><i
                                                    class="iconoir-calendar f-s-16 align-text-top me-2"></i>Oct 1 -
                                                Oct 15, 2024</p>
                                        </div>
                                        <div class="my-4">
                                            <h4 class="text-primary-dark">$22,450</h4>
                                        </div>
                                        <div class="custom-progress-container">
                                            <div class="progress-bar productive"></div>
                                            <div class="progress-bar middle"></div>
                                            <div class="progress-bar idle"></div>
                                        </div>
                                        <div class="progress-labels">
                                            <span>Productive</span>
                                            <span>Middle</span>
                                            <span>Idle</span>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-xxl-4">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card project-total-card">
                                    <div class="card-body">
                                        <div class="d-flex position-relative">
                                            <h5 class="text-dark txt-ellipsis-1">Total Hours</h5>
                                            <div class="clock-box">
                                                <div class="clock">
                                                    <div class="hour" id="hour" style="transform: translate(-50%, -100%) rotate(18deg);"></div>
                                                    <div class="min" id="min" style="transform: translate(-50%, -100%) rotate(216deg);"></div>
                                                    <div class="sec" id="sec" style="transform: translate(-50%, -100%) rotate(168deg);"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="d-flex">
                                                <h2 class="text-info-dark hour-display">12H</h2>
                                            </div>
                                            <div class="progress-labels mg-t-40">
                                                <span class="text-info">Productive</span>
                                                <span class="text-info">Middle</span>
                                                <span class="text-info">Idle</span>
                                            </div>
                                            <div class="custom-progress-container info-progress">
                                                <div class="progress-bar productive"></div>
                                                <div class="progress-bar middle"></div>
                                                <div class="progress-bar idle"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="card bg-info-300 project-details-card">
                                    <div class="card-body">
                                       
                                        <div class="my-4">
                                            <h5 class="f-w-600 text-info-dark txt-ellipsis-1">PURCHASE </h5>
                                            <h5 class="f-w-600 text-info-dark txt-ellipsis-1">WALLET </h5>
                                            <h5 class="f-w-600 text-info-dark txt-ellipsis-1">$25,000 </h5>
                                           
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="card bg-success-300 project-details-card">
                                    <div class="card-body">
                                       
                                        <div class="my-4">
                                            <h5 class="f-w-600 text-success-dark txt-ellipsis-1">DIRECT ICOMe</h5>
                                            <h5 class="f-w-600 text-success-dark txt-ellipsis-1">$13,800</h5>
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6">
                                <div class="card core-teams-card">
                                    <div class="card-body">
                                        <div class="d-flex">
                                            <h5 class="text-dark f-w-600 txt-ellipsis-1"> LEVEL INCOME</h5>
                                        </div>
                                        <div>
                                            <h2 class="text-warning-dark my-4 d-inline-flex align-items-baseline">$1k
                                                <span class="f-s-12 text-dark">Team Members</span>
                                            </h2>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-lg-4 col-xxl-4 order--1-lg">
                        <div class="row">
                            <div class="col-12">
                                <div class="card bg-danger-300 product-sold-card">
                                    <div class="card-body">
                                        <div>
                                            <h5 class="text-danger-dark f-w-600 ">MAGICAL Income</h5>
                                            <div id="productSold"></div>
                                        </div>
                                        <div>
                                            <h4>$6.56k</h4>
                                            <p class="mb-0 text-dark f-w-500 txt-ellipsis-1">Last Week<span
                                                    class="badge bg-white-300 text-danger-dark ms-2">-45%</span>
                                            </p>
                                        </div>
                                        <a class="bg-danger h-35 w-35 d-flex-center b-r-50 product-sold-icon"
                                            href="">
                                            <i class="iconoir-arrow-right f-w-600 f-s-18 animate__pulse animate__fadeOutRight  animate__infinite animate__slower"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="card product-store-card">
                                    <div class="card-body">
                                        <i class="ph-bold  ph-circle circle-bg-img"></i>
                                        <div>
                                            <p class="text-success f-s-18 f-w-600 txt-ellipsis-1">REWARD INCOME</p>

                                            <h2 class="text-success-dark mb-0">$6,876</h2>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    

                    <div class="col-md-7 col-xxl-5">
                        <div class="p-3">
                            <h5>Sales by Country</h5>
                        </div>
                        <div class="row">
                            <div class="col-6 col-sm-4">
                                <div class="card country-card-warning">
                                    <div class="card-body">
                                        <i class="flag-icon flag-icon-deu f-s-28 b-r-20"></i>
                                        <div class="mt-3">
                                            <h6 class="mb-0">Germany</h6>
                                            <p class="mb-0">3.8k</p>
                                        </div>
                                        <i class="iconoir-language icon-bg text-white"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4">
                                <div class="card bg-primary-300 ">
                                    <div class="card-body ">
                                        <i class="flag-icon flag-icon-aia f-s-28 b-r-20"></i>
                                        <div class="mt-3">
                                            <h6 class="mb-0">Australia</h6>
                                            <p class="text-primary f-w-600 mb-0">3.8k</p>
                                        </div>
                                    </div>
                                    <i class="iconoir-language icon-bg text-primary top-space-0"></i>
                                    <span class="position-absolute top-0 end-0 pa-6 bg-success b-2-white border-light rounded-circle animate__animated animate__heartBeat animate__infinite animate__fast"></span>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4">
                                <div class="card country-card-danger">
                                    <div class="card-body">
                                        <i class="flag-icon flag-icon-can f-s-28 b-r-20"></i>
                                        <div class="mt-3">
                                            <h6 class="mb-0">Germany</h6>
                                            <p class="f-w-600 mb-0">3.8k</p>
                                        </div>
                                        <i class="iconoir-language icon-bg text-white"></i>
                                    </div>
                                </div>
                            </div>

                            <div class="col-6 col-sm-4">
                                <div class="card country-card-info">
                                    <div class="card-body">
                                        <i class="flag-icon flag-icon-fra f-s-28 b-r-20"></i>
                                        <div class="mt-3">
                                            <h6 class="mb-0">France</h6>
                                            <p class="f-w-600 mb-0">3.8k</p>
                                        </div>
                                        <i class="iconoir-language icon-bg text-white"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4">
                                <div class="card country-card-danger">
                                    <div class="card-body">
                                        <i class="flag-icon flag-icon-usa f-s-28 b-r-20"></i>
                                        <div class="mt-3">
                                            <h6 class="mb-0">USA</h6>
                                            <p class="f-w-600 mb-0">3.8k</p>
                                        </div>
                                        <i class="iconoir-language icon-bg text-white"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 col-sm-4">
                                <div class="card country-card-warning">
                                    <div class="card-body">
                                        <i class="flag-icon flag-icon-esp f-s-28 b-r-20"></i>
                                        <div class="mt-3">
                                            <h6 class="mb-0">Spain</h6>
                                            <p class="f-w-500 mb-0">3.8k</p>
                                        </div>
                                        <i class="iconoir-language icon-bg text-white"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-6 col-xxl-3">
                        <div class="p-3">
                            <h5>Transaction</h5>
                        </div>
                        <div class="card transaction-card">

                            <div class="card-body">

                                <div class="text-center">
                                    <img alt="logo-img" src="assets/images/form/done.png">
                                    <h6 class="text-success-dark mb-0">Thank You!</h6>
                                    <p class="mb-0 f-w-600 text-success d-inline transaction-txt">Your transaction
                                        was
                                        successful </p>
                                    <img alt="gif"
                                        class="w-30 d-inline align-text-bottom"
                                        src="assets/images/dashboard/ecommerce-dashboard/celebration.gif">
                                </div>

                                <div class="custom-divider"></div>

                                <div class="d-flex justify-content-between">
                                    <div>
                                        <p class="text-dark f-w-500 mb-0"><i
                                                class="iconoir-credit-cards f-s-16 align-text-top me-2"></i>Transaction
                                            ID</p>
                                        <h6 class="text-success-dark">568368657681</h6>
                                    </div>
                                    <div>
                                        <p class="text-dark f-w-500 mb-0"><i
                                                class="iconoir-dollar-circle f-s-16 align-text-top me-2"></i>Amount
                                        </p>
                                        <h6 class="text-success-dark">$68.00</h6>
                                    </div>
                                </div>

                                <div class="mt-3">
                                    <p class="text-dark f-w-500 mb-0"><i
                                            class="iconoir-calendar f-s-16 align-text-top me-2"></i>Date & Time</p>
                                    <h6 class="mb-0 text-success-dark">15 Jun 2024 • 6:90PM</h6>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </main>
    </div>



    </div>
    <!-- <div class="modal show" data-bs-backdrop="static" id="welcomeCard" tabindex="-1" aria-modal="true" role="dialog" style="display: block; padding-left: 0px;">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content welcome-card">

                <div class="modal-body p-0">
                    <div class="text-center position-relative welcome-card-content z-1 p-3">
                        <div class="text-end position-relative z-1">
                            <i class="fa fa-x fs-5 text-dark f-w-600" data-bs-dismiss="modal"></i>
                        </div>
                        <h2 class="f-w-700 text-primary-dark mb-0"><span>Welcome!</span> <img alt="gif" class="w-45 d-inline align-baseline" src="assets/images/dashboard/ecommerce-dashboard/celebration.gif">
                        </h2>

                        <div class="modal-img-box">
                            <img alt="img" class=" img-fluid" src="assets/images/modals/welcome-1.png">
                        </div>
                        <div class="modal-btn mb-4">
                            <button class="btn btn-primary text-white btn-sm rounded" data-bs-dismiss="modal" type="button">
                                Get Started
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div> -->



<?php include 'Include/Footer.php'; ?>