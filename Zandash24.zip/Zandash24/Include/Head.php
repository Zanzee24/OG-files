<!DOCTYPE html>
<html lang="en">

<head>


    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="Multipurpose, super flexible, powerful, clean modern responsive bootstrap 5 admin template">
    <meta name="keywords"
        content="admin template, ra-admin admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="la-themes">

    <title>Zanthium </title>
    <link rel="icon" href="assets/images/logo/favicon.png" type="image/x-icon">
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link crossorigin href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <!-- apexcharts css-->
    <link rel="stylesheet" type="text/css" href="assets/vendor/apexcharts/apexcharts.css">

    <!-- slick css -->
    <link rel="stylesheet" href="assets/vendor/slick/slick.css">
    <link rel="stylesheet" href="assets/vendor/slick/slick-theme.css">


    <!-- glight css -->
    <link rel="stylesheet" href="assets/vendor/glightbox/glightbox.min.css">

    <!--font-awesome-css-->
    <link rel="stylesheet" href="assets/vendor/fontawesome/css/all.css">

    <!--animation-css-->
    <link rel="stylesheet" href="assets/vendor/animation/animate.min.css">

    <!-- iconoir icon css  -->
    <link href="assets/vendor/ionio-icon/css/iconoir.css" rel="stylesheet">

    <!-- tabler icons-->
    <link rel="stylesheet" type="text/css" href="assets/vendor/tabler-icons/tabler-icons.css">

    <!--flag Icon css-->
    <link rel="stylesheet" type="text/css" href="assets/vendor/flag-icons-master/flag-icon.css">

    <!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/bootstrap.min.css">

    <!--  prism CSS-->
    <link href="assets/vendor/prism/prism.min.css" rel="stylesheet">

    <!-- simplebar css-->
    <link rel="stylesheet" type="text/css" href="assets/vendor/simplebar/simplebar.css">

    <!-- App css-->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

    <!-- Responsive css-->
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <!-- font cdn -->
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
