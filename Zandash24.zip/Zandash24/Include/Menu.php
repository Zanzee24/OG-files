<div class="app-wrapper">
    <nav>
        <div class="app-logo">
            <a class="logo d-inline-block" href="index.php">
                <img alt="#" src="assets/images/logo/1.png">
            </a>

            <span class="bg-light-primary toggle-semi-nav">
                <i class="fa fa-chevrons-right f-s-20"></i>
            </span>
        </div>
        <div class="app-nav" id="app-simple-bar">
            <ul class="main-nav p-0 mt-2">

                <li class="no-sub">

                    <a class="" href="index.php">
                        <i class="iconoir-home-alt"></i>
                        dashboard
                    </a>

                </li>
                <li>
                    <a aria-expanded="false" class="" data-bs-toggle="collapse" href="#apps">
                        <i class="iconoir-apple-shortcuts"></i>
                        Profile
                    </a>

                </li>
                <li class="no-sub">
                    <a class="" href="widget.php">
                        <i class="iconoir-view-grid"></i> Packages
                    </a>
                </li>

                <li>
                    <a aria-expanded="false" class="" data-bs-toggle="collapse" href="#ui-kits">

                        <i class="iconoir-handbag"></i>
                       Investments
                    </a>
                    <ul class="collapse" id="ui-kits">
                        <li><a href="cheatsheet.php">Cheatsheet</a></li>
                        <li><a href="alert.php">Alert</a></li>
                        <li><a href="badges.php">Badges</a></li>
                        <li><a href="buttons.php">Buttons</a></li>
                        <li><a href="cards.php">Cards</a></li>
                        <li><a href="dropdown.php">Dropdown</a></li>
                        <li><a href="grid.php">Grid</a></li>
                        <li><a href="avtar.php">Avtar</a></li>
                        <li><a href="tabs.php">Tabs</a></li>
                        <li><a href="accordions.php">Accordions</a></li>
                        <li><a href="progress.php">Progress</a></li>
                        <li><a href="notifications.php">Notifications</a></li>
                        <li><a href="list.php">Lists</a></li>
                        <li><a href="helper_classes.php">Helper Classes</a></li>
                        <li><a href="background.php">Background</a></li>
                        <li><a href="divider.php">Divider</a></li>
                        <li><a href="ribbons.php">Ribbons</a></li>
                        <li><a href="editor.php">Editor </a></li>
                        <li><a href="collapse.php">Collapse</a></li>
                        <li><a href="footer-page.php">Footer</a></li>
                        <li><a href="shadow.php">Shadow</a></li>
                        <li><a href="wrapper.php">Wrapper</a></li>
                        <li><a href="bullet.php">Bullet</a></li>
                        <li><a href="placeholder.php">Placeholder</a></li>
                        <li><a href="alignment.php">Alignment Thing</a></li>
                    </ul>
                </li>


                <li>
                    <a aria-expanded="false" class="" data-bs-toggle="collapse" href="#advance-ui">
                        <i class="iconoir-shopping-bag-plus"></i> Fainncial 
                        
                    </a>
                    <ul class="collapse" id="advance-ui">
                        <li><a href="modals.php">Modals</a></li>
                        <li><a href="offcanvas.php">Offcanvas Toggle</a></li>
                        <li><a href="sweetalert.php">Sweat Alert</a></li>
                        <li><a href="scrollbar.php">Scrollbar</a></li>
                        <li><a href="spinners.php">Spinners</a></li>
                        <li><a href="animation.php">Animation</a></li>
                        <li><a href="video_emaded.php">Video Embed</a></li>
                        <li><a href="tour.php">Tour</a></li>
                        <li><a href="slick.php">Slider</a></li>
                        <li><a href="bootstrap_slider.php">Bootstrap Slider</a></li>
                        <li><a href="scrollpy.php">Scrollpy</a></li>
                        <li><a href="tooltips_popovers.php">Tooltip & Popovers</a></li>
                        <li><a href="ratings.php">Rating</a></li>
                        <li><a href="prismjs.php">Prismjs</a></li>
                        <li><a href="count_down.php">Count Down</a></li>
                        <li><a href="countup.php"> Count up </a></li>
                        <li><a href="draggable.php">Draggable</a></li>
                        <li><a href="tree-view.php">Tree View</a></li>
                        <li><a href="block_ui.php">Block Ui </a></li>
                    </ul>
                </li>
                <li>
                    <a aria-expanded="false" class="" data-bs-toggle="collapse" href="#icons">
                        <i class="iconoir-component"></i> Team Network
                    </a>
                    <ul class="collapse" id="icons">
                        <li><a href="fontawesome.php">Fontawesome</a></li>
                        <li><a href="flag_icons.php">Flag</a></li>
                        <li><a href="tabler_icons.php">Tabler</a></li>
                        <li><a href="weather_icon.php">Weather</a></li>
                        <li><a href="animated_icon.php">Animated</a></li>
                        <li><a href="iconoir_icon.php">Iconoir</a></li>
                        <li><a href="phosphor.php">Phosphor</a></li>
                    </ul>
                </li>
               


                <li>
                    <a aria-expanded="false" class="" data-bs-toggle="collapse" href="#other_pages">
                        <i class="iconoir-multiple-pages"></i> Other Pages
                    </a>
                    <ul class="collapse" id="other_pages">
                        <li><a href="blank.php">Blank</a></li>
                        <li><a href="maintenance.php">Maintenance</a></li>
                        <li><a href="landing.php">Landing Page</a></li>
                        <li><a href="coming_soon.php">Coming Soon</a></li>
                        <li><a href="sitemap.php">Sitemap</a></li>
                        <li><a href="privacy_policy.php">Privacy Policy</a></li>
                        <li><a href="terms_condition.php">Terms &amp; Condition</a></li>
                    </ul>
                </li>

               

                <li class="no-sub">
                    <a class="" href="mailto:teqlathemes@gmail.com">
                        <i class="iconoir-chat-bubble-question"></i> Support
                    </a>
                </li>

                <li class="no-sub">
                    <a class="" href="mailto:teqlathemes@gmail.com">
                        <i class="ph-duotone  ph-sign-out"></i> Log out
                    </a>
                </li>


            </ul>
        </div>

        <div class="menu-navs">
            <span class="menu-previous"><i class="ti ti-chevron-left"></i></span>
            <span class="menu-next"><i class="ti ti-chevron-right"></i></span>
        </div>

    </nav>