<?php 
error_reporting(E_ALL ^ E_NOTICE);
include("login-check.php"); 
if(isset($_POST['addEditRemark'])){
    $memberId=$_POST['memberId'];
    $id=$_POST['id'];
    $mainStatus=$_POST['mainStatus'];
    $fromDate=$_POST['fromDate'];
    $toDate=$_POST['toDate'];
    $userId=$_POST['userId'];
    $withdrawStatus=$_POST['withdrawStatus'];
    $remarks=$_POST['remarks'];
    $d=date('Y-m-d H:i:s');

    $queryUpdate=mysqli_query($con,"UPDATE meddolic_user_wallet_withdrawal_crypto SET remarks='$remarks',payment_date='$d',released='$withdrawStatus' WHERE id='$id'");

    if($withdrawStatus==3){
        $queryAmount=mysqli_query($con,"SELECT amount FROM meddolic_user_wallet_withdrawal_crypto WHERE id='$id'");
        $valAmount=mysqli_fetch_assoc($queryAmount);
        $amount=$valAmount['amount'];

        mysqli_query($con,"UPDATE meddolic_user_details SET wallet=wallet+'$amount' WHERE member_id='$memberId'");
        mysqli_query($con,"INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`,`date_time`,`trn_id`) VALUES ('$memberId',11,1,'$amount','$d','$id')");
    }
    if($queryUpdate){ ?>
    <script>
        alert("Action Taken Successfully!!!");
        window.top.location.href='walletWithdrawStatus?user_id=<?=$userId?>&withdrawStatus=<?=$withdrawStatus?>&from_date=<?=$fromDate?>&to_date=<?=$toDate?>';
    </script>
    <?php } else { ?>
        <script>
            alert("Action Taken Successfully!!!");
            window.top.location.href='walletWithdrawStatus?user_id=<?=$userId?>&withdrawStatus=<?=$withdrawStatus?>&from_date=<?=$fromDate?>&to_date=<?=$toDate?>';
        </script>
    <?php } } ?>
<?php include("../close-connection.php"); ?>