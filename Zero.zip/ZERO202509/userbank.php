
<?php include("login-check.php"); ?>
<?php include('include/head.php');
include('include/menu.php');
include('include/header.php'); ?>
<?php
date_default_timezone_set("Asia/Kolkata");
$user_id1 = "";
if ($_GET) {
 if ($_GET['user_id']) {
 $user_id1 = $_GET['user_id'];
 $query = "select count(*) from meddolic_user_details where user_id='$user_id1'";
 $result = mysqli_query($con, $query);
 $val = mysqli_fetch_array($result);
 if ($val[0] == 0) { ?>
 <script>
 alert("Invalid User Id");
 </script>
<?php
  $user_id1 = $_SESSION['admin_user_id'];
  }
 }
}
?>
<div class="container-fluid">
  <div class="row">
  <div class="col-sm-12 ">
 <div class="iq-card">
  <div class="iq-card-header d-flex justify-content-between">
  </div>
  <div class="iq-card-body">
  <form>
 <div class="form-row">
 <div class="col-3">
 <input class="form-control" type="text" placeholder="Enter User ID" name="user_id" value="<?= $user_id1 ?>">
   </div>
 <div class="col-3">
 <input class="btn btn-primary" type="submit" value="Search">
  </div>
  </div>
  </form>
 </div>
  </div>
 </div>
  <div class="col-sm-12">
  <div class="iq-card">
  <div class="iq-card-header d-flex justify-content-between">
  <div class="iq-header-title">
  <h4 class="card-title">Wallet Outstanding</h4>
  </div>
  </div>
  <div class="iq-card-body">
  <div class="table-responsive">
  <table id="example" class="table table-striped table-bordered">
  <thead>
  <tr>
  <th>#</th>
  <th>Name</th>
  <th>User ID</th>
 <th>Phone No</th>
  <th>Account Holder Name</th>
  <th>IFSC Code</th>
  <th>Bank Name</th>
  <th>Branch</th>
  <th>A/C No</th>
                 <th>Income Wallet</th>
 </tr>
 </thead>
  <tbody>
  <?php
  $query = "";
  if ($user_id1 != "") {
  $query = $query . " and user_id='$user_id1'";
  }
  $count = 0;
 
    $query = "SELECT a.ifsc,a.bank,a.branch,a.accNo,a.accName ,b.member_id,b.name,b.user_id,b.phone,b.wallet ,b.date_time from meddolic_user_bank_details a,meddolic_user_details b WHERE b.member_id=a.memberId " . $query . " ORDER BY wallet DESC";
 $result = mysqli_query($con, $query);
  while ($val1 = mysqli_fetch_array($result)) {
  $count++; ?>
  <tr>
  <td><?= $count ?></td>
   <td><?= $val1['name'] ?></td>
  <td><?= $val1['user_id'] ?></td>
  <td> <?= $val1['phone'] ?></td>
  <td> <?= $val1['accName'] ?></td>
  <td> <?= $val1['ifsc'] ?></td>
  <td> <?= $val1['bank'] ?></td>
    <td> <?= $val1['branch'] ?></td>
 <td> <?= $val1['accNo'] ?></td>
 <td> <?= $val1['wallet'] ?></td>

</tr>
<?php } ?>
 </tbody>
    </table>
  </div>
  </div>
  </div>
  </div>
  </div>
</div>
<div class="modal fade" id="editWallet" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="editWalletDash">
  <!-- Content Goes Here -->
  </div>
  </div>
 </div>
</div>
<?php include('include/footer.php'); ?>
<script>
  $('#editWallet').on('show.bs.modal', function(event) {
   var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  var modal = $(this);
  var memberId = recipient;
 $.ajax({
  type: "POST",
  url: "ajax_calls/editWalletAjax",
   data: {
  memberId: memberId
  },
  cache: false,
  success: function(data) {
  console.log(data);
 modal.find('.editWalletDash').html(data);
 },
  error: function(err) {
   console.log(err);
   }
  });
  })
 var d = document.getElementById("wallet");
  d.className += " active";
  var d = document.getElementById("userbank");
  d.className += " active";
</script>
</body>
</html>
