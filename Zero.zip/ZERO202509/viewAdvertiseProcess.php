
<br><br><br>
<center>
<h2>Processing your request!!!</h2>
<h3>Please do not press back or refresh!!!</h3>
</center>
<?php 

ob_start();
error_reporting(E_ALL ^ E_NOTICE); 
include("login-check.php");
if(isset($_POST['addAds'])){
    $advertiseName=$_POST['advertiseName'];
    $advertiseUrl=$_POST['advertiseUrl'];
    $watchTime=$_POST['watchTime'];
    $d=date("Y-m-d H:i:s");
    $todayDate=date("Y-m-d");

    $queryIn=mysqli_query($con,"INSERT INTO meddolic_config_ads_url (`advertiseName`,`advertiseUrl`,`watchTime`) VALUES ('$advertiseName','$advertiseUrl','$watchTime')");
    $advertiseId=$con->insert_id;
    if($queryIn){ ?>
        <script>
            alert('Advertise Added Successfully');
            window.top.location.href="viewAdvertise";
        </script>
        <?php
        exit;
    }else{ ?>
        <script>
            alert('Advertise Not Added...Try Again');
            window.top.location.href="viewAdvertise";
        </script>
        <?php
        exit;
    } }
if(isset($_POST['updateAds'])){
    $advertiseName=$_POST['advertiseName'];
    $advertiseUrl=$_POST['advertiseUrl'];
    $watchTime=$_POST['watchTime'];
    $advertiseId=$_POST['advertiseId'];
    $d=date("Y-m-d H:i:s");
    $todayDate=date("Y-m-d");

    $queryIn=mysqli_query($con,"UPDATE meddolic_config_ads_url SET `advertiseName`='$advertiseName',`advertiseUrl`='$advertiseUrl',`watchTime`='$watchTime' WHERE advertiseId='$advertiseId'");
    if($queryIn){ ?>
        <script>
            alert('Advertise Updated Successfully');
            window.top.location.href="viewAdvertise";
        </script>
        <?php
        exit;
    }else{ ?>
        <script>
            alert('Advertise Not Updated...Try Again');
            window.top.location.href="viewAdvertise";
        </script>
        <?php
        exit;
    } } ?>
<?php include("../close-connection.php"); ?>