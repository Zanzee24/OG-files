<br><br><br>
<center>
    <h2>Processing your request!!!</h2>
    <h3>Please do not press back or refresh!!!</h3>
</center>
<?php
ob_start();
error_reporting(E_ALL ^ E_NOTICE);
date_default_timezone_set("Asia/Kolkata");
include("login-check.php");
if (isset($_POST['addProduct'])) {
    $productName = $_POST['productName'];
    $frnch_member_Id = 1;
    $price = 999;
    $Quantity = $_POST['Quantity'];
    $d = date("Y-m-d H:i:s");
    $todayDate = date("Y-m-d");

    $totel = $price * $Quantity;

    // $queryWallet = mysqli_query($con, "SELECT fundwallet FROM franchise_meddolic_user_details WHERE frnch_member_Id='$frnch_member_Id'");
    // $valWallet = mysqli_fetch_array($queryWallet);
    //  $current_wallet = $valWallet[0];
    // if ($current_wallet <= 0) { ?>
    
    <script>
        //         alert("Insufficient Balance in Wallet");
        //         window.top.location.href = "addProduct";
        //     </script>
     <?php
    //     exit;
    // }

    // if ($current_wallet < $totel) { ?>
    
    <script>
        //         alert("Insufficient Balance in Wallet");
        //         window.top.location.href = "addProduct";
        //     </script>
     <?php
    //     exit;
    // }

    $queryIn = mysqli_query($con, "INSERT INTO `franchise_shopping_product_details`(`frnch_member_Id`,`productName`, `quanitty`,`stock`, `price`, `dateTime`) VALUES ('$frnch_member_Id','$productName','$Quantity','$Quantity','$price','$d')");
    if ($queryIn) {
        ?>
        <script>
            alert('Product Added Successfully');
            window.top.location.href = "addProduct";
        </script>
        <?php
        exit;
    } else { ?>
        <script>
            alert('Product Not Added...Try Again');
            window.top.location.href = "addProduct";
        </script>
        <?php
        exit;
    }
} ?>d
<?php include("../close-connection.php"); ?>