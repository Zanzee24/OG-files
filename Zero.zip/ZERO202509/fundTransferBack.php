<br><br><br>
<center>
<h2>Processing your request!!!</h2>
<h3>Please do not press back or refresh!!!</h3>
</center>
<?php 

date_default_timezone_set("Asia/Kolkata"); 
include("login-check.php");

if(isset($_POST['fundTransfer'])){
   
 	$user_id1=$_POST['sponser_id']; 
 	$sender_member_id=$_POST['login_member_id'];
 	$amount=$_POST['amount'];
 	$d=date("Y-m-d H:i:s");
 	$entry_date=date("Y-m-d");


	$result=mysqli_query($con,"SELECT * from meddolic_user_details where user_id='$user_id1' AND user_type=2 AND account_status=1");
	if(!mysqli_num_rows($result)) { ?>
	  <script>
	    alert("Invalid Member ID!!!");
	    window.top.location.href="fundTransfer";
	  </script>
	  <?php
	  exit;
	}

	$query1="SELECT member_id,email_id,name FROM meddolic_user_details WHERE user_id='$user_id1'";
	$result1=mysqli_query($con,$query1);
	$val1=mysqli_fetch_assoc($result1);
	$receiver_member_id=$val1['member_id'];
	$email_id=$val1['email_id'];
	$name=$val1['name'];

	mysqli_query($con,"UPDATE meddolic_user_details set fundWallet=fundWallet+'$amount' WHERE member_id='$receiver_member_id'");

	mysqli_query($con,"INSERT INTO meddolic_user_fund_transfer_history(`sender_member_id`,`receiver_member_id`,`amount`,`date_time`) VALUES ('$sender_member_id','$receiver_member_id','$amount','$d')");

	mysqli_query($con,"INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`, `amount`,`date_time`,`trn_id`) VALUES ('$receiver_member_id',6,2,'$amount','$d','$sender_member_id')"); ?>
<script>
  alert("Fund Transfer Successfully!!!");
  window.top.location.href="fundTransferHistory";
</script>
<?php } ?>
<?php include("../close-connection.php"); ?>