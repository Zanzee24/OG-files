<!DOCTYPE html>
<html lang="en">
<?php include("login-check.php"); ?>
<?php include('include/head.php');
include('include/menu.php');
include('include/header.php'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
      <div class="iq-card">
        <div class="iq-card-header d-flex justify-content-between">
          <div class="iq-header-title">
            <h4 class="card-title">Product List Here</h4>
          </div>
          <a class="btn btn-success" data-id="ThisID" data-toggle="modal" data-target="#addPaymentMode" href="#"
            style="float:right;"><i class="fa fa-plus"></i> Add New Product</a>
        </div>
        <div class="iq-card-body">
          <div class="table-responsive">
            <table id="example" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product Name</th>
                  <th>Price</th>
                  <th>Quantity</th>
                  <th>Stock</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $count = 0;
                $queryMode = mysqli_query($con, "SELECT productName,quanitty,price,dateTime,stock from franchise_shopping_product_details WHERE frnch_member_Id=1 AND  status=1 ORDER BY product_id DESC");
                while ($valMode = mysqli_fetch_array($queryMode)) {
                  $count++; ?>
                  <tr>
                    <td><?= $count; ?></td>
                    <td><?= $valMode['productName'] ?></td>
                    <td>₹ <?= $valMode['price'] ?></td>
                    <td><?= $valMode['quanitty'] ?></td>
                    <td><?= $valMode['stock'] ?></td>
                    <td><?= $valMode['dateTime'] ?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="addPaymentMode" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="false">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Add Product </h4>
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
      </div>
      <form action="addProductProccess" method="post" enctype="multipart/form-data">
        <div class="modal-body">
          <div class="form-group">
            <label class="control-label" for="inputSuccess">Product Name * </label>
            <input class="form-control" required name="productName" type="text" placeholder="Enter Product Name ">
            <input type="hidden" name="frnch_member_Id" value="<?= $frnch_member_Id ?>">

          </div>
          <div class="form-group">
            <label class="control-label" for="inputSuccess">product Price*</label>
            <input class="form-control" required value="999" type="number" readonly placeholder="Enter Product price">
          </div>
          <div class="form-group">
            <label class="control-label" for="inputSuccess">Quantity*</label>
            <input class="form-control" required name="Quantity" type="number"
              placeholder="Enter Product Quantity No. ">
          </div>
        </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-primary" name="addProduct" value="Add">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php include('include/footer.php'); ?>
<script>
  var d = document.getElementById("stock");
  d.className += " active";
  var d = document.getElementById("addProduct");
  d.className += " active";
</script>
</body>

</html>