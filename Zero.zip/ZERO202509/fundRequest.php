<!DOCTYPE html>
<html lang="en">
<?php include("login-check.php");?>
<?php include('include/head.php');
      include('include/menu.php'); 
      include('include/header.php'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
       <div class="iq-card">
          <div class="iq-card-header d-flex justify-content-between">
             <div class="iq-header-title">
                <h4 class="card-title">Fund Request</h4>
             </div>
          </div>
          <div class="iq-card-body">
              <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered" style="font-size: 13px;">
                 <thead>
                    <tr>
                    <th>#</th>
                      <th>UserId</th>
                      <th>Name</th>
                      <th>Requested Amount</th>
                      <th>Request Date</th>
                      <th>Payment Mode</th>
                      <th>Transaction ID</th>
                      <th>Transaction Copy</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                 </thead>
                 <tbody>
                 <?php
                      $count=0;
                      $queryFund=mysqli_query($con,"SELECT a.*,b.paymentName from meddolic_user_fund_request a, meddolic_config_payment_details b WHERE a.payment_id=b.payment_id ORDER BY a.date_time DESC");
                      while($valFund=mysqli_fetch_array($queryFund)){
                      $count++; ?>
                    <tr>
                      <td><?= $count; ?></td>
                      <td><?= $valFund['user_id']; ?></td>
                      <td><?= $valFund['name']; ?></td>
                      <td> <?= $valFund['requestFund'] ?></td>
                      <td><i class="fa fa-clock-o"></i> <?= $valFund['date_time']; ?></td>
                      <td><?= $valFund['paymentName']?></td>
                      <td><?= $valFund['paymentHash']?></td>
                      <td><img src="<?=$valFund['transactionImage']?>" height="150px" width="150px" ></td>
                      <td><?php if($valFund['status']==1) echo "Approved";
                      else if($valFund['status']==2) echo "Rejected";
                      else if($valFund['status']==0) echo "Pending";?></td>
                      <td><a href="fundRequestDetails?RqsID=<?=$valFund['id']?>" class="btn btn-success"> More </a></td>
                    </tr> 
                    <?php } ?>
                 </tbody>
              </table>
            </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include('include/footer.php'); ?>
<script> 
var d = document.getElementById("transfer");
    d.className += " active";
var d = document.getElementById("fundRequest");
    d.className += " active";
</script>
</body>
</html>