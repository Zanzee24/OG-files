<?php
    include("../../conection.php");
    $advertiseId = $_POST['advertiseId'];
    $query=mysqli_query($con,"UPDATE meddolic_config_ads_url SET advertiseStatus=0 WHERE advertiseId='$advertiseId'");
    if($query){
        echo true;
    } else {
        return false;
    }
?>