<?php
   include("../../conection.php");
    $newsId = $_POST['newsId'];
    $query=mysqli_query($con,"UPDATE meddolic_config_news_list SET newStatus=0 WHERE newsId='$newsId'");
    if($query){
        echo true;
    } else {
        return false;
    }
?>