<?php
   include("../../conection.php");
    $advertiseId = $_POST['advertiseId'];
     
    $queryDetails=mysqli_query($con,"SELECT advertiseId,advertiseName,advertiseUrl,watchTime FROM meddolic_config_ads_url WHERE advertiseId='$advertiseId'");
    $valDetails=mysqli_fetch_assoc($queryDetails); ?>
<div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle" style="color:#000;">Edit Ads : <?= $valDetails['advertiseName']?></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
    </div>
    <form action="viewAdvertiseProcess" method="post" enctype="multipart/form-data">
        <div class="modal-body" style="color:#000;">
            <div class="form-group">
                <div class="form-group">
                    <label class="control-label" for="inputSuccess">Ads Name *</label>
                    <input class="form-control" required type="text" name="advertiseName" value="<?= $valDetails['advertiseName']?>" >
                    <input type="hidden" value="<?= $valDetails['advertiseId']?>" name="advertiseId">
                </div>
            </div>
            <div class="form-group">
                <div class="form-group">
                    <label class="control-label" for="inputSuccess">Watch Time *</label>
                    <input class="form-control" required type="number" value="<?= $valDetails['watchTime']?>" name="watchTime" >
                </div>
            </div>
            <div class="form-group">
                <div class="form-group">
                    <label class="control-label" for="inputSuccess">Ads URL *</label>
                    <input class="form-control" required type="text" value="<?= $valDetails['advertiseUrl']?>" name="advertiseUrl" >
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" name="updateAds" class="btn btn-primary">Update Now</button>
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
    </form>
</div>