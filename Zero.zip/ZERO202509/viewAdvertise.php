<!DOCTYPE html>
<html lang="en">
<?php include("login-check.php");
      include('include/head.php');
      include('include/menu.php'); 
      include('include/header.php'); ?>
<?php 
    date_default_timezone_set("Asia/Kolkata"); 
    $user_id1="";
    if($_GET){
      if($_GET['user_id']){
        $user_id1=$_GET['user_id'];
        $query="select count(*) from meddolic_user_details where user_id='$user_id1'";
        $result=mysqli_query($con,$query);
        $val=mysqli_fetch_array($result);
        if($val[0]==0) { ?>
          <script>
            alert("Invalid User Id");
            </script>
          <?php
          $user_id1=$_SESSION['admin_user_id'];    
        }
      }
      if($_GET['from_date']){
          $show_date=$_GET['from_date'];
          $cal_date = date("Y-m-d", strtotime($show_date));
      }   
      if($_GET['to_date']){
        $show_date1=$_GET['to_date'];
        $cal_date1 = date("Y-m-d", strtotime($show_date1));
      }   
    } else{
      $show_date=date("d-m-Y"); 
      $show_date1=date("d-m-Y");
      $cal_date=date("Y-m-d"); 
      $cal_date1=date("Y-m-d");
    }
?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12">
       <div class="iq-card">
          <div class="iq-card-header d-flex justify-content-between">
             <div class="iq-header-title">
                <h4 class="card-title">Advertisement</h4>
                <a class="btn btn-success" data-id="ThisID"  data-toggle="modal" data-target="#addAds" href="javascript:void(0)" style="float:right;" ><i class="fa fa-plus"></i> Add Advertise</a>
             </div>
          </div>
          <div class="iq-card-body">
             <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered">
                   <thead>
                      <tr>
                      <th>#</th>
                        <th>Ads Name</th>
                        <th>Watch Time</th>
                        <th>Video URL</th>
                        <th>Action</th>
                      </tr>
                   </thead>
                   <?php
                    $count=0;
                    $queryAds=mysqli_query($con,"SELECT * FROM meddolic_config_ads_url WHERE advertiseStatus=1 ORDER BY advertiseId ASC");
                    while($valAds=mysqli_fetch_assoc($queryAds)){ 
                      $count++; ?>
                    <tr>
                      <td><?=$count?></td>
                      <td><?=$valAds['advertiseName']?></td>
                      <td><?=$valAds['watchTime']?> Sec</td>
                      <td><a href="<?=$valAds['advertiseUrl']?>" target="_blank" ><?=$valAds['advertiseUrl']?></td>
                      <td><a data-id="<?= $valAds['advertiseId']?>" data-toggle="modal" data-target="#editAds" data-whatever="<?= $valAds['advertiseId']?>" href="#" class="btn btn-success btn-sm" > Edit </a>&nbsp; <a href="javascript:void(0)" class="btn btn-danger btn-sm" onclick="deleteAds(<?=$valAds['advertiseId']?>)">Remove Ad</a></td>
                    </tr>
                    <?php } ?>
                   </tbody>
                </table>
             </div>
          </div>
       </div>
    </div>
  </div>
  </div>
  <div class="modal fade" id="addAds" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
          <h4 class="modal-title" id="myModalLabel" style="color:#000;">Add New Ads </h4>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
      </div>
      <form action="viewAdvertiseProcess" method="POST" enctype="multipart/form-data">
        <div class="modal-body" style="color:#000;">     
          <div class="form-group">
            <label class="control-label" for="inputSuccess">Ads Name * </label>
            <input class="form-control" required name="advertiseName" type="text" placeholder="Ads Name">
          </div>
          <div class="form-group">
            <label class="control-label" for="inputSuccess">Watch Time * </label>
            <input class="form-control" required name="watchTime" type="number" placeholder="Watch Time (In Sec)">
          </div>
          <div class="form-group">
            <label class="control-label" for="inputSuccess">Ads URL * </label>
            <input class="form-control" required name="advertiseUrl" type="text" placeholder="Ads URL">
          </div>        
        </div>
        <div class="modal-footer">
          <input type="submit" class="btn btn-primary" name="addAds" value="Add New Ads">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
<div class="modal fade" id="editAds" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="adsEditDash">
             <!-- Content goes in here -->
            </div>
        </div>
    </div>
</div>
<?php include('include/footer.php'); ?>
<script>
    function deleteAds(advertiseId){
  if(advertiseId!=""){
      if(confirm('Are you sure to Delete this Advertise?')){
        $.ajax({
          type: "POST",
          url: 'ajax_calls/deleteAdsAjax',
          data: { advertiseId:advertiseId},
          cache: false,
          success: function(data){
               // alert(data);
            if(data){
              alert('Advertise Deleted Successfully');
              location.reload();
            }
          }
      });
    }
  }
}
$('#editAds').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  var modal = $(this);
  var advertiseId = recipient;
  $.ajax({
    type: "POST",
    url: "ajax_calls/editAdsAjax",
    data: { advertiseId: advertiseId },
    cache: false,
    success: function (data) {
      console.log(data);
      modal.find('.adsEditDash').html(data);
    },
    error: function(err) {
      console.log(err);
    }
  });  
})
var d = document.getElementById("viewAdvertise");
    d.className += " active";
</script>
</body>
</html>