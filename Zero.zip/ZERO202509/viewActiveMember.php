<!DOCTYPE html>
<html lang="en">
<?php include("login-check.php");?>
<?php include('include/head.php');
      include('include/menu.php'); 
      include('include/header.php'); ?>
<?php 
    date_default_timezone_set("Asia/Kolkata"); 
    $user_id1="";
    if($_GET){
      if($_GET['user_id']){
        $user_id1=$_GET['user_id'];
        $query="select count(*) from meddolic_user_details where user_id='$user_id1'";
        $result=mysqli_query($con,$query);
        $val=mysqli_fetch_array($result);
        if($val[0]==0) { ?>
          <script>
            alert("Invalid User Id");
            </script>
          <?php
          $user_id1=$_SESSION['admin_user_id'];    
        }
      }
      if($_GET['from_date']){
        $show_date=$_GET['from_date'];
        $cal_date = date("Y-m-d", strtotime($show_date));
      }   
      if($_GET['to_date'] ){
        $show_date1=$_GET['to_date'];
        $cal_date1 = date("Y-m-d", strtotime($show_date1));
      }
    } else{
      $show_date=date("d-m-Y"); 
      $show_date1=date("d-m-Y");
      $cal_date=date("Y-m-d"); 
      $cal_date1=date("Y-m-d");
    }
?>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-12 ">
      <div class="iq-card">
        <div class="iq-card-header d-flex justify-content-between">
        </div>
        <div class="iq-card-body">
           <form>
              <div class="form-row">
                <div class="col-3">
                  <input class="form-control" type="text" placeholder="Enter User ID" name="user_id" value="<?= $user_id1?>" >
                </div>
                <div class="col-3">
                  <input type="text" name="from_date" id="from_date" class="form-control " placeholder="e.g. From Date" required value="<?= $show_date; ?>" readonly >
                </div>
                <div class="col-3">
                  <input type="text" name="to_date" id="to_date" class="form-control " placeholder="e.g. To Date" required="" value="<?= $show_date1; ?>" readonly >
                </div>
                <div class="col-2">
                  <input class="btn btn-primary" type="submit" value="Search" >
                </div>
              </div>
           </form>
        </div>
      </div>
    </div>
    <div class="col-sm-12">
       <div class="iq-card">
          <div class="iq-card-header d-flex justify-content-between">
             <div class="iq-header-title">
                <h4 class="card-title">View Active Member</h4>
             </div>
          </div>
          <div class="iq-card-body">
             <div class="table-responsive">
                <table id="example" class="table table-striped table-bordered">
                   <thead>
                      <tr>
                        <th>#</th>          
                        <th>User Id</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Sponser</th>
                        <th>Joinig Date</th>
                        <th>Active Date</th>
                        <th>Password</th>
                        <th>More Details</th>
                      </tr>
                   </thead>
                   <tbody>
                      <?php
                        function name($con,$member_id){
                          $query="SELECT name from meddolic_user_details where member_id='$member_id' ";
                          $result=mysqli_query($con,$query);
                          $val1=mysqli_fetch_array($result);
                          return $val1[0];
                        }
                        function user_id($con,$member_id){
                          $query="SELECT user_id from meddolic_user_details where member_id='$member_id' ";
                          $result=mysqli_query($con,$query);
                          $val1=mysqli_fetch_array($result);
                          return $val1[0];
                        }
                        $query="";
                        if($user_id1!=""){
                          $query= $query." AND user_id='$user_id1'";  
                        }
                        $count=0;
                        $queryActive=mysqli_query($con,"SELECT user_id,name,phone,sponser_id,date_time,password,activation_date from meddolic_user_details WHERE member_id!=1 AND topup_flag=1 AND user_type=2 AND CAST(activation_date AS DATE) BETWEEN '$cal_date' AND '$cal_date1' ".$query." ORDER BY activation_date DESC");
                        while($valActive=mysqli_fetch_assoc($queryActive)){
                          $count++; ?>
                      <tr>
                        <td><?= $count?></td>
                        <td><?= $valActive['user_id']?></td>
                        <td><?= $valActive['name']?></td>
                        <td><?= $valActive['phone']?></td>
                        <td><?= name($con,$valActive['sponser_id'])." (User ID:".user_id($con,$valActive['sponser_id']).")";?></td>
                        <td><?= $valActive['date_time']?></td>
                        <td><?= $valActive['activation_date']?></td>
                        <td><?= $valActive['password']?></td>
                        <td><a href="viewMemberDetails?user_id=<?= $valActive['user_id']?>" class="btn btn-success btn-sm">More</a></td>
                      </tr>
                    <?php } ?>  
                   </tbody>
                </table>
             </div>
          </div>
       </div>
    </div>
  </div>
  </div>
<?php include('include/footer.php'); ?>
<script>
var d = document.getElementById("member");
    d.className += " active";
var d = document.getElementById("viewActiveMember");
    d.className += " active";
</script>
</body>
</html>