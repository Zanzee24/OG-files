<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Zero Problem Wellness || Admin Panel</title>
  <!-- Favicon -->
  <link rel="shortcut icon" href="../assets/images/successLogo.png" />
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
  <!-- Typography CSS -->
  <link rel="stylesheet" href="../assets/css/typography.css">
  <!-- Style CSS -->
  <link rel="stylesheet" href="../assets/css/style.css">
  <!-- Responsive CSS -->
  <link rel="stylesheet" href="../assets/css/responsive.css">
   <!-- Full calendar -->
  <link href='../assets/fullcalendar/core/main.css' rel='stylesheet' />
  <link href='../assets/fullcalendar/daygrid/main.css' rel='stylesheet' />
  <link href='../assets/fullcalendar/timegrid/main.css' rel='stylesheet' />
  <link href='../assets/fullcalendar/list/main.css' rel='stylesheet' />

  <link rel="stylesheet" href="../assets/css/flatpickr.min.css">
  <link rel="stylesheet" href="../assets/js/DataTable/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/js/DataTable/css/buttons.bootstrap4.min.css">
  <link rel="stylesheet" href="../assets/datepicker/bootstrap-datepicker.min.css">
  <link rel="stylesheet" href="../assets/sweetalert/dist/sweetalert.css">
  <style>
    .buttons-print {
      color: #fff;
      background-color: #23b7e5;
      border-color: #23b7e5;
    }
    .buttons-print:hover {
      color: #fff;
      background-color: #18a0ca;
      border-color: #1797be;
    }
    .buttons-excel {
      color: #fff;
      background-color: #23b7e5;
      border-color: #23b7e5;
    }
    .buttons-excel:hover {
      color: #fff;
      background-color: #18a0ca;
      border-color: #1797be;
    }
    .buttons-copy {
      color: #fff;
      background-color: #23b7e5;
      border-color: #23b7e5;
    }
    .buttons-copy:hover {
      color: #fff;
      background-color: #18a0ca;
      border-color: #1797be;
    }
    .buttons-csv {
      color: #fff;
      background-color: #23b7e5;
      border-color: #23b7e5;
    }
    .buttons-csv:hover {
      color: #fff;
      background-color: #18a0ca;
      border-color: #1797be;
    }
    .buttons-pdf {
      color: #fff;
      background-color: #23b7e5;
      border-color: #23b7e5;
    }
    .buttons-pdf:hover {
      color: #fff;
      background-color: #18a0ca;
      border-color: #1797be;
    }
  </style>
</head>