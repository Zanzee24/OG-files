<?php
require_once("../conection.php");
$ResID = isset($_GET['ResID']) ? trim($_GET['ResID']) : null;
$ID    = isset($_GET['ID']) ? trim($_GET['ID']) : null;
// Fetch user details
$queryAccess = mysqli_query($con, "SELECT name,user_id,member_id,topup_flag,wallet,fundWallet,email_id,phone FROM meddolic_user_details WHERE user_id='$_SESSION[member_user_id]'");
if ($valAccess = mysqli_fetch_array($queryAccess)) {
    $userName = $valAccess['name'];
    $userId = $valAccess['user_id'];
    $memberId = $valAccess['member_id'];
    $topupFlag = $valAccess['topup_flag'];
    $incomeWallet = $valAccess['wallet'];
    $fundWallet = $valAccess['fundWallet'];
    $emailId = $valAccess['email_id'];
    $phone = $valAccess['phone'];
}

// Fetch activation/order details
$queryTransfer = mysqli_query($con, "
    SELECT  
        product_quentity AS quantity, 
        investPrice AS price, 
        date_time AS dateTime 
    FROM meddolic_user_activation_details
    WHERE member_id='$memberId'
    ORDER BY date_time DESC
");
$queryTransfer11 = mysqli_query($con, "SELECT product_id, productName, price FROM franchise_shopping_product_details WHERE status=1 ORDER BY product_id ASC");
$remarks11 = mysqli_fetch_assoc($queryTransfer11);
$product_id = $remarks11['product_id'];
$productName = $remarks11['productName'];
$productPrice = $remarks11['price'];

// Prepare products array and calculate total price
$totalPrice = 0;
$products = [];
while ($row = mysqli_fetch_assoc($queryTransfer)) {
    $row['total'] = $row['quantity'] * $row['price'];
    $totalPrice += $row['price'];
    $products[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Zero Problem Receipt</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            font-size: 14px;
            line-height: 1.6;
            background: #fff;
            padding: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #323232;
            padding: 6px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        h1,
        h3 {
            margin: 5px 0;
            text-align: center;
        }

        .header-logo {
            height: 50px;
            vertical-align: middle;
            margin-right: 10px;
        }

        .footer-logo {
            height: 100px;
            vertical-align: middle;
        }

        .text-center {
            text-align: center;
        }

        .download-btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #0d6efd;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            margin-top: 10px;
        }

        .no-border {
            border: none;
        }

        .personal-details,
        .payment-details {
            width: 50%;
            vertical-align: top;
        }

        .payment-details table th,
        .payment-details table td {
            border: 1px solid #323232;
        }

        .payment-details table tfoot td {
            font-weight: bold;
            background-color: #f2f2f2;
        }
    </style>
</head>

<body>

    <table>
        <!-- Header -->
        <tr>
            <td colspan="2" class="text-center no-border">
                <h1>
                    <img src="assets/images/logo.png" alt="Logo" class="header-logo">
                </h1>
                <h3>Distributor IBO : <?= htmlspecialchars($userId) ?> (<?= htmlspecialchars($userName) ?>)</h3>
            </td>
        </tr>

        <!-- Personal & Order Details -->
        <tr>
            <td class="personal-details">
                <b>Personal Details</b><br><br>
                Name: <?= htmlspecialchars($userName) ?><br>
                Distributor IBO: <?= htmlspecialchars($userId) ?><br>
                Mobile No.: <?= htmlspecialchars($phone) ?><br>
            </td>
            <td class="payment-details">
                <b>Order Details</b><br><br>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background-color: #f2f2f2;">
                            <th>Product ID</th>
                            <th>Product Name</th>
                            <th>Qty</th>
                            <th>Product Price</th>
                            <!-- <th>Retail Profite</th> -->

                            <th>Total Price</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $index => $prod): ?>
                            <tr style="background-color: <?= $index % 2 == 0 ? '#ffffff' : '#f9f9f9' ?>;">
                                <td><?= $product_id ?></td>
                                <td><?= $productName ?></td>
                                <td style="text-align: center;"><?= htmlspecialchars($prod['quantity']) ?></td>
                                <td style="text-align: right;">₹<?= number_format($productPrice, 2) ?></td>
                                <!-- <td style="text-align: right;">₹<?= (htmlspecialchars($prod['quantity'])) * 199 ?></td> -->

                                <td style="text-align: right;">₹<?= number_format($prod['price'], 2) ?></td>
                                <td style="text-align: center;"><?= date('d-m-Y', strtotime($prod['dateTime'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" style="text-align: right;">Total:</td>
                            <td style="text-align: right;">₹<?= number_format($totalPrice, 2) ?></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </td>
        </tr>

        <!-- Footer -->
        <tr>
            <td class="text-center no-border">
                <img src="assets/images/logo.png" alt="Logo" class="footer-logo"><br>
                Zero Problem Wellness
            </td>
            <td class="text-center no-border">
                Authorised Signature<br>
                This is a computer generated statement
            </td>
        </tr>

        <!-- Download Button -->
        <tr>
            <td colspan="2" class="text-center">
                <a class="download-btn" href="#" onclick="window.print(); return false;">
                    Download
                </a>
            </td>

        </tr>
    </table>

</body>

</html>