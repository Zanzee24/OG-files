<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Zero Problem Wellness | User Dashboard</title>
    <!-- Favicon -->

    <link rel="shortcut icon" href="assets/images/favicon.png" />
    <!-- Library / Plugin Css Build -->
    <link rel="stylesheet" href="assets/css/core/libs.min.css">
    <link rel="stylesheet" href="assets/css/datum.min.css?v=1.0.0">
    <!-- Custom Css -->
    <link rel="stylesheet" href="assets/css/custom.min.css?v=1.0.0">
    <!-- Customizer Css -->
    <link rel="stylesheet" href="assets/css/customizer.min.css?v=1.0.0">
    <!-- font-awesome css -->
       <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="assets/vendor/font-awesome/css/all.min.css?v=1.0.0" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap"
        rel="stylesheet">

<!-- DataTables & Buttons CSS -->
    <link rel="stylesheet" href="assets/datatable/jquery.dataTables.min.css" />
    <link rel="stylesheet" href="assets/datatable/buttons.dataTables.min.css" />

    <style>
        .crd1 {
            padding-bottom: 68px !important;
        }

        .crd2 {
            padding-bottom: 17px !important;
        }

        .sidbr {
            background-color: #039c95 !important;
            color: white !important;
        }

        .sid-br {
            background-color: #034543 !important;
        }

        .lan-2 {
            color: white !important;
        }

        .lan-3 {
            color: white !important;
        }

        .lan-6 {
            color: white !important;
        }

        .lan-7 {
            color: white !important;
        }

        .le1 {
            color: white !important;
        }

        .icn {
            color: white !important;
        }

        .sidebar-toggle {
            color: black !important;
        }
    </style>
   
    <link rel="stylesheet" type="text/css" href="assets/assets/css/css/icons.min.css">
    <link rel="stylesheet" type="text/css" href="assets/assets/member-assets/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="assets/assets/member-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/assets/member-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="assets/assets/member-assets/css/colors.min.css">
    <link rel="stylesheet" type="text/css" href="assets/assets/member-assets/css/components.min.css">
    <link rel="stylesheet" type="text/css" href="assets/assets/member-assets/css/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="assets/assets/css/css/style.css">

</head>