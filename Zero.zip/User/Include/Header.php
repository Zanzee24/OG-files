<?php
// require_once("../conection.php");
$queryAccess = mysqli_query($con, "SELECT name,user_id,member_id,topup_flag,wallet,fundWallet,email_id,phone FROM meddolic_user_details WHERE user_id='$_SESSION[member_user_id]'");
if ($valAccess = mysqli_fetch_array($queryAccess)) {
    $userName = $valAccess['name'];
    $userId = $valAccess['user_id'];
    $memberId = $valAccess['member_id'];
    $topupFlag = $valAccess['topup_flag'];
    $incomeWallet = $valAccess['wallet'];
    $fundWallet = $valAccess['fundWallet'];
    $emailId = $valAccess['email_id'];
    $phone = $valAccess['phone'];
} ?>


<div class="iq-top-navbar">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0">
            <div class="side-menu-bt-sidebar">
                <svg xmlns="http://www.w3.org/2000/svg" class="text-secondary wrapper-menu text-white" width="30" fill="none"
                    viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </div>
            <div class="d-flex align-items-center">
                <div class="change-mode">
                    <div class="custom-control custom-switch custom-switch-icon custom-control-inline">
                        <div class="custom-switch-inner">
                            <p class="mb-0"> </p>
                            <div class="form-check form-switch">
                                <input class="form-check-input custom-control-input" type="checkbox" id="dark-mode">
                                <label class="form-check-label custom-control-label" for="dark-mode">
                                    <span class="switch-icon-right">
                                        <svg xmlns="http://www.w3.org/2000/svg" id="h-moon" height="20" width="20"
                                            class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                                        </svg>
                                    </span>
                                    <span class="switch-icon-left">
                                        <svg xmlns="http://www.w3.org/2000/svg" id="h-sun" height="20" width="20"
                                            class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                                        </svg>
                                    </span>
                            </div>

                            </label>
                        </div>
                        
                    </div>
                    
                </div>
                <div class="user-nav d-sm-flex d-none flex-column">
    <span class="user-name fw-bold text-white"><?= $userName?></span>
    <small class=" text-white">ID: <?= $userId ?></small>
</div>
<span class="avatar position-relative d-inline-block">
    <img class="rounded-circle m-1" src="assets/assets/images/user.png" height="40" width="40" alt="User Avatar">
    
    <?php if ($topupFlag == 1): ?>
        <!-- Online -->
        <span class="position-absolute bottom-0 end-0 translate-middle p-1 bg-success border border-white rounded-circle"></span>
    <?php else: ?>
        <!-- Offline -->
        <span class="position-absolute bottom-0 end-0 translate-middle p-1 bg-danger border border-white rounded-circle"></span>
    <?php endif; ?>
</span>



                </div>
            </div>
    </div>
    </nav>
</div>
</div>