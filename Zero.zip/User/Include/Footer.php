<!-- Footer -->
<footer class="footer mt-4 bg-light py-3">
  <div class="container-fluid">
    <div class="d-flex justify-content-center align-items-center">
      <p class="mb-0 text-center text-muted fw-medium">© 2025 Zero Problem Wellness. All Rights Reserved.</p>
    </div>
  </div>
</footer>

</div>

<!-- Scripts -->
<script src="assets/js/core/libs.min.js"></script>
<script src="assets/js/customizer.min.js"></script>

<!-- Library Bundle Script -->
<script src="assets/js/core/libs.min.js"></script>
<script src="assets/js/core/external.min.js"></script>
<!-- Chart Custom JavaScript -->
<script src="assets/js/customizer.js"></script>

<script src="assets/js/sidebar.js"></script>

<!-- Flextree Javascript-->
<script src="assets/js/flex-tree.min.js"></script>
<script src="assets/js/tree.js"></script>

<!-- Table Treeview JavaScript -->
<script src="assets/js/table-treeview.js"></script>

<!-- SweetAlert JavaScript -->
<script src="assets/js/sweetalert.js"></script>

<!-- Vectoe Map JavaScript -->
<script src="assets/js/vector-map-custom.js"></script>

<!-- Chart Custom JavaScript -->
<script src="assets/js/chart-custom.js"></script>
<script src="assets/js/charts/01.js"></script>

<!-- slider JavaScript -->
<script src="assets/js/slider.js"></script>

<!-- Emoji picker -->
<script src="assets/vendor/emoji-picker-element/index.js" type="module"></script>


<!-- app JavaScript -->
<script src="assets/js/app.js"></script>
<script src="custom.js"></script>

<!-- jQuery -->
<script src="assets/datatable/jquery-3.7.0.min.js"></script>

<!-- DataTables JS -->
<script src="assets/datatable/jquery.dataTables.min.js"></script>
<script src="assets/datatable/dataTables.buttons.min.js"></script>
<script src="assets/datatable/buttons.html5.min.js"></script>
<script src="assets/datatable/buttons.print.min.js"></script>

<!-- JSZip and pdfmake for export buttons -->
<script src="assets/datatable/jszip.min.js"></script>
<script src="assets/datatable/pdfmake.min.js"></script>
<script src="assets/datatable/vfs_fonts.js"></script>
<script src="assets/assets/member-assets/js/vendors.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.1/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flatpickr/4.5.4/flatpickr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.4/clipboard.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/spin.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/ladda.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.5/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.5/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.5/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.5/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.5/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/keytable/2.5.1/js/dataTables.keyTable.min.js"></script>
    <script src="https://cdn.datatables.net/select/1.2.7/js/dataTables.select.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="assets/assets/js/js/datatables.init.js"></script>
    <script src="assets/assets/member-assets/js/app-menu.min.js"></script>
    <script src="assets/assets/member-assets/js/app.js"></script>
    <script src="assets/assets/js/js/scripts.js"></script>
    <script src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.11"></script>

<script>
  $(document).ready(function () {
    $('.table').DataTable({
      dom: 'Bfrtip',
      buttons: ['copy', 'excel', 'csv', 'pdf'],
      paging: true,
      searching: true,
      ordering: true,
      pageLength: 10,  // Show 10 entries per page by default
      lengthMenu: [5, 10, 25, 50, 100]
    });
  });
</script>
</body>

</html>