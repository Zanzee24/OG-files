<?php require_once('Include/Head.php'); ?>
<style>
  html,
  body,
  .content-page {
    height: 100%;
    margin: 0;
    padding: 0;
  }
</style>

<div class="content-page">
  <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
    <div class="login-wrapper bg-white shadow p-4 rounded" style="width: 100%; max-width: 400px;">

      <!-- Logo -->
      <div class="text-center mb-3">
        <img src="assets/images/logo.png" alt="Logo" style="max-width: 110px;">
      </div>

      <!-- Welcome Text -->
      <h5 class="text-center text-primary font-weight-bold mb-4">Welcome Member...!</h5>

      <form method="post" action="con-login">

        <div class="form-group">
          <input type="text" class="form-control" id="inputUserId" placeholder="UserId" required
            value="<?php if (isset($_COOKIE[" memberUserId"])) {
              echo $_COOKIE["memberUserId"];
            } ?>">
        </div>

        <div class="form-group">
          <input type="password" class="form-control" name="login[password]" id="inputPassword"
            placeholder="Enter Password" onkeypress="return catchEnter(event)"
            value="<?php if (isset($_COOKIE[" memberPassKey"])) {
              echo $_COOKIE["memberPassKey"];
            } ?>">
          <small class="form-text text-right">
            <a href="authPassRecovery" class="text-success">Forgot Password?</a>
          </small>
        </div>

        <button class="btn btn-primary w-100" type="button" id="loginSubmit" onclick="LoginValidate()">Sign in</button>
        <button disabled style="display: none;" class="btn btn-warning btn-block w-100 loadingMore">Validating
          Data...</button>
      </form>

      <!-- Register Link -->
      <div class="mt-4 text-center">
        Don’t have an account?
        <a href="../authUserRegister" class="text-success font-weight-bold">Register Here!</a>
      </div>
    </div>
  </div>
</div>

<!-- JS -->

<script src="custom.js"></script>
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<!-- Appear JavaScript -->
<script src="../assets/js/jquery.appear.js"></script>
<!-- Countdown JavaScript -->
<script src="../assets/js/countdown.min.js"></script>
<!-- Counterup JavaScript -->
<script src="../assets/js/waypoints.min.js"></script>
<script src="../assets/js/jquery.counterup.min.js"></script>
<!-- Wow JavaScript -->
<script src="../assets/js/wow.min.js"></script>
<!-- Apexcharts JavaScript -->
<script src="../assets/js/apexcharts.js"></script>
<!-- Slick JavaScript -->
<script src="../assets/js/slick.min.js"></script>
<!-- Select2 JavaScript -->
<script src="../assets/js/select2.min.js"></script>
<!-- Owl Carousel JavaScript -->
<script src="../assets/js/owl.carousel.min.js"></script>
<!-- Magnific Popup JavaScript -->
<script src="../assets/js/jquery.magnific-popup.min.js"></script>
<!-- Smooth Scrollbar JavaScript -->
<script src="../assets/js/smooth-scrollbar.js"></script>
<!-- lottie JavaScript -->
<script src="../assets/js/lottie.js"></script>
<!-- am core JavaScript -->
<script src="../assets/js/core.js"></script>
<!-- am charts JavaScript -->
<script src="../assets/js/charts.js"></script>
<!-- am animated JavaScript -->
<script src="../assets/js/animated.js"></script>
<!-- am kelly JavaScript -->
<script src="../assets/js/kelly.js"></script>
<!-- Flatpicker Js -->
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<!-- Chart Custom JavaScript -->
<script src="../assets/js/chart-custom.js"></script>
<!-- Custom JavaScript -->
<script src="../assets/js/custom.js"></script>
<!-- Datatables-->
<script src="../assets/js/DataTable/js/jquery.dataTables.min.js"></script>
<script src="../assets/js/DataTable/js/dataTables.bootstrap4.min.js"></script>
<script src="../assets/js/DataTable/js/dataTables.buttons.min.js"></script>
<script src="../assets/js/DataTable/js/buttons.bootstrap4.min.js"></script>
<script src="../assets/js/DataTable/js/jszip.min.js"></script>
<script src="../assets/js/DataTable/js/pdfmake.min.js"></script>
<script src="../assets/js/DataTable/js/vfs_fonts.js"></script>
<script src="../assets/js/DataTable/js/buttons.html5.min.js"></script>
<script src="../assets/js/DataTable/js/buttons.print.min.js"></script>
<script src="../assets/js/DataTable/js/buttons.bootstrap.js"></script>
<!-- DATETIMEPICKER-->
<script src="../assets/datepicker/bootstrap-datepicker.min.js"></script>
<script src="../assets/sweetalert/dist/sweetalert.min.js"></script>