<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>

<div class="content-page">
  <div class="container-fluid ">
    <h4 class="fw-bold mb-3">
      <i class="fa fa-user-plus  text-primary me-2"></i>Rank Bonus
    </h4>

    <div class="row">
      <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body p-3">
          <!-- Responsive wrapper -->
          <div class="card">
            <div style="overflow-x: auto;">
              <div style="min-width: 600px;">
                <div class="card-body">
                  <div class="dt-ext table-responsive">
                    <table id="export-button" class="table table-bordered table-hover table-sm nowrap"
                      style="width:100%">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>User ID</th>
                          <th>Name</th>
                          <th>Rank Name</th>
                          <th>status </th>

                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $count = 0;
                        $queryLevel = mysqli_query($con, "SELECT  a.rewardId, a.rankName, b.name, b.user_id,b.currentReward  FROM meddolic_config_reward_income a, meddolic_user_details b WHERE b.member_id='$memberId' ORDER BY a.rewardId ASC");
                        while ($valLevel = mysqli_fetch_assoc($queryLevel)) {
                          $count++;
                        ?>
                          <tr>
                            <td><?= $count ?></td>
                            <td><?= $valLevel['user_id'] ?></td>
                            <td><?= $valLevel['name'] ?></td>
                            <td><?= $valLevel['rankName'] ?></td>

                            <td>
                              <?php if ($valLevel['rewardId'] <= $valLevel['currentReward']) { ?>
                                <span class="badge bg-success">Achieved</span>
                              <?php } else { ?>
                                <span class="badge bg-danger">Not Achieved</span>
                              <?php } ?>
                            </td>

                          </tr>
                        <?php } ?>
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>

      <?php require_once('Include/Footer.php'); ?>