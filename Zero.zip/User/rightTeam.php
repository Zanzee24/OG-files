<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>

<div class="content-page">
  <div class="container-fluid">
    <h4 class="fw-bold mb-3"><i class="fa fa-group  text-primary me-2"></i>Right Team</h4>

    <div class="row">
      <div class="card">
        <div class="card-body">

          <!-- ✅ Scrollable container -->
          <div style="width: 100%; overflow-x: auto;">
            <div style="min-width: 1000px;">
             <table id="export-button" class="table table-bordered table-hover table-sm nowrap"
                      style="width:100%">
                <thead>   
                                <tr>
                                    <th>#</th>
                                    <th>UserId</th>
                                    <th>Name</th>
                                    <th>EmailId</th>
                                    <th>Phone</th>
                                    <th>Register Date</th>
                                    <th>Active Status</th>
                                    <th>Active Date</th>
                                    <th>Total Business</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 
                            function totalInvest($con,$memberId){
                              $queryInvest=mysqli_query($con,"SELECT SUM(investPrice) FROM meddolic_user_activation_details WHERE member_id='$memberId'");
                              $valInvest=mysqli_fetch_array($queryInvest);
                              if($valInvest[0]!=""){
                                return $valInvest[0];
                              }else{
                                echo "0.00";
                              }
                            }
                            $count=0;
                            $queryDirect=mysqli_query($con,"SELECT a.member_id,a.user_id,a.name,a.email_id,a.phone,a.date_time,a.topup_flag,a.activation_date FROM meddolic_user_details a,meddolic_user_child_ids b WHERE b.member_id='$memberId' AND a.member_id=b.child_id AND b.legPosition=3 ORDER BY b.date_time DESC");
                            while($valDirect=mysqli_fetch_assoc($queryDirect)){
                              $count++; ?>
                            <tr>
                              <td><?= $count?></td>
                              <td><?= $valDirect['user_id']?></td>
                              <td><?= $valDirect['name']?></td>
                              <td><?= $valDirect['email_id']?></td>
                              <td><?= $valDirect['phone']?></td>
                              <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valDirect['date_time']));?></td>
                              <td><?php if($valDirect['topup_flag']==1) echo "<span class='badge bg-success'>Active</span>"; else echo "<span class='badge bg-danger'>In-Active</span>"; ?></td>
                              <td><?= $valDirect['activation_date']?></td>
                              <td><span class="badge bg-success"> <i class="fa fa-inr"></i> <?= totalInvest($con,$valDirect['member_id'])?></span></td>
                            </tr>
                            <?php } ?>     
                            </tbody>             
              </table>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once('Include/Footer.php'); ?>

<style>
  /* Ensure the table headers are visible while scrolling */
  table {
    border-collapse: collapse;
    width: 100%;
  }

  th,
  td {
    padding: 8px;
    text-align: left;
    white-space: nowrap;
    /* Prevent text from wrapping */
  }

  th {
    background-color: #f8f9fa;
    /* Light background for headers */
    position: sticky;
    /* Make header sticky */
    top: 0;
    /* Stick to the top */
    z-index: 10;
    /* Ensure it stays above other content */
  }

  /* Optional: Add some styles for better visibility */
  tr:nth-child(even) {
    background-color: #f2f2f2;
    /* Zebra striping for rows */
  }
</style>