<?php require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?> 
            <div class="content-page">
                <div class="container-fluid">
                    <h4 class="fw-bold mb-3">My Team</h4> <!-- Added heading -->
                                        <h4 class="fw-bold mb-3">Team and Network / Assets</h4> <!-- Added heading -->
                    
                        <div class="row">
                            <div class="card">
                                <div class="card-body">
                                    <div class="dt-ext table-responsive">
                                        <table class="table table-bordered table-hover display margin-top-10 w-p100">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>User Id</th>
                                                    <th>Name</th>
                                                    <th>Income Wallet</th>
                                                    <th>Purchase Wallet</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>U001</td>
                                                    <td>John Doe</td>
                                                    <td>$1,500</td>
                                                    <td>$500</td>
                                                </tr>
                                                <tr>
                                                    <td>2</td>
                                                    <td>U002</td>
                                                    <td>Jane Smith</td>
                                                    <td>$2,000</td>
                                                    <td>$750</td>
                                                </tr>
                                                <tr>
                                                    <td>3</td>
                                                    <td>U003</td>
                                                    <td>Michael Johnson</td>
                                                    <td>$1,200</td>
                                                    <td>$300</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                    
              <?php require_once('Include/Footer.php')  
              ?>   