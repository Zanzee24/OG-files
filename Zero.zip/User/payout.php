<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>

<div class="content-page">
    <div class="container-fluid ">
        <h4 class="fw-bold mb-3">
            <i class="fa fa-line-chart text-primary me-2"></i> Payout Report
        </h4>

        <div class="row">
            <div class="card shadow-sm border-0 rounded-4">
                <div class="card-body p-3">
                    <!-- Responsive wrapper -->
                    <div class="card">
                        <div style="overflow-x: auto;">
                            <div style="min-width: 600px;">
                                <div class="card-body">
                                    <div class="dt-ext table-responsive">
                                        <table id="export-button" class="table table-bordered table-hover table-sm nowrap"
                                            style="width:100%">
                                            <thead class="table-dark">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date & Time</th>
                                                    <th>Team Matching Income</th>
                                                    <th>Award & Reward Income</th>
                                                    <th>Monthly Salary Income</th>
                                                    <th>SP Points</th>
                                                    <th>Total Payable</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    // Get user details
                                                    $userQuery = mysqli_query($con, "SELECT user_id, name FROM meddolic_user_details WHERE member_id='$memberId'");
                                                    $userData = mysqli_fetch_array($userQuery);
                                                    $userId = $userData['user_id'] ?? '';
                                                    $userName = $userData['name'] ?? '';
                                                    
                                                    if (!$userId) {
                                                        echo "<tr><td colspan='8' class='text-center text-danger'>User not found</td></tr>";
                                                    } else {
                                                        // Main query to get all transactions date-wise in DESC order
                                                        $mainQuery = "
                                                            SELECT 
                                                                DATE(combined_date) as transaction_date,
                                                                MAX(combined_date) as latest_time
                                                            FROM (
                                                                SELECT date as combined_date FROM meddolic_user_token_matching_income WHERE memberId='$memberId' AND status=1
                                                                UNION ALL
                                                                SELECT date_time as combined_date FROM meddolic_user_reward_income_details WHERE member_id='$memberId' AND releaseStatus=1
                                                                UNION ALL
                                                                SELECT date_time as combined_date FROM meddolic_user_salary_income_details WHERE member_id='$memberId' AND releaseStatus=1
                                                                UNION ALL
                                                                SELECT date_time as combined_date FROM meddolic_user_activation_details WHERE member_id='$memberId' AND status=1
                                                            ) as all_dates
                                                            GROUP BY DATE(combined_date)
                                                            ORDER BY transaction_date DESC
                                                        ";
                                                        
                                                        $mainResult = mysqli_query($con, $mainQuery);
                                                        $count = 0;
                                                        $totalMatchingIncome = 0;
                                                        $totalRewardIncome = 0;
                                                        $totalSalaryIncome = 0;
                                                        $totalSP = 0;
                                                        $grandTotal = 0;
                                                        
                                                        if (mysqli_num_rows($mainResult) > 0) {
                                                            while ($dateRow = mysqli_fetch_array($mainResult)) {
                                                                $count++;
                                                                $currentDate = $dateRow['transaction_date'];
                                                                $latestTime = $dateRow['latest_time'];
                                                                
                                                                // Get Team Matching Income for this date
                                                                $matchingQuery = mysqli_query($con, "
                                                                    SELECT 
                                                                        COALESCE(SUM(matchingIncome), 0) as total_matching,
                                                                        MAX(date) as match_time
                                                                    FROM meddolic_user_token_matching_income 
                                                                    WHERE memberId='$memberId' 
                                                                    AND DATE(date) = '$currentDate' 
                                                                    AND status = 1
                                                                ");
                                                                $matchingRow = mysqli_fetch_array($matchingQuery);
                                                                $matchingIncome = $matchingRow['total_matching'];
                                                                $matchTime = $matchingRow['match_time'];

                                                                // Get Award & Reward Income for this date
                                                                $rewardQuery = mysqli_query($con, "
                                                                    SELECT 
                                                                        COALESCE(SUM(rewardIncome), 0) as total_reward,
                                                                        MAX(date_time) as reward_time,
                                                                        GROUP_CONCAT(rewardId ORDER BY rewardId) as reward_ids
                                                                    FROM meddolic_user_reward_income_details 
                                                                    WHERE member_id='$memberId' 
                                                                    AND DATE(date_time) = '$currentDate' 
                                                                    AND releaseStatus = 1
                                                                ");
                                                                $rewardRow = mysqli_fetch_array($rewardQuery);
                                                                $rewardsIncome = $rewardRow['total_reward'];
                                                                $rewardTime = $rewardRow['reward_time'];
                                                                $rewardIds = $rewardRow['reward_ids'];

                                                                // Get Monthly Salary Income for this date
                                                                $salaryQuery = mysqli_query($con, "
                                                                    SELECT 
                                                                        COALESCE(SUM(salaryIncome), 0) as total_salary,
                                                                        MAX(date_time) as salary_time
                                                                    FROM meddolic_user_salary_income_details 
                                                                    WHERE member_id='$memberId' 
                                                                    AND DATE(date_time) = '$currentDate' 
                                                                    AND releaseStatus = 1
                                                                ");
                                                                $salaryRow = mysqli_fetch_array($salaryQuery);
                                                                $salaryIncome = $salaryRow['total_salary'];
                                                                $salaryTime = $salaryRow['salary_time'];

                                                                // Get SP Points for this date
                                                                $spQuery = mysqli_query($con, "
                                                                    SELECT 
                                                                        COALESCE(SUM(SP_Point), 0) as total_sp,
                                                                        COUNT(*) as activation_count
                                                                    FROM meddolic_user_activation_details 
                                                                    WHERE member_id='$memberId' 
                                                                    AND DATE(date_time) = '$currentDate' 
                                                                    AND status = 1
                                                                ");
                                                                $spRow = mysqli_fetch_array($spQuery);
                                                                $SP_Point = $spRow['total_sp'];
                                                                $activationCount = $spRow['activation_count'];

                                                                // Calculate payable amount for this date
                                                                $Payable = $matchingIncome + $rewardsIncome + $salaryIncome;
                                                                
                                                                // Add to grand totals
                                                                $totalMatchingIncome += $matchingIncome;
                                                                $totalRewardIncome += $rewardsIncome;
                                                                $totalSalaryIncome += $salaryIncome;
                                                                $totalSP += $SP_Point;
                                                                $grandTotal += $Payable;
                                                                
                                                                // Display latest transaction time for the date
                                                                $displayTime = $latestTime;
                                                ?>
                                                    <tr>
                                                        <td><strong><?= $count ?></strong></td>
                                                        <td>
                                                            <strong><?= date('d M Y', strtotime($currentDate)) ?></strong><br>
                                                            <small class="text-muted">
                                                                <i class="fa fa-clock-o"></i> <?= date('h:i A', strtotime($displayTime)) ?>
                                                            </small>
                                                        </td>
                                                        <td>
                                                            <?php if ($matchingIncome > 0): ?>
                                                                <span class="badge bg-success">₹ <?= number_format($matchingIncome, 2) ?></span>
                                                                <?php if ($matchTime): ?>
                                                                    <br><small class="text-muted"><?= date('h:i A', strtotime($matchTime)) ?></small>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <span class="text-muted">0</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if ($rewardsIncome > 0): ?>
                                                                <span class="badge bg-warning text-dark">₹ <?= number_format($rewardsIncome, 2) ?></span>
                                                                <?php if ($rewardTime): ?>
                                                                    <br><small class="text-muted"><?= date('h:i A', strtotime($rewardTime)) ?></small>
                                                                <?php endif; ?>
                                                                <?php if ($rewardIds): ?>
                                                                    <br><small class="badge bg-secondary">Rewards: <?= $rewardIds ?></small>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <span class="text-muted">0</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if ($salaryIncome > 0): ?>
                                                                <span class="badge bg-info">₹ <?= number_format($salaryIncome, 2) ?></span>
                                                                <?php if ($salaryTime): ?>
                                                                    <br><small class="text-muted"><?= date('h:i A', strtotime($salaryTime)) ?></small>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <span class="text-muted">0</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if ($SP_Point > 0): ?>
                                                                <span class="badge bg-primary"><?= number_format($SP_Point) ?> SP</span>
                                                                <?php if ($activationCount > 1): ?>
                                                                    <br><small class="text-muted">(<?= $activationCount ?> activations)</small>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                <span class="text-muted">0</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <strong class="text-success">₹ <?= number_format($Payable, 2) ?></strong>
                                                        </td>
                                                        <td>
                                                            <a href="newreport.php?ResID=<?= $userId ?>&date=<?= $currentDate ?>" 
                                                               target="_blank" 
                                                               class="btn btn-sm btn-primary">
                                                                <i class="fa fa-file-text"></i> Receipt
                                                            </a>
                                                        </td>
                                                    </tr>
                                                <?php
                                                            }
                                                            
                                                            // Display totals row
                                                ?>
                                                    <tr class="table-secondary fw-bold">
                                                        <td colspan="2" class="text-end"><strong> TOTAL:</strong></td>
                                                        <td><span class="badge bg-success">₹ <?= number_format($totalMatchingIncome, 2) ?></span></td>
                                                        <td><span class="badge bg-warning text-dark">₹ <?= number_format($totalRewardIncome, 2) ?></span></td>
                                                        <td><span class="badge bg-info">₹ <?= number_format($totalSalaryIncome, 2) ?></span></td>
                                                        <td><span class="badge bg-primary"><?= number_format($totalSP) ?> SP</span></td>
                                                        <td><strong class="text-success fs-5">₹ <?= number_format($grandTotal, 2) ?></strong></td>
                                                        <td></td>
                                                    </tr>
                                                <?php
                                                        } else {
                                                            echo "<tr><td colspan='8' class='text-center text-warning'>No payout records found for this user</td></tr>";
                                                        }
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once('Include/Footer.php'); ?>