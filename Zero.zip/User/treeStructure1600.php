<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
  <?php
if ($_GET) {
  $userId1 = $_GET['userId'];
} else {
  $userId1 = $userId;
} ?>

<div class="content-page">
  <div class="container-fluid">
    <h4 class="fw-bold mb-3"><i class="fa fa-sitemap  text-primary me-2"></i> Team Tree</h4> <!-- Added heading -->

    <div class="row">
            <div class="box">
                <div class="box-header with-border">
                    <!-- <h4 class="box-title">Tree View</h4> -->
                </div>
                <div class="box-body">
                    <div class="table-responsive">
                        <div class="table-panel">
                            <div class="row">
                                <div class="col-lg-12">
                                     <?php
                                    $queryNew = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE user_id='$userId1'");
                                    $valNew = mysqli_fetch_assoc($queryNew);
                                    $memberId1 = $valNew['member_id'] ?>
                                    <iframe src="binaryPackageTree/binaryTree1600?member_id=<?= $memberId1 ?>" style="width: 100%; height: 500px; background: white; border: none;"></iframe>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
  </div>
</div>

<?php require_once('Include/Footer.php'); ?>
<script>
    var d = document.getElementById("Team");
    d.className += " active";
    var d = document.getElementById("treeStructure");
    d.className += " active";
</script>
