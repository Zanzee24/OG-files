<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

   include("../../conection.php");

if (isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];
    
     $query = mysqli_query($con,"SELECT product_id,productName,price,dateTime FROM franchise_shopping_product_details WHERE product_id = '$productId'");
    if ($product = mysqli_fetch_assoc($query)) {
        echo '<div class="product-details">';
        echo '<h3>Product Details</h3>';
        echo '<table class="table table-bordered">';
        
        foreach ($product as $key => $value) {
            if ($value !== null && $value !== '') {
                echo '<tr>';
                echo '<th>' . ucfirst(str_replace('_', ' ', $key)) . '</th>';
                echo '<td>' . htmlspecialchars($value) . '</td>';
                echo '</tr>';
            }
        }
        
        echo '</table>';
        echo '</div>';
    } else {
        echo '<p>Product details not found.</p>';
    }
} else {
    echo '<p>No product selected.</p>';
}
?>