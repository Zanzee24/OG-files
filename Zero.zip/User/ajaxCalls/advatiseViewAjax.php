<!-- Add Withdrawal Payment Remark -->
<?php include('../../conection.php');
  $advertiseId=$_POST['advertiseId'];
  $queryDetails=mysqli_query($con,"SELECT advertiseUrl,watchTime FROM meddolic_config_ads_url WHERE advertiseId='$advertiseId'");
  $valDetails=mysqli_fetch_assoc($queryDetails); ?>
<div class="modal-body">
  <iframe src='<?= $valDetails['advertiseUrl']?>' height="100%" width="100%"></iframe>
</div>