<?php include('../../conection.php');

  $payment_id=$_POST['paymentId'];

  $queryDetails=mysqli_query($con,"SELECT * FROM meddolic_config_payment_details WHERE payment_id='$payment_id'");
  $valDetails=mysqli_fetch_assoc($queryDetails); ?>
<div class="card card-custom mb-4" style="max-width: 100%;">
    <div class="card-header fw-bold text-primary">
        <?= htmlspecialchars($valDetails['paymentName']) ?>
    </div>
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-12 col-md-6 mb-3 mb-md-0 d-flex flex-column justify-content-center" style="min-height:140px;">
                <label for="tronLink" class="form-label fw-semibold mb-2">Payment Address</label>
                <textarea type="text" class="form-control" readonly onclick="copyTronLink()" id="tronLink" style="min-height: 60px;"><?= htmlspecialchars($valDetails['paymentAddress']) ?></textarea>
            </div>
            <div class="col-12 col-md-6 text-center d-flex flex-column align-items-center justify-content-center" style="min-height:140px;">
                <?php if($valDetails['paymentImage']!="") { ?>
                    <img src="../<?= htmlspecialchars($valDetails['paymentImage']) ?>" class="img-fluid rounded shadow-sm mb-2" style="max-width:180px;max-height:120px;" alt="Payment QR/Logo">
                <?php } ?>
            </div>
        </div>
    </div>
</div>