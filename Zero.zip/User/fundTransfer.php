<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>


<div class="content-page">
  <div class="container-fluid">

    <!-- Page Title -->
    <h4 class="fw-bold mb-4"><i class="fa fa-exchange  text-primary me-2"></i>P2P Transfer</h4>

    <!-- Transfer Form -->
    <div class="row">
      <div class="col-md-12">
        <div class="card shadow-sm">
          <div class="card-body">
            <form class="theme-form" action="fundTransferProcess" method="post">
              <div class="mb-3">
                <label>User ID:</label>
                <input type="text" name="sponser_id" id="sponser_id" class="form-control" placeholder="e.g. xxxxxxxxxx"
                  onblur="sponser_valid(this.value)" required>
              </div>
              <div class="mb-3">
                <label>Name:</label>
                <input type="text" id="sponser_name" class="form-control" placeholder="e.g. John Doe" disabled="">
              </div>
              <div class="mb-3">
                <label>Fund Wallet </label>
                <input type="text" id="current_wallet" name="current_wallet" class="form-control" readonly
                  value="<?= $fundWallet ?>">
              </div>
              <div class="mb-3">
                <label>Amount To Transfer:</label>
                <input type="number" id="transferAmount" name="amount" class="form-control"
                  placeholder="e.g. Transfer Amount" onkeypress="return onlynum(event)">
              </div>
              <div class="mb-3">
                <label>Transaction Password:</label>
                <input type="password" name="trnPassword" class="form-control" placeholder="e.g. Transaction Password"
                  required>
              </div>
              <button class="btn btn-primary w-100" value="Transfer" name="fundTransfer">Transfer</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Transfer History Table -->
    <div class="row mt-5">
      <div class="col-12">
        <div class="card shadow-sm">
          <div class="card-header bg-light">
            <h5 class="mb-0">P2P Transfer History</h5>
          </div>
          <div class="card-body">
            <!-- ✅ Scrollable wrapper -->
            <div style="overflow-x: auto; width: 100%;">
              <table class="table table-bordered table-hover table-sm" style="min-width: 800px;">
                <thead class="table-light text-center">
                  <tr>
                    <th>#</th>
                    <th>SenderId</th>
                    <th>Sender Name</th>
                    <th>ReceiverId</th>
                    <th>Receiver Name</th>
                    <th>Transfer Amount</th>
                    <th>Transfer Date</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $count = 0;
                  $queryTransfer = mysqli_query($con, "SELECT a.amount,a.date_time,b.user_id AS senderId,b.name AS senderName,c.user_id AS receiverId,c.name AS receiverName FROM meddolic_user_fund_transfer_history a, meddolic_user_details b, meddolic_user_details c WHERE a.sender_member_id='$memberId' AND a.sender_member_id=b.member_id AND a.receiver_member_id=c.member_id ORDER BY a.date_time DESC");
                  while ($valTransfer = mysqli_fetch_assoc($queryTransfer)) {
                    $count++; ?>
                    <tr>
                      <td><?= $count ?></td>
                      <td><?= $valTransfer['senderId'] ?></td>
                      <td><?= $valTransfer['senderName'] ?></td>
                      <td><?= $valTransfer['receiverId'] ?></td>
                      <td><?= $valTransfer['receiverName'] ?></td>
                      <td>
                        <span class="badge bg-success" style="font-size:1rem;">
                          <i class="fa fa-inr"></i> <?= $valTransfer['amount'] ?>
                        </span>
                      </td>
                      <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTransfer['date_time'])); ?>
                      </td>
                    </tr>
                  <?php } ?>

                </tbody>
              </table>
            </div>
            <!-- End Scrollable wrapper -->
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require_once('Include/Footer.php'); ?>