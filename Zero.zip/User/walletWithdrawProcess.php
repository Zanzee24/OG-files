<?php
include("loginCheck.php");
require('../PHPMailer/EncrptyModel.php');
if (isset($_POST['walletWithdraw'])) {
	$queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
    WHERE user_id='{$_SESSION['member_user_id']}'");
	$valAccess = mysqli_fetch_array($queryAccess);
	if (!$valAccess) {
		echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
		exit;
	}
	$memberId = $valAccess['member_id'];
	$withdraw_amount = $_POST['withdrawAmount'];
	$minimumPayout = $_POST['minimumWithdraw'];
	$trnPassword = $_POST['trnPassword'];
	// $paymentId=$_POST['paymentId'];

	$d = date("Y-m-d H:i:s");
	$todayDate = date('Y-m-d');

	// Validate all required POST fields
	$requiredFields = ['withdrawAmount', 'minimumWithdraw', 'trnPassword'];
	foreach ($requiredFields as $field) {
		if (empty($_POST[$field])) {
			?>
			<script>
				alert("Please fill all required fields!");
				window.top.location.href = "walletWithdraw";
			</script>
			<?php
			exit;
		}
	}

	if ($withdraw_amount < 0 || $withdraw_amount == '') { ?>
		<script>
			alert("Please Enter Valid Withdraw Amount");
			window.top.location.href = 'walletWithdraw';
		</script>
		<?php
		exit;
	}

	if ($withdraw_amount < $minimumPayout) { ?>
		<script>
			alert("The Minimum withdraw amount is Rs <?= $minimumPayout; ?>");
			window.top.location.href = 'walletWithdraw';
		</script>
		<?php
		exit;
	}


	$queryBank = mysqli_query($con, "SELECT ifsc, bank, branch, accNo, accName FROM meddolic_user_bank_details WHERE memberId='$memberId'");
	$valBank = mysqli_fetch_array($queryBank);

	// Check if bank details are properly filled
	if (
		empty($valBank['ifsc']) ||
		empty($valBank['bank']) ||
		empty($valBank['branch']) ||
		empty($valBank['accNo']) ||
		empty($valBank['accName'])
	) {
		echo "<script>
        alert('Please complete your bank details before making a withdrawal.');
        window.top.location.href='bankDetail';
    </script>";
		exit;
	}


	$result = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_wallet_withdrawal_crypto WHERE member_id='$memberId' AND CAST(date_time AS date)='$todayDate' AND (released=1 OR released=0)");
	$val = mysqli_fetch_array($result);
	if ($val[0] >= 1) { ?>
		<script>
			alert("The Maximun Withdraw Limit Reached today");
			window.top.location.href = 'walletWithdraw';
		</script>
		<?php
		exit;
	}

	$queryWallet = mysqli_query($con, "SELECT  wallet FROM meddolic_user_details WHERE member_id='$memberId'");
	$valWallet = mysqli_fetch_array($queryWallet);
	$currentWallet = $valWallet[0];
	if ($currentWallet < $withdraw_amount) { ?>
		<script>
			alert("Insufficient Balance in Your Wallet To Withdraw");
			window.top.location.href = 'walletWithdraw';
		</script>
		<?php
		exit;
	}

	$queryCheck = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where member_id='$memberId'AND trnPassword='$trnPassword'");
	$valCheck = mysqli_fetch_array($queryCheck);
	if ($valCheck[0] == 0) { ?>
		<script>
			alert("Incorrect Transaction Password!!!");
			window.top.location.href = 'walletWithdraw';
		</script>
		<?php
		exit;
	}

	$orderId = rand(11101, 99999) . $memberId . date('s') . date('h');
	$queryConfig = mysqli_query($con, "SELECT withdrawCharge FROM meddolic_config_misc_setting");
	$valConfig = mysqli_fetch_assoc($queryConfig);
	$withdrawCharge = $valConfig['withdrawCharge'];

	$Charge = $withdraw_amount * $withdrawCharge / 100;
	$netAmount = $withdraw_amount - $Charge;

	$queryIn = mysqli_query($con, "INSERT INTO meddolic_user_wallet_withdrawal_crypto (`member_id`,`payout_date`,`date_time`,`amount`,`withdrawCharge`,`netAmount`,`orderid`,`paymentId`) VALUES ('$memberId','$todayDate','$d','$withdraw_amount','$Charge','$netAmount','$orderId','$paymentId')");
	$lastWithdraw = $con->insert_id;

	mysqli_query($con, "UPDATE meddolic_user_details SET wallet=wallet-'$withdraw_amount' WHERE member_id='$memberId'");

	mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`,`date_time`,`trn_id`) VALUES ('$memberId',11,1,'$withdraw_amount','$d','$lastWithdraw')"); ?>
	<script>
		alert("Wallet Withdraw Successfully");
		window.top.location.href = "walletWithdraw";
	</script>
<?php } ?>
<?php include("../close-connection.php"); ?>