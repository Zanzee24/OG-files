<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
<div class="content-page">
    <div class="container-fluid">
        <h4 class="fw-bold mb-3">
            <i class="fa fa-user-plus  text-primary me-2"></i>
            User Profile
        </h4><!-- Heading moved outside the card -->
        <div class="row">
            <div class="col-sm-12 col-xl-12 xl-100">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="icon-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="trnPassTab" data-bs-toggle="tab" href="#trnPass"
                                    role="tab">
                                    <i class="fa fa-lock"></i> Transaction Security
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="icon-tabContent">
                            <div class="tab-pane fade active show" id="trnPass" role="tabpanel">
                                <form class="form theme-form" action="userProfileAuthProcess" method="POST">
                                    <div class="card-body">
                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">Current Transaction Password
                                                *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" name="trnPassword"
                                                    placeholder="Current Transaction Password">
                                                <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">New Transaction Password *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" id="trnPassword"
                                                    placeholder="Enter New Password"
                                                    onkeyup="matchPassword('trnPassword','confirmTrnPassword','trnPwdErrorMsg','trnJoin')"
                                                    name="trnPassword1">
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">Retype Transaction Password *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" id="confirmTrnPassword"
                                                    placeholder="Retype Transaction Password"
                                                    onkeyup="matchPassword('trnPassword','confirmTrnPassword','trnPwdErrorMsg','trnJoin')"
                                                    name="trnPassword2">
                                                <span id="trnPwdErrorMsg" class="text-danger"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card-footer text-end">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button class="btn btn-success" type="submit" name="changeTrn"
                                                id="trnJoin">Change</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php require_once('Include/Footer.php')
            ?>