<?php
require_once("../conection.php");
$ResID = isset($_GET['ResID']) ? trim($_GET['ResID']) : null;
$selectedDate = isset($_GET['date']) ? trim($_GET['date']) : date('Y-m-d');

// Fetch user details from ResID
$queryUser = mysqli_query($con, "SELECT name, user_id, member_id, wallet, fundWallet, email_id, phone, aadhar_address 
    FROM meddolic_user_details 
    WHERE user_id='$ResID'");

if ($valUser = mysqli_fetch_array($queryUser)) {
    $userName = $valUser['name'];
    $userId = $valUser['user_id'];
    $memberId = $valUser['member_id'];
    $incomeWallet = $valUser['wallet'];
    $fundWallet = $valUser['fundWallet'];
    $emailId = $valUser['email_id'];
    $phone = $valUser['phone'];
    $address = $valUser['aadhar_address'];
} else {
    die("User not found");
}

// Get Company Payout Number (total payouts till date)
$companyPayoutQuery = mysqli_query($con, "
    SELECT COUNT(DISTINCT DATE(date)) as total_payouts
    FROM meddolic_user_token_matching_income
    WHERE status = 1
");
$companyPayoutData = mysqli_fetch_array($companyPayoutQuery);
$companyPayoutNo = $companyPayoutData['total_payouts'] ?? 0;

// Get User's Payout Number (user's payout count till selected date)
$userPayoutQuery = mysqli_query($con, "
    SELECT COUNT(DISTINCT transaction_date) as user_payouts
    FROM (
        SELECT DATE(date) as transaction_date FROM meddolic_user_token_matching_income WHERE memberId='$memberId' AND status=1 AND DATE(date) <= '$selectedDate'
        UNION
        SELECT DATE(date_time) as transaction_date FROM meddolic_user_reward_income_details WHERE member_id='$memberId' AND releaseStatus=1 AND DATE(date_time) <= '$selectedDate'
        UNION
        SELECT DATE(date_time) as transaction_date FROM meddolic_user_salary_income_details WHERE member_id='$memberId' AND releaseStatus=1 AND DATE(date_time) <= '$selectedDate'
        UNION
        SELECT DATE(date_time) as transaction_date FROM meddolic_user_activation_details WHERE member_id='$memberId' AND status=1 AND DATE(date_time) <= '$selectedDate'
    ) as all_dates
");
$userPayoutData = mysqli_fetch_array($userPayoutQuery);
$myPayoutNo = $userPayoutData['user_payouts'] ?? 0;

// Get Team Matching Income for selected date
$matchingQuery = mysqli_query($con, "
    SELECT COALESCE(SUM(matchingIncome), 0) as total_matching
    FROM meddolic_user_token_matching_income 
    WHERE memberId='$memberId' 
    AND DATE(date) = '$selectedDate' 
    AND status = 1
");
$matchingRow = mysqli_fetch_array($matchingQuery);
$matchingIncome = $matchingRow['total_matching'];

// Get Award & Reward Income for selected date
$rewardQuery = mysqli_query($con, "
    SELECT COALESCE(SUM(rewardIncome), 0) as total_reward
    FROM meddolic_user_reward_income_details 
    WHERE member_id='$memberId' 
    AND DATE(date_time) = '$selectedDate' 
    AND releaseStatus = 1
");
$rewardRow = mysqli_fetch_array($rewardQuery);
$rewardsIncome = $rewardRow['total_reward'];

// Get Monthly Salary Income for selected date
$salaryQuery = mysqli_query($con, "
    SELECT COALESCE(SUM(salaryIncome), 0) as total_salary
    FROM meddolic_user_salary_income_details 
    WHERE member_id='$memberId' 
    AND DATE(date_time) = '$selectedDate' 
    AND releaseStatus = 1
");
$salaryRow = mysqli_fetch_array($salaryQuery);
$salaryIncome = $salaryRow['total_salary'];

// Get SP Points for selected date
$spQuery = mysqli_query($con, "
    SELECT COALESCE(SUM(SP_Point), 0) as total_sp
    FROM meddolic_user_activation_details 
    WHERE member_id='$memberId' 
    AND DATE(date_time) = '$selectedDate' 
    AND status = 1
");
$spRow = mysqli_fetch_array($spQuery);
$SP_Point = $spRow['total_sp'];

// Calculate Total Earnings
$totalEarnings = $matchingIncome + $rewardsIncome + $salaryIncome;

// Calculate TDS (5% of total earnings)
$tdsRate = 5;
$tdsAmount = ($totalEarnings * $tdsRate) / 100;

// Calculate Admin Charge (assuming 10% - adjust as needed)
$adminChargeRate = 10;
$adminCharge = ($totalEarnings * $adminChargeRate) / 100;

// Over Data (if any deduction)
$overData = 0;

// Total Deductions
$totalDeductions = $tdsAmount + $overData;

// Net Payable Amount
$netPayable = $totalEarnings - $totalDeductions;

// Get Business Summary - Cumulative till selected date
$businessQuery = mysqli_query($con, "
    SELECT 
        COALESCE(SUM(leftBus), 0) as total_left,
        COALESCE(SUM(rightBus), 0) as total_right
    FROM meddolic_user_reward_income_details 
    WHERE member_id='$memberId' 
    AND DATE(date_time) <= '$selectedDate'
    AND releaseStatus = 1
");
$businessRow = mysqli_fetch_array($businessQuery);
$totalLeftBusiness = $businessRow['total_left'];
$totalRightBusiness = $businessRow['total_right'];

// Get Business for current date only
$newBusinessQuery = mysqli_query($con, "
    SELECT 
        COALESCE(SUM(leftBus), 0) as new_left,
        COALESCE(SUM(rightBus), 0) as new_right
    FROM meddolic_user_reward_income_details 
    WHERE member_id='$memberId' 
    AND DATE(date_time) = '$selectedDate'
    AND releaseStatus = 1
");
$newBusinessRow = mysqli_fetch_array($newBusinessQuery);
$newLeftBusiness = $newBusinessRow['new_left'];
$newRightBusiness = $newBusinessRow['new_right'];

// Calculate Business C.F. (Carried Forward - previous balance)
$cfLeftBusiness = $totalLeftBusiness - $newLeftBusiness;
$cfRightBusiness = $totalRightBusiness - $newRightBusiness;

// Paid SP (matched business)
$paidLeftSP = min($totalLeftBusiness, $totalRightBusiness);
$paidRightSP = $paidLeftSP;

// Carry Forward after matching
$cfLeft = $totalLeftBusiness - $paidLeftSP;
$cfRight = $totalRightBusiness - $paidRightSP;

// Date formatting
$fromPeriod = date('d-m-Y', strtotime($selectedDate));
$toPeriod = date('d-m-Y', strtotime($selectedDate));

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Payout Receipt - <?= htmlspecialchars($userId) ?></title>
    <style>
        @media print {
            .download-btn {
                display: none;
            }
        }
    </style>
</head>
<style>
    .header-logo {
        height: 50px;
        vertical-align: middle;
        margin-right: 10px;
    }

    .footer-logo {
        height: 100px;
        vertical-align: middle;
    }

    .text-center {
        text-align: center;
    }

    .download-btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: #fff;
        text-decoration: none;
        border-radius: 4px;
        margin-top: 10px;
        cursor: pointer;
        border: none;
        font-size: 16px;
    }
    
    .download-btn:hover {
        background-color: #0b5ed7;
    }
</style>

<body style="margin: 0;background: #fff;padding: 15px;font: 14px/1.8 'Arial', sans-serif;">
    <table style="width: 100%;border-collapse: collapse; display: table; border-spacing: 2px; margin-bottom: 0;line-height: 20px;white-space: nowrap">
        <tbody>
            <tr>
                <td colspan="4" class="text-center no-border">
                    <h1>
                        <img src="assets/images/logo.png" alt="Logo" class="header-logo">
                    </h1>
                    <h3>Distributor IBO : <?= htmlspecialchars($userId) ?> (<?= htmlspecialchars($userName) ?>)</h3>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">
                    <b>Personal Details</b>
                </td>
                <td colspan="2" style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">
                    <b>Payment Details</b>
                </td>
            </tr>
            <tr>
                <td style="vertical-align: top;border-left: 1px solid #323232;border-top: 1px solid #323232;border-bottom: 1px solid #323232;border-right: 0;padding: .25rem;">
                    Name : <br>
                    Distributor IBO : <br>
                    Mobile No. : <br>
                    Address :
                </td>
                <td style="vertical-align: top;border-left:0;border-top: 1px solid #323232;border-bottom: 1px solid #323232;padding: .25rem;white-space: normal">
                    <?= htmlspecialchars($userName) ?> <br>
                    <?= htmlspecialchars($userId) ?> <br>
                    <?= htmlspecialchars($phone) ?><br>
                    <?= htmlspecialchars($address ?: 'N/A') ?><br>
                </td>
                <td style="vertical-align: top;border-left: 1px solid #323232;border-top: 1px solid #323232;border-bottom: 1px solid #323232;border-right: 0;padding: .25rem;">
                    Company Payout No : <br>
                    My Payout No : <br>
                    From Period : <br>
                    To Period :
                </td>
                <td style="vertical-align: top;border-left:0;border-right: 1px solid #323232;border-top: 1px solid #323232;border-bottom: 1px solid #323232;padding: .25rem;">
                    <?= $companyPayoutNo ?> <br>
                    <?= $myPayoutNo ?> <br>
                    <?= $fromPeriod ?> <br>
                    <?= $toPeriod ?>
                </td>
            </tr>
            <tr>
                <td colspan="4" style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;"></td>
            </tr>
            <tr>
                <th style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">Earnings</th>
                <th style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">Amount (In INR )</th>
                <!-- <th style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">Deductions</th>
                <th style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">Amount (In INR )</th> -->
            </tr>
            <tr>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">
                    Team Matching Income <br>
                    Award And Reward Income <br>
                    Monthly Closing Matching Income<br>
                </td>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center">
                    <?= number_format($matchingIncome, 2) ?><br>
                    <?= number_format($rewardsIncome, 2) ?><br>
                    <?= number_format($salaryIncome, 2) ?><br>
                </td>
                <!-- <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: left">
                    TDS (<?= $tdsRate ?>%) <br>
                    Over Data <br>
                </td>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center">
                    <?= number_format($tdsAmount, 2) ?> <br>
                    <?= number_format($overData, 2) ?> <br>
                </td> -->
            </tr>
            <tr>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;"><strong>Total Earnings</strong></td>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center">
                    <strong><?= number_format($totalEarnings, 2) ?></strong>
                </td>
                <!-- <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: left"><strong>Total Deductions</strong></td>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center">
                    <strong><?= number_format($totalDeductions, 2) ?></strong>
                </td> -->
            </tr>
            <tr>
                <td colspan="2" style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">
                    <table style="width: 100%; border-collapse: collapse; display: table; border-spacing: 2px; margin-bottom: 0;line-height: 20px;white-space: nowrap">
                        <tbody>
                            <tr>
                                <th colspan="3" style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;background: #f0f0f0;">BUSINESS SUMMARY</th>
                            </tr>
                            <tr>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;background: #f8f8f8;"><strong>&nbsp;</strong></td>
                                <th style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;background: #f8f8f8;">Left SP</th>
                                <th style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;background: #f8f8f8;">Right SP</th>
                            </tr>
                            <tr>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong>Bu.C.F.</strong></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><?= number_format($cfLeftBusiness, 2) ?></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><?= number_format($cfRightBusiness, 2) ?></td>
                            </tr>
                            <tr>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong>New Bu.</strong></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><?= number_format($newLeftBusiness, 2) ?></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><?= number_format($newRightBusiness, 2) ?></td>
                            </tr>
                            <tr>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong>Total SP</strong></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong><?= number_format($totalLeftBusiness, 2) ?></strong></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong><?= number_format($totalRightBusiness, 2) ?></strong></td>
                            </tr>
                            <tr>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong>Paid SP</strong></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><?= number_format($paidLeftSP, 2) ?></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><?= number_format($paidRightSP, 2) ?></td>
                            </tr>
                            <tr>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong>C.F.</strong></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong><?= number_format($cfLeft, 2) ?></strong></td>
                                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center;"><strong><?= number_format($cfRight, 2) ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;">
                    <strong>Total Amount Payable (In SP)</strong> <br><br>
                    <strong>Net Payable Amount (In INR)</strong>
                </td>
                <td style="vertical-align: middle;border: 1px solid #323232;padding: .25rem;text-align: center">
                    <strong><?= number_format($SP_Point) ?></strong><br><br>
                    <strong style="font-size: 18px; color: #28a745;">₹ <?= number_format($totalEarnings, 2) ?></strong>
                </td>
            </tr>
            <tr>
                <td colspan="2" style="vertical-align: middle;border-left: 1px solid #323232;border-bottom: 1px solid #323232;border-right: 0;padding: 1rem;">
                    <img src="assets/images/logo.png" alt="Logo" class="footer-logo"><br>
                </td>
                <td colspan="2" style="vertical-align: middle;border-right: 1px solid #323232;border-bottom: 1px solid #323232;border-left: 0;padding: 1rem;">
                    <span>
                        <strong>Authorised Signature</strong><br>
                        <small>This is a computer generated statement</small><br>
                        <small>Generated on: <?= date('d-m-Y h:i A') ?></small>
                    </span>
                </td>
            </tr>
            <tr>
                <td colspan="4" style="text-align: center;padding: 1.5rem;">
                    <button class="download-btn" onclick="window.print(); return false;">
                        📥 Download / Print Receipt
                    </button>
                </td>
            </tr>
        </tbody>
    </table>
</body>

</html>