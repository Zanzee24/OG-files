<?php
    require_once("../conection.php");
    use PHPMailer\PHPMailer\PHPMailer;
    $userId = mysqli_real_escape_string($con,$_POST['userId']);
    $emailId = mysqli_real_escape_string($con,$_POST['emailId']);
    $authToken = mysqli_real_escape_string($con,$_POST['userAgent']);
    $sessionToken=$_SESSION['passTokenSet'];
    if($authToken==$sessionToken){
        $queryMail=mysqli_query($con,"SELECT name,phone,password,email_id FROM meddolic_user_details WHERE user_id='$userId' AND email_id='$emailId' AND user_type=2 AND account_status=1");
        if($valMail=mysqli_fetch_array($queryMail)){
            $emailId=$valMail['email_id'];
            $name=$valMail['name'];
            $password=$valMail['password'];
            // $trnPassword=$valMail['trnPassword'];

            require_once "../PHPMailer/PHPMailer.php";
            require_once "../PHPMailer/SMTP.php";
            require_once "../PHPMailer/Exception.php";
            require_once "../PHPMailer/OAuthCredential.php";

            $mailSubject="Zero Problem Wellness Password Recover";
    $newMsg = '
<html>
<head>
    <title>Zero Problem Wellness Password Recovery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            color: #333333;
            background-color: #ffffff;
            margin: 0;
            padding: 20px;
        }
        .email-container {
            max-width: 600px;
            margin: auto;
            border: 1px solid #eeeeee;
            padding: 20px;
            background-color: #fafafa;
        }
        .highlight {
            color: #4b0082;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            font-size: 12px;
            color: #777777;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <p>Dear <span class="highlight">' . $name . '</span>,</p>

        <p>We received a request to recover the login credentials for your Zero Problem Wellness account. Below are your login details:</p>

        <p><strong>Affiliate ID:</strong> <span class="highlight">' . $userId . '</span><br>
        <strong>Login Password:</strong> <span class="highlight">' . $password . '</span></p>

        <p>We recommend changing your password after your next login to ensure account security.</p>

        <p>Thank you,<br>
        <strong>Zero Problem Wellness Team</strong></p>

        <div class="footer">
            This is an automated message. Please do not reply to this email.
        </div>
    </div>
</body>
</html>';
            $mail = new PHPMailer();
            $mail->isSMTP();
            // $mail->SMTPDebug = 4;  //Keep It commented this is used for debugging                          
            $mail->Host = smtpServer; // smtp address of your email
            $mail->SMTPAuth = true;
            $mail->Username = EmailCode;
            $mail->Password = addCode;
            $mail->Port = smtpPort; 
            $mail->SMTPSecure = "tls"; 
            $mail->smtpConnect([
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
                ]
            ]);

            //Email Settings
            $mail->isHTML(true);
            $mail->setFrom(EmailCode, mailerName);
            $mail->addAddress($emailId); // enter email address whom you want to send
            $mail->Subject = ("$mailSubject");
            $mail->Body = $newMsg;
            $mail->send();

            echo "true";
            return true;
        } else {
            return false ;
        }    
    }else {
        return false ;
    } ?>
