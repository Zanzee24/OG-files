<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
<div class="content-page">
    <div class="container-fluid py-4">
        <h4 class="fw-bold mb-3 "><i class="fa fa-credit-card  text-primary me-2"></i>Fund Request</h4>
        <div class="row">
            <div class="col-lg-12 col-md-8 col-sm-12 ">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <form action="fundRequestBack" method="post" class="theme-form" enctype="multipart/form-data"
                            onsubmit="return confirm('Are You Sure to Submit?')">
                            <div class="mb-3">
                                <label class="form-label">UserId</label>
                                <input type="text" name="user_id" class="form-control" readonly value="<?= $userId ?>">

                            </div>
                            <div class="mb-3">
                                <label class="form-label">Name</label>
                                <input type="text" name="name" class="form-control" readonly value="<?= $userName ?>">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Fund Need (In <i class="fa fa-inr"></i>) *</label>
                                <input type="number" name="requestFund" class="form-control" required
                                    onkeypress="return onlynum(event)">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Payment Mode *</label>
                                <select class="form-control" name="payment_id" required
                                    onchange="showAddressQR(this.value)">
                                    <option value=""> Select One </option>
                                    <?php $queryMode = mysqli_query($con, "SELECT * FROM meddolic_config_payment_details WHERE status=1 ORDER BY payment_id ASC");
                                    while ($valMode = mysqli_fetch_assoc($queryMode)) { ?>
                                        <option value="<?= $valMode['payment_id'] ?>"> <?= $valMode['paymentName'] ?>
                                        </option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Payment Slip *</label>
                                <input type="file" name="transactionImage" class="form-control" required
                                    accept=".jpg, .png, .gif, .jpeg, .PNG, .GIF, .JPG, .JPEG">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Transaction ID *</label>
                                <input type="text" name="paymentHash" class="form-control" required>
                            </div>
                            <button class="btn btn-primary w-100" name="fundRequest">Submit</button>
                        </form>
                        <div class="col-12 col-md-12" id="paymentDetails" style="display:none;"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header ">
                        <h6>Fund Request History</h6>
                    </div>
                    <div class="card-body table-responsive">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>User ID</th>
                                        <th>Name</th>
                                        <th>Requested Amount</th>
                                        <th>Request Date</th>
                                        <th>Payment Mode</th>
                                        <th>Transaction ID</th>
                                        <th>Transaction Slip</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $queryFund = mysqli_query($con, "SELECT a.*,b.paymentName from meddolic_user_fund_request a, meddolic_config_payment_details b WHERE a.member_id='$memberId' AND  a.payment_id=b.payment_id ORDER BY a.date_time DESC");
                                    $count = 0;
                                    while ($valFund = mysqli_fetch_array($queryFund)) {
                                        $count++; ?>
                                        <tr>
                                            <td><?= $count; ?></td>
                                            <td><?= $valFund['user_id']; ?></td>
                                            <td><?= $valFund['name']; ?></td>
                                            <td>
                                                <span class="badge bg-success" style="font-size:1rem;">
                                                    <i class="fa fa-inr"></i> <?= $valFund['requestFund'] ?>
                                                </span>
                                            </td>
                                            <td><i class="fa fa-clock-o"></i> <?= $valFund['date_time']; ?></td>
                                            <td><?= $valFund['paymentName'] ?></td>
                                            <td><?= $valFund['paymentHash'] ?></td>
                                            <td><img src="<?= $valFund['transactionImage'] ?>" height="150px" width="150px">
                                            </td>
                                            <td>
                                                <?php
                                                if ($valFund['status'] == 1)
                                                    echo '<span class="badge bg-success">Approved</span>';
                                                else if ($valFund['status'] == 2)
                                                    echo '<span class="badge bg-danger">Rejected</span>';
                                                else if ($valFund['status'] == 0)
                                                    echo '<span class="badge bg-warning text-dark">Pending</span>';
                                                ?>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>

            function copyTronLink() {
                var copyText = document.getElementById("tronLink");
                copyText.select();
                document.execCommand("Copy");
                alert("Payment Details Copied Successfully!!!");
            }
            function showAddressQR(paymentId) {
                var showDiv = document.getElementById("paymentDetails");
                if (paymentId != "") {
                    $.ajax({
                        type: "POST",
                        url: 'ajaxCalls/fetchPaymentDetails',
                        data: { paymentId: paymentId },
                        cache: false,
                        success: function (data) {
                            showDiv.style.display = "block";
                            if (data) {
                                $('#paymentDetails').html(data);
                            }
                        }
                    });
                } else {
                    showDiv.style.display = "none";
                }
            }
        </script>
        <?php require_once('Include/Footer.php'); ?>