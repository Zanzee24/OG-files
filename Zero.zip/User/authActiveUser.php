<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');

?>
<div class="content-page">
    <div class="container-fluid">
        <h4 class="fw-bold mb-3"> <i class="fa fa-archive  text-primary me-2"></i> Purchase Package</h4>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <form class="theme-form" action="authActiveUserProcess" method="post">
                            <div class="mb-3">
                                <label>UserId *</label>
                                <input type="text" name="sponser_id" id="sponser_id" class="form-control"
                                    placeholder="Enter User Id" onblur="sponser_valid(this.value)" required>
                                <input type="hidden" name="loginMemberId" value="<?= $memberId ?>">
                            </div>
                            <div class="mb-3">
                                <label>Name *</label>
                                <input type="text" id="sponser_name" class="form-control" placeholder="e.g. Name"
                                    disabled>
                            </div>
                            <div class="mb-3">
                                <label> Fund Wallet *</label>
                                <input type="text" name="fundWallet" class="form-control" readonly
                                    value="<?= $fundWallet ?>">
                            </div>

                            <div class="mb-3">
                                <label for="productId">Select Product</label>
                                <select class="form-control" required id="productId" name="product_id"
                                    style="height:50px;width: 100%;">
                                    <option value="">Select Product (Min:2)</option>
                                    <?php
                                    $resultCountry = mysqli_query($con, "SELECT product_id, productName, price,quanitty,stock FROM franchise_shopping_product_details WHERE status=1 ORDER BY product_id ASC");
                                    while ($valCountry = mysqli_fetch_assoc($resultCountry)) {
                                    ?>
                                        <option value="<?= $valCountry['product_id'] ?>"
                                            data-name="<?= htmlspecialchars($valCountry['productName']) ?>"
                                            data-price="<?= $valCountry['price'] ?>"
                                            data-stock="<?= $valCountry['quanitty'] ?>">
                                            <?= htmlspecialchars($valCountry['productName']) ?> -
                                            ₹<?= $valCountry['price'] ?>
                                            (Available: <?= $valCountry['stock'] ?>)
                                        </option>
                                    <?php } ?>
                                </select>

                            </div>
                            <div id="productDetailsContainer" style="margin-top: 20px;"></div>

                            <div class="mb-3">
                                <label for="quantity">Enter Quantity(Min-2)</label>
                                <input type="number" class="form-control" id="quantity" name="quantity" min="2" required
                                    style="width: 100%;">
                            </div>
                            <input type="hidden" name="ResID" id="productIdField" value="">
                            <input type="hidden" name="frnch_member_Id" value="<?= $frnch_member_Id ?>">

                            <div id="billingInfo" class="border p-3 mt-3"
                                style="display: none; background-color: #f8f9fa;">
                                <div class="card">
                                    <div class="card-body col-sm-3">
                                        <div class="item-img text-center">
                                            <a href="">
                                                <img class="img-fluid card-img-top"
                                                    src="assets/images/1.png"
                                                    alt="Zero Problem Wellness" />
                                            </a>
                                        </div>
                                        <div class="card-body">
                                            <span class="product_title text-success">
                                                Zero Problem Wellness
                                            </span>
                                            <h6 class="item-name mb-1">
                                                <span id="billProductName"></span>
                                            </h6>
                                            <div class="product_price">
                                                <div class="d-flex justify-content-between">
                                                    <span class="text-dark">Unit Price:</span>
                                                    <span id="billPrice" class="text-dark"></span>
                                                </div>
                                                <div class="d-flex justify-content-between">
                                                    <span class="text-dark">Quantity</span>
                                                    <span id="billQty" class="text-dark"></span>
                                                </div>

                                                <div class="d-flex justify-content-between">
                                                    <span class="text-dark">Total Price</span>
                                                    <span id="billTotal" class="text-dark"></span>
                                                </div>




                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <!-- <h5>🧾 Bill Summary</h5>
                                <p><strong>Product:</strong> <span id="billProductName"></span></p>
                                <p><strong>Unit Price:</strong> ₹<span id="billPrice"></span></p>
                                <p><strong>Quantity:</strong> <span id="billQty"></span></p>
                                <p><strong>Total:</strong> ₹<span id="billTotal"></span></p> -->
                            </div>
                            <div class="mb-3">
                                <label>Transaction Password *</label>
                                <input type="password" name="trnPassword" class="form-control" required
                                    placeholder="Enter Transaction Password">
                            </div>
                            <button type="submit" name="upgradeNow" class="btn btn-primary action-button mt-3">
                                Buy Product
                            </button>
                        </form>
                    </div>
                </div>
            </div>



            <div class="row mt-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Activation History</h5>
                    </div>
                    <div class="row">
                        <div class="card">
                            <div class="card-body">
                                <div style="overflow-x: auto;">
                                    <div style="width: 100%; overflow-x: auto;">
                                        <table id="export-button" class="table table-bordered table-hover table-sm nowrap"
                                            style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>User Id</th>
                                                    <th>Name</th>
                                                    <th>Product Amount</th>
                                                    <th>Purchase Date</th>
                                                    <th>Purchase By</th>
                                                    <th>Receipt</th>
                                                    <th>All Receipt</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $count = 0;
                                                $queryActive = mysqli_query($con, "SELECT a.id,a.investPrice ,a.date_time,b.user_id,b.name,c.user_id AS activerId,c.name AS activerName from meddolic_user_activation_details a, meddolic_user_details b, meddolic_user_details c WHERE (a.activate_by='$memberId' OR a.member_id='$memberId') AND a.member_id=b.member_id AND a.activate_by=c.member_id AND a.walletType=1 ORDER BY a.date_time DESC");
                                                while ($valActive = mysqli_fetch_assoc($queryActive)) {
                                                    $count++; ?>
                                                    <tr>
                                                        <td><?= $count ?></td>
                                                        <td><?= $valActive['user_id'] ?></td>
                                                        <td><?= $valActive['name'] ?></td>
                                                        <td>
                                                            <span class="badge bg-success">
                                                                <i class="fa fa-inr"></i> <?= $valActive['investPrice'] ?>
                                                            </span>
                                                        </td>
                                                        <td><i class="fa fa-clock-o"></i>
                                                            <?= date("d-m-Y H:i:d", strtotime($valActive['date_time'])); ?>
                                                        </td>
                                                        <td><?= $valActive['activerName'] . " (User ID:" . $valActive['activerId'] . ")"; ?>
                                                        </td>
                                                        <td><a href="resept?ResID=<?= $valActive['user_id'] ?>&ID=<?= $valActive['id'] ?>" target="_blank" class="btn btn-sm btn-primary">View Receipt</a></td>
                                                        <td><a href="resept2?ResID=<?= $valActive['user_id'] ?>" target="_blank" class="btn btn-sm btn-primary">All Receipt</a></td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
                <script>
                    $(document).ready(function() {
                        $('#productId').change(function() {
                            var productId = $(this).val();
                            if (productId) {
                                $('#productDetailsContainer').html('<p>Loading product details...</p>');
                                $.ajax({
                                    url: 'ajaxCalls/get_product_detailsAjax.php',
                                    type: 'POST',
                                    data: {
                                        product_id: productId
                                    },
                                    success: function(response) {
                                        $('#productDetailsContainer').html(response);
                                    },
                                    error: function() {
                                        $('#productDetailsContainer').html('<p>Error loading product details.</p>');
                                    }
                                });
                            } else {
                                $('#productDetailsContainer').html('');
                            }
                        });
                    });
                </script>
                <script>
                    document.getElementById('productId').addEventListener('change', function() {
                        const selectedValue = this.value;
                        document.getElementById('productIdField').value = selectedValue;
                    });
                </script>


                <script>
                    $('#productId').change(function() {
                        $('#productIdField').val($(this).val());
                    });
                </script>


                <a id="buyProductLink" href="#" class="btn btn-primary action-button float-left" style="display: none;">
                    Buy Product
                </a>

                <script>
                    // Replace the button click handler with this
                    $('#buyProductLink').click(function(e) {
                        e.preventDefault(); // Prevent default link behavior
                        if (selectedProductId) {
                            window.location.href = 'fundRequestRejectBack?ResID=' + selectedProductId;
                        }
                    });
                </script>
                <script>
                    const productSelect = document.getElementById('productId');
                    const quantityInput = document.getElementById('quantity');
                    const billingBox = document.getElementById('billingInfo');
                    const productIdField = document.getElementById('productIdField');

                    const billProductName = document.getElementById('billProductName');
                    const billPrice = document.getElementById('billPrice');
                    const billQty = document.getElementById('billQty');
                    const billTotal = document.getElementById('billTotal');

                    let currentStock = 0;

                    function updateBill() {
                        const selected = productSelect.options[productSelect.selectedIndex];
                        const price = parseFloat(selected.getAttribute('data-price')) || 0;
                        const productName = selected.getAttribute('data-name') || '';
                        const stock = parseInt(selected.getAttribute('data-stock')) || 0;
                        const qty = parseInt(quantityInput.value) || 0;

                        currentStock = stock;

                        if (price > 0 && qty > 0) {
                            if (qty > stock) {
                                alert("❌ Entered quantity exceeds available stock (" + stock + ")");
                                quantityInput.value = stock;
                                return;
                            }

                            const total = price * qty;

                            billProductName.textContent = productName;
                            billPrice.textContent = price.toFixed(2);
                            billQty.textContent = qty;
                            billTotal.textContent = total.toFixed(2);

                            billingBox.style.display = 'block';
                            productIdField.value = selected.value;
                        } else {
                            billingBox.style.display = 'none';
                        }
                    }

                    productSelect.addEventListener('change', function() {
                        const selected = productSelect.options[productSelect.selectedIndex];
                        const stock = parseInt(selected.getAttribute('data-stock')) || 0;

                        quantityInput.value = '';
                        quantityInput.max = stock;
                        quantityInput.placeholder = `Max ${stock}`;
                        billingBox.style.display = 'none';

                        updateBill();
                    });
                    quantityInput.addEventListener('input', updateBill);
                </script>
                <?php require_once('Include/Footer.php'); ?>