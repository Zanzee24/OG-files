<?php
//Wallet Add & Statement Add & Upgrade Code Starts//
function incomeEntry($con, $member_id, $trnId, $incomeAmount, $statementId, $d)
{
    mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`,`date_time`,`trn_id`) VALUES ('$member_id','$statementId',2,'$incomeAmount','$d','$trnId')");
    mysqli_query($con, "UPDATE meddolic_user_details SET wallet=wallet+'$incomeAmount' WHERE member_id='$member_id'");
}
//Wallet Add & Statement Add & Upgrade Code Ends//

//Reward Rank Set Code Start
function rewardRelease($con, $parentId, $rewardId, $leftBusiness, $rightBusiness, $rewardIncome, $d)
{
    $queryleftbus = mysqli_query($con, "SELECT SUM(product_quentity) as leftbusiness FROM meddolic_user_activation_details WHERE member_id IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$parentId'AND legPosition=2 AND topup_status=1)");
    $valleftbus = mysqli_fetch_array($queryleftbus);
    $leftbus = $valleftbus['leftbusiness'];

    $queryrightbus = mysqli_query($con, "SELECT SUM(product_quentity) as rightbusiness FROM meddolic_user_activation_details WHERE member_id IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$parentId'AND legPosition=3 AND topup_status=1)");
    $valrightbus = mysqli_fetch_array($queryrightbus);
    $rightbus = $valrightbus['rightbusiness'];
    
    // echo "member Id->$parentId,leftbus->$leftbus,leftBusiness->$leftBusiness,rightbus->$rightbus ,rightBusiness->$rightBusiness<br>";

    if ($leftBusiness <= $leftbus && $rightBusiness <= $rightbus) {
        mysqli_query($con, "INSERT INTO `meddolic_user_reward_income_details`(`member_id`, `rewardId`, `rewardIncome`,`leftBus`,`rightBus`, `date_time`) VALUES ('$parentId','$rewardId','$rewardIncome','$leftbus','$rightbus','$d')");

        $rewardIncomeId = $con->insert_id;
        incomeEntry($con, $parentId, $rewardIncomeId, $rewardIncome, 1, $d);

        mysqli_query($con, "UPDATE meddolic_user_details SET currentReward='$rewardId' WHERE member_id='$parentId'");
        $nextReward = $rewardId + 1;
        if ($nextReward <= 18) {
            $queryRe = mysqli_query($con, "SELECT leftBus,rightBus,rewardIncome FROM meddolic_config_reward_income WHERE rewardId='$nextReward'");
            $valRe = mysqli_fetch_assoc($queryRe);
            $leftBusiness = $valRe['leftBus'];
            $rightBusiness = $valRe['rightBus'];
            $rewardIncome = $valRe['rewardIncome'];
         
            rewardRelease($con, $parentId, $nextReward, $leftBusiness, $rightBusiness, $rewardIncome, $d);
        }
    }
}

//Reward Income Release Code Ends
function relayRewardLoop($con, $memberId, $d)
{
    $queryMain = mysqli_query($con, "SELECT a.member_id,b.currentReward FROM meddolic_user_child_ids a, meddolic_user_details b WHERE a.child_id='$memberId' AND a.member_id=b.member_id AND b.topup_flag=1");
    while ($valMain = mysqli_fetch_assoc($queryMain)) {
        $parentId = $valMain['member_id'];
        $currentReward = $valMain['currentReward'];
        $nextReward = $currentReward + 1;
        if ($nextReward <= 18) {
            $queryRew = mysqli_query($con, "SELECT  leftBus,rightBus,rewardIncome FROM meddolic_config_reward_income WHERE rewardId='$nextReward'");
            $valRew = mysqli_fetch_assoc($queryRew);
            $leftBusiness = $valRew['leftBus'];
            $rightBusiness = $valRew['rightBus'];
            $rewardIncome = $valRew['rewardIncome'];
    
            rewardRelease($con, $parentId, $nextReward, $leftBusiness, $rightBusiness, $rewardIncome, $d);
        }
    }
}