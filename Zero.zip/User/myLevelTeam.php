<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
<div class="content-page">
  <div class="container-fluid">
    <h4 class="fw-bold mb-3"><i class="fa fa-sitemap  text-primary me-2"></i>Level Team</h4> <!-- Added heading -->

    <div class="row">
      <div class="card">
        <div class="card-body">
          <div style="overflow-x: auto;">
            <div style="min-width: 1000px;">
            <table id="export-button" class="table table-bordered table-hover table-sm nowrap"
                      style="width:100%">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Level Number.</th>
                    <th>Total Member</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  for ($level = 1; $level <= 20; $level++) {
                    $queryMember = mysqli_query($con, "SELECT COUNT(1) AS totalMember FROM meddolic_user_child_ids WHERE member_id='$memberId' AND level='$level'");
                    $valMember = mysqli_fetch_array($queryMember);
                    $count++; ?>
                    <tr>
                      <td><?= $level ?></td>
                      <td>Level <?= $level; ?></td>
                      <td><i class="fa fa-user"></i> <?= isset($valMember[0]) ? $valMember[0] : '0'; ?></td>
                      <td><a href="levelTeamDetails?MemberID=<?= $memberId ?>&LevelID=<?= $level ?>"
                          class="btn btn-sm btn-outline-secondary px-3">More</a></td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once('Include/Footer.php'); ?>

<style>
  /* Ensure the table headers are visible while scrolling */
  table {
    border-collapse: collapse;
    width: 100%;
  }

  th,
  td {
    padding: 8px;
    text-align: left;
    white-space: nowrap;
    /* Prevent text from wrapping */
  }

  th {
    background-color: #f8f9fa;
    /* Light background for headers */
    position: sticky;
    /* Make header sticky */
    top: 0;
    /* Stick to the top */
    z-index: 10;
    /* Ensure it stays above other content */
  }

  /* Optional: Add some styles for better visibility */
  tr:nth-child(even) {
    background-color: #f2f2f2;
    /* Zebra striping for rows */
  }
</style>