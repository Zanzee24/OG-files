<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');

$queryBank = mysqli_query($con, "SELECT ifsc,bank,branch,accNo,accName,passimage FROM meddolic_user_bank_details WHERE memberId='$memberId'");
$valBank = mysqli_fetch_array($queryBank);
$ifsc = $valBank['ifsc'];
$bank = $valBank['bank'];
$branch = $valBank['branch'];
$accountNo = $valBank['accNo'];
$acName = $valBank['accName'];
$passimage = $valBank['passimage'];



?>
<div class="content-page">
  <div class="container-fluid">
    <h4 class="fw-bold mb-3">Bank Details</h4> <!-- Heading moved outside the card -->

    <div class="row">
      <div class="col-sm-12 col-xl-12 xl-100">
        <div class="card">
          <div class="card-body">
            <ul class="nav nav-tabs" id="icon-tab" role="tablist">
              <li class="nav-item"><a class="nav-link active" id="bankDetailsTab" data-bs-toggle="tab"
                  href="#bankDetails" role="tab" aria-controls="bankDetails" aria-selected="true"
                  data-bs-original-title><i class="icofont icofont-address-book"></i>Bank Details</a></li>
            </ul>
            <div class="tab-content" id="icon-tabContent">
              <div class="tab-pane fade active show" id="bankDetails" role="tabpanel" aria-labelledby="bankDetailsTab" >
                <form class="form theme-form" action="userProfileAuthProcess" method="POST" enctype="multipart/form-data">
                  <div class="card-body">
                    <div class="row">
                      <div class="col">
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Account Holder Name *</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control" required value="<?= $acName ?>" name="acName"
                              placeholder="Enter Account Holder Name" required>
                            <input type="hidden" name="memberId" value="<?= $memberId ?>">
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">IFSC Code *</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control" required value="<?= $ifsc ?>" name="ifsc"
                              placeholder="Enter IFSC Code" required>
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Bank Name *</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control" required value="<?= $bank ?>" name="bank"
                              placeholder="Enter Bank Name" required>
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Branch *</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control" required value="<?= $branch ?>" name="branch"
                              placeholder="Enter Branch" required>
                          </div>
                        </div>
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">A/C No. *</label>
                          <div class="col-sm-6">
                            <input type="number" class="form-control" required value="<?= $accountNo ?>"
                              placeholder="Enter A/C No." name="accountNo" onkeypress="return onlynum(event)" required>
                          </div>
                        </div>
                        <!-- add image upload -->
                        <div class="mb-3 row">
                          <label class="col-sm-3 col-form-label">Upload Document *</label>
                          <div class="col-sm-6">
                            <input type="file" class="form-control" name="passimage" id="passimage"
                              accept="image/*"
                              onchange="previewImage(this, 'passPreview')">
                            <div style="margin-top:10px;">
                              <img id="passPreview"
                                src="<?= !empty($passimage) && $passimage != 'N/A' ? 'User/bankDetail/' . htmlspecialchars($passimage) : '#' ?>"
                                alt="Document Preview"
                                style="max-width:200px; display:<?= !empty($passimage) && $passimage != 'N/A' ? 'block' : 'none' ?>; border:1px solid #ccc; padding:5px;">
                            </div>
                          </div>
                        </div>



                        <button class="btn btn-primary w-50" type="submit" name="addbank">Save</button>
                      </div>
                    </div>
                  </div>

                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  function previewImage(input, previewId) {
    const preview = document.getElementById(previewId);
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function(e) {
        preview.src = e.target.result;
        preview.style.display = 'block';
      };
      reader.readAsDataURL(input.files[0]);
    }
  }
</script>
<?php require_once('Include/Footer.php')
?>