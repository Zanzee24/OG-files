<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>

<link rel="stylesheet" href="assets/css/custom-dashboard.css">
<?php
$todayDate = date('Y-m-d');
$d = date('Y-m-d H:i:s');
$queryGe = mysqli_query($con, "SELECT member_id,wallet,topup_flag,activation_date,fundWallet,date_time,sponser_id FROM meddolic_user_details WHERE user_id='$userId'");
$valGe = mysqli_fetch_assoc($queryGe);
$memberId = $valGe['member_id'];
$incomeWallet = $valGe['wallet'];
$topupFlag = $valGe['topup_flag'];
$fundWallet = $valGe['fundWallet'];
$activationDate = $valGe['activation_date'];
$joinDate = $valGe['date_time'];
$sponser_id = $valGe['sponser_id'];

$querySponserUser = mysqli_query($con, "SELECT user_id FROM meddolic_user_details WHERE member_id='$sponser_id'");
$valSponserUser = mysqli_fetch_array($querySponserUser);
$sponserUserID = $valSponserUser[0];

$querySponser = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE sponser_id='$memberId'");
$valSponser = mysqli_fetch_array($querySponser);
$totalSponser = $valSponser[0];

$queryReferral = mysqli_query($con, "SELECT SUM(matchingIncome) FROM meddolic_user_token_matching_income WHERE memberId='$memberId' ");
$valReferral = mysqli_fetch_array($queryReferral);
$matchingIncome = $valReferral[0];

$queryLevel = mysqli_query($con, "SELECT  SUM(a.rewardsIncome) AS rewardsIncome FROM meddolic_config_reward_income a, meddolic_user_details b WHERE b.member_id='$memberId' AND b.currentReward>=a.rewardId ");
$valLevel = mysqli_fetch_assoc($queryLevel);
$rewardsIncome = $valLevel['rewardsIncome'];

// $queryRoi = mysqli_query($con, "SELECT SUM(incomeAmount) FROM meddolic_user_cashback_income_details WHERE member_id='$memberId' AND status=1");
// $valRoi = mysqli_fetch_array($queryRoi);
// $roiIncome = $valRoi[0];

// $queryLevel = mysqli_query($con, "SELECT SUM(levelIncome) FROM meddolic_user_level_roi_income WHERE memberId='$memberId' AND releaseStatus=1");
// $valLevel = mysqli_fetch_array($queryLevel);
// $levelIncome = $valLevel[0];

$querySalary = mysqli_query($con, "SELECT SUM(salaryIncome) FROM meddolic_user_salary_income_details WHERE member_id='$memberId' ");
$valSalary = mysqli_fetch_array($querySalary);
$salaryIncome = $valSalary[0];


$totalIncome = $matchingIncome  + $rewardsIncome + $salaryIncome;

$queryWithdraw = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_wallet_withdrawal_crypto WHERE member_id='$memberId' AND (released=1 OR released=0)");
$valWithdraw = mysqli_fetch_array($queryWithdraw);
$totalWithdraw = $valWithdraw[0];

$queryTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' ");
$valTeam = mysqli_fetch_array($queryTeam);
$totalTeam = $valTeam[0];

$queryLeftTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND legPosition=2 ");
$valLeftTeam = mysqli_fetch_array($queryLeftTeam);
$leftTeam = $valLeftTeam[0];

$queryRightTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND legPosition=3 ");
$valRightTeam = mysqli_fetch_array($queryRightTeam);
$rightTeam = $valRightTeam[0];

$queryDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=1");
$valDirect = mysqli_fetch_array($queryDirect);
$activeSponser = $valDirect[0];

$queryInDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=0");
$valInDirect = mysqli_fetch_array($queryInDirect);
$inActiveSponser = $valInDirect[0];

$queryActveTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=1");
$valActveTeam = mysqli_fetch_array($queryActveTeam);
$activeTeam = $valActveTeam[0];

$queryInActiveTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=0 ");
$valInActiveTeam = mysqli_fetch_array($queryInActiveTeam);
$inActiveTeam = $valInActiveTeam[0];


$queryInvestment = mysqli_query($con, "SELECT SUM(investPrice) FROM meddolic_user_activation_details WHERE member_id='$memberId' AND status=1 ");
$valInvestment = mysqli_fetch_array($queryInvestment);
$totalInvestment = $valInvestment[0];

$queryTeam = mysqli_query($con, "SELECT SUM(investPrice) FROM meddolic_user_activation_details WHERE member_id IN ( SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=1)");
$valTeam = mysqli_fetch_array($queryTeam);
$teamBusiness = $valTeam[0];

$queryDirect = mysqli_query($con, "SELECT SUM(investPrice) FROM meddolic_user_activation_details WHERE sponser_id='$memberId'");
$valDirect = mysqli_fetch_array($queryDirect);
$directBusiness = $valDirect[0];

$queryNews = mysqli_query($con, "SELECT news,newStatus FROM meddolic_config_news_list WHERE newStatus=1");
$valNews = mysqli_fetch_assoc($queryNews);
?>

<div class="content-page">
    <!-- Top bar -->
    <!-- Top Bar -->
    <div class="container my-3">
        <div class="row">
                        <div class="col-lg-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-end">
                                        <div class="dashboard-content-left">
                                            <h4 class="text-primary">Zero Problem </h4>
                                            <p><?php
                    if ($valNews && $valNews['newStatus'] == 1 && !empty($valNews['news'])) {
                    ?>
                        <marquee>
                            <i class="fas fa-bullhorn me-2"></i> <?= htmlspecialchars($valNews['news']) ?>
                        </marquee>
                    <?php
                    } else {
                    ?>
                        <div class="text-muted fw-semibold px-2">
                            <i class="fas fa-bullhorn me-2 text-secondary"></i> Welcome to Zero Problem Wellness!
                        </div>
                    <?php
                    }
                    ?></p>
                                            
                                        </div>
                                        <div class="dashboard-content-right">
                                            <img src="https://image.freepik.com/free-vector/businessman-offer-invest-with-small-business-franchise-branch-expansion-strategy-financial-marketing-planning-vector-illustrator_101179-1423.jpg" class="img-fluid" width="150px" height="150px" alt="Franchise Images">
                                        </div>
                                    </div>
                                     <div class="col-md-12">
               
                <div class="bg-white mt-2 p-2 rounded border small d-flex justify-content-between align-items-center">
                    <div class="text-break me-2" id="referralLink">
                        https://zeroproblemwellness.com/authUserRegister?affiliateCode=<?= $userId ?>
                    </div>
                    <button class="btn btn-sm btn-outline-primary" onclick="copyReferralLink()"
                        title="Copy to clipboard">
                        <i class="fas fa-copy"></i>
                    </button>
                </div>
            </div>
                                </div>
                            </div>
                        </div>
                    </div>
    </div>
    
        <div class="row match-height">
                        <div class="col-xl-12 col-sm-12">
                            <div class="card user-card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-xl-5 col-sm-6 d-flex flex-column justify-content-between border-container-lg">
                                            <div class="user-avatar-section">
                                                <div class="d-flex justify-content-start">
                                                    <img class="img-fluid rounded" src="https://healthomwellness.in/images/user.png" alt="User avatar" />
                                                    <div class="d-flex flex-column ml-1">
                                                        <div class="user-info mb-1">
                                                            <h4 class="mb-0"><?= $userName?></h4>
                                                            <span class="card-text"><button class="btn btn-link p-0" type="button" data-clipboard-text="IBO659312458"
            data-title="Click To Copy" data-toggle="tooltip" data-placement="bottom"
             >
           <?= $userId?>
             </button>
           </span>
                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-7 col-sm-6 mt-xl-0">
                                            <table class="table table-borderless">
                                                <tbody>
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="uil uil-user"></i>
                                                            <span class="font-weight-bold">User name</span>
                                                        </td>
                                                        <td class="text-truncate custom-width"><?= $userName?></td>
                                                    </tr>
                                                   
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="uil uil-envelope-minus"></i>
                                                            <span class="font-weight-bold">Email</span>
                                                        </td>
                                                        <td class="text-truncate custom-width text-break"><?= $emailId?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="uil uil-check-circle"></i>
                                                            <span class="font-weight-bold">Status</span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                           <?php if ($topupFlag == 1): ?>
                        <span>
                            <span class="dot bg-success me-1"></span> ACTIVE
                        </span>
                    <?php else: ?>
                        <span><span class="dot bg-danger me-1"></span>IN-ACTIVE</span>
                    <?php endif; ?> 
                                                        </td>
                                                    </tr>
                                                   
                                                    
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="uil uil-calendar-alt"></i>
                                                            <span class="font-weight-bold">Sponsor ID </span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= $sponserUserID?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="uil uil-mobile-android"></i>
                                                            <span class="font-weight-bold">Mobile </span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= $phone?>
                                                        </td>
                                                    </tr>
                                                       <tr>
                                                        <td class="custom-width">
                                                            <i class="uil uil-calendar-alt"></i>
                                                            <span class="font-weight-bold">Joining Date </span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= $joinDate?>
                                                        </td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="uil uil-calendar-alt"></i>
                                                            <span class="font-weight-bold">Activation Date</span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= isset($activationDate) ? $activationDate : 'N/A'; ?>
                                                        </td>
                                                    </tr>
                                                 
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="fas fa-users"></i>
                                                            <span class="font-weight-bold">Total Direct </span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= $totalSponser?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="fas fa-users"></i>
                                                            <span class="font-weight-bold">Total Team </span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= $totalTeam?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="fas fa-users"></i>
                                                            <span class="font-weight-bold">Left Team </span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= $leftTeam?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td class="custom-width">
                                                            <i class="fas fa-users"></i>
                                                            <span class="font-weight-bold">Right Team </span>
                                                        </td>
                                                        <td class="text-truncate custom-width">
                                                            <?= $rightTeam?>
                                                        </td>
                                                    </tr>
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="d-flex align-items-center user-total-numbers overflow-auto">


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

    <!-- Cards grid -->
        <div class="row match-height mt-4">
                       <div class="col-xl-12 col-sm-12">
                            <div class="card user-card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="cards">
        <!-- <div class="card">
            <div class="card-icon yellow-bg"><i class="fas fa-users"></i></div>
            <div class="card-text">
                <div class="font-weight-bold">
                    <?php if ($topupFlag == 1): ?>
                        <span>
                            <span class="dot bg-success me-1"></span> ACTIVE
                        </span>
                    <?php else: ?>
                        <span><span class="dot bg-danger me-1"></span>IN-ACTIVE</span>
                    <?php endif; ?>
                </div>
                <div class="font-weight-bold">ID Status</div>
            </div>
        </div> -->
        <div class="card">
            <div class="card-icon green-bg"><i class="fas fa-rupee-sign"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($incomeWallet) ? $incomeWallet : '0.00'; ?></div>
                <div class="font-weight-bold">Income Wallet</div>
            </div>
        </div>
        <div class="card">
            <div class="card-icon blue-bg"><i class="fas fa-rupee-sign"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($fundWallet) ? $fundWallet : '0.00'; ?></div>
                <div class="font-weight-bold">Purchase Wallet</div>
            </div>
        </div>

        <!--<div class="card">-->
        <!--    <div class="card-icon pink-bg"><i class="fas fa-rupee-sign"></i></div>-->
        <!--    <div class="card-text">-->
        <!--        <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>-->
        <!--            <?= isset($retailProfit) ? $retailProfit : '0.00'; ?></div>-->
        <!--        <div class="font-weight-bold">Retail Profit</div>-->
        <!--    </div>-->
        <!--</div>-->
        <div class="card">
            <div class="card-icon yellow-bg"><i class="fas fa-rupee-sign"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($matchingIncome) ? $matchingIncome : '0.00'; ?></div>
                <div class="font-weight-bold">Team Matching Income</div>
            </div>
        </div>
        <div class="card">
            <div class="card-icon green-bg"><i class="fas fa-rupee-sign"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($rewardsIncome) ? $rewardsIncome : '0.00'; ?></div>
                <div class="font-weight-bold">Rank Bonus</div>
            </div>
        </div>
        <div class="card">
            <div class="card-icon blue-bg"><i class="fas fa-rupee-sign"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($salaryIncome) ? $salaryIncome : '0.00'; ?></div>
                <div class="font-weight-bold">Monthly Salary Income</div>
            </div>
        </div>
        <!-- <div class="card">
            <div class="card-icon pink-bg"><i class="fas fa-rupee-sign"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($rewardsIncome) ? $rewardsIncome : '0.00'; ?></div>
                <div class="font-weight-bold">Reward & Awards</div>
            </div>
        </div> -->

        <div class="card">
            <div class="card-icon purple-bg"><i class="fas fa-wallet"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($totalIncome) ? $totalIncome : '0.00'; ?> </div>
                <div class="font-weight-bold">Total Income</div>
            </div>
        </div>
        <!--<div class="card">-->
        <!--    <div class="card-icon pink-bg"><i class="fas fa-coins"></i></div>-->
        <!--    <div class="card-text">-->
        <!--        <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>-->
        <!--            <?= isset($totalInvestment) ? $totalInvestment : '0.00'; ?> </div>-->
        <!--        <div class="font-weight-bold">Total Investment</div>-->
        <!--    </div>-->
        <!--</div>-->
        <div class="card">
            <div class="card-icon yellow-bg"><i class="fas fa-arrow-circle-down"></i></div>
            <div class="card-text">
                <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>
                    <?= isset($totalWithdraw) ? $totalWithdraw : '0.00'; ?> </div>
                <div class="font-weight-bold">Total Payouts</div>
            </div>
        </div>
        <!--<div class="card">-->
        <!--    <div class="card-icon green-bg"><i class="fas fa-coins"></i></div>-->
        <!--    <div class="card-text">-->
        <!--        <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>-->
        <!--            <?= isset($directBusiness) ? $directBusiness : '0.00'; ?> </div>-->
        <!--        <div class="font-weight-bold">Direct Business</div>-->
        <!--    </div>-->
        <!--</div>-->
        <!--<div class="card">-->
        <!--    <div class="card-icon blue-bg"><i class="fas fa-coins"></i></div>-->
        <!--    <div class="card-text">-->
        <!--        <div class="font-weight-bold"><i class="fas fa-rupee-sign"></i>-->
        <!--            <?= isset($teamBusiness) ? $teamBusiness : '0.00'; ?> </div>-->
        <!--        <div class="font-weight-bold">Total Business</div>-->
        <!--    </div>-->
        <!--</div>-->
    </div>

                                        
                                                  
                              </div>
                                    </div>
                                </div>
                            </div>
                        </div>             

                    </div>

   



</div>
<button type="button" id="modalShow" data-bs-toggle="modal" data-bs-target="#welcomeNotice"
    class="btn btn-primary ms-2 mb-2" style="display:none;">
    <i class="fas fa-bullhorn me-1"></i> Show Notice
</button>
<?php
$queryConfig = mysqli_query($con, "SELECT dashboardImage,imageStatus FROM meddolic_config_misc_setting");
$valConfig = mysqli_fetch_assoc($queryConfig);
?>
<div id="welcomeNotice" class="modal fade" tabindex="-1" aria-labelledby="welcomeNoticeLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 18px;">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold" id="welcomeNoticeLabel">
                    <i class="fas fa-bullhorn text-primary me-2"></i>Notice
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <?php if (!empty($valConfig['dashboardImage'])): ?>
                    <img src="../<?= htmlspecialchars($valConfig['dashboardImage']) ?>" class="img-fluid rounded shadow-sm"
                        alt="Dashboard Notice" style="max-width: 100%; height: auto;">
                <?php else: ?>
                    <p class="text-muted">No notice image available.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once('Include/Footer.php'); ?>
<script>
    function copyReferralLink() {
        const linkText = document.getElementById("referralLink").textContent.trim();
        navigator.clipboard.writeText(linkText).then(() => {
            alert("Referral link copied to clipboard!");
        }).catch(err => {
            console.error("Copy failed", err);
        });
    }

    function popMsg() {
        <?php if ($valConfig['imageStatus'] == 1) { ?>
            $('#modalShow').click();
        <?php } ?>
    }
    window.load = popMsg();
</script>