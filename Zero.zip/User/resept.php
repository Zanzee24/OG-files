<?php
/**
 * Order Receipt Generator
 * Generates order receipts with product details and pricing information
 */

require_once("../conection.php");

// ============================================================================
// SECURITY: Input Validation
// ============================================================================

function sanitizeInput($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

$resId = isset($_GET['ResID']) ? sanitizeInput($_GET['ResID']) : null;
$orderId = isset($_GET['ID']) ? sanitizeInput($_GET['ID']) : null;

// ============================================================================
// DATABASE: Fetch User Details
// ============================================================================

function getUserDetails($con, $sessionUserId) {
    $stmt = mysqli_prepare($con, 
        "SELECT name, user_id, member_id, topup_flag, wallet, fundWallet, email_id, phone, aadhar_address 
         FROM meddolic_user_details 
         WHERE user_id = ? LIMIT 1"
    );
    
    if (!$stmt) {
        return ['error' => 'Database preparation error: ' . mysqli_error($con)];
    }
    
    mysqli_stmt_bind_param($stmt, "s", $sessionUserId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        mysqli_stmt_close($stmt);
        return $row;
    }
    
    mysqli_stmt_close($stmt);
    return ['error' => 'User not found'];
}

// ============================================================================
// DATABASE: Fetch Order Details
// ============================================================================

function getOrderDetails($con, $memberId, $orderId) {
    $stmt = mysqli_prepare($con,
        "SELECT id, product_quentity AS quantity, investPrice AS price, 
                SP_Point, date_time AS dateTime 
         FROM meddolic_user_activation_details
         WHERE member_id = ? AND id = ?
         ORDER BY date_time DESC"
    );
    
    if (!$stmt) {
        return ['error' => 'Database preparation error: ' . mysqli_error($con)];
    }
    
    mysqli_stmt_bind_param($stmt, "ss", $memberId, $orderId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    $orders = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $orders[] = $row;
    }
    
    mysqli_stmt_close($stmt);
    
    if (empty($orders)) {
        return ['error' => 'No orders found'];
    }
    
    return $orders;
}

// ============================================================================
// DATABASE: Fetch Product Details
// ============================================================================

function getProductDetails($con) {
    $stmt = mysqli_prepare($con,
        "SELECT product_id, productName, price 
         FROM franchise_shopping_product_details 
         WHERE status = 1 
         ORDER BY product_id ASC 
         LIMIT 1"
    );
    
    if (!$stmt) {
        return [
            'product_id' => 'HPE-01',
            'productName' => 'Zero Problem Wellness Product',
            'price' => 999
        ];
    }
    
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        mysqli_stmt_close($stmt);
        return $row;
    }
    
    mysqli_stmt_close($stmt);
    
    return [
        'product_id' => 'HPE-01',
        'productName' => 'Zero Problem Wellness Product',
        'price' => 999
    ];
}

// ============================================================================
// MAIN EXECUTION
// ============================================================================

// Validate session
$sessionUserId = $_SESSION['member_user_id'] ?? null;
if (!$sessionUserId) {
    die("Error: Session expired. Please login again.");
}

// Fetch user details
$userData = getUserDetails($con, $sessionUserId);
if (isset($userData['error'])) {
    die("Error: " . $userData['error']);
}

// Validate order ID
if (!$orderId) {
    die("Error: Order ID is required");
}

// Fetch order details
$orderDetails = getOrderDetails($con, $userData['member_id'], $orderId);
if (isset($orderDetails['error'])) {
    die("Error: " . $orderDetails['error']);
}

// Fetch product details
$productData = getProductDetails($con);

// Calculate totals
$totalPrice = 0;
$totalQuantity = 0;
$totalRetailProfit = 0;
$products = [];

foreach ($orderDetails as $order) {
    $quantity = $order['quantity'];
    $price = $order['price'];
    $productPrice = $productData['price'];
    $retailProfitPerUnit = 199; // Retail profit per unit
    
    $product = [
        'id' => $order['id'],
        'product_id' => $productData['product_id'],
        'product_name' => $productData['productName'],
        'quantity' => $quantity,
        'product_price' => $productPrice,
        'retail_profit_per_unit' => $retailProfitPerUnit,
        'total_retail_profit' => $quantity * $retailProfitPerUnit,
        'total_price' => $price,
        'date' => $order['dateTime'],
        'sp_points' => $order['SP_Point'] ?? 0
    ];
    
    $totalPrice += $price;
    $totalQuantity += $quantity;
    $totalRetailProfit += $product['total_retail_profit'];
    $products[] = $product;
}

// Invoice metadata
$invoiceNo = 686 + (int)$orderId;
$invoiceDate = date('d-m-Y');
$gstin = "";

// ============================================================================
// HTML TEMPLATE
// ============================================================================
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Receipt - <?= htmlspecialchars($userData['user_id']) ?></title>
    <style>
        @media print {
            .download-btn, .btn-container { display: none; }
            body { padding: 0; }
            .no-print { display: none; }
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: 'Segoe UI', Arial, sans-serif;
            font-size: 13px;
            line-height: 1.6;
            background: #f5f5f5;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: #fff;
            border: 2px solid #333;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .header {
            text-align: center;
            padding: 20px;
            border-bottom: 2px solid #333;
            background: linear-gradient(to bottom, #f8f9fa 0%, #e9ecef 100%);
        }

        .header-logo {
            height: 70px;
            margin-bottom: 10px;
        }

        .header h2 {
            margin: 10px 0 5px 0;
            font-size: 24px;
            color: #2c3e50;
        }

        .header h3 {
            margin: 5px 0;
            font-size: 15px;
            color: #555;
            font-weight: normal;
        }

        .section-title {
            background: linear-gradient(to right, #6c757d 0%, #495057 100%);
            color: white;
            font-weight: 600;
            padding: 10px 15px;
            margin: 0;
            font-size: 14px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        .info-table {
            margin-bottom: 0;
        }

        .info-table td {
            padding: 10px 15px;
            border: 1px solid #333;
            vertical-align: top;
        }

        .info-label {
            font-weight: 600;
            color: #495057;
            min-width: 140px;
            display: inline-block;
        }

        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .product-table th,
        .product-table td {
            border: 1px solid #333;
            padding: 10px 8px;
            text-align: left;
        }

        .product-table th {
            background-color: #e9ecef;
            font-weight: 600;
            color: #2c3e50;
            text-align: center;
        }

        .product-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .product-table tbody tr:hover {
            background-color: #f0f0f0;
        }

        .product-table tfoot td {
            font-weight: 600;
            background-color: #e9ecef;
            border-top: 2px solid #333;
        }

        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-left { text-align: left; }

        .footer {
            border-top: 2px solid #333;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .footer-logo-section {
            text-align: center;
            flex: 1;
        }

        .footer-logo {
            height: 80px;
            margin-bottom: 10px;
        }

        .footer-signature {
            text-align: center;
            flex: 1;
            border-left: 1px solid #ddd;
            padding-left: 20px;
        }

        .footer-signature strong {
            display: block;
            margin-bottom: 60px;
            font-size: 15px;
            color: #2c3e50;
        }

        .footer-signature small {
            color: #666;
            font-style: italic;
        }

        .download-btn {
            display: inline-block;
            padding: 14px 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            cursor: pointer;
            border: none;
            font-size: 16px;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            transition: all 0.3s ease;
        }

        .download-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }

        .btn-container {
            text-align: center;
            padding: 30px;
            background: #f8f9fa;
        }

        .highlight {
            color: #667eea;
            font-weight: 600;
        }

        .invoice-info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0;
        }

        .invoice-info-cell {
            padding: 15px;
            border: 1px solid #333;
        }

        .receipt-badge {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <img src="assets/images/logo.png" alt="Company Logo" class="header-logo">
            <h2>ZERO PROBLEM WELLNESS</h2>
            <div class="receipt-badge">ORDER RECEIPT</div>
            <h3>Distributor IBO: <span class="highlight"><?= htmlspecialchars($userData['user_id']) ?></span> (<?= htmlspecialchars($userData['name']) ?>)</h3>
        </div>

        <!-- Invoice Information -->
        <div class="section-title">Invoice Information</div>
        <div class="invoice-info-grid">
            <div class="invoice-info-cell">
                <span class="info-label">Invoice No</span> : <strong><?= $invoiceNo ?></strong><br>
                <span class="info-label">Invoice Date</span> : <?= $invoiceDate ?><br>
                <span class="info-label">GSTIN</span> : <?= $gstin ?>
            </div>
            <div class="invoice-info-cell">
                <span class="info-label">Order No</span> : <strong><?= htmlspecialchars($orderId) ?></strong><br>
                <span class="info-label">Order Date</span> : <?= date('d-m-Y', strtotime($products[0]['date'])) ?>
            </div>
        </div>

        <!-- Personal Details -->
        <div class="section-title">Personal Details</div>
        <table class="info-table">
            <tr>
                <td style="width: 50%;">
                    <span class="info-label">Distributor IBO</span> : <?= htmlspecialchars($userData['user_id']) ?><br>
                    <span class="info-label">Name</span> : <?= htmlspecialchars($userData['name']) ?><br>
                    <span class="info-label">Mobile No</span> : <?= htmlspecialchars($userData['phone'] ?: 'N/A') ?><br>
                    <span class="info-label">Email</span> : <?= htmlspecialchars($userData['email_id'] ?: 'N/A') ?>
                </td>
                <td style="width: 50%;">
                                        <span class="info-label">Name</span> : <?= htmlspecialchars($userData['name']) ?><br>

                    <span class="info-label">Address</span> : <?= htmlspecialchars($userData['aadhar_address'] ?: 'N/A') ?><br>
                </td>
            </tr>
        </table>

        <!-- Order Details -->
        <div class="section-title">Order Details</div>
        <table class="product-table">
            <thead>
                <tr>
                    <th style="width: 50px;">S.No</th>
                    <th style="width: 100px;">Product ID</th>
                    <th>Product Name</th>
                    <th style="width: 60px;">Qty</th>
                    <th style="width: 110px;">Unit Price</th>
                    <!-- <th style="width: 110px;">Retail Profit</th> -->
                    <th style="width: 110px;">Total Price</th>
                    <th style="width: 100px;">SP Points</th>
                    <th style="width: 100px;">Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $index => $product): ?>
                    <tr>
                        <td class="text-center"><?= $index + 1 ?></td>
                        <td class="text-center"><?= htmlspecialchars($product['product_id']) ?></td>
                        <td><?= htmlspecialchars($product['product_name']) ?></td>
                        <td class="text-center"><?= htmlspecialchars($product['quantity']) ?></td>
                        <td class="text-right">₹ <?= number_format($product['product_price'], 2) ?></td>
                        <!-- <td class="text-right">₹ <?= number_format($product['total_retail_profit'], 2) ?></td> -->
                        <td class="text-right">₹ <?= number_format($product['total_price'], 2) ?></td>
                        <td class="text-center"><?= number_format($product['sp_points'], 2) ?></td>
                        <td class="text-center"><?= date('d-m-Y', strtotime($product['date'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="text-right"><strong> TOTAL</strong></td>
                    <td class="text-center"><strong><?= $totalQuantity ?></strong></td>
                    <td></td>
                    <!-- <td class="text-right"><strong>₹ <?= number_format($totalRetailProfit, 2) ?></strong></td> -->
                    <td class="text-right"><strong>₹ <?= number_format($totalPrice, 2) ?></strong></td>
                    <td class="text-center"><strong><?= number_format(array_sum(array_column($products, 'sp_points')), 2) ?></strong></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>

        <!-- Footer -->
        <div class="footer">
            <div class="footer-logo-section">
                <img src="assets/images/logo.png" alt="Company Logo" class="footer-logo">
                <p style="margin: 5px 0; font-weight: 600; color: #2c3e50;">Zero Problem Wellness</p>
                <p style="margin: 0; font-size: 11px; color: #666;">Your Health, Our Priority</p>
            </div>
            <div class="footer-signature">
                <strong>Authorised Signatory</strong>
                <small>This is a computer generated receipt and does not require a physical signature</small>
            </div>
        </div>
    </div>

    <div class="btn-container no-print">
        <button class="download-btn" onclick="window.print(); return false;">
            📥 Download / Print Receipt
        </button>
    </div>
</body>
</html>