<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');

$queryProfile = mysqli_query($con, "SELECT pancard,panimage FROM meddolic_user_details WHERE user_id='$userId'");
$valProfile = mysqli_fetch_assoc($queryProfile);
$pancard = $valProfile['pancard'];
$panimage = $valProfile['panimage'];



?>
<div class="content-page">
    <div class="container-fluid">
        <h4 class="fw-bold mb-3">Pan Card Details</h4> <!-- Heading moved outside the card -->

        <div class="row">
            <div class="col-sm-12 col-xl-12 xl-100">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="icon-tab" role="tablist">
                            <li class="nav-item"><a class="nav-link active" id="bankDetailsTab" data-bs-toggle="tab"
                                    href="#bankDetails" role="tab" aria-controls="bankDetails" aria-selected="true"
                                    data-bs-original-title><i class="icofont icofont-address-book"></i>Pan Card Details</a></li>
                        </ul>
                        <div class="tab-content" id="icon-tabContent">
                            <div class="tab-pane fade active show" id="bankDetails" role="tabpanel" aria-labelledby="bankDetailsTab">
                                <form class="form theme-form" action="userProfileAuthProcess" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" name="_token" value="">
                                    <input type="hidden" name="_method" value="put">

                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <div class="card-title-wrap">
                                                        <h4 class="card-title my-2">Identity Information</h4>
                                                    </div>
                                                </div>

                                                <div class="card-body">
                                                    <!-- PAN Card Number -->
                                                    <div class="form-group mb-2">
                                                        <label for="pan">Pan Card</label>
                                                        <div class="input-group input-group-merge">
                                                            <span class="input-group-text"><i class="fa fa-credit-card"></i></span>
                                                            <input
                                                                id="pan"
                                                                type="text"
                                                                name="pancard"
                                                                class="form-control"
                                                                placeholder="Enter PAN Card (e.g. ABCDE1234F)"
                                                                maxlength="10"
                                                                minlength="10"
                                                                required
                                                                oninput="this.value = this.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0,10);"
                                                                pattern="[A-Z]{5}[0-9]{4}[A-Z]{1}" value="<?= $pancard ?>">
                                                        </div>
                                                    </div>

                                                    <!-- PAN Card Image Upload -->
                                                    <div class="form-group mb-2">
                                                        <label for="panimage">Pan Card Image</label>
                                                        <input type="file" id="panimage" name="panimage" accept="image/png, image/jpeg, image/jpg"
                                                            onchange="previewImage(this, 'panPreview')">
                                                        <div style="margin-top:10px;">
                                                            <img id="panPreview"
                                                                src="<?= !empty($panimage) && $panimage != 'N/A' ? 'User/pandetails/' . htmlspecialchars($panimage) : '#' ?>"
                                                                alt="PAN Image Preview"
                                                                style="max-width:200px; display:<?= !empty($panimage) && $panimage != 'N/A' ? 'block' : 'none' ?>; border:1px solid #ccc; padding:5px;">
                                                        </div>
                                                    </div>



                                                </div>

                                                <!-- Submit Button -->
                                                <button class="btn btn-primary" type="submit" name="addpan">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function previewImage(input, previewId) {
        const preview = document.getElementById(previewId);
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
<script>
    function previewImage(input, previewId) {
        const preview = document.getElementById(previewId);
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.src = '#';
            preview.style.display = 'none';
        }
    }
</script>

<?php require_once('Include/Footer.php')
?>