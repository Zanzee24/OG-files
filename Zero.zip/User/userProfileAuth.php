<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
<?php
$queryProfile = mysqli_query($con, "SELECT date_time,sponser_id,countryId,name,user_id,email_id,phone FROM meddolic_user_details WHERE user_id='$userId'");
$valProfile = mysqli_fetch_assoc($queryProfile);
$dateTime = $valProfile['date_time'];
$sponserId = $valProfile['sponser_id'];
$countryId = $valProfile['countryId'];
$name = $valProfile['name'];
$email_id = $valProfile['email_id'];
$phone = $valProfile['phone'];

if ($countryId != '') {
    $queryCountry = mysqli_query($con, "SELECT countryName FROM meddolic_config_country_list WHERE country_id='$countryId'");
    $valCountry = mysqli_fetch_assoc($queryCountry);
    $countryName = $valCountry['countryName'];
} 
$querySponser = mysqli_query($con, "SELECT user_id FROM meddolic_user_details WHERE member_id='$sponserId'");
$valSponser = mysqli_fetch_assoc($querySponser);
$sponserUserId = $valSponser['user_id'];
?>
<div class="content-page">
    <div class="container-fluid">
        <h4 class="fw-bold mb-3"> 
        <i class="fa fa-user-plus  text-primary me-2"></i>
        User Profile</h4> 
        
        <div class="row">
            <div class="col-sm-12 col-xl-12 xl-100">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="icon-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="profileTab" data-bs-toggle="tab" href="#userProfile"
                                    role="tab">
                                    <i class="fa fa-users"></i> Profile
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="icon-tabContent">
                            <div class="tab-pane fade active show" id="userProfile" role="tabpanel"
                                aria-labelledby="profileTab">
                                <form class="form theme-form" action="userProfileAuthProcess" method="POST">
                                    <div class="card-body">
                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">Name *</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" data-val="true"
                                                    data-val-regex="Please enter only alphabets"
                                                    data-val-regex-pattern="^[a-zA-Z\s]+$"
                                                    data-val-required="Name is Required" id="name" name="name"
                                                    placeholder="Name" required type="text" value="<?= $userName ?>" readonly />
                                                <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label for="MobNo" class="col-sm-3 col-form-label">Mobile No *</label>
                                            <div class="col-sm-6">
                                                <input type="tel" class="form-control" id="phone" name="phone"
                                                    placeholder="Mobile Number" required value="<?= $phone ?>"
                                                    onkeypress="return onlynum(event)" aria-required="true" readonly  />
                                            </div>
                                        </div>


                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">Email Id *</label>
                                            <div class="col-sm-6">
                                                <input class="form-control" data-val="true"
                                                    data-val-regex="Enter Valid Email Id"
                                                    data-val-regex-pattern="^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,6})$"
                                                    data-val-required="Email Id is Required" id="EmailID" name="emailId"
                                                    required placeholder="Email ID" type="email"
                                                    value="<?= $email_id ?>" readonly />
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label for="M_COUNTRY" class="col-sm-3 col-form-label">Country *</label>
                                            <div class="col-sm-6">
                                                <select class="form-control" required id="M_COUNTRY" name="countryId">
                                                    <option value="">Select Country</option>
                                                    <?php $queryCountry = "SELECT * FROM meddolic_config_country_list WHERE status=1 ORDER BY countryName ASC";
                                                    $resultCountry = mysqli_query($con, $queryCountry);
                                                    while ($valCountry = mysqli_fetch_assoc($resultCountry)) { ?>
                                                        <option value="<?= $valCountry['country_id'] ?>" <?php if ($valCountry['country_id'] == $countryId)
                                                            echo "selected"; ?>>
                                                            <?= $valCountry['countryName'] ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">Sponser Id</label>
                                            <div class="col-sm-6">
                                                <input class="form-control"
                                                    placeholder="Sponser Id" type="text" value="<?= $sponserUserId ?>"
                                                    readonly />
                                            </div>
                                        </div>


                                        <div class="card-footer text-end">
                                            <div class="col-sm-9 offset-sm-3">
                                                <button class="btn btn-primary" type="submit"
                                                    name="profileUpdate">Update</button>
                                            </div>
                                        </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <?php require_once('Include/Footer.php')
            ?>