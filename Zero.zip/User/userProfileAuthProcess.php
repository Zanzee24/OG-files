<?php
include("loginCheck.php");
require('../PHPMailer/EncrptyModel.php');
if (isset($_POST['profileUpdate'])) {
        $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
    WHERE user_id='{$_SESSION['member_user_id']}'");
	$valAccess = mysqli_fetch_array($queryAccess);
	  if(!$valAccess){
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
	$memberId = $valAccess['member_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $emailId = $_POST['emailId'];
    $countryId = $_POST['countryId'];

    $d = date("Y-m-d H:i:s");
    mysqli_query($con, "UPDATE meddolic_user_details SET name='$name',email_id='$emailId',phone='$phone',countryId='$countryId' WHERE member_id='$memberId'"); ?>
    <script>
        alert("Profile Updated Successfully!!!");
        window.top.location.href = "userProfileAuth";
    </script>
<?php }




if (isset($_POST['addbank'])) {
    $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
        WHERE user_id='{$_SESSION['member_user_id']}'");
    $valAccess = mysqli_fetch_array($queryAccess);
    if (!$valAccess) {
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
    $memberId = $valAccess['member_id'];
    $ifsc = trim($_POST['ifsc']);
    $bank = trim($_POST['bank']);
    $branch = trim($_POST['branch']);
    $accNo = trim($_POST['accountNo']);
    $accName = trim($_POST['acName']);
    $d = date("Y-m-d H:i:s");

    // Handle passbook / bank document upload
    if (!empty($_FILES['passimage']['name'])) {
        $fileName = $_FILES['passimage']['name'];
        $tmpName = $_FILES['passimage']['tmp_name'];
        $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $newFileName = 'passbook_' . $memberId . '.' . $ext;
        $uploadDir = 'User/bankDetail/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        move_uploaded_file($tmpName, $uploadDir . $newFileName);
        $passimage = $newFileName;
    } else {
        $passimage = "N/A";
    }

    // Check if bank details already exist for this member
    $checkQuery = mysqli_query($con, "SELECT COUNT(*) FROM meddolic_user_bank_details WHERE memberId='$memberId'");
    $row = mysqli_fetch_array($checkQuery);

    if ($row[0] > 0) {
        // Update existing record
        $query = mysqli_query($con, "UPDATE meddolic_user_bank_details 
            SET bank=UCASE('$bank'), branch=UCASE('$branch'), ifsc=UCASE('$ifsc'), 
                accNo='$accNo', accName=UCASE('$accName'), addDate='$d', passimage='$passimage' 
            WHERE memberId='$memberId'");
        if ($query) {
            echo "<script>alert('Bank Details Updated Successfully'); window.top.location.href='bankDetail';</script>";
            exit;
        } else {
            echo "<script>alert('Bank Details Not Updated...Try Again'); window.top.location.href='bankDetail';</script>";
            exit;
        }
    } else {
        // Insert new record
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_bank_details 
            (memberId, bank, branch, ifsc, accNo, accName, addDate, passimage) 
            VALUES ('$memberId', UCASE('$bank'), UCASE('$branch'), UCASE('$ifsc'), '$accNo', UCASE('$accName'), '$d', '$passimage')");
        if ($queryIn) {
            echo "<script>alert('Bank Details Added Successfully'); window.top.location.href='bankDetail';</script>";
            exit;
        } else {
            echo "<script>alert('Bank Details Not Added...Try Again'); window.top.location.href='bankDetail';</script>";
            exit;
        }
    }
}

if (isset($_POST['addpan'])) {
    // Make sure session and member_id are valid
    $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
        WHERE user_id='{$_SESSION['member_user_id']}'");
    $valAccess = mysqli_fetch_array($queryAccess);
    if (!$valAccess) {
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
    $memberId = $valAccess['member_id'];
    
    $panCard = trim($_POST['pancard']);
    $d = date("Y-m-d H:i:s");

    // Handle file upload
    if (!empty($_FILES['panimage']['name'])) {
        $fileName = $_FILES['panimage']['name'];
        $fileTmp = $_FILES['panimage']['tmp_name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $newFileName = 'pan_' . $memberId . '.' . $fileExt;
        $uploadDir = 'User/pandetails/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        move_uploaded_file($fileTmp, $uploadDir . $newFileName);
        $panImage = $newFileName;
    } else {
        $panImage = "N/A";
    }

    // Check if PAN details already exist
    $checkQuery = mysqli_query($con, "SELECT COUNT(*) FROM meddolic_user_details WHERE member_id='$memberId'");
    $row = mysqli_fetch_array($checkQuery);

    if ($row[0] > 0) {
        // Update existing record
        $query = mysqli_query($con, "UPDATE meddolic_user_details 
            SET pancard='$panCard', panimage='$panImage', date_time='$d' 
            WHERE member_id='$memberId'");
        if ($query) {
            echo "<script>alert('PAN Details Updated Successfully'); window.top.location.href = 'pandetails';</script>";
            exit;
        } else {
            echo "<script>alert('PAN Details Not Updated. Try Again'); window.top.location.href = 'pandetails';</script>";
            exit;
        }
    } else {
        // Insert new record
        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_details 
            (member_id, pancard, panimage, date_time) 
            VALUES ('$memberId', '$panCard', '$panImage', '$d')");
        if ($queryIn) {
            echo "<script>alert('PAN Details Added Successfully'); window.top.location.href = 'pandetails';</script>";
            exit;
        } else {
            echo "<script>alert('PAN Details Not Added. Try Again'); window.top.location.href = 'pandetails';</script>";
            exit;
        }
    }
}

if (isset($_POST['addaadhaar'])) {
    // Ensure session and member_id are valid
    $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
        WHERE user_id='{$_SESSION['member_user_id']}'");
    $valAccess = mysqli_fetch_array($queryAccess);
    if (!$valAccess) {
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
    $memberId = $valAccess['member_id'];
    
    $aadhaarCard = trim($_POST['aadhaar_card']);
//    die();
    $aadhaarAddress = trim($_POST['aadhaar_card_address']);
    $d = date("Y-m-d H:i:s");

    // Handle front image upload
    if (!empty($_FILES['aadhaar_card_image']['name'])) {
        $fileFront = $_FILES['aadhaar_card_image']['name'];
        $tmpFront = $_FILES['aadhaar_card_image']['tmp_name'];
        $extFront = strtolower(pathinfo($fileFront, PATHINFO_EXTENSION));
        $newFileFront = 'aadhaar_front_' . $memberId . '.' . $extFront;
        $uploadDir = 'User/addharcard/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        move_uploaded_file($tmpFront, $uploadDir . $newFileFront);
    } else {
        $newFileFront = "N/A";
    }

    // Handle back image upload
    if (!empty($_FILES['aadhaar_card_back_image']['name'])) {
        $fileBack = $_FILES['aadhaar_card_back_image']['name'];
        $tmpBack = $_FILES['aadhaar_card_back_image']['tmp_name'];
        $extBack = strtolower(pathinfo($fileBack, PATHINFO_EXTENSION));
        $newFileBack = 'aadhaar_back_' . $memberId . '.' . $extBack;
        $uploadDir = 'User/addharcard/';
        move_uploaded_file($tmpBack, $uploadDir . $newFileBack);
    } else {
        $newFileBack = "N/A";
    }

    // Check if Aadhaar details already exist
    // $checkQuery = mysqli_query($con, "SELECT COUNT(*) FROM meddolic_user_details WHERE member_id='$memberId'");
    // $row = mysqli_fetch_array($checkQuery);

    // if ($row[0] > 0) {
        // Update existing record
    $query = mysqli_query($con, "UPDATE meddolic_user_details 
            SET adharcard='$aadhaarCard', aadhar_address='$aadhaarAddress', 
                aadharimage1='$newFileFront', aadharimage2='$newFileBack', date_time='$d' 
            WHERE member_id='$memberId'");
          
        if ($query) {
            echo "<script>alert('Aadhaar Details Updated Successfully'); window.top.location.href = 'addharcard';</script>";
            exit;
        } else {
            echo "<script>alert('Aadhaar Details Not Updated. Try Again'); window.top.location.href = 'addharcard';</script>";
            exit;
        }
    // } else {
    //     // Insert new record
    //     $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_details 
    //         (member_id, adharcard, aadhar_address, aadharimage1, aadharimage2, date_time) 
    //         VALUES ('$memberId', '$aadhaarCard', '$aadhaarAddress', '$newFileFront', '$newFileBack', '$d')");
    //     if ($queryIn) {
    //         echo "<script>alert('Aadhaar  Details Added Successfully'); window.top.location.href = 'addharcard';</script>";
    //         exit;
    //     } else {
    //         echo "<script>alert('Aadhaar Details Not Added. Try Again'); window.top.location.href = 'addharcard';</script>";
    //         exit;
    //     }
    // }
}


if (isset($_POST['addWalletAddress'])) {
    $currencyId = $_POST['currencyId'];
    $memberId = $_POST['memberId'];
    $walletAddress = $_POST['walletAddress'];
    $trnPassword = trim($_POST['trnPassword']);
    $d = date("Y-m-d H:i:s");

    // $newCalObj = new passEncrypt;
    // $encTrnPass = $newCalObj->twoPassEncrypt($trnPassword);
    $queryCheck = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE member_id='$memberId' AND trnPassword='$trnPassword'");
    $valCheck = mysqli_fetch_array($queryCheck);
    if ($valCheck[0] == 0) { ?>
        <script>
            alert("Incorrect Transaction Password!!!");
            window.top.location.href = 'walletAddressAdd';
        </script>
        <?php
        exit;
    }

    $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_wallet_address_details (`currency_id`,`member_id`,`walletAddress`,`addDate`) VALUES ('$currencyId','$memberId','$walletAddress','$d')");
    if ($queryIn) { ?>
        <script>
            alert('Wallet Address Added Successfully');
            window.top.location.href = "walletAddressAdd";
        </script>
        <?php
        exit;
    } else { ?>
        <script>
            alert('Wallet Address Not Added...Try Again');
            window.top.location.href = "walletAddressAdd";
        </script>
        <?php
        exit;
    }
}
if (isset($_POST['changeLogin'])) {
        $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
    WHERE user_id='{$_SESSION['member_user_id']}'");
	$valAccess = mysqli_fetch_array($queryAccess);
	  if(!$valAccess){
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
	$memberId = $valAccess['member_id'];
    $password = $_POST['password'];
    $password1 = $_POST['password1'];
    $password2 = $_POST['password2'];
    $d = date("Y-m-d H:i:s");

    if ($password2 != $password1) { ?>
        <script>
            alert("New Login passwords do not match!!!");
            window.top.location.href = 'changePassword';
        </script>
        <?php
        exit;
    }
    // $newCalObj= new passEncrypt;
    // $encPass= $newCalObj -> twoPassEncrypt($password);

    $stmt = $con->prepare("SELECT COUNT(*) FROM meddolic_user_details WHERE member_id = ? AND password = ?");
    $stmt->bind_param("ss", $memberId, $password); // "ss" means two strings
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count == 0) {
        ?>
        <script>
            alert("Incorrect Current Login password!!!");
            window.top.location.href = 'changePassword';
        </script>
        <?php
        exit;
    }


    // $newCalObj= new passEncrypt;
    // $newEncPass= $newCalObj -> twoPassEncrypt($password1);
    $result1 = mysqli_query($con, "UPDATE meddolic_user_details SET password='$password1' WHERE member_id='$memberId'");
    if ($result1) {
        unset($_SESSION['user_member_id']);
        unset($_SESSION['member_user_id']);
        unset($_SESSION['member_password']); ?>
        <script>
            alert("Login Password Updated Successfully!!!\nNow please login again with new password. ");
            window.top.location.href = 'changePassword';
        </script>
        <?php
    }
}
if (isset($_POST['changeTrn'])) {
        $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
    WHERE user_id='{$_SESSION['member_user_id']}'");
	$valAccess = mysqli_fetch_array($queryAccess);
	  if(!$valAccess){
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
	$memberId = $valAccess['member_id'];
    $password = $_POST['trnPassword'];
    $password1 = $_POST['trnPassword1'];
    $password2 = $_POST['trnPassword2'];
    $d = date("Y-m-d H:i:s");
    if ($password2 != $password1) { ?>
        <script>
            alert("New Transaction passwords and Confirm Transaction Password do not match!!!");
            window.top.location.href = 'TrnPassword';
        </script>
        <?php
        exit;
    }
    // $newCalObj1= new passEncrypt;
    // $encTrnPass= $newCalObj1 -> twoPassEncrypt($password);

    $stmt = $con->prepare("SELECT COUNT(*) FROM meddolic_user_details WHERE member_id = ? AND trnPassword = ?");
    $stmt->bind_param("ss", $memberId, $password);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count == 0) {
        ?>
        <script>
            alert("Incorrect Current Transaction password!!!");
            window.top.location.href = 'TrnPassword';
        </script>
        <?php
        exit;
    }


    // $newCalObj1= new passEncrypt;
    // $newencTrnPass= $newCalObj1 -> twoPassEncrypt($password1);
    $result1 = mysqli_query($con, "UPDATE meddolic_user_details SET trnPassword='$password1' WHERE member_id='$memberId'");
    if ($result1) { ?>
        <script>
            alert("Transaction Password Updated Successfully!!!");
            window.top.location.href = 'TrnPassword';
        </script>
        <?php
    }
} ?>
<?php include("../close-connection.php"); ?>