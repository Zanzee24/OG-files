<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
<div class="content-page">
    <div class="container-fluid">
        <h4 class="fw-bold mb-3">
            <i class="fa fa-user-plus  text-primary me-2"></i>
            User Profile
        </h4> <!-- Heading moved outside the card -->
        <div class="row">
            <div class="col-sm-12 col-xl-12 xl-100">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs" id="icon-tab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="loginPassTab" data-bs-toggle="tab" href="#loginPass"
                                    role="tab">
                                    <i class="fa fa-lock"></i> Login Security
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="icon-tabContent">
                            <div class="tab-pane fade active show" id="loginPass" role="tabpanel">
                                <form class="form theme-form" action="userProfileAuthProcess" method="POST">
                                    <div class="card-body">
                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">Current Login Password *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" name="password"
                                                    id="currentPass" placeholder="Current Login Password">
                                                <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">New Login Password *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" id="loginPassword"
                                                    placeholder="Enter Password"
                                                    onkeyup="matchPassword('loginPassword','confirmLoginPassword','loginPasswordErrorMsg','loginJoin')"
                                                    name="password1">
                                            </div>
                                        </div>

                                        <div class="mb-3 row">
                                            <label class="col-sm-3 col-form-label">Retype Login Password *</label>
                                            <div class="col-sm-6">
                                                <input type="password" class="form-control" id="confirmLoginPassword"
                                                    placeholder="Confirm Password"
                                                    onkeyup="matchPassword('loginPassword','confirmLoginPassword','loginPasswordErrorMsg','loginJoin')"
                                                    name="password2">
                                                <span id="loginPasswordErrorMsg" class="text-danger"></span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card-footer text-end">
                                        <div class="col-sm-9 offset-sm-3">
                                            <button class="btn btn-success" type="submit" name="changeLogin"
                                                id="loginJoin">Change</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php require_once('Include/Footer.php') ?>