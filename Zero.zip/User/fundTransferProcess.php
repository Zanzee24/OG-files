<?php 
include("loginCheck.php");
require_once('../PHPMailer/EncrptyModel.php');
if(isset($_POST['fundTransfer'])){
	    $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
    WHERE user_id='{$_SESSION['member_user_id']}'");
	$valAccess = mysqli_fetch_array($queryAccess);
	  if(!$valAccess){
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
	$loginMemberId = $valAccess['member_id'];
	$user_id1=$_POST['sponser_id']; 
	$amount=$_POST['amount'];
	$trnPassword=$_POST['trnPassword'];
	$directNeed=$_POST['directNeed'];
	$minTransfer=$_POST['minTransfer'];
	$d=date("Y-m-d H:i:s");
	$entry_date=date("Y-m-d");

	if($amount<=0 || $amount==''){ ?>
    <script>
      alert("Please Enter Valid Transfer Amount!!!");
      window.top.location.href='fundTransfer';
    </script>
    <?php
    exit;
  }
  if($amount<$minTransfer){ ?>
		<script>
			alert("The Minimum Transfer amount is Rs <?=$minTransfer?>");
			window.top.location.href='fundTransfer';
		</script>
		<?php
		exit;
	}
  $queryDirect=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_details WHERE sponser_id='$loginMemberId' AND topup_flag=1");
  $valDirect=mysqli_fetch_array($queryDirect);
  $totalDirect=$valDirect[0];
  if($totalDirect<$directNeed){ ?>
    <script>
      alert("Minimum <?=$directNeed?> Active Direct for P2P Transfer!!!");
      window.top.location.href='fundTransfer';
    </script>
    <?php
    exit;
  }

	$queryCheck=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_details WHERE member_id='$loginMemberId' AND trnPassword='$trnPassword'");
	$valCheck=mysqli_fetch_array($queryCheck);
	if($valCheck[0]==0) { ?>
    <script>
      alert("Incorrect Transaction Password!!!");
      window.top.location.href='fundTransfer';
    </script>
    <?php
    exit;
	}
	$result=mysqli_query($con,"SELECT * from meddolic_user_details WHERE user_id='$user_id1' AND user_type=2 AND account_status=1");
	if(!mysqli_num_rows($result)) { ?>
	  <script>
	    alert("Invalid / Suspended User Details!!!");
	    window.top.location.href="fundTransfer";
	  </script>
	  <?php
	  exit;
	}
	$resultFund=mysqli_query($con,"SELECT fundWallet from meddolic_user_details WHERE member_id='$loginMemberId' AND fundWallet>='$amount'");
	if(!mysqli_num_rows($resultFund)){ ?>
		<script>
		alert("Insufficient Balance in Wallet to Transfer!!!");
	    window.top.location.href="fundTransfer";
		</script>
		<?php
		exit;
	}

	$query1="SELECT member_id,phone FROM meddolic_user_details WHERE user_id='$user_id1'";
	$result1=mysqli_query($con,$query1);
	$val1=mysqli_fetch_assoc($result1);
	$receiver_member_id=$val1['member_id'];
	$receiverPhone=$val1['phone'];

	$querySender=mysqli_query($con,"SELECT user_id FROM meddolic_user_details WHERE member_id='$loginMemberId'");
	$valSender=mysqli_fetch_assoc($querySender);
	

	if($loginMemberId==$receiver_member_id){ ?>
		<script>
			alert("You Can't Transfer Fund to Yourself!!!");
	    	window.top.location.href="fundTransfer";
		</script>
		<?php
		exit;
	}	
	mysqli_query($con,"UPDATE meddolic_user_details SET fundWallet=fundWallet+'$amount' WHERE member_id='$receiver_member_id'");

	mysqli_query($con,"UPDATE meddolic_user_details SET fundWallet=fundWallet-'$amount' WHERE member_id='$loginMemberId'");

	mysqli_query($con,"INSERT INTO meddolic_user_fund_transfer_history (`sender_member_id`,`receiver_member_id`,`amount`,`date_time`) VALUES ('$loginMemberId','$receiver_member_id','$amount','$d')");

	mysqli_query($con,"INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`, `amount`,`date_time`,`trn_id`) VALUES ('$loginMemberId',5,1,'$amount','$d','$receiver_member_id')");

	mysqli_query($con,"INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`, `amount`,`date_time`,`trn_id`) VALUES ('$receiver_member_id',6,2,'$amount','$d','$loginMemberId')");?>
	<script>
	  alert("Fund Transfer Successfully!!!");
	  window.top.location.href="fundTransfer";
	</script>
	<?php } ?>
	<?php include("../close-connection.php");?>