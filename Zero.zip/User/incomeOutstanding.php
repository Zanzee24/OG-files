<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');

date_default_timezone_set("Asia/Kolkata");

// Default values
$user_id = isset($_GET['user_id']) ? $_GET['user_id'] : '';
$from_date = isset($_GET['from_date']) ? $_GET['from_date'] : date("d-m-Y");
$to_date = isset($_GET['to_date']) ? $_GET['to_date'] : date("d-m-Y");

$from_date_sql = date("Y-m-d", strtotime($from_date));
$to_date_sql = date("Y-m-d", strtotime($to_date));
?>
<style>
    .badge-success { background-color: #28a745; color: white; padding: 5px; }
    .badge-danger { background-color: #dc3545; color: white; padding: 5px; }
  </style>

<div class="content-page">
  <div class="container-fluid ">
    <h4 class="fw-bold mb-3">
      <i class="fa fa-credit-card  text-primary me-2"></i> History
    </h4>

    <div class="row">
      <div class="card shadow-sm border-0 rounded-4">
        <div class="card-body p-3">
          <!-- Responsive wrapper -->
          <div class="card">
            <div style="overflow-x: auto;">
              <div style="min-width: 600px;">
                <div class="card-body">
                  <div class="dt-ext table-responsive">
                    <table class="table table-bordered table-hover table-sm" style="min-width: 800px;">
                      <thead>
                      <tr>
                        <th>#</th>
                        <th>User ID</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Income Type</th>
                        <th>Transaction Type</th>
                        <th>Remark</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $query = "SELECT b.user_id, a.date_time, a.amount, a.deb_cr, c.statement_type, c.wallet_remark
                                FROM meddolic_user_wallet_statement a
                                JOIN meddolic_user_details b ON a.member_id = b.member_id
                                JOIN meddolic_config_wallet_statement_type c ON a.wallet_statement_id = c.wallet_statement_id
                                WHERE DATE(a.date_time) BETWEEN '$from_date_sql' AND '$to_date_sql'";

                      if (!empty($user_id)) {
                          $safe_user_id = mysqli_real_escape_string($con, $user_id);
                          $query .= " AND b.user_id = '$safe_user_id'";
                      }

                      $query .= " ORDER BY a.date_time DESC";

                      $result = mysqli_query($con, $query);
                      $count = 0;

                      while ($row = mysqli_fetch_assoc($result)) {
                          $count++;
                          $is_credit = ($row['deb_cr'] == 2);
                          ?>
                          <tr>
                            <td><?= $count ?></td>
                            <td><?= htmlspecialchars($row['user_id']) ?></td>
                            <td>
                              <span class="badge <?= $is_credit ? 'badge-success' : 'badge-danger' ?>">
                                <?= $row['amount'] ?> ₹
                              </span>
                            </td>
                            <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($row['date_time'])) ?></td>
                            <td><?= htmlspecialchars($row['statement_type']) ?></td>
                            <td>
                              <span class="badge <?= $is_credit ? 'badge-success' : 'badge-danger' ?>">
                                <?= $is_credit ? "Credit" : "Debit" ?>
                              </span>
                            </td>
                            <td><?= htmlspecialchars($row['wallet_remark']) ?></td>
                          </tr>
                          <?php
                      }
                      ?>
                    </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
  <script>
    $(function () {
      $("#from_date, #to_date").datepicker({
        dateFormat: "dd-mm-yy",
        changeMonth: true,
        changeYear: true,
        maxDate: 0
      });
    });
  </script>

      <?php require_once('Include/Footer.php'); ?>