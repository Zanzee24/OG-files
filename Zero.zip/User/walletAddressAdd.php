<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>


<div class="content-page">
  <div class="container-fluid">

    <!-- Page Title -->
    <h4 class="fw-bold mb-4"><i class="fa fa-plus  text-primary me-2"></i>Wallet Address Add</h4>

    <!-- Transfer Form -->
    <div class="row">
      <div class="col-md-6">
        <div class="card shadow-sm">
          <div class="card-body">
            <form class="theme-form" action="userProfileAuthProcess" method="post">
              <div class="mb-3">
                <label>Select Currency *</label>
                <select class="form-control" name="currencyId" required id="currencyId">
                  <option value=""> Select One </option>
                  <?php $queryCoin = mysqli_query($con, "SELECT * FROM meddolic_config_currency_list WHERE status=1 ORDER BY currencyName ASC");
                  while ($valCoin = mysqli_fetch_assoc($queryCoin)) { ?>
                    <option value="<?= $valCoin['currency_id'] ?>"> <?= $valCoin['currencyName'] ?></option>
                  <?php } ?>
                </select>
              </div>
              <div class="mb-3">
                <label>Wallet Address *</label>
                <input class="form-control" name="walletAddress" id="walletAddress" type="text" required
                  placeholder="Enter Wallet Address" style="text-transform: uppercase;">
                <input type="hidden" name="memberId" value="<?= $memberId ?>" />
              </div>
              <div class="mb-3">
                <label>Transaction Password -:</label>
                <input type="password" name="trnPassword" class="form-control" required
                  placeholder="Enter Transaction Password">
              </div>

              <button class="btn btn-primary w-100" type="submit" name="addWalletAddress">Save</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Transfer History Table -->
    <div class="row mt-5">
      <div class="col-12">
        <div class="card shadow-sm">

          <div class="card-body">
            <!-- ✅ Scrollable wrapper -->
            <div style="overflow-x: auto; width: 100%;">
              <table class="table table-bordered table-hover table-sm" style="min-width: 800px;">
                <thead class="table-light text-center">
                  <tr>
                    <th>Sr No.</th>
                    <th>Currency Name</th>
                    <th>Wallet Address</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $count = 0;
                  $queryWallet = mysqli_query($con, "SELECT a.payment_id,a.walletAddress,a.addDate,b.currencyName FROM meddolic_user_wallet_address_details a, meddolic_config_currency_list b WHERE a.member_id='$memberId' AND a.currency_id=b.currency_id AND a.status=1 ORDER BY a.addDate DESC");
                  while ($valWallet = mysqli_fetch_assoc($queryWallet)) {
                    $count++; ?>
                    <tr>
                      <td><?= $count ?></td>
                      <td><?= $valWallet['currencyName'] ?></td>
                      <td><?= $valWallet['walletAddress'] ?></td>
                      <td><a href="javascript:void(0)" class="btn btn-danger btn-sm"
                          onclick="deleteWalletAddress(<?= $valWallet['payment_id'] ?>)"><i class="fa fa-trash"></i>
                          Delete</a></td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- End Scrollable wrapper -->
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require_once('Include/Footer.php'); ?>
<script>
    function deleteWalletAddress(paymentId) {
        if (paymentId != "") {
            if (confirm('Are you sure to Delete this Wallet Address?')) {
                $.ajax({
                    type: "POST",
                    url: 'ajaxCalls/deleteWalletAddressAjax',
                    data: { paymentId: paymentId },
                    cache: false,
                    success: function (data) {
                        // alert(data);
                        if (data) {
                            alert('Wallet Address Deleted Successfully');
                            location.reload();
                        }
                    }
                });
            }
        }
    }
</script>