<?php
include("loginCheck.php");
require_once('../PHPMailer/EncrptyModel.php');
require_once('authIncomeFunction.php');
if (isset($_POST['upgradeNow'])) {
    $queryAccess = mysqli_query($con, "SELECT member_id FROM meddolic_user_details 
    WHERE user_id='{$_SESSION['member_user_id']}'");
    $valAccess = mysqli_fetch_array($queryAccess);
    if (!$valAccess) {
        echo "<script>alert('Invalid session. Please log in again.'); window.top.location.href='login';</script>";
        exit;
    }
    $loginMemberId = $valAccess['member_id'];
    $user_id1 = $_POST['sponser_id'];
    $quantity = $_POST['quantity'];
    $trnPassword = $_POST['trnPassword'];
    $packageId = $_POST['packageId'];
    $product_id = $_POST['product_id'];
    $d = date("Y-m-d H:i:s");
    $todayDate = date("Y-m-d");

    $packagePrice = $quantity * 800;
    $DP_point = $quantity * 7;


    if ($quantity < 2) { ?>
        <script>
            alert("Please Buy product atleast minimun-2 ");
            window.history.back(); 
        </script>
        <?php
        exit;
    }

    // $newCalObj = new passEncrypt;
    // $encTrnPass = $newCalObj->twoPassEncrypt($trnPassword);
    $queryCheck = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE member_id='$loginMemberId' AND trnPassword='$trnPassword'");
    $valCheck = mysqli_fetch_array($queryCheck);
    if ($valCheck[0] == 0) { ?>
        <script>
            alert("Incorrect Transaction Password!!!");
            window.history.back(); 
        </script>
        <?php
        exit;
    }
    $resultUser = mysqli_query($con, "SELECT * FROM meddolic_user_details WHERE user_id='$user_id1'");
    if (!mysqli_num_rows($resultUser)) { ?>
        <script>
            alert("Invalid User Id!!!");
            window.history.back(); 
        </script>
        <?php
        exit;
    }

    $queryWallet = mysqli_query($con, "SELECT fundWallet,sponser_id FROM meddolic_user_details WHERE member_id='$loginMemberId'");
    $valWallet = mysqli_fetch_array($queryWallet);
    $current_wallet = $valWallet[0];
    $sponser_idd = $valWallet[1];
    if ($current_wallet <= 0) { ?>
        <script>
            alert("Insufficient Balance in Wallet to Purchase");
            window.top.location.href = "authActiveUser";
        </script>
        <?php
        exit;
    }

    if ($current_wallet < $packagePrice) { ?>
        <script>
            alert("Insufficient Balance in Wallet to Purchase");
            window.top.location.href = "authActiveUser";
        </script>
        <?php
        exit;
    }

    $queryDetails = mysqli_query($con, "SELECT a.member_id,a.sponser_id,a.topup_flag,b.topup_flag AS sponserTop,b.currentReward FROM meddolic_user_details a, meddolic_user_details b WHERE a.user_id='$user_id1' AND a.sponser_id=b.member_id");
    $valDetails = mysqli_fetch_assoc($queryDetails);
    $memberId = $valDetails['member_id'];
    $sponser_id = $valDetails['sponser_id'];
    $topup_flag = $valDetails['topup_flag'];
    $sponserTopup = $valDetails['sponserTop'];
    $currentReward = $valDetails['currentReward'];
    $nextReward = $currentReward + 1;

        $sql=mysqli_query($con,"SELECT stock FROM franchise_shopping_product_details WHERE product_id='$product_id' ");
        $vals=mysqli_fetch_assoc($sql);
        $stock=$vals['stock'];
        if($quantity<=$stock){
            mysqli_query($con, "UPDATE franchise_shopping_product_details SET stock=stock-'$quantity' WHERE product_id='$product_id'");
            
            mysqli_query($con,  "INSERT INTO `franchise_shopping_product_purchase_details`(`member_id`, `product_id`, `quantity`, `price`, `dateTime`, `purchaseBy`) VALUES ('$memberId','$product_id','$quantity','$packagePrice','$d','$loginMemberId')");
          
        $stockUpdate=mysqli_query($con,"SELECT stock FROM franchise_shopping_product_details WHERE product_id='$product_id' ");
        $valStock=mysqli_fetch_assoc($stockUpdate);
        $stockNew=$valStock['stock'];
        if($stockNew==0){
         mysqli_query($con, "UPDATE franchise_shopping_product_details SET status=0 WHERE product_id='$product_id'");
            }
            
        }else{?>
                <script>
                    alert("This Product Stock Only Available <?=$stock?> ");
                    window.history.back(); 
                </script>
                <?php
                exit;
        }
            



    //Activation & Update Code Starts//  
    mysqli_query($con, "UPDATE meddolic_user_details SET fundWallet=fundWallet-'$packagePrice' WHERE member_id='$loginMemberId'");
    mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`, `amount`, `date_time`,`trn_id`) VALUES ('$loginMemberId',7,1,'$packagePrice','$d','$memberId')");

    if ($topup_flag == 0) {
        mysqli_query($con, "UPDATE meddolic_user_details SET topup_flag=1,activation_date='$d' WHERE member_id='$memberId'");

        mysqli_query($con, "UPDATE meddolic_user_child_ids SET topup_status=1,topup_date='$d' WHERE child_id='$memberId'");
    }
    mysqli_query($con,"INSERT INTO meddolic_user_activation_details (`member_id`,`sponser_id`,`packageId`,`investPrice`,`date_time`,`activate_by`,`SP_Point`,`product_quentity`) VALUES ('$memberId','$sponser_id','$packageId','$packagePrice','$d','$loginMemberId','$DP_point','$quantity')");
    //Activation & Update Code Ends//

    //Reward Income Code Start
    if ($nextReward <= 18) {
        $queryRe = mysqli_query($con, "SELECT leftBus,rightBus,rewardIncome FROM meddolic_config_reward_income WHERE rewardId='$nextReward'");
        $valRe = mysqli_fetch_assoc($queryRe);
        $leftBusiness = $valRe['leftBus'];
        $rightBusiness = $valRe['rightBus'];
        $rewardIncome = $valRe['rewardIncome'];
        rewardRelease($con, $sponser_id, $nextReward, $leftBusiness, $rightBusiness, $rewardIncome, $d);
    }
    relayRewardLoop($con, $memberId, $d);
    //Reward Income Code End

    // echo "Done";
    echo "<script>alert('Congratulation...Package Purchase Successful!!!');window.top.location.href='authActiveUser';</script>";
} ?>
<?php include("../close-connection.php"); ?>