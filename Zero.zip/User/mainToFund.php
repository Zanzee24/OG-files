<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>


<div class="content-page">
  <div class="container-fluid">

    <!-- Page Title -->
    <h4 class="fw-bold mb-4"><i class="fa fa-credit-card  text-primary me-2"></i>Income Wallet to Purchase Wallet</h4>

    <!-- Transfer Form -->
    <div class="row">
      <div class="col-md-12">
        <div class="card shadow-sm">
          <div class="card-body">
            <form class="theme-form" action="mainToFundProcess" method="post">
              <div class="mb-3">
                <label>User ID:</label>
                <input type="text" name="sponser_id" id="sponser_id" class="form-control" placeholder="e.g. xxxxxxxxxx"
                  required value="<?= $userId ?>" readonly>
              </div>
              <div class="mb-3">
                <label>Name:</label>
                <input type="text" id="sponser_name" class="form-control" placeholder="e.g. John Doe" disabled=""
                  value="<?= $userName ?>">
              </div>
              <div class="mb-3">
                <label>Income Wallet:</label>
                <input type="text" class="form-control" name="incomeWallet" value="<?= $incomeWallet ?>" readonly>
              </div>
              <div class="mb-3">
                <label>Purchase Wallet:</label>
                <input type="text" id="current_wallet" name="fundWallet" class="form-control" readonly
                  value="<?= $fundWallet ?>">
              </div>
              <div class="mb-3">
                <label>Amount To Transfer:</label>
                <input type="number" id="amount" name="amount" class="form-control" placeholder="e.g. Transfer Amount"
                  onkeypress="return onlynum(event)" required>
              </div>
              <div class="mb-3">
                <label>Transaction Password:</label>
                <input type="password" name="trnPassword" class="form-control" placeholder="e.g. Transaction Password"
                  required>
              </div>
              <button class="btn btn-primary w-100" name="fundTransfer">Transfer</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Transfer History Table -->
    <div class="row mt-5">
      <div class="col-12">
        <div class="card shadow-sm">
          <div class="card-header bg-light">
            <h5 class="mb-0">Income Wallet To Purchase Wallet History</h5>
          </div>
          <div class="card-body">
            <!-- ✅ Scrollable wrapper -->
            <div style="overflow-x: auto; width: 100%;">
              <table class="table table-bordered table-hover table-sm" style="min-width: 800px;">
                <thead class="table-light text-center">
                  <tr>
                    <th>#</th>
                    <th>UserId</th>
                    <th>Name</th>
                    <th>Transfer Amount</th>
                    <th>Transfer Date</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $count = 0;
                  $queryTransfer = mysqli_query($con, "SELECT a.transferAmount,a.transferDate,a.incomeWallet,a.fundWallet,b.user_id,b.name FROM meddolic_user_income_wallet_transfer a, meddolic_user_details b WHERE a.memberId='$memberId' AND a.memberId=b.member_id ORDER BY a.transferDate DESC");
                  while ($valTransfer = mysqli_fetch_assoc($queryTransfer)) {
                    $count++; ?>
                    <tr>
                      <td><?= $count ?></td>
                      <td><?= $valTransfer['user_id'] ?></td>
                      <td><?= $valTransfer['name'] ?></td>
                      <td>
                      <span class="badge bg-success" style="font-size:1rem;">
                        <i class="fa fa-inr"></i> <?= $valTransfer['transferAmount'] ?>
                      </span></td>
                      <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTransfer['transferDate'])) ?>
                      </td>
                    </tr>
                  <?php } ?>

                </tbody>
              </table>
            </div>
            <!-- End Scrollable wrapper -->
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require_once('Include/Footer.php'); ?>