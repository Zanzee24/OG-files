<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
            <div class="content-page">
                <div class="container-fluid">
                   
                    <h4 class="fw-bold mb-3 "><i class="fa fa-rocket  text-primary me-2"></i>Support System</h4>
                
                    <!-- Create New Ticket Button -->
                    <div class="row mb-3">
                        <div class="col-md-12 text-end">
                            <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#myModal" class="btn btn-info text-white">
                                <i class="fa fa-plus-circle"></i> Create New Ticket
                            </a>
                        </div>
                    </div>
                
                    <!-- Outbox Tickets -->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card shadow">
                                <div class="card-header bg-primary text-white">
                                    <h5><i class="fa fa-paper-plane"></i> All Outbox Tickets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="dt-ext table-responsive">
                                        <table class="table table-striped table-hover table-bordered w-100">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Ticket No</th>
                                                    <th>Subject</th>
                                                    <th>Message</th>
                                                    <th>Priority</th>
                                                    <th>Raise Date</th>
                                                    <th>Last Update</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                             <tbody>
              <?php 
                $count=0;
                $queryRequest=mysqli_query($con,"SELECT a.ticketCode,a.ticketMessage,a.raiseDate,a.actionDate,a.ticketStatus,b.user_id,b.name,c.subjectName,d.priorityName FROM meddolic_user_support_ticket a, meddolic_user_details b, meddolic_config_support_subject c, meddolic_config_support_priority d WHERE a.memberId='$memberId' AND a.memberId=b.member_id AND a.subjectId=c.subjectId AND a.priorityId=d.priorityId ORDER BY a.raiseDate DESC");
                while($valRequest=mysqli_fetch_assoc($queryRequest)){
                  $count++; ?>
                  <tr>
                    <td><?= $count?></td>
                    <td><?= $valRequest['ticketCode']?></td>
                    <td><?= $valRequest['subjectName']?></td>
                    <td><?= $valRequest['ticketMessage']?></td>
                    <td><?= $valRequest['priorityName']?></td>
                    <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valRequest['raiseDate']))?></td>
                    <td><?php if($valRequest['actionDate']!=''){ ?> <i class="fa fa-clock-o"></i>  <?= date("d-m-Y H:i:s", strtotime($valRequest['actionDate'])); } ?></td>
                    <td><?php if($valRequest['ticketStatus']==1) echo "<span class='badge bg-primary'>OPEN</span>";else if($valRequest['ticketStatus']==2) echo "<span class='badge bg-warning'>PROCESSING</span>";else if($valRequest['ticketStatus']==3) echo "<span class='badge bg-success'>RESOLVED</span>";?></td>
                  </tr>
                  <?php } ?>
              </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <!-- Inbox Tickets -->
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="card shadow">
                                <div class="card-header bg-success text-white">
                                    <h5><i class="fa fa-inbox"></i> All Inbox Tickets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="dt-ext table-responsive">
                                        <table class="table table-striped table-hover table-bordered w-100">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>#</th>
                                                    <th>Subject</th>
                                                    <th>Message</th>
                                                    <th>Date</th>
                                                </tr>
                                            </thead>
                                           <tbody>
              <?php 
              $count=0;
              $queryResponse=mysqli_query($con,"SELECT a.adminMessage,a.actionDate,a.ticketStatus,b.user_id,b.name,c.subjectName FROM meddolic_user_support_ticket a, meddolic_user_details b, meddolic_config_support_subject c WHERE a.memberId='$memberId' AND a.memberId=b.member_id AND a.subjectId=c.subjectId AND a.adminMessage<>'' ORDER BY a.actionDate DESC");
              while($valResponse=mysqli_fetch_assoc($queryResponse)){
                $count++; ?>
                <tr>
                  <td><?= $count?></td>
                  <td><?= $valResponse['subjectName']?></td>
                  <td><?= $valResponse['adminMessage']?></td>
                  <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valResponse['actionDate']))?></td>
                </tr>
                <?php } ?>
              </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <!-- Create New Ticket Modal -->
                    <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <form action="SupportProcess" enctype="multipart/form-data" method="POST">
                                <div class="modal-content">
                                    <div class="modal-header bg-primary text-white">
                                        <h4 class="modal-title" id="myModalLabel">
                                            <i class="fa fa-ticket-alt"></i> Create a New Ticket
                                        </h4>
                                        <button type="button" class="close" data-bs-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="row">
                                            <!-- Subject Selection -->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label><i class="fa fa-tag"></i> Subject</label>
                                                    <select class="form-control" required id="subjectId" name="subjectId">
                    <option value=""> Select One </option>
                      <?php $querySubject=mysqli_query($con,"SELECT subjectId,subjectName FROM meddolic_config_support_subject WHERE subjectStatus=1");
                      while($valSubject=mysqli_fetch_assoc($querySubject)){ ?>
                        <option value="<?=$valSubject['subjectId']?>"> <?= $valSubject['subjectName']?> </option>
                      <?php } ?>
                    </select>
                                                     <input type="hidden" name="memberId" value="<?=$memberId?>">
                                                </div>
                                            </div>
                
                                            <!-- Priority Selection -->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label><i class="fa fa-exclamation-circle"></i> Priority</label>
                                                     <select class="form-control" required id="priorityId" name="priorityId">
                    <option value=""> Select One </option>
                      <?php $queryPriority=mysqli_query($con,"SELECT priorityId,priorityName FROM meddolic_config_support_priority WHERE priorityStatus=1");
                      while($valPriority=mysqli_fetch_assoc($queryPriority)){ ?>
                      <option value="<?=$valPriority['priorityId']?>"> <?= $valPriority['priorityName']?></option>
                      <?php } ?>
                    </select>
                                                </div>
                                            </div>
                
                                            <!-- Message Box -->
                                            <div class="col-md-12 mt-3">
                                                <div class="form-group">
                                                    <label><i class="fas fa-comment-alt"></i> Message</label>
                                                    <textarea class="form-control" name="ticketMessage" placeholder="Enter Message" rows="3" required></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success" name="supportTicket">
                                            <i class="fa fa-paper-plane"></i> Submit
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                
                    <?php require_once('Include/Footer.php')
               ?> 