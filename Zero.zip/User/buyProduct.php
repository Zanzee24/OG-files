<!DOCTYPE html>
<html lang="en">
<?php include("login-check.php"); ?>
<?php include('include/head.php');
include('include/menu.php');
include('include/header.php'); ?>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12">
			<div class="iq-card">
				<div class="iq-card-header d-flex justify-content-between">
					<div class="iq-header-title">
						<h4 class="card-title">Bill Generate Here</h4>
					</div>
				</div>
				<div class="iq-card-body">
					<div class="table-responsive">
						<div class="form-group">
							<label for="productId">Select Product</label>
							<select class="form-control" required id="productId" name="productId"
								style="height:50px;width: 50%;">
								<option value="">Select Product</option>
								<?php
								$resultCountry = mysqli_query($con, "SELECT product_id, productName, price,quanitty FROM franchise_shopping_product_details WHERE status=1 ORDER BY product_id ASC");
								while ($valCountry = mysqli_fetch_assoc($resultCountry)) {
									?>
									<option value="<?= $valCountry['product_id'] ?>"
										data-name="<?= htmlspecialchars($valCountry['productName']) ?>"
										data-price="<?= $valCountry['price'] ?>"
										data-stock="<?= $valCountry['quanitty'] ?>">
										<?= htmlspecialchars($valCountry['productName']) ?> - ₹<?= $valCountry['price'] ?>
										(Available: <?= $valCountry['quanitty'] ?>)
									</option>
								<?php } ?>
							</select>
						</div>

						<div id="productDetailsContainer" style="margin-top: 20px;"></div>
						<form id="buyProductForm" action="buyProductProccess" method="post"
							style="display: inline;">
						    <div class="form-group">
                    	 <div class="form-group">
                                 <label>User ID -:</label>
                                 <input type="text" name="sponser_id" id="sponser_id" class="form-control" placeholder="e.g. xxxxxxxxxx" onblur="sponser_valid(this.value)" required >
                                 
                              </div>
                           </div>
                           <div class="col-md-12">
                              <div class="form-group">
                                 <label>Name -: </label>
                                 <input type="text" id="sponser_name" class="form-control" placeholder="e.g. John Doe"  disabled="" >
                              </div>
                           </div>
                           
							<div class="form-group">
								<label for="quantity">Enter Quantity</label>
								<input type="number" class="form-control" id="quantity" name="quantity" min="1" required
									style="width: 200px;">
							</div>
							
							
	
							<input type="hidden" name="ResID" id="productIdField" value="">
							<input type="hidden" name="frnch_member_Id" value="<?= $frnch_member_Id ?>">

							<div id="billingInfo" class="border p-3 mt-3"
								style="display: none; background-color: #f8f9fa;">
								<h5>🧾 Bill Summary</h5>
								<p><strong>Product:</strong> <span id="billProductName"></span></p>
								<p><strong>Unit Price:</strong> ₹<span id="billPrice"></span></p>
								<p><strong>Quantity:</strong> <span id="billQty"></span></p>
								<p><strong>Total:</strong> ₹<span id="billTotal"></span></p>
							</div>
							<button type="submit" name="buyProduct" class="btn btn-primary action-button mt-3">
								Buy Product
							</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php include('include/footer.php'); ?>
<script>
    
    function sponser_valid(sponser_id){
   document.getElementById("sponser_name").value="";
    if(!sponser_id==""){
        if (window.XMLHttpRequest){
            xmlhttp=new XMLHttpRequest();
        }
        else{// code for IE6, IE5
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange=function(){
            if(xmlhttp.readyState==4 && xmlhttp.status==200){
                var v=xmlhttp.responseText;
                if(v.trim()!=""){
                    document.getElementById("sponser_name").value=v.trim();
                }
                else{
                    alert("Invalid User ID");
                    document.getElementById("sponser_id").value="";
                }
            }
        }
        xmlhttp.open("GET","ajax_calls/get_sponser_name?sponser_id="+sponser_id,true);
        xmlhttp.send();
    }
}

	var d = document.getElementById("stock");
	d.className += " active";
	var d = document.getElementById("addProduct");
	d.className += " active";
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
	$(document).ready(function () {
		$('#productId').change(function () {
			var productId = $(this).val();
			if (productId) {
				$('#productDetailsContainer').html('<p>Loading product details...</p>');
				$.ajax({
					url: 'ajax_calls/get_product_detailsAjax.php',
					type: 'POST',
					data: { product_id: productId },
					success: function (response) {
						$('#productDetailsContainer').html(response);
					},
					error: function () {
						$('#productDetailsContainer').html('<p>Error loading product details.</p>');
					}
				});
			} else {
				$('#productDetailsContainer').html('');
			}
		});
	});
</script>
<script>
	document.getElementById('productId').addEventListener('change', function () {
		const selectedValue = this.value;
		document.getElementById('productIdField').value = selectedValue;
	});
</script>


<script>
	$('#productId').change(function () {
		$('#productIdField').val($(this).val());
	});
</script>


<a id="buyProductLink" href="#" class="btn btn-primary action-button float-left" style="display: none;">
	Buy Product
</a>

<script>
	// Replace the button click handler with this
	$('#buyProductLink').click(function (e) {
		e.preventDefault(); // Prevent default link behavior
		if (selectedProductId) {
			window.location.href = 'fundRequestRejectBack?ResID=' + selectedProductId;
		}
	});
</script>
<script>
	const productSelect = document.getElementById('productId');
	const quantityInput = document.getElementById('quantity');
	const billingBox = document.getElementById('billingInfo');
	const productIdField = document.getElementById('productIdField');

	const billProductName = document.getElementById('billProductName');
	const billPrice = document.getElementById('billPrice');
	const billQty = document.getElementById('billQty');
	const billTotal = document.getElementById('billTotal');

	let currentStock = 0;

	function updateBill() {
		const selected = productSelect.options[productSelect.selectedIndex];
		const price = parseFloat(selected.getAttribute('data-price')) || 0;
		const productName = selected.getAttribute('data-name') || '';
		const stock = parseInt(selected.getAttribute('data-stock')) || 0;
		const qty = parseInt(quantityInput.value) || 0;

		currentStock = stock;

		if (price > 0 && qty > 0) {
			if (qty > stock) {
				alert("❌ Entered quantity exceeds available stock (" + stock + ")");
				quantityInput.value = stock;
				return;
			}

			const total = price * qty;

			billProductName.textContent = productName;
			billPrice.textContent = price.toFixed(2);
			billQty.textContent = qty;
			billTotal.textContent = total.toFixed(2);

			billingBox.style.display = 'block';
			productIdField.value = selected.value;
		} else {
			billingBox.style.display = 'none';
		}
	}

	productSelect.addEventListener('change', function () {
		const selected = productSelect.options[productSelect.selectedIndex];
		const stock = parseInt(selected.getAttribute('data-stock')) || 0;

		quantityInput.value = '';
		quantityInput.max = stock;
		quantityInput.placeholder = `Max ${stock}`;
		billingBox.style.display = 'none';

		updateBill();
	});
	quantityInput.addEventListener('input', updateBill);
</script>




</body>

</html>