<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?>
<div class="content-page">
  <div class="container-fluid">
    <!-- Page Title -->
    <h4 class="fw-bold mb-4"><i class="fa fa-exchange  text-primary me-2"></i>P2P Receive History</h4>
    <!-- Transfer History Table -->
    <div class="row mt-5">
      <div class="col-12">
        <div class="card shadow-sm">
          <div class="card-body">
            <!-- ✅ Scrollable wrapper -->
            <div style="overflow-x: auto; width: 100%;">
              <table class="table table-bordered table-hover table-sm" style="min-width: 800px;">
                <thead class="table-light text-center">
                  <tr>
                    <th>#</th>
                    <th>ReceiverId</th>
                    <th>Receiver Name</th>
                    <th>SenderId</th>
                    <th>Sender Name</th>
                    <th>Received Amount</th>
                    <th>Received Date</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $count = 0;
                  $queryTransfer = mysqli_query($con, "SELECT a.amount,a.date_time,b.user_id AS senderId,b.name AS senderName,c.user_id AS receiverId,c.name AS receiverName FROM meddolic_user_fund_transfer_history a, meddolic_user_details b, meddolic_user_details c WHERE a.receiver_member_id='$memberId' AND a.sender_member_id=b.member_id AND a.receiver_member_id=c.member_id ORDER BY a.date_time DESC");
                  while ($valTransfer = mysqli_fetch_assoc($queryTransfer)) {
                    $count++; ?>
                    <tr>
                      <td><?= $count ?></td>
                      <td><?= $valTransfer['receiverId'] ?></td>
                      <td><?= $valTransfer['receiverName'] ?></td>
                      <td><?= $valTransfer['senderId'] ?></td>
                      <td><?= $valTransfer['senderName'] ?></td>
                      <td>
                        <span class="badge bg-success" style="font-size:1rem;">
                          <i class="fa fa-inr"></i> <?= $valTransfer['amount'] ?>
                        </span>
                      </td>
                      <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTransfer['date_time'])) ?>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- End Scrollable wrapper -->
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<?php require_once('Include/Footer.php'); ?>