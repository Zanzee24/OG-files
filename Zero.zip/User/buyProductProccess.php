<br><br><br>
<center>
    <h2>Processing your request!!!</h2>
    <h3>Please do not press back or refresh!!!</h3>
</center>
<?php
ob_start();
error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);
date_default_timezone_set("Asia/Kolkata");
include("login-check.php");
if (isset($_POST['buyProduct'])) {
    $frnch_member_Id = $_POST['frnch_member_Id'];
    $user_id = $_POST['sponser_id'];
    $productId = (int) $_POST['ResID'];
    $quantity = (int) $_POST['quantity'];
    $d = date("Y-m-d H:i:s");

    $productDetails = mysqli_query($con, "SELECT productName,quanitty,price FROM franchise_shopping_product_details WHERE product_id='$productId'");
    $valProduct = mysqli_fetch_assoc($productDetails);
    $productName = $valProduct['productName'];
    $stock = $valProduct['quanitty'];
    $price = $valProduct['price'];

    $totelPrice = $quantity * $price;

    $query1 = "SELECT member_id,email_id,name,sponser_id,currentReward FROM meddolic_user_details WHERE user_id='$user_id'";
    $result1 = mysqli_query($con, $query1);
    $val1 = mysqli_fetch_assoc($result1);
    $receiver_member_id = $val1['member_id'];
    $email_id = $val1['email_id'];
    $name = $val1['name'];
    $sponser_id = $val1['sponser_id'];
    $currentReward = $val1['currentReward'];


    $totelProduct = $stock - $quantity;
    if ($totelProduct <= 0) {
        mysqli_query($con, "UPDATE franchise_shopping_product_details SET status=0 WHERE product_id='$productId'");
    }

    $packageId = 0;
    $packagePrice = $totelPrice / 2;
    mysqli_query($con, "INSERT INTO meddolic_user_activation_details (`member_id`,`sponser_id`,`packageId`,`investPrice`,`date_time`,`activate_by`,`walletType`) VALUES ('$receiver_member_id','$sponser_id','$packageId','$packagePrice','$d','$receiver_member_id',2)");


    if ($currentReward == 0) {
        $repurchase = 3;
    } else {
        $productDetails = mysqli_query($con, "SELECT repurchaseIncome FROM meddolic_config_reward_income WHERE rewardId='$currentReward'");
        $valProduct = mysqli_fetch_assoc($productDetails);
        $repurchase = $valProduct['repurchaseIncome'];
    }

    $repurchaseIncome = $totelPrice * $repurchase / 100;
    mysqli_query($con, "INSERT INTO `meddolic_user_repurchase_income`(`memberId`, `repurchaseIncome`, `price`, `repurchasePercent`, `product_id`, `dateTime`) VALUES ('$receiver_member_id','$repurchaseIncome','$totelPrice','$repurchase','$productId','$d')");
    $trnId = $con->insert_id;

    mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`,`date_time`,`trn_id`) VALUES ('$receiver_member_id',16,2,'$repurchaseIncome','$d','$trnId')");
    mysqli_query($con, "UPDATE meddolic_user_details SET wallet=wallet+'$repurchaseIncome' WHERE member_id='$receiver_member_id'");

    mysqli_query($con, "UPDATE franchise_shopping_product_details SET quanitty=quanitty-'$quantity' WHERE product_id='$productId'");
    $queryIn = mysqli_query($con, "INSERT INTO `franchise_shopping_product_purchase_details`(`member_id`,`product_id`, `quantity`,`price`, `dateTime`,`purchaseBy`) VALUES ('$receiver_member_id','$productId','$quantity','$totelPrice','$d',1)");

    if ($queryIn) {
        ?>
        <script>
            alert('Product Purchase  Successfully');
            window.top.location.href = "buyProduct";
        </script>
        <?php
        exit;
    } else { ?>
        <script>
            alert('Product Not Purchase...Try Again');
            window.top.location.href = "buyProduct";
        </script>
        <?php
        exit;
    }
} ?>
<?php include("../close-connection.php"); ?>