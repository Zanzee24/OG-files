<?php
require_once("loginCheck.php");
require_once('Include/Head.php');
require_once('Include/Header.php');
require_once('Include/Menu.php');
?><?php

$queryAmount = mysqli_query($con, "SELECT minimumWithdraw FROM meddolic_config_misc_setting");
$valAmount = mysqli_fetch_assoc($queryAmount);
$minimumWithdraw = $valAmount['minimumWithdraw'];

unset($_SESSION['withdrawTokenSet']);
$randToken = rand(1111, 9999) . time() . date('s');
$newToken = md5($randToken);
$_SESSION['withdrawTokenSet'] = $newToken;
$todayDay = date('w'); ?>
<div class="content-page">
  <div class="container-fluid">
    <h4 class="fw-bold mb-3"><i class="fa fa-sign-out  text-primary me-2"></i>Withdrawal</h4>
    <!-- Heading moved outside the card -->


    <div class="row">
      <div class="col-sm-12">
        <div class="card">
          <div class="card-body">
            <form class="theme-form" action="walletWithdrawProcess" method="post">
              <div class="mb-3">
                <label>UserId </label>
                <input type="text" name="user_id" class="form-control" placeholder="e.g. john12345" readonly
                  value="<?= $userId ?>">
                <input type="hidden" name="goodFile" value="<?= $newToken ?>">
                <input type="hidden" name="withdrawCharge" value="<?= $withdrawCharge ?>">
                <input type="hidden" name="minimumWithdraw" value="<?= $minimumWithdraw ?>">
              </div>
              <div class="mb-3">
                <label>Name </label>
                <input type="text" name="name" class="form-control" placeholder="e.g. John Doe" readonly
                  value="<?= $userName ?>">
              </div>
              <div class="mb-3">
                <label>Income Wallet </label>
                <input type="text" class="form-control" value="<?= $incomeWallet ?>" readonly>
              </div>

              <div class="mb-3">
                <label>Withdraw Amount ( Minimum <i class="fa fa-inr"></i> <?= $minimumWithdraw ?> ) * </label>
                <input type="number" name="withdrawAmount" class="form-control" placeholder="Enter Withdraw Amount"
                  required onkeypress="return onlynum(event)">
              </div>
              <div class="mb-3">
                <label>Transaction Password *</label>
                <input type="password" name="trnPassword" class="form-control" placeholder="e.g. Transaction Password"
                  required>
              </div>
              <div class="">
                <button class="btn btn-primary" data-bs-original-title="" title="Withdraw" name="walletWithdraw"
                  value="Withdraw">Withdraw</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-5">
      <div class="col-12">
        <div class="card shadow-sm">
          <div class="card-header bg-light">
            <h5 class="mb-0">Withdraw History</h5>
          </div>
          <div class="card-body">
            <!-- ✅ Scrollable wrapper -->
            <div style="overflow-x: auto; width: 100%;">
              <table class="table table-bordered table-hover table-sm" style="min-width: 800px;">
                <thead class="table-light text-center">
                  <tr>
                    <th>#</th>
                    <th>User Id</th>
                    <th>Gross Amount</th>
                    <th>Charge</th>
                    <th>Net Amount</th>
                    <th>OrderId</th>
                    <th>Bank Details</th>
                    <th>Date</th>
                    <th>Withdraw Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $count = 0;
                  $queryWithdraw = mysqli_query($con, "SELECT a.*,b.name,b.user_id,c.bank,c.branch,c.ifsc,c.accNo,c.accName,c.bank FROM meddolic_user_wallet_withdrawal_crypto a, meddolic_user_details b, meddolic_user_bank_details c WHERE a.member_id='$memberId' AND a.member_id=b.member_id AND a.member_id=c.memberId  ORDER BY a.date_time DESC");
                  while ($valWithdraw = mysqli_fetch_assoc($queryWithdraw)) {
                    $count++; ?>
                    <tr>
                      <td><?= $count ?></td>
                      <td><?= $valWithdraw['user_id'] ?></td>
                      <td><span class="badge bg-success"><i class="fa fa-inr"></i> <?= $valWithdraw['amount'] ?></span>
                      </td>
                      <td><span class="badge bg-success"><i class="fa fa-inr"></i>
                          <?= $valWithdraw['withdrawCharge'] ?></span></td>
                      <td><span class="badge bg-danger"><i class="fa fa-inr"></i> <?= $valWithdraw['netAmount'] ?></span>
                      </td>
                      <td><?= $valWithdraw['orderid'] ?></td>
                      <td>
                        <div><strong>Bank:</strong> <?= $valWithdraw['bank'] ?></div>
                        <div><strong>Branch:</strong> <?= $valWithdraw['branch'] ?></div>
                        <div><strong>IFSC:</strong> <?= $valWithdraw['ifsc'] ?></div>
                        <div><strong>Acc No:</strong> <?= $valWithdraw['accNo'] ?></div>
                        <div><strong>Acc Name:</strong> <?= $valWithdraw['accName'] ?></div>
                      </td>
                      <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valWithdraw['date_time'])) ?>
                      </td>
                      <td>
                        <?php if ($valWithdraw['released'] == 0)
                          echo "<span class='badge bg-primary'>PROCESSING</span>";
                        else if ($valWithdraw['released'] == 1)
                          echo "<span class='badge bg-success'>RELEASED</span>";
                        else if ($valWithdraw['released'] == 3)
                          echo "<span class='badge bg-danger'>REJECTED</span>";
                        else if ($valWithdraw['released'] == 2)
                          echo "<span class='badge bg-danger'>PENDING</span>";
                        else if ($valWithdraw['released'] == 4)
                          echo "<span class='badge bg-warning'>PROCESSING</span>"; ?>
                      </td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <!-- End Scrollable wrapper -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php require_once('Include/Footer.php')
  ?>