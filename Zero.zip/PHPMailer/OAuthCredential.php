<?php
	define('EmailCode','');
	define('addCode','');
	define('mailerName','Zero Problem Wellness');
	define('smtpServer','smtp.gmail.com');
	define('smtpPort','587'); ?>