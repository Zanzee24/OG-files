<?php
error_reporting(E_ALL);
session_start();
date_default_timezone_set('Asia/Kolkata');
$con=mysqli_connect("localhost","root","","testbilglobal");
if (mysqli_connect_errno()){
	echo "Failed to connect to mysqli: " . mysqli_connect_error();
}
?>