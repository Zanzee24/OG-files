<?php
session_start();
require_once('conection.php');


unset($_SESSION['tokenSet']);
$randToken = rand(1111, 9999) . time() . date('s');
$newToken = md5($randToken);
$_SESSION['tokenSet'] = $newToken; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bit Global - Registration</title>

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="./User/assets/img/favicon/favicon.png">
  <link href="User/assets/css/app.min.css" rel="stylesheet" type="text/css">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">

  <style>
    /* Background Video */
    /* Reset + base */
    * {
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0;
      padding: 0;
      min-height: 100%;
      font-family: 'Montserrat', sans-serif;
      overflow-x: hidden;
    }

    /* Background video */
    .video-bg {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center;
      z-index: -1;
    }

    /* Flex container */
    .container {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      /* flexible, doesn’t crop */
      padding: 20px;
    }

    /* Glass box */
    .login-box {
      width: 100%;
      max-width: 420px;
      margin: 0 auto;
      /* ensure it’s centered in its container */
      background: rgba(255, 255, 255, 0.07);
      backdrop-filter: blur(12px);
      border-radius: 15px;
      padding: 25px;
      box-shadow: 0 0 25px rgba(255, 165, 0, 0.3);
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: white;
    }

    /* Logo */
    .logo img {
      max-width: 180px;
      width: 100%;
      height: auto;
      display: inline-block;
      /* margin: 0 auto 15px auto; */
    }

    .logo {
      display: block;
      /* flex not needed here */
      text-align: center;
      /* center the inner <a> */
      margin-bottom: 15px;
    }

    /* Text */
    .login-box p {
      text-align: center;
      margin-bottom: 20px;
      font-size: 15px;
      line-height: 1.4;
    }

    /* Form inputs */
    .form-control {
      width: 100%;
      background: rgba(255, 255, 255, 0.12) !important;
      border: none;
      color: #fff !important;
      padding: 12px;
      border-radius: 8px;
      font-size: 14px;
    }

    .form-control:focus {
      outline: none;
      box-shadow: 0 0 8px rgba(255, 165, 0, 0.4);
    }

    .form-control::placeholder {
      color: rgba(255, 255, 255, 0.6);
    }

    /* Input group */
    .input-group-text {
      background: rgba(255, 255, 255, 0.12);
      border: none;
      color: #fff;
      border-radius: 0 8px 8px 0;
      cursor: pointer;
    }

    /* Button */
    .btn-submit {
      width: 100%;
      padding: 12px;
      margin-top: 10px;
      background: linear-gradient(45deg, #F0B71F, #FE723F);
      border: none;
      color: white;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      transition: 0.3s ease;
    }

    .btn-submit:hover {
      box-shadow: 0 5px 15px rgba(254, 114, 63, 0.5);
      transform: translateY(-2px);
    }

    /* Footer link */
    .login-link {
      text-align: center;
      margin-top: 15px;
      font-size: 14px;
    }

    .login-link a {
      color: #F0B71F;
      text-decoration: none;
    }

    .login-link a:hover {
      text-decoration: underline;
    }

    /* ✅ Mobile adjustments */
    @media (max-width: 480px) {
      .login-box {
        padding: 20px 15px;
        max-width: 100%;
      }

      .login-box p {
        font-size: 13px;
      }

      .btn-submit {
        font-size: 14px;
        padding: 10px;
      }

      .form-control {
        font-size: 13px;
        padding: 10px;
      }

      .logo img {
        max-width: 140px;
        margin-bottom: 12px;
      }
    }

    

    /* Dark dropdown for country */
    #M_COUNTRY {
      background: rgba(30, 30, 30, 0.9) !important;
      /* dark bg */
      color: #f1f1f1 !important;
      /* light text */
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      padding: 12px;
      font-size: 14px;
      appearance: none;
      /* remove native OS dropdown arrow */
      -webkit-appearance: none;
      -moz-appearance: none;
      background-image: url("data:image/svg+xml;utf8,<svg fill='white' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/></svg>");
      background-repeat: no-repeat;
      background-position: right 10px center;
      background-size: 16px;
    }

    /* Dropdown options */
    #M_COUNTRY option {
      background: #1e1e1e;
      color: #f1f1f1;
    }

    /* Mobile number input group */
    .form-input {
      display: flex;
      align-items: center;
      background: rgba(255, 255, 255, 0.12);
      border-radius: 8px;
      overflow: hidden;
    }

    #phoneCode {
      background: rgba(255, 255, 255, 0.15);
      color: #fff;
      border: none;
      padding: 12px;
      min-width: 60px;
      text-align: center;
      font-weight: 600;
      border-right: 1px solid rgba(255, 255, 255, 0.2);
    }



    /* Wrapper looks like one input */
    .phone-wrapper {
      display: flex;
      align-items: center;
      background: rgba(30, 30, 30, 0.9);
      border: 1px solid rgba(255, 255, 255, 0.2);
      border-radius: 8px;
      overflow: hidden;
    }

    /* Country code prefix */
    #phoneCode {
      background: rgba(255, 255, 255, 0.15);
      color: #fff;
      padding: 12px 16px;
      font-size: 14px;
      font-weight: 600;
      border-right: 1px solid rgba(255, 255, 255, 0.2);
      min-width: 65px;
      text-align: center;
    }

    /* Phone number input */
    #MobPhone {
      flex: 1;
      border: none;
      outline: none;
      background: transparent;
      color: #fff;
      padding: 12px;
      font-size: 14px;
    }

    #MobPhone::placeholder {
      color: rgba(255, 255, 255, 0.6);
    }
  </style>
</head>

<body>

  <!-- Background video -->
  <video class="video-bg" loop autoplay muted playsinline>
    <source src="../assets/img/lo-bg.mp4" type="video/mp4">
  </video>

  <div class="container">
    <div class="login-box">
      <div class="logo text-center">
        <a href="index.php"><img src="./User/assets/img/logo/whitelogo.png" alt="Zanthium Logo"></a>
      </div>

      <p>Create your BitGlobal account</p>

      <form method="post" action="authRegisterProcess.php">

        <?php
        if (!empty($_GET['affiliateCode'])) {
          $query1 = "SELECT name FROM meddolic_user_details WHERE user_id='" . mysqli_real_escape_string($con, $_GET['affiliateCode']) . "'";
          $result1 = mysqli_query($con, $query1);
          $val1 = mysqli_fetch_assoc($result1);
          $sponser_name = $val1['name'];
        ?>
          <div class="form-group">
            <!--<label for="sponser_id">Sponsor ID</label>-->
            <input class="form-control" name="sponser_id1" disabled value="<?= htmlspecialchars($_GET['affiliateCode']) ?>">
            <input type="hidden" name="sponser_id" value="<?= htmlspecialchars($_GET['affiliateCode']) ?>">
          </div>
          <div class="form-group">
            <!--<label for="sponsorName">Sponsor Name :</label>-->
            <input class="form-control mt-2" disabled value="<?= htmlspecialchars($sponser_name) ?>" placeholder="Sponsor Name">
          </div>
        <?php } else { ?>
          <div class="form-group">
            <!--<label for="sponser_id">Sponsor ID :</label>-->
            <input class="form-control" name="sponser_id" required id="sponser_id" onblur="sponserNewValid(this.value)"
              placeholder="Enter Sponsor ID">
          </div>
          <div class="form-group">
            <!--<label for="sponsorName">Sponsor Name</label>-->
            <input class="form-control mt-2" readonly disabled id="sponsorName" placeholder="Sponsor Name">
          </div>
        <?php } ?>


        <div class="form-group mb-3 mt-3">
          <input type="text" name="username" class="form-control" placeholder="Full Name" required>
          <input type="hidden" name="goodFile" value="<?= $newToken ?>">
        </div>

        <div class="form-group mb-3">
          <input type="email" name="email" class="form-control" placeholder="Email Address" required>
        </div>



        <div class="form-group mb-3">
          <select class="form-control" required id="M_COUNTRY" name="countryId">
            <option value="">Select Country</option>
            <?php $queryCountry = "SELECT * FROM meddolic_config_country_list WHERE status=1 ORDER BY countryName ASC";
            $resultCountry = mysqli_query($con, $queryCountry);
            while ($valCountry = mysqli_fetch_assoc($resultCountry)) { ?>
              <option value="<?= $valCountry['country_id'] ?>"
                data-phone-code="<?= $valCountry['country_code'] ?>">
                <?= $valCountry['countryName'] ?>
              </option>
            <?php } ?>
          </select>
        </div>



        <div class="form-group mb-3">
          <div class="phone-wrapper">
            <span id="phoneCode">+--</span>
            <input type="text" id="MobPhone" name="phone" placeholder="Enter mobile number" required>
          </div>
        </div>

        <div class="form-group mb-3">
          <div class="input-group">
            <input type="text" name="password" class="form-control" placeholder="Password" required>
          </div>
        </div>


        <button type="submit" name="submitRegister" class="btn-submit">Sign Up</button>

        <div class="login-link">
          Already have an account? <a href=" 
          auth.php">Login Now</a>
        </div>
      </form>
    </div>
  </div>


  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const countrySelect = document.getElementById('M_COUNTRY');
      const phoneCodeSpan = document.getElementById('phoneCode');
      const phoneInput = document.querySelector('input[name="phone"]');

      countrySelect.addEventListener('change', function() {
        const selectedCountry = countrySelect.options[countrySelect.selectedIndex];
        const countryPhoneCode = selectedCountry.getAttribute('data-phone-code');
        phoneCodeSpan.textContent = '+' + countryPhoneCode;
      });
    });
  </script>

  <script>
    function togglePasswordVisibility() {
      var passwordInput = document.getElementById("inputPassword");
      var eyeIcon = document.getElementById("eyeIcon");
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
      } else {
        passwordInput.type = "password";
        eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
      }
    }

    function toggleConfirmPasswordVisibility() {
      var passwordInput = document.getElementById("confirmPassword");
      var eyeIcon = document.getElementById("eyeIconConfirm");
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
      } else {
        passwordInput.type = "password";
        eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
      }
    }
  </script>


  <script>
    function sponserNewValid(sponser_id) {
      document.getElementById("sponsorName").value = "";
      if (sponser_id != "") {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            let res = xmlhttp.responseText.trim();
            if (res !== "") {
              document.getElementById("sponsorName").value = res;
            } else {
              alert("Invalid Sponsor ID");
              document.getElementById("sponser_id").value = "";
            }
          }
        }
        xmlhttp.open("GET", "getSponserNameAjax?sponserId=" + sponser_id, true);
        xmlhttp.send();
      }
    }
  </script>

</body>

</html>