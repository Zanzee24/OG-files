<?php
	define('EmailCode','');
	define('addCode','');
	define('mailerName','Zanthium');
	define('smtpServer','smtp.gmail.com');
	define('smtpPort','587'); ?>


