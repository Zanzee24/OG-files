<br><br><br>
<center>
<h2>Processing your request!!!</h2>
<h3>Please do not press back or refresh!!!</h3>
</center>
<?php
use PHPMailer\PHPMailer\PHPMailer;
require_once("conection.php");

if (isset($_POST['submitRegister'])) {

    $newToken = $_SESSION['tokenSet'];
    $goodFile = mysqli_real_escape_string($con, $_POST['goodFile']);
    if ($goodFile == $newToken) {
        $name = mysqli_real_escape_string($con, $_POST['username']);
        $sponser_id = mysqli_real_escape_string($con, $_POST['sponser_id']);
        $emailId = mysqli_real_escape_string($con, $_POST['email']);
        $phone = mysqli_real_escape_string($con, $_POST['phone']);
        $countryId = mysqli_real_escape_string($con, $_POST['countryId']);
          $loginPassword = mysqli_real_escape_string($con, $_POST['password']);
        // $trnPassword = mysqli_real_escape_string($con, $_POST['trnPassword']);


        $d = date("Y-m-d H:i:s");
        $dt = date("Y-m-d");
        $queryCheck = mysqli_query($con, "SELECT * FROM meddolic_user_details WHERE user_id='$sponser_id' AND account_status=1");
        if (!mysqli_num_rows($queryCheck)) { ?>
            <script>
                alert("Invalid / Suspended Sponser Id!!!");
                history.go(-1);
            </script>
        <?php
            exit;
        }
        $querySponser = mysqli_query($con, "SELECT member_id from meddolic_user_details where user_id='$sponser_id'");
        $valSponser = mysqli_fetch_array($querySponser);
        $sponser_member_id = $valSponser[0];

        function trnPassword( $length = 6 ) {
            $chars = "0123456789";
            $password = substr( str_shuffle( $chars ), 0, $length );
            return $password;
        }
        // $loginPassword=trnPassword(6);
        $trnPassword=trnPassword (6);

    
        $queryInsert = mysqli_query($con, "INSERT INTO meddolic_user_details (`name`,`email_id`,`phone`,`password`,`trnPassword`,`sponser_id`,`date_time`,`countryId`) VALUES ('$name','$emailId','$phone','$loginPassword','$trnPassword','$sponser_member_id','$d','$countryId')");
        $used_member_id = $con->insert_id;

        $newMember = base64_encode($used_member_id);
        $newMd = md5($used_member_id);
        $newSha = sha1($used_member_id);

        $_SESSION['newDevineToken'] = $used_member_id;
        $_SESSION['newAdvineToken'] = $newSha;
        $_SESSION['ngDefine'] = $newMd;

        function userIdSet($con, $used_member_id, $name, $loginPassword, $d, $emailId, $trnPassword)
        {
            require_once "PHPMailer/PHPMailer.php";
            require_once "PHPMailer/SMTP.php";
            require_once "PHPMailer/Exception.php";
            require_once "PHPMailer/OAuthCredential.php";
            $user_id = "ZT" . rand(11, 99) . rand(111, 999);
            $queryExist = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE user_id='$user_id'");
            $valExist = mysqli_fetch_array($queryExist);
            if ($valExist[0] == 0) {
                mysqli_query($con, "UPDATE meddolic_user_details SET user_id='$user_id' WHERE member_id='$used_member_id'");
                $mailSubject = "Zanthium Details";
                $newMsg = '<html>
                        <head>
                            <title>Zanthium Details</title>
                            <link href="https://svc.webspellchecker.net/spellcheck31/lf/scayt3/ckscayt/css/wsc.css" rel="stylesheet" type="text/css" />
                        </head>
                        <body><span style="background-color:#ffffff; color:#222222; font-family:arial,helvetica,sans-serif; font-size:small">Dear Member,&nbsp;</span><span style="color:#ff0000"><span style="font-family:comic sans ms,cursive"><span style="font-size:small"><strong>' . $name . '</strong></span></span></span><span style="background-color:#ffffff; color:#222222; font-family:arial,helvetica,sans-serif; font-size:small">,&nbsp;<br />
                        <br />While Register account with <em><span style="font-size:14px"><strong>Bit Global </strong></span></em>, you have accepted the terms of the Public Offer Agreement. This electronic agreement has the same legal effect, sets the same rights and obligations as a normal agreement signed by the two parties.</span>
                        <br />
                        <span style="background-color:#ffffff; color:#222222; font-family:arial,helvetica,sans-serif; font-size:small"><em><strong><span style="font-size:14px">Xtrem </span></strong></em> has registered a account on your name. Below are its access details<br /><br />
                        <strong>AffiliateId</strong>  <strong>' . $user_id . '</strong></span><br />
                        <span style="color:#FF8C00"><span style="background-color:rgb(255, 255, 255); font-family:arial,helvetica,sans-serif; font-size:small"><strong>Login Password</strong></span></span><span style="background-color:rgb(255, 255, 255); color:rgb(34, 34, 34); font-family:arial,helvetica,sans-serif; font-size:small">  <em>' . $loginPassword . '</em></span><br />
                        <span style="color:#FF8C00"><span style="background-color:rgb(255, 255, 255); font-family:arial,helvetica,sans-serif; font-size:small"><strong>Transaction Password -: </strong></span></span><span style="background-color:rgb(255, 255, 255); color:rgb(34, 34, 34); font-family:arial,helvetica,sans-serif; font-size:small">  <em>' . $trnPassword . '</em></span><br />                        
                        <br />Much appreciated and Respect:</span><br />
                        <span style="font-family:georgia,serif"><span style="background-color:rgb(255, 255, 255); font-size:small"><strong>Bit Global TEAM</strong></span></span><span style="background-color:rgb(255, 255, 255); color:rgb(34, 34, 34); font-family:arial,helvetica,sans-serif; font-size:small">.</span></body></html>';
                $mail = new PHPMailer();
                $mail->isSMTP();
                $mail->SMTPDebug = 4;  //Keep It commented this is used for debugging                          
                $mail->Host = smtpServer; // smtp address of your email
                $mail->SMTPAuth = true;
                $mail->Username = EmailCode;
                $mail->Password = addCode;
                $mail->Port = smtpPort;
                $mail->SMTPSecure = "tls";
                $mail->smtpConnect([
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    ]
                ]);

                //Email Settings
                $mail->isHTML(true);
                $mail->setFrom(EmailCode, mailerName);
                $mail->addAddress($emailId); // enter email address whom you want to send
                $mail->Subject = ("$mailSubject");
                $mail->Body = $newMsg;
                $mail->send();
            } else {
                userIdSet($con, $used_member_id, $name, $loginPassword, $d, $emailId, $trnPassword);
            }
        }
        userIdSet($con, $used_member_id, $name, $loginPassword, $d, $emailId, $trnPassword);

        //Joining Code Ends//    

        //Child ID Code Starts//
        $queryChild = mysqli_query($con, "SELECT sponser_id,date_time FROM meddolic_user_details WHERE member_id='$used_member_id'");
        $valChild = mysqli_fetch_array($queryChild);
        $parent_id = $valChild[0];
        $date_time = $valChild[1];
        $level = 1;
        while ($parent_id) {
            mysqli_query($con, "INSERT INTO meddolic_user_child_ids (`member_id`,`child_id`,`level`,`date_time`) VALUES ('$parent_id','$used_member_id','$level','$date_time')");

            $queryUser = mysqli_query($con, "SELECT sponser_id FROM meddolic_user_details WHERE member_id='$parent_id'");
            $valUser = mysqli_fetch_array($queryUser);
            $parent_id = $valUser[0];
            $level++;
        }
        //Child ID Code Ends//

        unset($_SESSION['tokenSet']); ?>
        <script>
            window.top.location.href = "authRegisterSuccess?BorCool=<?= $newMd ?>&glowCoco=<?= $newMember ?>&kriNote=<?= $newSha ?>";
        </script>
    <?php } else { ?>
        <script>
            alert('Your Session Expired.Please re Submit your form Again');
            history.go(-1);
        </script>
<?php }
} ?>
<?php require("close-connection.php"); ?>