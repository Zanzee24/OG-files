<?php require('conection.php');  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="dark" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Favicon icon-->
  <link rel="shortcut icon" type="image/png" href="User/assets/assets/images/logos/favicon.png" />

  <!-- Core Css -->
  <link rel="stylesheet" href="User/assets/assets/css/styles.css" />
  <title>MaterialM Bootstrap Admin</title>
</head>

    <style>
        :root {
            --primary-color: #FE723F;
            --secondary-color: #F0B71F;
            --dark-bg: #181818;
            --light-text: #ffffff;
            --success-color: #4CAF50;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: var(--dark-bg);
            color: var(--light-text);
            min-height: 100vh;
            overflow-x: hidden;
        }
        
        .video-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
            opacity: 0.5;
        }
        
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login_box {
            background: rgba(0, 0, 0, 0.85);
            border-radius: 15px;
            padding: 40px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(254, 114, 63, 0.3);
            text-align: center;
            animation: fadeIn 0.5s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .logo {
            margin-bottom: 25px;
        }
        
        .logo img {
            max-width: 180px;
            height: auto;
        }
        
        .success-header {
            color: var(--light-text);
            margin-bottom: 25px;
        }
        
        .success-header .icon {
            font-size: 80px;
            color: var(--success-color);
            margin-bottom: 15px;
            animation: bounce 1s;
        }
        
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-20px); }
            60% { transform: translateY(-10px); }
        }
        
        .success-header h2 {
            font-size: 24px;
            margin-bottom: 10px;
            color: var(--secondary-color);
            font-weight: 600;
        }
        
        .success-header p {
            margin-bottom: 0;
            font-size: 16px;
            opacity: 0.9;
        }
        
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        
        .col-form-label {
            display: block;
            font-weight: 500;
            color: var(--secondary-color);
            margin-bottom: 8px;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            color: white;
            font-family: 'Orbitron', sans-serif;
            transition: all 0.3s;
        }
        
        .form-control:disabled {
            opacity: 0.8;
            cursor: not-allowed;
        }
        
        .or {
            color: rgba(255, 255, 255, 0.6) !important;
            margin: 25px 0 15px;
            text-align: center;
            font-size: 14px;
            position: relative;
        }
        
        .or:before,
        .or:after {
            content: "";
            display: inline-block;
            width: 30%;
            height: 1px;
            background: rgba(255, 255, 255, 0.2);
            position: absolute;
            top: 50%;
        }
        
        .or:before {
            left: 0;
        }
        
        .or:after {
            right: 0;
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-center a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .text-center a:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }
        
        .btn-login {
            margin-top: 25px;
        }
        
        .signin-link {
            background: linear-gradient(45deg, var(--secondary-color), var(--primary-color));
            color: white;
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-block;
        }
        
        .signin-link:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(254, 114, 63, 0.4);
        }
        
        @media (max-width: 576px) {
            .login_box {
                padding: 30px 20px;
            }
            
            .success-header .icon {
                font-size: 60px;
            }
            
            .success-header h2 {
                font-size: 20px;
            }
            
            .or:before,
            .or:after {
                width: 25%;
            }
        }
    </style>
<?php
  $newMember=$_GET['glowCoco'];
 $glowCoco=base64_decode($newMember);
  $queryNew=mysqli_query($con,"SELECT name,phone,sponser_id,password,trnPassword,user_id,password,trnPassword FROM meddolic_user_details WHERE member_id='$_SESSION[newDevineToken]' AND user_type=2");
 $valNew=mysqli_fetch_assoc($queryNew);
 $newName=$valNew['name'];
  $phone=$valNew['phone'];
  $newUserId=$valNew['user_id'];
   $password=$valNew['password'];
   $trnPassword=$valNew['trnPassword'];
  $sponser_id=$valNew['sponser_id'];?>
<body>
  <!-- Preloader -->
  <div class="preloader">
    <img src="User/assets/assets/images/logos/favicon.png" alt="loader" class="lds-ripple img-fluid" />
  </div>
  <div id="main-wrapper">
    <div class="position-relative overflow-hidden radial-gradient min-vh-100 w-100 d-flex align-items-center justify-content-center">
      <div class="d-flex align-items-center justify-content-center w-100">
        <div class="row justify-content-center w-100">
          <div class="col-md-8 col-lg-6 col-xxl-3">
            <div class="card mb-0 bg-body">
              <div class="card-body">
                <a href="User" class="text-nowrap logo-img text-center d-block mb-5 w-100">
                  <img src="User/assets/assets/images/logos/logo-icon.png" class="dark-logo" alt="Logo-Dark" />
                </a>
                <h2>Registration Successful!</h2>
                <p>Your account has been created successfully. Please save your credentials.</p>
               
                <div class="position-relative text-center my-4">
                  <p class="mb-0 fs-4 px-3 d-inline-block bg-body z-index-5 position-relative"></p>
                  <span class="border-top w-100 position-absolute top-50 start-50 translate-middle"></span>
                </div>
                <form>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">User ID</label>
                     <input class="form-control" value="<?= $newUserId ?>" disabled>
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Name</label>
                    <input class="form-control" value="<?= $newName ?>" disabled>
                  </div>
                 
                  <div class="mb-4">
                    <label for="exampleInputPassword1" class="form-label">Login Password</label>
                        <input class="form-control" value="<?= $password ?>" disabled>
                  </div>
                  <div class="mb-4">
                    <label for="exampleInputPassword1" class="form-label">Transaction Password</label>
                        <input class="form-control" value="<?= $trnPassword ?>" disabled>
                  </div>
                  <a href="User" class="btn btn-primary w-100 py-8 mb-4 rounded-2">Back</a>
                 
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="dark-transparent sidebartoggler"></div>
   <script>
        // Star animation script
        document.addEventListener('DOMContentLoaded', function () {
            const container = document.getElementById('stars-container');
            const starCount = 100;

            for (let i = 0; i < starCount; i++) {
                const star = document.createElement('div');
                star.classList.add('star');

                // Random size between 1px and 3px
                const size = Math.random() * 2 + 1;
                star.style.width = `${size}px`;
                star.style.height = `${size}px`;

                // Random position
                star.style.left = `${Math.random() * 100}%`;
                star.style.top = `${Math.random() * 100}%`;

                // Random animation duration between 10s and 20s
                const duration = Math.random() * 10 + 10;
                star.style.animationDuration = `${duration}s`;

                // Random delay
                star.style.animationDelay = `${Math.random() * 10}s`;

                container.appendChild(star);
            }
        });

        function sponserNewValid(sponser_id) {
            document.getElementById("sponsorName").value = "";
            if (!sponser_id == "") {
                if (window.XMLHttpRequest) {
                    xmlhttp = new XMLHttpRequest();
                }
                else {
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                }
                xmlhttp.onreadystatechange = function () {
                    if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                        var v = xmlhttp.responseText;
                        if (v.trim() != "") {
                            document.getElementById("sponsorName").value = v.trim();
                        } else {
                            alert("Invalid Sponser ID");
                            document.getElementById("sponser_id").value = "";
                        }
                    }
                }
                xmlhttp.open("GET", "getSponserNameAjax?sponserId=" + sponser_id, true);
                xmlhttp.send();
            }
        }
    </script>
  <!-- Import Js Files -->
  <script src="User/assets/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="User/assets/assets/libs/simplebar/dist/simplebar.min.js"></script>
  <script src="User/assets/assets/js/theme/app.dark.init.js"></script>
  <script src="User/assets/assets/js/theme/theme.js"></script>
  <script src="User/assets/assets/js/theme/app.min.js"></script>

  <!-- solar icons -->
  <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
</body>

</html>