<div class="page-wrapper">
  <!--  Header Start -->
  <header class="topbar">
    <div class="with-vertical"><!-- ---------------------------------- -->
      <!-- Start Vertical Layout Header -->
      <!-- ---------------------------------- -->
      <nav class="navbar navbar-expand-lg p-0">
        <ul class="navbar-nav">
          <li class="nav-item nav-icon-hover ms-n3">
            <a class="nav-link sidebartoggler" id="headerCollapse" href="javascript:void(0)">
              <iconify-icon icon="solar:hamburger-menu-line-duotone" class="fs-7"></iconify-icon>
            </a>
          </li>
          <li class="nav-item nav-icon-hover d-none d-lg-block dropdown">
            <div class="hover-dd">
              <a class="nav-link" id="drop2" href="javascript:void(0)" aria-haspopup="true" aria-expanded="false">
                <iconify-icon icon="solar:widget-3-line-duotone" class="fs-6"></iconify-icon>
              </a>
              <div class="dropdown-menu dropdown-menu-nav  dropdown-menu-animate-up" aria-labelledby="drop2">
                <div class="row">
                  <div class="col-8">
                    <div class="ps-3 pt-3">
                      <div class="border-bottom">
                        <div class="row">
                          <div class="col-12">
                            <div class="card bg-primary-gt text-white overflow-hidden shadow-none">
                              <div class="card-body position-relative z-1">
                                <div class="row justify-content-between align-items-center">
                                  <div class="col-sm-6">
                                    <h5 class="fw-semibold mb-9 fs-5 text-white">Welcome back David!</h5>
                                    <p class="mb-9 opacity-75">
                                      You have earned 54% more than last month
                                      which is great thing.
                                    </p>
                                    <button type="button" class="btn btn-danger">Check</button>
                                  </div>
                                  <div class="col-sm-5">
                                    <div class="position-relative mb-n7 text-end">
                                      <img src="assets/assets/images/backgrounds/welcome-bg2.png" alt="materialm-img" class="img-fluid">
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                        </div>
                      </div>
                      <div class="row align-items-center py-3">
                        <div class="col-8">
                          <a class="fw-semibold text-dark d-flex align-items-center lh-1 bg-hover-primary" href="">
                            <i class="ti ti-help fs-6 me-2"></i>Frequently Asked Questions
                          </a>
                        </div>
                        <div class="col-4">
                          <div class="d-flex justify-content-end pe-4">
                            <button class="btn btn-primary rounded-pill">Check</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-4 ms-n4">
                    <div class="position-relative p-3 border-start h-100">
                      <h5 class="fs-5 mb-9 fw-semibold">Quick Links</h5>
                      <ul>
                        <li class="mb-3">
                          <a class="fw-semibold bg-hover-primary" href="">Pricing Page</a>
                        </li>

                        <li class="mb-3">
                          <a class="fw-semibold bg-hover-primary" href="">Account Settings</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </li>
        </ul>

        <div class="d-block d-lg-none">
          <img src="assets/assets/images/logos/dark-logo.png" class="dark-logo" width="50" alt="Zanthium-img" />
          <img src="assets/assets/images/logos/light-logo.png" class="light-logo" width="50" alt="Zanthium-img" />
        </div>
        <a class="navbar-toggler p-0 border-0 nav-icon-hover" href="javascript:void(0)" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="p-2">
            <i class="fa-solid fa-ellipsis"></i>
          </span>
        </a>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
          <div class="d-flex align-items-center justify-content-between">
            <ul class="navbar-nav flex-row mx-auto ms-lg-auto align-items-center justify-content-center">


              <li class="nav-item nav-icon-hover">
                <a class="nav-link moon dark-layout" href="javascript:void(0)">
                  <iconify-icon icon="solar:moon-line-duotone" class="moon fs-6"></iconify-icon>
                </a>
                <a class="nav-link sun light-layout" href="javascript:void(0)">
                  <iconify-icon icon="solar:sun-2-line-duotone" class="sun fs-6"></iconify-icon>
                </a>
              </li>

              <!-- ------------------------------- -->


              <!-- ------------------------------- -->
              <!-- start profile Dropdown -->
              <!-- ------------------------------- -->
              <li class="nav-item dropdown">
                <a class="nav-link" href="javascript:void(0)" id="drop1" aria-expanded="false">
                  <div class="d-flex align-items-center gap-2 lh-base">
                    <img src="assets/assets/images/profile/user-1.jpg" class="rounded-circle" width="35" height="35" alt="Zanthium-img" />
                  </div>
                </a>
                <div class="dropdown-menu content-dd dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop1">
                  <div class="profile-dropdown position-relative" data-simplebar>
                    <div class="py-3 px-7 pb-0">
                      <h5 class="mb-0 fs-5 fw-semibold">User Profile</h5>
                    </div>
                    <div class="d-flex align-items-center py-9 mx-7 border-bottom">
                      <img src="assets/assets/images/profile/user-1.jpg" class="rounded-circle" width="80" height="80" alt="Zanthium-img" />
                      <div class="ms-3">
                        <h5 class="mb-0 fs-4">Jonathan Deo</h5>
                        <span class="mb-1 d-block">Admin</span>
                        <p class="mb-0 d-flex align-items-center gap-2">
                          <i class="ti ti-mail fs-4"></i> info@Zanthium.com
                        </p>
                      </div>
                    </div>
                    <div class="message-body">
                      <a href="profile" class="py-8 px-7 mt-8 d-flex align-items-center">
                        <span class="d-flex align-items-center justify-content-center bg-primary-subtle text-primary rounded round">
                          <iconify-icon icon="solar:wallet-2-line-duotone" class="fs-7"></iconify-icon>
                        </span>
                        <div class="w-75 v-middle ps-3">
                          <h5 class="mb-1 fs-3 fw-medium">My Profile</h5>
                          <span class="fs-2 d-block text-body-secondary">Account Settings</span>
                        </div>
                      </a>


                    </div>
                    <div class="d-grid py-4 px-7 pt-8">
                      <a href="auth" class="btn btn-primary">Log Out</a>
                    </div>
                  </div>
                </div>
              </li>
              <!-- ------------------------------- -->
              <!-- end profile Dropdown -->
              <!-- ------------------------------- -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- ---------------------------------- -->
      <!-- End Vertical Layout Header -->
      <!-- ---------------------------------- -->

      <!-- ------------------------------- -->
      <!-- apps Dropdown in Small screen -->
      <!-- ------------------------------- -->

    </div>
    <div class="app-header with-horizontal">
      <nav class="navbar navbar-expand-xl container-fluid p-0">
        <ul class="navbar-nav">

          <li class="nav-item d-none d-xl-block">
            <a href=".." class="text-nowrap nav-link">
              <img src="assets/assets/images/logos/dark-logo.png" class="dark-logo" width="180" alt="Zanthium-img" />
              <img src="assets/assets/images/logos/light-logo.png" class="light-logo" width="180" alt="Zanthium-img" />
            </a>
          </li>
          <li class="nav-item nav-icon-hover d-none d-lg-block dropdown">
            <div class="hover-dd">
              <a class="nav-link" id="drop2" href="javascript:void(0)" aria-haspopup="true" aria-expanded="false">
                <iconify-icon icon="solar:widget-3-line-duotone" class="fs-6"></iconify-icon>
              </a>

            </div>
          </li>

        </ul>
        <div class="d-block d-xl-none">
          <a href=".." class="text-nowrap nav-link">
            <img src="assets/assets/images/logos/dark-logo.png" width="180" alt="Zanthium-img" />
          </a>
        </div>
        <a class="navbar-toggler nav-icon-hover p-0 border-0" href="javascript:void(0)" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="p-2">
            <i class="ti ti-dots fs-7"></i>
          </span>
        </a>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
          <div class="d-flex align-items-center justify-content-between px-0 px-xl-8">
            <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-center">


              <!-- ------------------------------- -->
              <!-- start message Dropdown -->

              <!-- ------------------------------- -->
              <!-- start profile Dropdown -->
              <!-- ------------------------------- -->
              <li class="nav-item dropdown">
                <a class="nav-link" href="javascript:void(0)" id="drop1" data-bs-toggle="dropdown" aria-expanded="false">
                  <div class="d-flex align-items-center gap-2 lh-base">
                    <img src="assets/assets/images/profile/user-1.jpg" class="rounded-circle" width="35" height="35" alt="Zanthium-img" />
                  </div>
                </a>
                <div class="dropdown-menu content-dd dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop1">
                  <div class="profile-dropdown position-relative" data-simplebar>
                    <div class="py-3 px-7 pb-0">
                      <h5 class="mb-0 fs-5 fw-semibold">User Profile</h5>
                    </div>
                    <div class="d-flex align-items-center py-9 mx-7 border-bottom">
                      <img src="assets/assets/images/profile/user-1.jpg" class="rounded-circle" width="80" height="80" alt="Zanthium-img" />
                      <div class="ms-3">
                        <h5 class="mb-0 fs-4">Jonathan Deo</h5>
                        <span class="mb-1 d-block">Admin</span>
                        <p class="mb-0 d-flex align-items-center gap-2">
                          <i class="ti ti-mail fs-4"></i> info@Zanthium.com
                        </p>
                      </div>
                    </div>
                    <div class="message-body">
                      <a href="profile" class="py-8 px-7 mt-8 d-flex align-items-center">
                        <span class="d-flex align-items-center justify-content-center bg-primary-subtle text-primary rounded round">
                          <iconify-icon icon="solar:wallet-2-line-duotone" class="fs-7"></iconify-icon>
                        </span>
                        <div class="w-75 v-middle ps-3">
                          <h5 class="mb-1 fs-3 fw-medium">My Profile</h5>
                          <span class="fs-2 d-block text-body-secondary">Account Settings</span>
                        </div>
                      </a>

                    </div>
                    <div class="d-grid py-4 px-7 pt-8">
                      <a href="auth" class="btn btn-primary">Log Out</a>
                    </div>
                  </div>
                </div>
              </li>
              <!-- ------------------------------- -->
              <!-- end profile Dropdown -->
              <!-- ------------------------------- -->
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>