 <div id="main-wrapper">
     <aside class="side-mini-panel with-vertical">
         <div><!-- ---------------------------------- -->
             <!-- Start Vertical Layout Sidebar -->
             <!-- ---------------------------------- -->
             <div class="iconbar">
                 <div>
                     <div class="mini-nav">
                         <div class="brand-logo d-flex align-items-center justify-content-between justify-content-lg-center">
                             <a href="" class="text-nowrap logo-img">
                                 <img src="assets/assets/images/logos/logo-icon.png" alt="Logo" style="width: 50px;" />
                             </a>
                             <a href="javascript:void(0)" class="sidebartoggler close-btn ms-auto text-decoration-none fs-5 d-flex d-xl-none align-items-center justify-content-center text-danger">
                                 <i class="material-symbols-outlined fs-5">cancel</i>
                             </a>
                         </div>
                         <ul class="mini-nav-ul" data-simplebar>
                             <!-- --------------------------------------------------------------------------------------------------------- -->
                             <!-- Dashboards -->
                             <!-- --------------------------------------------------------------------------------------------------------- -->
                             <li class="mini-nav-item" id="mini-1">
                                 <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Dashboards">
                                     <iconify-icon icon="solar:home-angle-line-duotone" class="fs-7"></iconify-icon>
                                 </a>
                             </li>
                             <!-- --------------------------------------------------------------------------------------------------------- -->
                             <!-- Landingpage -->
                             <!-- --------------------------------------------------------------------------------------------------------- -->
                             <li class="mini-nav-item" id="mini-2">
                                 <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Profiles">
                                     <svg xmlns="http://www.w3.org/2000/svg" class="fs-7" width="28" height="28" viewBox="0 0 24 24">
                                         <g fill="none">
                                             <path fill="currentColor" d="M4 18a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2" opacity="0.16" />
                                             <path stroke="currentColor" stroke-linejoin="round" stroke-width="2" d="M4 18a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2Z" />
                                             <circle cx="12" cy="7" r="3" stroke="currentColor" stroke-width="2" />
                                         </g>
                                     </svg>
                                 </a>
                             </li>
                             <li class="mini-nav-item" id="mini-3">
                                 <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Deposit">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 16 16">
                                         <path fill="currentColor" d="m8 16l-2-3h1v-2h2v2h1zm7-15v8H1V1zm1-1H0v10h16z" />
                                         <path fill="currentColor" d="M8 2a3 3 0 1 1 0 6h5V7h1V3h-1V2zM5 5a3 3 0 0 1 3-3H3v1H2v4h1v1h5a3 3 0 0 1-3-3" />
                                     </svg> </a>
                             </li>
                             <li class="mini-nav-item" id="mini-4">
                                 <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Investment">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24">
                                         <g fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5">
                                             <path d="M19 9.5V8.3c-.008-2.803-.095-4.289-1.033-5.246C16.933 2 15.269 2 11.942 2h-1.883C6.731 2 5.068 2 4.034 3.054S3 5.806 3 9.2v4.6c0 3.394 0 5.091 1.034 6.146c.918.936 2.332 1.04 4.966 1.052" />
                                             <path stroke-linejoin="round" d="M18.675 19.689L21 22m-1-5.5a4.5 4.5 0 1 0-9 0a4.5 4.5 0 0 0 9 0" />
                                             <path d="M7 7h8m-8 4h3" />
                                         </g>
                                     </svg> </a>
                             </li>
                             <li class="mini-nav-item" id="mini-5">
                                 <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Team">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 16 16">
                                         <path fill="currentColor" d="M8 2.002a1.998 1.998 0 1 0 0 3.996a1.998 1.998 0 0 0 0-3.996M12.5 3a1.5 1.5 0 1 0 0 3a1.5 1.5 0 0 0 0-3m-9 0a1.5 1.5 0 1 0 0 3a1.5 1.5 0 0 0 0-3M5 7.993A1 1 0 0 1 6 7h4a1 1 0 0 1 1 1v3a3 3 0 0 1-.146.927A3.001 3.001 0 0 1 5 11zM4 8c0-.365.097-.706.268-1H2a1 1 0 0 0-1 1v2.5a2.5 2.5 0 0 0 3.436 2.319A4 4 0 0 1 4 10.999zm8 0v3c0 .655-.157 1.273-.436 1.819A2.5 2.5 0 0 0 15 10.5V8a1 1 0 0 0-1-1h-2.268c.17.294.268.635.268 1" />
                                     </svg> </a>
                             </li>

                             <li class="mini-nav-item" id="mini-7">
                                 <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Withdrawal">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24">
                                         <g fill="currentColor" fill-rule="evenodd" clip-rule="evenodd">
                                             <path d="M21.1 8.004q-.085-.005-.181-.004h-2.525c-2.068 0-3.837 1.628-3.837 3.75s1.77 3.75 3.837 3.75h2.525q.096.001.182-.004a1.755 1.755 0 0 0 1.645-1.628c.004-.06.004-.125.004-.185V9.817c0-.06 0-.125-.004-.185a1.755 1.755 0 0 0-1.645-1.628m-2.928 4.746c.532 0 .963-.448.963-1s-.431-1-.963-1c-.533 0-.964.448-.964 1s.431 1 .964 1" />
                                             <path d="M20.918 17a.22.22 0 0 1 .221.278c-.2.712-.519 1.32-1.03 1.83c-.749.75-1.698 1.081-2.87 1.239c-1.14.153-2.595.153-4.433.153h-2.112c-1.838 0-3.294 0-4.433-.153c-1.172-.158-2.121-.49-2.87-1.238c-.748-.749-1.08-1.698-1.238-2.87C2 15.099 2 13.644 2 11.806v-.112C2 9.856 2 8.4 2.153 7.26c.158-1.172.49-2.121 1.238-2.87c.749-.748 1.698-1.08 2.87-1.238C7.401 3 8.856 3 10.694 3h2.112c1.838 0 3.294 0 4.433.153c1.172.158 2.121.49 2.87 1.238c.511.512.83 1.119 1.03 1.831a.22.22 0 0 1-.221.278h-2.524c-2.837 0-5.337 2.24-5.337 5.25s2.5 5.25 5.337 5.25zM5.75 7a.75.75 0 0 0 0 1.5h4a.75.75 0 0 0 0-1.5z" />
                                         </g>
                                     </svg> </a>
                             </li>
                             <li class="mini-nav-item" id="mini-8">
                                 <a href="javascript:void(0)" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Support">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24">
                                         <path fill="currentColor" d="M18.72 14.76c.35-.85.54-1.76.54-2.76c0-.72-.11-1.41-.3-2.05c-.65.15-1.33.23-2.04.23A9.07 9.07 0 0 1 9.5 6.34a9.2 9.2 0 0 1-4.73 4.88c-.04.25-.04.52-.04.78A7.27 7.27 0 0 0 12 19.27c1.05 0 2.06-.23 2.97-.64c.57 1.09.83 1.63.81 1.63c-1.64.55-2.91.82-3.78.82c-2.42 0-4.73-.95-6.43-2.66a9 9 0 0 1-2.24-3.69H2v-4.55h1.09a9.09 9.09 0 0 1 15.33-4.6a9 9 0 0 1 2.47 4.6H22v4.55h-.06L18.38 18l-5.3-.6v-1.67h4.83zm-9.45-2.99c.3 0 .59.12.8.34a1.136 1.136 0 0 1 0 1.6c-.21.21-.5.33-.8.33c-.63 0-1.14-.5-1.14-1.13s.51-1.14 1.14-1.14m5.45 0c.63 0 1.13.51 1.13 1.14s-.5 1.13-1.13 1.13s-1.14-.5-1.14-1.13a1.14 1.14 0 0 1 1.14-1.14" />
                                     </svg> </a>
                             </li>
                             <li class="mini-nav-item" id="mini-9">
                                 <a href="auth" data-bs-toggle="tooltip" data-bs-custom-class="custom-tooltip" data-bs-placement="right" data-bs-title="Logout">
                                     <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24">
                                         <path fill="currentColor" d="M15 2h-1c-2.828 0-4.243 0-5.121.879C8 3.757 8 5.172 8 8v8c0 2.828 0 4.243.879 5.121C9.757 22 11.172 22 14 22h1c2.828 0 4.243 0 5.121-.879C21 20.243 21 18.828 21 16V8c0-2.828 0-4.243-.879-5.121C19.243 2 17.828 2 15 2" opacity="0.6" />
                                         <path fill="currentColor" d="M8 8c0-1.538 0-2.657.141-3.5H8c-2.357 0-3.536 0-4.268.732S3 7.143 3 9.5v5c0 2.357 0 3.535.732 4.268S5.643 19.5 8 19.5h.141C8 18.657 8 17.538 8 16z" opacity="0.4" />
                                         <path fill="currentColor" fill-rule="evenodd" d="M4.47 11.47a.75.75 0 0 0 0 1.06l2 2a.75.75 0 0 0 1.06-1.06l-.72-.72H14a.75.75 0 0 0 0-1.5H6.81l.72-.72a.75.75 0 1 0-1.06-1.06z" clip-rule="evenodd" />
                                     </svg> </a>
                             </li>


                         </ul>
                     </div>
                     <div class="sidebarmenu">
                         <nav class="sidebar-nav" id="menu-right-mini-1" data-simplebar="init">
                             <div class="simplebar-wrapper" style="margin: -24px -16px;">
                                 <div class="simplebar-height-auto-observer-wrapper">
                                     <div class="simplebar-height-auto-observer"></div>
                                 </div>
                                 <div class="simplebar-mask">
                                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                         <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: 100%; overflow: hidden;">
                                             <div class="simplebar-content" style="padding: 24px 16px;">
                                                 <ul class="sidebar-menu" id="sidebarnav">
                                                     <!-- ---------------------------------- -->
                                                     <!-- Home -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="nav-small-cap">
                                                         <span class="hide-menu">Dashboards</span>
                                                     </li>
                                                     <!-- ---------------------------------- -->
                                                     <!-- Dashboard -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="dashboard" aria-expanded="false">
                                                             <iconify-icon icon="solar:home-angle-line-duotone" class=""></iconify-icon>
                                                             <span class="hide-menu">Home</span>
                                                         </a>
                                                     </li>



                                                     <li>
                                                         <span class="sidebar-divider lg"></span>
                                                     </li>



                                                 </ul>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="simplebar-placeholder" style="width: 240px; height: 868px;"></div>
                             </div>
                             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                             </div>
                             <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="height: 0px; display: none; transform: translate3d(0px, 0px, 0px);"></div>
                             </div>
                         </nav>
                         <nav class="sidebar-nav" id="menu-right-mini-2" data-simplebar="init">
                             <div class="simplebar-wrapper" style="margin: -24px -16px;">
                                 <div class="simplebar-height-auto-observer-wrapper">
                                     <div class="simplebar-height-auto-observer"></div>
                                 </div>
                                 <div class="simplebar-mask">
                                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                         <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden;">
                                             <div class="simplebar-content" style="padding: 24px 16px;">
                                                 <ul class="sidebar-menu" id="sidebarnav">
                                                     <!-- ---------------------------------- -->
                                                     <!-- Home -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="nav-small-cap">
                                                         <span class="hide-menu">Profile</span>
                                                     </li>
                                                     <!-- ---------------------------------- -->
                                                     <!-- Dashboard -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="profile"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Edit Profile</a>
                                                     </li>
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="changepassword"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Change Password</a>
                                                     </li>
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="TransactionPassword"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon>Transaction Password</a>
                                                     </li>
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="address"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Add Wallet Address</a>
                                                     </li>
                                                 </ul>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                             </div>
                             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                             </div>
                             <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="height: 0px; display: none;"></div>
                             </div>
                         </nav>
                         <nav class="sidebar-nav" id="menu-right-mini-3" data-simplebar="init">
                             <div class="simplebar-wrapper" style="margin: -24px -16px;">
                                 <div class="simplebar-height-auto-observer-wrapper">
                                     <div class="simplebar-height-auto-observer"></div>
                                 </div>
                                 <div class="simplebar-mask">
                                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                         <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden;">
                                             <div class="simplebar-content" style="padding: 24px 16px;">
                                                 <ul class="sidebar-menu" id="sidebarnav">
                                                     <li class="nav-small-cap">
                                                         <span class="hide-menu">Deposit</span>
                                                     </li>


                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="Income"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Topup Wallet</a>
                                                     </li>

                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="deposit"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Fund Deposit</a>
                                                     </li>

                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="p2p"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> P2P Trarnsfer</a>
                                                     </li>

                                                 </ul>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                             </div>
                             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                             </div>
                             <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="height: 0px; display: none;"></div>
                             </div>
                         </nav>
                         <nav class="sidebar-nav" id="menu-right-mini-4" data-simplebar="init">
                             <div class="simplebar-wrapper" style="margin: -24px -16px;">
                                 <div class="simplebar-height-auto-observer-wrapper">
                                     <div class="simplebar-height-auto-observer"></div>
                                 </div>
                                 <div class="simplebar-mask">
                                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                         <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden;">
                                             <div class="simplebar-content" style="padding: 24px 16px;">
                                                 <ul class="sidebar-menu" id="sidebarnav">
                                                     <!-- ---------------------------------- -->
                                                     <!-- Home -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="nav-small-cap">
                                                         <span class="hide-menu">Investment</span>
                                                     </li>

                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="botPurchase"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Bot Purchase</a>
                                                     </li>
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="botPurchase"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Package Purchase</a>
                                                     </li>
                                                    
                                                 </ul>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                             </div>
                             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                             </div>
                             <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="height: 0px; display: none;"></div>
                             </div>
                         </nav>
                         <nav class="sidebar-nav" id="menu-right-mini-5" data-simplebar="init">
                             <div class="simplebar-wrapper" style="margin: -24px -16px;">
                                 <div class="simplebar-height-auto-observer-wrapper">
                                     <div class="simplebar-height-auto-observer"></div>
                                 </div>
                                 <div class="simplebar-mask">
                                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                         <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden;">
                                             <div class="simplebar-content" style="padding: 24px 16px;">
                                                 <ul class="sidebar-menu" id="sidebarnav">
                                                     <!-- ---------------------------------- -->
                                                     <!-- Home -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="nav-small-cap">
                                                         <span class="hide-menu">Team Network</span>
                                                     </li>

                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="Referral"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Referral Team</a>
                                                     </li>
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="level"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Level Team</a>
                                                     </li>
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="level"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Genealogy</a>
                                                     </li>
                                                 </ul>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                             </div>
                             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                             </div>
                             <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="height: 0px; display: none;"></div>
                             </div>
                         </nav>

                         <nav class="sidebar-nav" id="menu-right-mini-7" data-simplebar="init">
                             <div class="simplebar-wrapper" style="margin: -24px -16px;">
                                 <div class="simplebar-height-auto-observer-wrapper">
                                     <div class="simplebar-height-auto-observer"></div>
                                 </div>
                                 <div class="simplebar-mask">
                                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                         <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden;">
                                             <div class="simplebar-content" style="padding: 24px 16px;">
                                                 <ul class="sidebar-menu" id="sidebarnav">
                                                     <!-- ---------------------------------- -->
                                                     <!-- Home -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="nav-small-cap">
                                                         <span class="hide-menu">Withdrawal</span>
                                                     </li>


                                                     <!-- ---------------------------------- -->
                                                     <!-- Dashboard -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="view_withdrwal"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Withdrawal</a>
                                                     </li>
                                                 </ul>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                             </div>
                             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                             </div>
                             <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="height: 0px; display: none;"></div>
                             </div>
                         </nav>
                         <nav class="sidebar-nav" id="menu-right-mini-8" data-simplebar="init">
                             <div class="simplebar-wrapper" style="margin: -24px -16px;">
                                 <div class="simplebar-height-auto-observer-wrapper">
                                     <div class="simplebar-height-auto-observer"></div>
                                 </div>
                                 <div class="simplebar-mask">
                                     <div class="simplebar-offset" style="right: 0px; bottom: 0px;">
                                         <div class="simplebar-content-wrapper" tabindex="0" role="region" aria-label="scrollable content" style="height: auto; overflow: hidden;">
                                             <div class="simplebar-content" style="padding: 24px 16px;">
                                                 <ul class="sidebar-menu" id="sidebarnav">
                                                     <!-- ---------------------------------- -->
                                                     <!-- Home -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="nav-small-cap">
                                                         <span class="hide-menu">Support</span>
                                                     </li>


                                                     <!-- ---------------------------------- -->
                                                     <!-- Dashboard -->
                                                     <!-- ---------------------------------- -->
                                                     <li class="sidebar-item">
                                                         <a class="sidebar-link" href="ticket"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 256 256"><g fill="currentColor"><path d="M176 128a48 48 0 1 1-48-48a48 48 0 0 1 48 48" opacity="0.2"/><path d="M140 128a12 12 0 1 1-12-12a12 12 0 0 1 12 12"/></g></svg></iconify-icon> Support</a>
                                                     </li>
                                                 </ul>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                                 <div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div>
                             </div>
                             <div class="simplebar-track simplebar-horizontal" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="width: 0px; display: none;"></div>
                             </div>
                             <div class="simplebar-track simplebar-vertical" style="visibility: hidden;">
                                 <div class="simplebar-scrollbar" style="height: 0px; display: none;"></div>
                             </div>
                         </nav>

                     </div>

                 </div>
             </div>
         </div>
     </aside>