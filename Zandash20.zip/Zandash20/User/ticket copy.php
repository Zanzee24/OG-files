<?php include 'include/head.php';
require_once("loginCheck.php");

?>

<body class="dark-mode">
    <!-- P2P Exchange Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success">
                        <i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard.php">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Support</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Support</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-12">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#ticketModal">
                                <i class="mdi mdi-plus-circle-outline"></i> Create New Ticket
                            </button>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">All Outbox Tickets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped"
                                            id="tickets-table">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th width="5%">#</th>
                                                    <th width="15%">Ticket No</th>
                                                    <th width="15%">Subject</th>
                                                    <th width="25%">Message</th>
                                                    <th width="10%">Priority</th>
                                                    <th width="10%">Raise Date</th>
                                                    <th width="10%">Last Update</th>
                                                    <th width="10%">Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $count = 0;
                                                $queryRequest = mysqli_query($con, "SELECT a.ticketCode,a.ticketMessage,a.raiseDate,a.actionDate,a.ticketStatus,b.user_id,b.name,c.subjectName,d.priorityName FROM meddolic_user_support_ticket a, meddolic_user_details b, meddolic_config_support_subject c, meddolic_config_support_priority d WHERE a.memberId='$memberId' AND a.memberId=b.member_id AND a.subjectId=c.subjectId AND a.priorityId=d.priorityId ORDER BY a.raiseDate DESC");
                                                while ($valRequest = mysqli_fetch_assoc($queryRequest)) {
                                                    $count++; ?>
                                                    <tr>
                                                        <td><?= $count ?></td>
                                                        <td><?= $valRequest['ticketCode'] ?></td>
                                                        <td><?= $valRequest['subjectName'] ?></td>
                                                        <td><?= $valRequest['ticketMessage'] ?></td>
                                                        <td><?= $valRequest['priorityName'] ?></td>
                                                        <td><i class="fa fa-clock-o"></i>
                                                            <?= date("d-m-Y H:i:s", strtotime($valRequest['raiseDate'])) ?>
                                                        </td>
                                                        <td><?php if ($valRequest['actionDate'] != '') { ?> <i
                                                                    class="fa fa-clock-o"></i>
                                                                <?= date("d-m-Y H:i:s", strtotime($valRequest['actionDate']));
                                                        } ?>
                                                        </td>
                                                        <td><?php if ($valRequest['ticketStatus'] == 1)
                                                            echo "<span class='badge badge-primary'>OPEN</span>";
                                                        else if ($valRequest['ticketStatus'] == 2)
                                                            echo "<span class='badge badge-warning'>PROCESSING</span>";
                                                        else if ($valRequest['ticketStatus'] == 3)
                                                            echo "<span class='badge badge-success'>RESOLVED</span>"; ?>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">All Inbox Tickets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped" id="inbox-table">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th width="5%">#</th>
                                                    <th width="25%">Subject</th>
                                                    <th width="50%">Message</th>
                                                    <th width="20%">Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $count = 0;
                                                $queryResponse = mysqli_query($con, "SELECT a.adminMessage,a.actionDate,a.ticketStatus,b.user_id,b.name,c.subjectName FROM meddolic_user_support_ticket a, meddolic_user_details b, meddolic_config_support_subject c WHERE a.memberId='$memberId' AND a.memberId=b.member_id AND a.subjectId=c.subjectId AND a.adminMessage<>'' ORDER BY a.actionDate DESC");
                                                while ($valResponse = mysqli_fetch_assoc($queryResponse)) {
                                                    $count++; ?>
                                                    <tr>
                                                        <td><?= $count ?></td>
                                                        <td><?= $valResponse['subjectName'] ?></td>
                                                        <td><?= $valResponse['adminMessage'] ?></td>
                                                        <td><i class="fa fa-clock-o"></i>
                                                            <?= date("d-m-Y H:i:s", strtotime($valResponse['actionDate'])) ?>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Ticket Creation Modal -->
            <div class="modal fade" id="ticketModal" tabindex="-1" role="dialog" aria-labelledby="ticketModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <form action="SupportProcess" method="POST" enctype="multipart/form-data">
                            <div class="modal-header bg-primary text-white">
                                <h5 class="modal-title">Create New Support Ticket</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="subjectId" class="form-label">Subject</label>
                                        <select class="form-select" id="subjectId" name="subjectId" required>
                                            <option value="" selected disabled>Select Subject</option>
                                            <?php $querySubject = mysqli_query($con, "SELECT subjectId,subjectName FROM meddolic_config_support_subject WHERE subjectStatus=1");
                                            while ($valSubject = mysqli_fetch_assoc($querySubject)) { ?>
                                                <option value="<?= $valSubject['subjectId'] ?>">
                                                    <?= $valSubject['subjectName'] ?></option>
                                            <?php } ?>
                                        </select>
                                        <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="priorityId" class="form-label">Priority</label>
                                        <select class="form-select" id="priorityId" name="priorityId" required>
                                            <option value="" selected disabled>Select Priority</option>
                                            <?php $queryPriority = mysqli_query($con, "SELECT priorityId,priorityName FROM meddolic_config_support_priority WHERE priorityStatus=1");
                                            while ($valPriority = mysqli_fetch_assoc($queryPriority)) { ?>
                                                <option value="<?= $valPriority['priorityId'] ?>">
                                                    <?= $valPriority['priorityName'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="ticketMessage" class="form-label">Message</label>
                                    <textarea class="form-control" id="ticketMessage" name="ticketMessage" rows="6"
                                        placeholder="Describe your issue in detail..."
                                        style="color: #000000; background-color: #ffffff;" required></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="ticketAttachment" class="form-label">Attachment (Optional)</label>
                                    <input class="form-control" type="file" id="ticketAttachment"
                                        name="ticketAttachment">
                                    <div class="form-text">Max file size: 5MB (JPEG, PNG, PDF only)</div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary" name="supportTicket">Submit
                                    Ticket</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <?php include 'include/footer.php'; ?>
        </div>
    </div>

    <script>
        var d = document.getElementById("Support");
        d.className += " active";
    </script>
</body>

</html>