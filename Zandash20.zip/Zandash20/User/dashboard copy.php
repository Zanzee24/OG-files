<?php
require_once("loginCheck.php");
include 'include/head.php';
require_once('include/header.php');
?>


<?php
$todayDate = date('Y-m-d');
$d = date('Y-m-d H:i:s');
$queryFo = mysqli_query($con, "SELECT rewardRank,roiWallet,member_id,wallet,fundWallet,topup_flag,activation_date FROM meddolic_user_details WHERE user_id='$userId'");
$valFo = mysqli_fetch_assoc($queryFo);
$wallet = $valFo['wallet'];
$fundWallet = $valFo['fundWallet'];
$topup_flag = $valFo['topup_flag'];
 $activation_date = $valFo['activation_date'];
 $roiWallet = $valFo['roiWallet'];

 $rewardRank = $valFo['rewardRank'];


$querySponsor = mysqli_query($con, "SELECT
    (SELECT COUNT(1) FROM meddolic_user_details WHERE sponser_id='$memberId') AS totalSponser,
    (SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=1) AS activeSponser,
    (SELECT COUNT(1) FROM meddolic_user_details where sponser_id='$memberId' AND topup_flag=0) AS inActiveSponser,
    (SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' ) AS totalTeam,
    (SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=1) AS activeTeam,
    (SELECT COUNT(1) FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=0 ) AS inActiveTeam");
$valIncome = mysqli_fetch_assoc($querySponsor);
$totalSponser = $valIncome['totalSponser'];
$activeSponser = $valIncome['activeSponser'];
$inActiveSponser = $valIncome['inActiveSponser'];
$totalTeam = $valIncome['totalTeam'];
$activeTeam = $valIncome['activeTeam'];
$inActiveTeam = $valIncome['inActiveTeam'];

$queryIncome = mysqli_query($con, " SELECT
      (SELECT SUM(referralIncome) FROM meddolic_user_bot_sponsor_income 
       WHERE memberId='$memberId' AND releaseStatus=1) AS botReferral,

      (SELECT SUM(levelIncome) FROM meddolic_user_bot_level_income 
       WHERE memberId='$memberId' AND status=1) AS botLevel,

      (SELECT SUM(rewardIncome) FROM meddolic_user_bot_reward_income 
       WHERE memberId='$memberId' AND status=1) AS botrewardIncome,



       (SELECT SUM(levelIncome) FROM meddolic_user_level_income 
       WHERE memberId='$memberId' AND status=1) AS teamLevelIncome,

      (SELECT SUM(incomeAmount) FROM meddolic_user_cashback_income_details 
       WHERE member_id='$memberId' AND status=1) AS monthlyRoi,

      (SELECT SUM(referralIncome) FROM meddolic_user_sponsor_income 
       WHERE memberId='$memberId' AND releaseStatus=1) AS referralIncome,

        (SELECT SUM(rewardIncome) FROM meddolic_user_reward_income 
       WHERE memberId='$memberId' AND releaseStatus=1) AS rewardIncome	
");



$valDataGet = mysqli_fetch_assoc($queryIncome);
$botReferralIncome = $valDataGet['botReferral'];
$botLevelIncome    = $valDataGet['botLevel'];
$botRewardIncome   = $valDataGet['botrewardIncome'];


$teamLevelIncome = $valDataGet['teamLevelIncome'];
$monthlyRoi = $valDataGet['monthlyRoi'];
$referralIncome = $valDataGet['referralIncome'];
$rewardIncome     = $valDataGet['rewardIncome'];


$totalEarning = $botReferralIncome + $botLevelIncome + $botRewardIncome + $teamLevelIncome + $monthlyRoi + $referralIncome + $rewardIncome;

// $cappingEarning = $directIncome + $salaryIncome + $levelIncome;



$queryWithdraw = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_wallet_withdrawal_crypto WHERE member_id='$memberId' AND (released=1 OR released=0)");
$valWithdraw = mysqli_fetch_array($queryWithdraw);
$totalWithdraw = $valWithdraw[0];

$queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId' AND investStatus=2");
$valInvest = mysqli_fetch_array($queryInvest);
$totalSelfInvest = $valInvest[0];

$queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId' AND CAST(dateTime AS DATE)='$todayDate'");
$valInvest = mysqli_fetch_array($queryInvest);
$todaySelfInvest = $valInvest[0];

$queryConvert = mysqli_query($con, "SELECT SUM(transferAmount) FROM meddolic_user_income_wallet_transfer WHERE memberId='$memberId'");
$valConvert = mysqli_fetch_array($queryConvert);
$totalConvert = $valConvert[0];
$newWithdraw = $totalWithdraw + $totalConvert;

$queryTeam = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId IN ( SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$memberId' AND topup_status=1) AND investStatus=2");
$valTeam = mysqli_fetch_array($queryTeam);
$teamBusiness = $valTeam[0];


// if ($totalSelfInvest != 0) {
//     $totalPercentageworking = $cappingEarning * 100 / $totalSelfInvest;
// } else {
//     $totalPercentageworking = 0;
// }
// if ($totalSelfInvest != 0) {
//     $totalPercentagenonworking = $roiIncome * 100 / $totalSelfInvest;
// } else {
//     $totalPercentagenonworking = 0;
// }


$queryNews = mysqli_query($con, "SELECT news,newStatus FROM meddolic_config_news_list WHERE newStatus=1");
$valNews = mysqli_fetch_assoc($queryNews);
$news = $valNews['news'];

// Initialize
$legBusiness = [];
$totalBus = 0;

// Fetch all directs
$queryBus = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE sponser_id='$memberId' ORDER BY activation_date ASC");

while ($valDirect = mysqli_fetch_assoc($queryBus)) {
    $directId = $valDirect['member_id'];

    // Self business
    $querySelf = mysqli_query($con, "SELECT SUM(investAmount) AS selfBus FROM meddolic_user_invest_history WHERE memberId='$directId' AND investStatus=2");
    $valSelf = mysqli_fetch_assoc($querySelf);

    // Downline business
    $queryDown = mysqli_query($con, "SELECT SUM(investAmount) AS downBus 
        FROM meddolic_user_invest_history 
        WHERE memberId IN (
            SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$directId' AND topup_status=1
        ) AND investStatus=1");
    $valDown = mysqli_fetch_assoc($queryDown);

    $netBusiness = floatval($valSelf['selfBus']) + floatval($valDown['downBus']);
    $totalBus += $netBusiness;
    $legBusiness[] = $netBusiness;
}

// Now split into 3 legs (40,40,20)
$firstLeg = $secondLeg = $thirdLeg = 0;

if (!empty($legBusiness)) {
    rsort($legBusiness); // sort descending
    $firstLeg  = $legBusiness[0] ?? 0;
    $secondLeg = $legBusiness[1] ?? 0;
    $thirdLeg  = $totalBus - ($firstLeg + $secondLeg); // rest combine

}


$queryrank = mysqli_query($con, "SELECT rewardName FROM meddolic_config_reward_income WHERE rewardId='$rewardRank'");
$valreward = mysqli_fetch_array($queryrank);
$rank = $valreward['rewardName'];

$nextId = $rewardRank + 1;
$nextrankquery = mysqli_query($con, "SELECT rewardName FROM meddolic_config_reward_income WHERE rewardId='$nextId'");
$valnextrank = mysqli_fetch_array($nextrankquery);
$nextRank = $valnextrank['rewardName'];


$queryRankEligibility = mysqli_query($con, "SELECT totalBusiness FROM meddolic_config_reward_income WHERE rewardId='$nextId'");
$valEligibility = mysqli_fetch_array($queryRankEligibility);
$rankEligibility = $valEligibility['totalBusiness'];
?>


</head>




<body class="dark-mode show">



    <div class="wrapper">
        <!-- Sidebar -->
        <div class="leftside-menu">
            <a href="dashboard.php" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <!-- Main Content -->
        <div class="content-page">
            <div class="content">
                <!-- Topbar -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <!-- First Row - Referral and News -->
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <div class="card">
                                <div class="refferal_copy p-3">
                                    <h5>Referral Links</h5>
                                    <div class="input-group">
                                        <input type="text"
                                            value="http://bitglobal.trade/registration?affiliateCode=<?= $userId ?>"
                                            class="form-control"
                                            readonly
                                            id="myInput">
                                        <button onclick="copyLink()" class="btn btn-success">Copy</button>
                                    </div>
                                    <small id="copyMsg" style="color:green; display:none;">✅ Link copied!</small>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 mb-3">
                            <div class="card">
                                <div class="news_main">
                                    <div class="news_heading">
                                        <h4>News</h4>
                                    </div>
                                    <div class="marquee">
                                        <marquee onmouseover="this.stop()" behavior="scroll" direction="left"
                                            scrollamount="5" onmouseout="this.start()">

                                            <h4 style="color: black;font-size: 24px; font-weight: 600; font-family: none;">
                                                <marquee style="width:100%;"><?= $valNews['news'] ?> </marquee>
                                            </h4>

                                        </marquee>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Dashboard Cards -->
                    <div class="row">

                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 mb-3">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <div>
                                        <h3>$ <?= isset($fundWallet) ? $fundWallet : '0.00'; ?> </h3>
                                        <p> Fund Wallet </p>
                                    </div>
                                    <div id="chart1" class="cherst" style="min-height: 105px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <div>
                                        <h3>$ <?= isset($incomeWallet) ? $incomeWallet : '0.00'; ?> </h3>
                                        <p>Income Wallet </p>
                                    </div>
                                    <div id="chart2" style="min-height: 105px;"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <div>
                                        <h3>$ <?= isset($roiWallet) ? $roiWallet : '0.00'; ?> </h3>
                                        <p>Roi Wallet </p>
                                    </div>
                                    <div id="chart13" style="min-height: 105px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <div>
                                        <h3>$ <?= isset($totalEarning) ? $totalEarning : '0.00'; ?> </h3>
                                        <p>Total Earning </p>
                                    </div>
                                    <div id="chart3" style="min-height: 105px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <div>
                                        <h3>$ <?= isset($totalWithdraw) ? $totalWithdraw : '0.00'; ?></h3>
                                        <p>Total Withdrawal </p>
                                    </div>
                                    <div id="chart4" style="min-height: 105px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <div>
                                        <h3>$ <?= isset($teamBusiness) ? $teamBusiness : '0'; ?></h3>
                                        <p>Total Business </p>
                                    </div>
                                    <div id="chart5" class="cherst" style="min-height: 105px;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <a href="botReferralIncome.php" class="text-decoration-none">
                                <div class="dashbord_cards">
                                    <div class="conteste">
                                        <div>
                                            <h3>$ <?= isset($botReferralIncome) ? $botReferralIncome : '0.00'; ?></h3>
                                            <p> E-Referral Income</p>
                                        </div>
                                        <div id="chart6" style="min-height: 105px;"></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <a href="levelQualify.php" class="text-decoration-none">
                                <div class="dashbord_cards">
                                    <div class="conteste">
                                        <div>
                                            <h3>$<?= isset($botRewardIncome) ? $botRewardIncome : '0.00'; ?> </h3>
                                            <p> Level Qualify Income</p>
                                        </div>
                                        <div id="chart7" style="min-height: 105px;"></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <a href="eLevelIncome.php" class="text-decoration-none">
                                <div class="dashbord_cards">
                                    <div class="conteste">
                                        <div>
                                            <h3>$<?= isset($botLevelIncome) ? $botLevelIncome : '0.00'; ?> </h3>
                                            <p> E-Level Income </p>
                                        </div>
                                        <div id="chart8" style="min-height: 105px;"></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <!-- <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <div>
                                        <h3>$ <?= isset($monthlyRoi) ? $monthlyRoi : '0.00'; ?></h3>
                                        <p>Monthly ROI Income </p>
                                    </div>
                                    <div id="chart9" style="min-height: 105px;"></div>
                                </div>
                            </div>
                        </div> -->

                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <a href="monthlyRoi.php" class="text-decoration-none">
                                <div class="dashbord_cards">
                                    <div class="conteste">
                                        <div>
                                            <h3>$ <?= isset($monthlyRoi) ? $monthlyRoi : '0.00'; ?></h3>
                                            <p>Monthly ROI Income</p>
                                        </div>
                                        <div id="chart9" style="min-height: 105px;"></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <a href="referralIncome.php" class="text-decoration-none">
                                <div class="dashbord_cards">
                                    <div class="conteste">
                                        <div>
                                            <h3>$ <?= isset($referralIncome) ? $referralIncome : '0.00'; ?></h3>
                                            <p>Referral Income </p>
                                        </div>
                                        <div id="chart10" style="min-height: 105px;"></div>
                                    </div>
                                </div>
                            </a>
                        </div>


                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <a href="teamLevelIncome.php" class="text-decoration-none">
                                <div class="dashbord_cards">
                                    <div class="conteste">
                                        <div>
                                            <h3>$ <?= isset($teamLevelIncome) ? $teamLevelIncome : '0.00'; ?></h3>
                                            <p>Team Level Income</p>
                                        </div>
                                        <div id="chart11" style="min-height: 105px;"></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <a href="rewardIncome.php" class="text-decoration-none">
                                <div class="dashbord_cards">
                                    <div class="conteste">
                                        <div>
                                            <h3>$ <?= isset($rewardIncome) ? $rewardIncome : '0.00'; ?></h3>
                                            <p>Reward Income </p>
                                        </div>
                                        <div id="chart12" style="min-height: 105px;"></div>
                                    </div>
                                </div>
                            </a>
                        </div>

                        <style>
                            .binary-tree {
                                display: flex;
                                justify-content: space-around;
                                margin-top: 15px;
                                position: relative;
                            }

                            .binary-tree::before {
                                content: '';
                                position: absolute;
                                top: -15px;
                                left: 25%;
                                width: 50%;
                                height: 2px;
                                background: gold;
                            }

                            .branch {
                                background: #111;
                                padding: 10px;
                                border-radius: 8px;
                                flex: 0 0 40%;
                                box-shadow: inset 0 0 8px rgba(0, 0, 0, 0.4), inset 0 0 15px rgba(255, 215, 0, 0.3);
                            }

                            .branch p {
                                margin: 0;
                                font-size: 14px;
                                color: gold;
                            }

                            .branch h4 {
                                margin: 5px 0 0;
                                color: white;
                            }
                        </style>
                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards" style="text-align: center; padding: 15px;">
                                <div class="conteste">
                                    <div>
                                        <!-- Top node -->
                                        <h3> <?= isset($totalTeam) ? $totalTeam : '0'; ?></h3>
                                        <p>Total Team</p>

                                        <!-- Binary branches -->
                                        <div class="binary-tree">
                                            <div class="branch left">
                                                <p>Active Team</p>
                                                <h4><?= isset($activeTeam) ? $activeTeam : '0'; ?></h4>
                                            </div>
                                            <div class="branch right">
                                                <p>Inactive Team</p>
                                                <h4> <?= isset($inActiveTeam) ? $inActiveTeam : '0'; ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards" style="text-align: center; padding: 15px;">
                                <div class="conteste">
                                    <div>
                                        <!-- Top node -->
                                        <h3> <?= isset($totalSponser) ? $totalSponser : '0'; ?></h3>
                                        <p>Direct Team</p>

                                        <!-- Binary branches -->
                                        <div class="binary-tree">
                                            <div class="branch left">
                                                <p>Active Referrals</p>
                                                <h4> <?= isset($activeSponser) ? $activeSponser : '0'; ?></h4>
                                            </div>
                                            <div class="branch right">
                                                <p>Inactive Referrals</p>
                                                <h4><?= isset($inActiveSponser) ? $inActiveSponser : '0'; ?></h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <!-- <div class="col-xl-4 col-lg-6 col-md-6 col-sm-12 p-2 m-0">
                            <div class="dashbord_cards">
                                <div class="conteste">
                                    <h3>Rank Status: <?php echo $stats['rank_status']; ?> </h3>
                                    <p>Your(BV) : $ <?php echo number_format($stats['your_bv'], 2); ?> </p>
                                    <p>Team(BV) : $ <?php echo number_format($stats['team_bv'], 2); ?> </p>
                                    <div class="progress_bars">
                                        <p> <span><?php echo $stats['rank_progress']; ?>%</span></p>
                                        <div class="progress w-100">
                                            <div class="progress-bar" style="width:<?php echo $stats['rank_progress']; ?>%; background:#FEE078;"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <script>
                        $(function() {
                            "use strict";

                            const chartConfigs = [{
                                    id: "chart1",
                                    name: "Total Sales",
                                    color: "#F59E0B",
                                    gradient: "#FCD34D",
                                    data: [10, 15, 30, 25, 40, 20, 60, 35, 20]
                                },
                                {
                                    id: "chart2",
                                    name: "New Users",
                                    color: "#10B981",
                                    gradient: "#6EE7B7",
                                    data: [2, 5, 10, 15, 12, 18, 24, 28, 30]
                                },
                                {
                                    id: "chart3",
                                    name: "Revenue",
                                    color: "#6366F1",
                                    gradient: "#A5B4FC",
                                    data: [20, 25, 35, 45, 30, 50, 60, 80, 70]
                                },
                                {
                                    id: "chart4",
                                    name: "Registrations",
                                    color: "#EC4899",
                                    gradient: "#F9A8D4",
                                    data: [5, 10, 15, 10, 20, 15, 25, 30, 35]
                                },
                                {
                                    id: "chart5",
                                    name: "Withdrawals",
                                    color: "#EF4444",
                                    gradient: "#FCA5A5",
                                    data: [3, 8, 5, 12, 7, 15, 20, 10, 9]
                                },
                                {
                                    id: "chart6",
                                    name: "Referrals",
                                    color: "#8B5CF6",
                                    gradient: "#C4B5FD",
                                    data: [1, 4, 9, 14, 12, 10, 18, 22, 25]
                                },
                                {
                                    id: "chart7",
                                    name: "Active Users",
                                    color: "#14B8A6",
                                    gradient: "#99F6E4",
                                    data: [6, 12, 18, 16, 22, 24, 28, 26, 30]
                                },
                                {
                                    id: "chart8",
                                    name: "Clicks",
                                    color: "#F97316",
                                    gradient: "#FDBA74",
                                    data: [30, 28, 32, 35, 40, 42, 38, 44, 48]
                                },
                                {
                                    id: "chart9",
                                    name: "Transactions",
                                    color: "#0EA5E9",
                                    gradient: "#7DD3FC",
                                    data: [15, 20, 18, 25, 30, 28, 35, 40, 38]
                                },
                                {
                                    id: "chart10",
                                    name: "Earnings",
                                    color: "#22C55E",
                                    gradient: "#86EFAC",
                                    data: [1000, 1200, 1500, 1400, 1700, 2000, 2100, 2300, 2500]
                                },
                                {
                                    id: "chart11",
                                    name: "Referrals",
                                    color: "#8B5CF6",
                                    gradient: "#C4B5FD",
                                    data: [1, 4, 9, 14, 12, 10, 18, 22, 25]
                                },
                                {
                                    id: "chart12",
                                    name: "Registrations",
                                    color: "#EC4899",
                                    gradient: "#F9A8D4",
                                    data: [5, 10, 15, 10, 20, 15, 25, 30, 35]
                                }
                                {
                                    id: "chart13",
                                    name: "Clicks",
                                    color: "#F97316",
                                    gradient: "#FDBA74",
                                    data: [30, 28, 32, 35, 40, 42, 38, 44, 48]
                                }

                            ];

                            chartConfigs.forEach(cfg => {
                                var options = {
                                    series: [{
                                        name: cfg.name,
                                        data: cfg.data
                                    }],
                                    chart: {
                                        height: 105,
                                        type: 'area',
                                        sparkline: {
                                            enabled: true
                                        },
                                        zoom: {
                                            enabled: false
                                        }
                                    },
                                    dataLabels: {
                                        enabled: false
                                    },
                                    stroke: {
                                        width: 3,
                                        curve: 'smooth'
                                    },
                                    fill: {
                                        type: 'gradient',
                                        gradient: {
                                            shade: 'dark',
                                            gradientToColors: [cfg.gradient],
                                            shadeIntensity: 1,
                                            type: 'vertical',
                                            opacityFrom: 0.5,
                                            opacityTo: 0.0
                                        }
                                    },
                                    colors: [cfg.color],
                                    tooltip: {
                                        theme: "dark",
                                        fixed: {
                                            enabled: false
                                        },
                                        x: {
                                            show: false
                                        },
                                        y: {
                                            title: {
                                                formatter: () => ''
                                            }
                                        },
                                        marker: {
                                            show: false
                                        }
                                    },
                                    xaxis: {
                                        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep']
                                    }
                                };

                                const chart = new ApexCharts(document.querySelector(`#${cfg.id}`), options);
                                chart.render();
                            });

                        });
                    </script>
                    <!-- Profile Section -->
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="row py-3 px-2 align-items-center">
                                    <div class="col-xl-6 col-lg-6 mb-3 mb-lg-0">
                                        <div class="profile_boxese">
                                            <h3>About Me</h3>
                                            <ul>
                                                <li>User Id: <span><?= $userId ?></span></li>
                                                <li>User Name: <span><?= $userName ?></span></li>
                                                <!--<li>Member Id: <span><?= $memberId ?></span></li>-->
                                                <li>Email Id <span><?= $emailId ?></span></li>
                                                <li>Status <span> <?php if ($topup_flag == 1) echo "<span class='badge badge-success'>ACTIVE</span>";
                                                                    else echo "<span class='badge badge-danger'>IN-ACTIVE</span>" ?></span></li>
                                                <li>Activation Date <span><?= $activation_date ?></span></li>
                                            </ul>
                                            <a href="dashboard" class="btn btn-primary">Refresh Page</a>
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6">
                                        <div class="profile_boxese">
                                            <h3>Business History</h3>
                                            <ul>
                                                <!--<li>Total cap: <span>$ 0.00</span></li>-->
                                                <li>Self Investment: <span>$ <?= isset($totalSelfInvest) ? $totalSelfInvest : '0'; ?></span></li>
                                                <li>Team business: <span>$ <?= isset($teamBusiness) ? $teamBusiness : '0'; ?></span></li>
                                                <li>Current rank: <span><?= isset($rank) ? $rank : '-'; ?></span></li>
                                                <li>Next rank: <span><?= isset($nextRank) ? $nextRank : '-'; ?></span></li>
                                                <li>One Leg: <span><?= isset($firstLeg) ? $firstLeg : '0'; ?></span></li>
                                                <li>Two leg : <span><?= isset($secondLeg) ? $secondLeg : '0'; ?></span></li>
                                                <li>Other Leg : <span><?= isset($thirdLeg) ? $thirdLeg : '0'; ?></span></li>
                                                <li>Debited - Reward & Rank Eligibility : <span>$ <?= isset($rankEligibility) ? $rankEligibility : '0'; ?></span></li>
                                            </ul>
                                            <a href="dashboard" class="btn btn-primary">Refresh Page</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Trading View Widget -->
                    <div class="row mt-3">
                        <div class="col-md-12">
                            <div class="dashbord_box2">
                                <div class="tradingview-widget-container" style="height:500px;width:100%">
                                    <div class="tradingview-widget-container__widget"
                                        style="height:calc(100% - 32px);width:100%"></div>
                                    <script type="text/javascript" src="assets/js/chart.js" async>
                                        {
                                            "autosize": true,
                                            "symbol": "BITSTAMP:BTCUSD",
                                            "interval": "D",
                                            "timezone": "Etc/UTC",
                                            "theme": "dark",
                                            "style": "1",
                                            "locale": "en",
                                            "hide_top_toolbar": true,
                                            "allow_symbol_change": true,
                                            "support_host": "https://www.tradingview.com"
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Popup Modal -->
            <!-- <div class="modal fade" id="exampleModalpopup1" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-body">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <img src="assets/img/banner/WhatsApp_Image_2025-07-20_at_11_16_07_3c571f8d.jpg"
                                class="img-fluid">
                        </div>
                    </div>
                </div>
            </div> -->

           
        </div>
    </div>

    <!-- JavaScript -->
 <?php include 'include/footer.php'; ?>
    <script>
        function copyLink() {
            var copyText = document.getElementById("myInput");
            var value = copyText.value;

            // Modern way (only works on https/localhost)
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(value).then(() => {
                    showCopied();
                }).catch(err => {
                    console.error("Clipboard API failed:", err);
                    fallbackCopy(copyText);
                });
            } else {
                // Fallback for http or unsupported browsers
                fallbackCopy(copyText);
            }
        }

        function fallbackCopy(input) {
            input.removeAttribute("readonly"); // temporarily make it selectable
            input.select();
            input.setSelectionRange(0, 99999); // for mobile
            document.execCommand("copy");
            input.setAttribute("readonly", true);
            showCopied();
        }

        function showCopied() {
            var msg = document.getElementById("copyMsg");
            msg.style.display = "inline";
            setTimeout(() => msg.style.display = "none", 2000);
        }
    </script>


    <script>
        // Countdown Timer
        var countDownDate = new Date("0").getTime();
        var x = setInterval(function() {
            var now = new Date().getTime();
            var distance = countDownDate - now;
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            document.getElementById("demo").innerHTML = days + " Day " + hours + " : " + minutes + " : " + seconds + "  ";

            if (distance < 0) {
                clearInterval(x);
                document.getElementById("demo").innerHTML = "EXPIRED";
            }
        }, 1000);

        // Copy Referral Link
    </script>

    <script src="assets/js/charst.js"></script>
    <script src="assets/js/apexcharts.min.js"></script>
</body>

</html>