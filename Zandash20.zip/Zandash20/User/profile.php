<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>

<div class="body-wrapper">
    <div class="container-fluid">
        <div class="card card-body">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="d-sm-flex align-items-center justify-space-between">
                        <h4 class="fw-semibold fs-4 mb-4 mb-md-0 card-title">User Profile</h4>
                        <nav aria-label="breadcrumb" class="ms-auto">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item d-flex align-items-center">
                                    <a class="text-muted text-decoration-none d-flex" href="dashboard.php">
                                        <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                        User Profile
                                    </span>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="card overflow-hidden">
            <div class="card-body p-0">
                <img src="assets/assets/images/backgrounds/profilebg.jpg" alt="materialm-img" class="img-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-4 order-lg-1 order-2">
                        <div class="d-flex align-items-center justify-content-around m-4">
                            <div class="text-center">
                                <i class="fa-solid fa-envelope"></i>
                                <h4 class="mb-0 fw-semibold lh-1">Mail</h4>
                                <p class="mb-0 ">user@gmail.com</p>
                            </div>
                            <div class="text-center">
                                <i class="fa-solid fa-phone"></i>
                                <h4 class="mb-0 fw-semibold lh-1">Phone</h4>
                                <p class="mb-0 ">+ 91 12421415</p>
                            </div>
                            <div class="text-center">
                                <i class="fa-solid fa-map-location-dot"></i>
                                <h4 class="mb-0 fw-semibold lh-1">Address</h4>
                                <p class="mb-0 ">23,vil India</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mt-n3 order-lg-2 order-1">
                        <div class="mt-n5">
                            <div class="d-flex align-items-center justify-content-center mb-2">
                                <div class="d-flex align-items-center justify-content-center round-110">
                                    <div class="border border-4 border-white d-flex align-items-center justify-content-center rounded-circle overflow-hidden round-100">
                                        <img src="assets/assets/images/profile/user-1.jpg" alt="materialm-img" class="w-100 h-100">
                                    </div>
                                </div>
                            </div>
                            <div class="text-center">
                                <h5 class="mb-0">Jonathan Deo</h5>
                                <p class="mb-0">Designer</p>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-4 order-last">
                        <ul class="list-unstyled d-flex align-items-center justify-content-center justify-content-lg-end my-3 mx-4 pe-4 gap-3">
                            <li>
                                <a class="d-flex align-items-center justify-content-center btn btn-primary p-2 fs-4 rounded-circle" href="javascript:void(0)" width="30" height="30">
                                    <i class="ti ti-brand-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn btn-secondary d-flex align-items-center justify-content-center p-2 fs-4 rounded-circle" href="javascript:void(0)">
                                    <i class="ti ti-brand-dribbble"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn btn-danger d-flex align-items-center justify-content-center p-2 fs-4 rounded-circle" href="javascript:void(0)">
                                    <i class="ti ti-brand-youtube"></i>
                                </a>
                            </li>
                            <li>
                                <button class="btn btn-primary text-nowrap">Add To Story</button>
                            </li>
                        </ul>
                    </div> -->
                </div>
                <ul class="nav nav-pills user-profile-tab justify-content-end mt-2 bg-primary-subtle rounded-2 rounded-top-0" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link hstack gap-2 rounded-0 fs-12 py-6 active" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="true">
                            <i class="fa fa-user-circle fs-5"></i>
                            <span class="d-none d-md-block">Profile</span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link hstack gap-2 rounded-0 fs-12 py-6" id="pills-followers-tab" data-bs-toggle="pill" data-bs-target="#pills-followers" type="button" role="tab" aria-controls="pills-followers" aria-selected="false" tabindex="-1">
                            <i class="fa fa-lock fs-5"></i>
                            <span class="d-none d-md-block">Change Password</span>
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link hstack gap-2 rounded-0 fs-12 py-6" id="pills-friends-tab" data-bs-toggle="pill" data-bs-target="#pills-friends" type="button" role="tab" aria-controls="pills-friends" aria-selected="false" tabindex="-1">
                            <i class="fa fa-key fs-5"></i>
                            <span class="d-none d-md-block">Current Transaction Password</span>
                        </button>
                    </li>


                </ul>
            </div>
        </div>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade active show" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow-none border">
                            <div class="card-body">
                                <h4 class="card-title mb-3">Profile</h4>
                                <div class="repeater-default">
                                    <div data-repeater-list="">
                                        <div data-repeater-item="">
                                            <form>
                                                <div class="row">
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="name">Name</label>
                                                        <input type="text" class="form-control" placeholder="Name">
                                                    </div>
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="email">Email</label>
                                                        <input type="email" class="form-control" placeholder="Email">
                                                    </div>
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="pwd">Password</label>
                                                        <input type="password" class="form-control" id="pwd" placeholder="Password">
                                                    </div>
                                                   
                                                    
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="mt-3 pt-3 border-top">
                                        <button data-repeater-create="" class="btn btn-success hstack gap-6">
                                            Add
                                            <i class="fa fa-circle-plus ms-1 fs-5"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

            <div class="tab-pane fade" id="pills-gallery" role="tabpanel" aria-labelledby="pills-gallery-tab" tabindex="0">
                <div class="d-sm-flex align-items-center justify-content-between mt-3 mb-4">
                    <h3 class="mb-3 mb-sm-0 fw-semibold d-flex align-items-center">Gallery <span class="badge text-bg-secondary fs-2 rounded-4 py-1 px-2 ms-2">12</span>
                    </h3>
                    <form class="position-relative">
                        <input type="text" class="form-control search-chat py-2 ps-5" id="text-srh" placeholder="Search Friends">
                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y text-dark ms-3"></i>
                    </form>
                </div>

            </div>
        </div>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade " id="pills-followers" role="tabpanel" aria-labelledby="pills-followers-tab" tabindex="0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow-none border">
                            <div class="card-body">
                                <h4 class="card-title mb-3">Change Password</h4>
                                <div class="repeater-default">
                                    <div data-repeater-list="">
                                        <div data-repeater-item="">
                                            <form>
                                                <div class="row">
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="name">Current Login Password</label>
                                                        <input type="text" class="form-control" placeholder="Password">
                                                    </div>
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="email">New Login Password</label>
                                                        <input type="email" class="form-control" placeholder="Password">
                                                    </div>
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="pwd">Retype Password</label>
                                                        <input type="password" class="form-control" id="pwd" placeholder="Password">
                                                    </div>
                                                   
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="mt-3 pt-3 border-top">
                                        <button data-repeater-create="" class="btn btn-success hstack gap-6">
                                            Add
                                            <i class="fa fa-circle-plus ms-1 fs-5"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

            <div class="tab-pane fade" id="pills-gallery" role="tabpanel" aria-labelledby="pills-gallery-tab" tabindex="0">
                <div class="d-sm-flex align-items-center justify-content-between mt-3 mb-4">
                    <h3 class="mb-3 mb-sm-0 fw-semibold d-flex align-items-center">Change Transaction Password <span class="badge text-bg-secondary fs-2 rounded-4 py-1 px-2 ms-2">12</span>
                    </h3>
                    <form class="position-relative">
                        <input type="text" class="form-control search-chat py-2 ps-5" id="text-srh" placeholder="Search Friends">
                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y text-dark ms-3"></i>
                    </form>
                </div>

            </div>
        </div>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade " id="pills-friends" role="tabpanel" aria-labelledby="pills-friends-tab" tabindex="0">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow-none border">
                            <div class="card-body">
                                <h4 class="card-title mb-3"> Transaction Password</h4>
                                <div class="repeater-default">
                                    <div data-repeater-list="">
                                        <div data-repeater-item="">
                                            <form>
                                                <div class="row">
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="name">Current Transaction Password</label>
                                                        <input type="text" class="form-control" placeholder="Password">
                                                    </div>
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="email">New Transaction Password</label>
                                                        <input type="email" class="form-control" placeholder="Password">
                                                    </div>
                                                    <div class="mb-3 col-md-3">
                                                        <label class="form-label" for="pwd">Retype Transaction Password</label>
                                                        <input type="password" class="form-control" id="pwd" placeholder="Password">
                                                    </div>
                                                   
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="mt-3 pt-3 border-top">
                                        <button data-repeater-create="" class="btn btn-success hstack gap-6">
                                            Add
                                            <i class="fa fa-circle-plus ms-1 fs-5"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

            <div class="tab-pane fade" id="pills-gallery" role="tabpanel" aria-labelledby="pills-gallery-tab" tabindex="0">
                <div class="d-sm-flex align-items-center justify-content-between mt-3 mb-4">
                    <h3 class="mb-3 mb-sm-0 fw-semibold d-flex align-items-center">Gallery <span class="badge text-bg-secondary fs-2 rounded-4 py-1 px-2 ms-2">12</span>
                    </h3>
                    <form class="position-relative">
                        <input type="text" class="form-control search-chat py-2 ps-5" id="text-srh" placeholder="Search Friends">
                        <i class="ti ti-search position-absolute top-50 start-0 translate-middle-y text-dark ms-3"></i>
                    </form>
                </div>

            </div>
        </div>

    </div>
</div>
<?php include 'Include/Footer.php'; ?>