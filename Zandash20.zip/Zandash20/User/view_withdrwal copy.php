<?php include 'include/head.php';
require_once("loginCheck.php");

?>
<?php
$queryDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE sponser_id='$memberId' AND topup_flag=1");
$valDirect = mysqli_fetch_array($queryDirect);
$totalDirect = $valDirect[0];

$queryAmount = mysqli_query($con, "SELECT withdrawCharge,minimumWithdraw FROM meddolic_config_misc_setting");
$valAmount = mysqli_fetch_assoc($queryAmount);
$withdrawCharge = $valAmount['withdrawCharge'];
$minimumWithdraw = $valAmount['minimumWithdraw'];

unset($_SESSION['withdrawTokenSet']);
$randToken = rand(1111, 9999) . time() . date('s');
$newToken = md5($randToken);
$_SESSION['withdrawTokenSet'] = $newToken;
$todayDay = date('w');
?>

<body class="dark-mode">
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Withdrawal Request</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <form class="theme-form" action="walletWithdrawProcess" method="post">
                                        <div class="mb-3">
                                            <label>UserId </label>
                                            <input type="text" name="user_id" class="form-control"
                                                placeholder="e.g. john12345" readonly value="<?= $userId ?>">
                                            <input type="hidden" name="member_id" value="<?= $memberId ?>">
                                            <input type="hidden" name="goodFile" value="<?= $newToken ?>">
                                            <input type="hidden" name="withdrawCharge" value="<?= $withdrawCharge ?>">
                                            <input type="hidden" name="minimumWithdraw" value="<?= $minimumWithdraw ?>">
                                        </div>
                                        <div class="mb-3">
                                            <label>Name </label>
                                            <input type="text" name="name" class="form-control"
                                                placeholder="e.g. John Doe" readonly value="<?= $userName ?>">
                                        </div>


                                        <div class="mb-3">
                                            <label>Select Wallet </label>
                                            <select name="walletType" id="walletType" class="form-control">
                                                <option value="wallet">Income Wallet (<?= isset($incomeWallet) ? $incomeWallet : '0.00'; ?>)</option>
                                                <option value="roiWallet">ROI Wallet (<?= isset($roiWallet) ? $roiWallet : '0.00'; ?>)</option>
                                            </select>
                                        </div>




                                        <div class="mb-3">
                                            <label>Select wallet Address</label>
                                            <select class="form-control" name="paymentId" required id="paymentId">
                                                <option value="">Select BEP-20 USDT Address </option>
                                                <?php $queryWallet = mysqli_query($con, "SELECT a.payment_id,a.walletAddress,b.currencyName FROM meddolic_user_wallet_address_details a, meddolic_config_currency_list b WHERE a.member_id='$memberId' AND a.currency_id=b.currency_id AND a.status=1 ORDER BY a.addDate DESC");
                                                while ($valWallet = mysqli_fetch_assoc($queryWallet)) { ?>
                                                    <option value="<?= $valWallet['payment_id'] ?>">
                                                        <?= $valWallet['currencyName'] ?> [ <?= $valWallet['walletAddress'] ?> ]
                                                    </option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label>Withdraw Amount *</label>
                                            <input type="number" name="withdrawAmount" class="form-control"
                                                placeholder="Enter Withdraw Amount" required
                                                onkeypress="return onlynum(event)">

                                        </div>
                                        <div class="mb-3">
                                            <label>Transaction Password *</label>
                                            <input type="password" name="trnPassword" class="form-control"
                                                placeholder="e.g. Transaction Password" required>
                                        </div>
                                        <div class="">
                                            <button class="btn btn-primary" data-bs-original-title="" title="Withdraw"
                                                name="walletWithdraw" title="Withdraw"
                                                value="Withdraw">Withdraw</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped nowrap">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>User Id</th>
                                                <th>Amount</th>
                                                <th>Withdraw Charge</th>
                                                <th>Net Amount</th>
                                                <th>Order Id</th>
                                                <th>Wallet Type</th>
                                                <th>Date</th>
                                                <th>Payout Date</th>
                                                <th>Withdraw Status</th>
                                                <th>Action Date</th>
                                                <th>Remark</th>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryWithdraw = mysqli_query($con, "SELECT a.*,b.user_id FROM meddolic_user_wallet_withdrawal_crypto a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.member_id=b.member_id ORDER BY a.id DESC");
                                            while ($valWithdraw = mysqli_fetch_assoc($queryWithdraw)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count; ?></td>
                                                    <td><?= $valWithdraw['user_id'] ?></td>
                                                    <td><span class="badge badge-danger"><i class="fa fa-usd"></i>
                                                            <?= $valWithdraw['amount'] ?></span></td>
                                                    <td><span class="badge badge-danger"><i class="fa fa-"></i>
                                                            <?= $valWithdraw['withdrawCharge'] ?> %</span></td>
                                                    <td><span class="badge badge-success"><i class="fa fa-usd"></i>
                                                            <?= $valWithdraw['netAmount'] ?></span></td>

                                                    <td><?= $valWithdraw['orderid'] ?></td>
                                                    <td><?= $valWithdraw['walletType'] ?></td>
                                                    <td><i class="fa fa-clock-o"></i> <?= $valWithdraw['date_time'] ?></td>
                                                    <td><i class="fa fa-clock-o"></i> <?= $valWithdraw['showDate'] ?></td>
                                                    <td><?php if ($valWithdraw['released'] == 0)
                                                            echo "<span class='badge badge-primary'>PENDING</span>";
                                                        else if ($valWithdraw['released'] == 1)
                                                            echo "<span class='badge badge-success'>RELEASED</span>";
                                                        else if ($valWithdraw['released'] == 2)
                                                            echo "<span class='badge badge-warning'>PROCESSING</span>";
                                                        else if ($valWithdraw['released'] == 3)
                                                            echo "<span class='badge badge-danger'>REJECTED</span>"; ?>
                                                    </td>
                                                    <td><?= $valWithdraw['payment_date'] ?></td>
                                                    <td><?= $valWithdraw['remarks'] ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include 'include/footer.php'; ?>
        </div>
    </div>

    <script>
        function updateBalance(walletType) {
            // AJAX call to get balance for selected wallet
            // This is just a placeholder - implement your actual balance fetching logic
            if (walletType === '1') {
                document.getElementById('bal').textContent = '$100.00'; // Example balance
            } else {
                document.getElementById('bal').textContent = '$0.00';
            }
        }

        // Initialize form validation
        document.getElementById('withdrawalForm').addEventListener('submit', function(e) {
            const amount = parseFloat(this.elements['amount'].value);
            const balanceText = document.getElementById('bal').textContent;
            const balance = parseFloat(balanceText.replace('$', ''));

            if (amount > balance) {
                e.preventDefault();
                alert('Withdrawal amount cannot exceed available balance');
            }
        });

        // Update balance when wallet type changes
        document.querySelector('select[name="wallet_type"]').addEventListener('change', function() {
            updateBalance(this.value);
        });

        // Initialize with default balance
        updateBalance('1');

        function send_otp_email(id) {
            var result = confirm("Want to send otp");
            if (result) {
                var txtuserid = $('#' + id).val();
                $.ajax({
                    type: "POST",
                    url: baseUrl + "get_details/send_otp_email",
                    dataType: 'json',
                    data: {
                        'txtintuserid': txtuserid
                    },
                    success: function(msg) {
                        $("#divtotp").html(msg);
                    }
                });
            }
        }

        function wallet_address(id) {
            var txtuserid = $('#' + id).val();
            $.ajax({
                type: "POST",
                url: baseUrl + "get_details/getwallet_address",
                dataType: 'json',
                data: {
                    'txtintuserid': txtuserid
                },
                success: function(msg) {
                    if (msg != '') {
                        $('#txtcryptoaddress').val(msg);
                    } else {
                        $('#txtcryptoaddress').val('');
                        alert("Please Add Your Wallet Address");
                    }
                }
            });
        }
    </script>
    <script>
        var d = document.getElementById("Wallet");
        d.className += " active";
    </script>

</body>

</html>