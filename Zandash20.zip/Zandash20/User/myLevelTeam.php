<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('include/head.php');

?>
<?php
if ($_GET) {
    if ($_GET['fromDate']) {
        $showDate = $_GET['fromDate'];
        $calDate = date("Y-m-d", strtotime($showDate));
    }
    if ($_GET['toDate']) {
        $showDate1 = $_GET['toDate'];
        $calDate1 = date("Y-m-d", strtotime($showDate1));
    }
} else {
    $showDate = date("d-m-Y");
    $showDate1 = date("d-m-Y");
    $calDate = date("Y-m-d");
    $calDate1 = date("Y-m-d");
}
?>

<body class="dark-mode">
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="Dashboard">Dashboard</a></li>
                                        <li class="breadcrumb-item active">Team & Network</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">My Team</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Daily ROI Income</h4>
                                <form class="row row-cols-sm-3 theme-form mt-3 form-bottom">
                                    <div class="col-md-3 mb-3 d-flex">
                                        <div class="input-group">
                                            <input type="text" class="form-control pull-right" name="fromDate"
                                                id="fromDate" value="<?= $showDate ?>" readonly><span
                                                class="input-group-text"><i class="fa fa-calendar"></i></span>
                                        </div>
                                    </div>
                                    <div class="col-md-3 mb-3 d-flex">
                                        <div class="input-group">
                                            <input type="text" class="form-control pull-right" name="toDate" id="toDate"
                                                value="<?= $showDate1 ?>" readonly><span class="input-group-text"><i
                                                    class="fa fa-calendar"></i></span>
                                        </div>
                                    </div>
                                    <div class="mb-3 d-flex">
                                        <button class="btn btn-primary" data-bs-original-title=""
                                            title="">Search</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Team Members</h4>
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped nowrap">
                                       <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Level Number.</th>
                                                <th>Total Member</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            for ($level = 1; $level <= 25; $level++) {
                                                $queryMember = mysqli_query($con, "SELECT COUNT(1) AS totalMember FROM meddolic_user_child_ids WHERE member_id='$memberId' AND level='$level'");
                                                $valMember = mysqli_fetch_array($queryMember);
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $level ?></td>
                                                    <td>Level <?= $level; ?></td>
                                                    <td><i class="fa fa-user"></i>
                                                        <?= isset($valMember[0]) ? $valMember[0] : '0'; ?></td>
                                                    <td><a href="levelTeamDetails?MemberID=<?= $memberId ?>&LevelID=<?= $level ?>"
                                                            class="btn btn-primary">More</a></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php include 'include/footer.php'; ?>

    <script>
        var d = document.getElementById("Team");
        d.className += " active";
        var d = document.getElementById("myLevelTeam");
        d.className += " active";
    </script>
</body>

</html>