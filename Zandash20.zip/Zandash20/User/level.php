<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>

<div class="body-wrapper">
    <div class="container-fluid">
        <div class="card card-body">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="d-sm-flex align-items-center justify-space-between">
                        <h4 class="fw-semibold fs-4 mb-4 mb-md-0 card-title">Level </h4>
                        <nav aria-label="breadcrumb" class="ms-auto">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item d-flex align-items-center">
                                    <a class="text-muted text-decoration-none d-flex" href="dashboard.php">
                                        <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                        Level
                                    </span>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Fund Transfer Form -->

        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Level</h4>
                        <div class="table-responsive">
                            <table class="table text-nowrap mb-0 align-middle">
                                <thead class="text-dark fs-4">
                                    <tr>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0">User</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0"> Name</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0">Team</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0">Status</h6>
                                        </th>
                                        <th>
                                            <h6 class="fs-4 fw-semibold mb-0">Budget</h6>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="assets/assets/images/profile/user-3.jpg" class="rounded-circle" width="40" height="40">
                                                <div class="ms-3">
                                                    <h6 class="fs-4 fw-semibold mb-0">Sunil Joshi</h6>
                                                    <span class="fw-normal">Web Designer</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="mb-0 fw-normal fs-4">Elite Admin</p>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:void(0)" class="text-bg-secondary text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    S
                                                </a>
                                                <a href="javascript:void(0)" class="text-bg-danger text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    D
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-success-subtle text-success">Active</span>
                                        </td>
                                        <td>
                                            <h6 class="fs-4 fw-semibold mb-0">$3.9k</h6>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="assets/assets/images/profile/user-2.jpg" class="rounded-circle" width="40" height="40">
                                                <div class="ms-3">
                                                    <h6 class="fs-4 fw-semibold mb-0">Arlene McCoy</h6>
                                                    <span class="fw-normal">Project Manager</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="mb-0 fw-normal fs-4">Real Homes WP Theme</p>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:void(0)" class="text-bg-primary text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    A
                                                </a>
                                                <a href="javascript:void(0)" class="text-bg-warning text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    X
                                                </a>
                                                <a href="javascript:void(0)" class="text-bg-secondary text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    N
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-warning-subtle text-warning">Pending</span>
                                        </td>
                                        <td>
                                            <h6 class="fs-4 fw-semibold mb-0">$24.5k</h6>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="assets/assets/images/profile/user-6.jpg" class="rounded-circle" width="40" height="40">
                                                <div class="ms-3">
                                                    <h6 class="fs-4 fw-semibold mb-0">Christopher Jamil</h6>
                                                    <span class="fw-normal">Project Manager</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="mb-0 fw-normal fs-4">MedicalPro WP Theme</p>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:void(0)" class="text-bg-danger text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    X
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-primary-subtle text-primary">Completed</span>
                                        </td>
                                        <td>
                                            <h6 class="fs-4 fw-semibold mb-0">$12.8k</h6>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="assets/assets/images/profile/user-4.jpg" class="rounded-circle" width="40" height="40">
                                                <div class="ms-3">
                                                    <h6 class="fs-4 fw-semibold mb-0">Evelyn Pope</h6>
                                                    <span class="fw-normal">Frontend Engineer</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="mb-0 fw-normal fs-4">Hosting Press HTML</p>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:void(0)" class="text-bg-primary text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    Y
                                                </a>
                                                <a href="javascript:void(0)" class="text-bg-danger text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    X
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-success-subtle text-success">Active</span>
                                        </td>
                                        <td>
                                            <h6 class="fs-4 fw-semibold mb-0">$2.4k</h6>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="assets/assets/images/profile/user-5.jpg" class="rounded-circle" width="40" height="40">
                                                <div class="ms-3">
                                                    <h6 class="fs-4 fw-semibold mb-0">Micheal Doe</h6>
                                                    <span class="fw-normal">Content Writer</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="mb-0 fw-normal fs-4">Hosting Press HTML</p>
                                        </td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <a href="javascript:void(0)" class="text-bg-secondary text-white fs-6 round-40 rounded-circle me-n2 card-hover border border-2 border-white d-flex align-items-center justify-content-center">
                                                    S
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-danger-subtle text-danger">Cancel</span>
                                        </td>
                                        <td>
                                            <h6 class="fs-4 fw-semibold mb-0">$9.3k</h6>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>



                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- You can keep the table section below as it is, just ensure data is populated dynamically -->

        <?php include 'Include/Footer.php'; ?>