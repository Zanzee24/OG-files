<?php
require_once("loginCheck.php");
include('include/head.php'); ?>
<style>
  /* Add these styles to fix the dashboard layout */
  .dashboard-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 1.5rem;
    margin-bottom: 2rem;
  }

  .dashboard-card,
  .accent-card,
  .summary-card {
    background-color: white;
    border-radius: 10px;
    padding: 1.5rem;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    position: relative;
    overflow: hidden;
  }

  .accent-card {
    background: linear-gradient(135deg, #00bfa6 0%, #6a11cb 100%);
    color: white;
  }

  .dashboard-card .card-label,
  .accent-card .card-label {
    font-size: 0.8rem;
    color: #7b8794;
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
  }

  .accent-card .card-label {
    color: rgba(255, 255, 255, 0.9);
  }

  .dashboard-card .card-label i,
  .accent-card .card-label i {
    margin-right: 0.5rem;
  }

  .dashboard-card .card-value,
  .accent-card .card-value {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 1rem;
  }

  .dashboard-card .card-icon,
  .accent-card .card-icon {
    position: absolute;
    right: 1.5rem;
    bottom: 1.5rem;
    font-size: 2rem;
    opacity: 0.2;
  }

  .accent-card .card-icon {
    opacity: 0.4;
    color: white;
  }

  .summary-card {
    grid-column: span 2;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .summary-card .card-label {
    font-size: 0.9rem;
    color: #7b8794;
    margin-bottom: 0.5rem;
    font-weight: 500;
  }

  .summary-card .stat {
    margin-right: 1.5rem;
  }

  .summary-card .stat .label {
    font-size: 0.75rem;
    color: #7b8794;
  }

  .summary-card .stat .num {
    font-size: 1.1rem;
    font-weight: 600;
    margin-top: 0.25rem;
  }

  .icon-container {
    font-size: 2.5rem;
    opacity: 0.2;
    color: #4361ee;
  }

  /* Responsive adjustments for dashboard grid */
  @media (max-width: 1200px) {
    .dashboard-grid {
      grid-template-columns: repeat(3, 1fr);
    }
  }

  @media (max-width: 992px) {
    .dashboard-grid {
      grid-template-columns: repeat(2, 1fr);
    }
  }

  @media (max-width: 768px) {
    .dashboard-grid {
      grid-template-columns: 1fr;
    }

    .summary-card {
      grid-column: span 1;
    }
  }

  /* Withdrawal form styling to match your theme */
  .site-card {
    background-color: white;
    border-radius: 10px;
    padding: 2rem;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    margin-bottom: 2rem;
  }

  .site-card .card-header {
    background: transparent;
    border: none;
    padding: 0;
    margin-bottom: 1.5rem;
  }

  .main-btn {
    background: linear-gradient(135deg, #00bfa6 0%, #6a11cb 100%);
    color: white;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-weight: 500;
    transition: all 0.3s ease;
  }

  .main-btn:hover {
    opacity: 0.9;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 191, 166, 0.3);
  }
  .badge {
    
    --bs-badge-color: #000000 !important;
  }
</style>

<!-- Sidebar -->
<?php include('include/menu.php'); ?>


<!-- Main Content -->
<div class="main-content">
  <!-- Topbar -->
  <?php include('include/header.php'); ?>




  <!-- Withdrawal Section -->
  <div class="row justify-content-center mt-4">
    <div class="col-lg-8">
      <div class="site-card">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center">
          <h4 class="mb-0">Withdrawal Address</h4>
        </div>
         <div class="card-body">
          <form class="form theme-form" action="my-profileupdate" method="POST">
              <div class="row">
                <div class="form-group col-md-6 col-sm-6">
                  <label>Select Currency *</label>
                  <select class="form-control" name="currencyId" required id="currencyId">
                    <option value=""> Select One </option>
               <?php $queryCoin = mysqli_query($con, "SELECT * FROM meddolic_config_currency_list WHERE status=1 ORDER BY currencyName ASC");
                    while ($valCoin = mysqli_fetch_assoc($queryCoin)) { ?>
                      <option value="<?= $valCoin['currency_id'] ?>"> <?= $valCoin['currencyName'] ?></option>
                    <?php } ?>
                  </select>
                </div>
                <div class="form-group col-md-6 col-sm-6">
                  <div class="form-group">
                    <label>Wallet Address *</label>
                    <input class="form-control" name="walletAddress" id="walletAddress" type="text" required placeholder="Enter Wallet Address">
                    <input type="hidden" name="memberId" value="<?= $memberId ?>" />
                  </div>
                </div>

                <div class="form-group col-md-4 col-sm-6">
                  <div class="form-group">
                    <label>Email Verification *</label>
                    <input placeholder="Verification Code" name="emailOtp"  type="text" class="form-control" required>

                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <button style="margin-top:33px;padding:6px 20px 10px 20px; white-space: nowrap;" 
        type="button" 
        class="btn btn-primary col-md-2 col-sm-3" 
        id="emailBtn"
        onclick="addressVerifyOTP('<?= $userId ?>','<?= $emailId ?>')">
    Send OTP <span id="count" style="visibility:hidden;">00 S</span>
</button>

                  </div>
                </div>

                <div class="form-group">
                  <?php if ($valExist[0] < 2) { ?>
                    <button type="submit" name="addWalletAddress" class="btn btn-primary col-md-12 col-sm-12">Save</button>
                  <?php } ?>
                </div>
              </div>
          </div>
          </form>
        </div>
      </div>
    </div>


  <!-- Withdrawal History -->
  <div class="row mt-4">
    <div class="col-12">
      <div class="content-card"  >
        <div class="card-header-title" >
          <i class="bi bi-clock-history"></i> Withdrawal History
        </div>
        <div class="table-responsive">
          <table class="table custom-table">
              <thead>
                <tr>
                  <th>Sr No.</th>
                  <th>USDT Network</th>
                  <th>Wallet Address</th>
                  <!--<th>Action</th>-->
                </tr>
              </thead>
              <tbody>
                <?php
                $count = 0;
                $queryWallet = mysqli_query($con, "SELECT a.payment_id,a.walletAddress,a.addDate,b.currencyName FROM meddolic_user_wallet_address_details a, meddolic_config_currency_list b WHERE a.member_id='$memberId' AND a.currency_id=b.currency_id AND a.status=1 ORDER BY a.addDate DESC");
                while ($valWallet = mysqli_fetch_assoc($queryWallet)) {
                  $count++; ?>
                  <tr>
                    <td><?= $count ?></td>
                    <td><?= $valWallet['currencyName'] ?></td>
                    <td><?= $valWallet['walletAddress'] ?></td>
                    <!--<td><a href="javascript:void(0)" class="btn btn-danger btn-sm" onclick="deleteWalletAddress(<?= $valWallet['payment_id'] ?>)"><i class="fa fa-trash"></i> Delete</a></td>-->
                  </tr>
                <?php } ?>
              </tbody>
                        </table>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Footer -->
</div>



<?php include('include/footer.php'); ?>
    <script>
      const getOtpButton = document.getElementById('getOtp');

      getOtpButton.addEventListener('click', async () => {
        const memberId = <?= $memberId ?>;

        const data = await fetch('ajaxCalls/sendOtpAjax.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: `memberId=${encodeURIComponent(memberId)}`
        }).then(res => res.text());

        console.log(data);

        if (data.trim() == "success") {
          alert("OTP sent successfully");
        } else {
          alert("Failed to send OTP");
        }
      });
    </script>

    