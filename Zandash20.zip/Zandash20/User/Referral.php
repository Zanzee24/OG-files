<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>

<div class="body-wrapper">
    <div class="container-fluid">
        <div class="card card-body">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="d-sm-flex align-items-center justify-space-between">
                        <h4 class="fw-semibold fs-4 mb-4 mb-md-0 card-title">Referral </h4>
                        <nav aria-label="breadcrumb" class="ms-auto">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item d-flex align-items-center">
                                    <a class="text-muted text-decoration-none d-flex" href="dashboard.php">
                                        <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                        Referral 
                                    </span>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Fund Transfer Form -->
        
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Referral</h4>
                        <div class="table-responsive">
                            <table id="history_table" class="table table-bordered table-striped">
                                <thead >
                                    <tr>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th>From User</th>
                                        <th>To User</th>
                                        <th>Amount</th>
                                        <th>Wallet Type</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Replace with real database query
                                    $transfers = [
                                        [
                                            'date' => '2025-10-15',
                                            'from_user' => 'john123',
                                            'to_user' => 'mary456',
                                            'amount' => 150.00,
                                            'wallet' => 'Income Wallet',
                                            'status' => 'Success',
                                        ],
                                        [
                                            'date' => '2025-10-14',
                                            'from_user' => 'john123',
                                            'to_user' => 'david789',
                                            'amount' => 75.50,
                                            'wallet' => 'Purchase Wallet',
                                            'status' => 'Pending',
                                        ]
                                    ];

                                    $count = 1;
                                    foreach ($transfers as $transfer) {
                                        echo "<tr>
                                    <td>{$count}</td>
                                    <td>{$transfer['date']}</td>
                                    <td>{$transfer['from_user']}</td>
                                    <td>{$transfer['to_user']}</td>
                                    <td>$" . number_format($transfer['amount'], 2) . "</td>
                                    <td>{$transfer['wallet']}</td>
                                    <td><span class='badge " . ($transfer['status'] == 'Success' ? 'bg-success' : 'bg-warning') . "'>{$transfer['status']}</span></td>
                                </tr>";
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- You can keep the table section below as it is, just ensure data is populated dynamically -->

        <?php include 'Include/Footer.php'; ?>