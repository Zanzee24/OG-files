<?php include 'include/head.php'; ?> 
</body>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success"><i
					class="mdi mdi-archive"></i><span>P2P Exchange</span>
				</a>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
			<span>
				<img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
			</span>
		</a>
              <?php include 'include/sidebar.php'; ?> 
        
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>
                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Network</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Genealogy </a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Genealogy </h4>
                            </div>
                        </div>
                    </div>
                </div>


                                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>
                 <style>
                    .dashbord_box2 .tradingview-widget-container {
                        height: 500px !important;
                    }
                </style>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <!----<h4 class="card-title">Team Structure</h4>-->
                                <form action="" method="post">
                                    <div class="row">
                                        <div class="col-md-6">

                                            <div class="">
                                                <label class="control-label ">Search Here <span style="color:red">*</span></label>
                                                <div class="form-group label-floating is-empty ">
                                                    <label class="control-label"></label>
                                                    <input type="text" class="form-control" id="search_id" name="search_id" placeholder="Search Here">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-2 bgnt">
                                            <label class="control-label">&nbsp;</label>
                                            <button type="submit" class="btn btn-success">Search</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <button type="button" onclick="window.history.back()" class="btn btn-success mb-4">Back</button>
                                <div class="tree">

                                    <ul style="overflow-x: scroll;height:560px;">
                                        <li>
                                            <a href="https://www.bitcapitalx.com/User_action/tree_view_level/13681" class="tooltips" data-id="13681">
										<img
											src="https://www.bitcapitalx.com/application/libraries/red.png" /><br>Ms Rahi<br>BTC322524									</a>
                                            <ul>
                                                <li>
                                                    <a href="https://www.bitcapitalx.com/User_action/tree_view_level/13697" class="tooltips" data-id="13697">
														<img
															src="https://www.bitcapitalx.com/application/libraries/red.png" /><br>MD TANSIR ALAM<br>BTC303357													</a>
                                                </li>
                                                <li>
                                                    <a href="https://www.bitcapitalx.com/User_action/tree_view_level/14017" class="tooltips" data-id="14017">
														<img
															src="https://www.bitcapitalx.com/application/libraries/red.png" /><br>manisha<br>BTC401328													</a>
                                                </li>
                                            </ul>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php include 'include/footer.php'; ?> 