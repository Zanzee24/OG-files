<?php include 'include/head.php';
require_once("loginCheck.php");

?>

</body>

<body class="dark-mode">
    
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard.php" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard.php">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Manage Fund</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Fund Transfer</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Fund Transfer</h4>
                            </div>
                        </div>
                    </div>
                </div>


                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>
                <div class="row">

                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <form class="theme-form" action="mainToFundProcess" method="post">
                                    <div class="mb-3">
                                        <label>User ID -:</label>
                                        <input type="text" name="sponser_id" id="sponser_id" class="form-control"
                                            placeholder="e.g. xxxxxxxxxx" required value="<?= $userId ?>" readonly>
                                        <input type="hidden" name="loginMemberId" value="<?= $memberId ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Name -: </label>
                                        <input type="text" id="sponser_name" class="form-control"
                                            placeholder="e.g. John Doe" disabled="" value="<?= $userName ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Income Wallet -:</label>
                                        <input type="text" id="current_wallet" name="incomeWallet" class="form-control"
                                            readonly value="<?= $incomeWallet ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Purchase Wallet -:</label>
                                        <input type="text" id="current_wallet" name="fundWallet" class="form-control"
                                            readonly value="<?= $fundWallet ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Amount To Transfer -:</label>
                                        <input type="number" id="transferAmount" name="amount" class="form-control"
                                            placeholder="e.g. Transfer Amount" onkeypress="return onlynum(event)"
                                            required>
                                    </div>
                                    <div class="mb-3">
                                        <label>Transaction Password *</label>
                                        <input type="password" name="trnPassword" id="trnPassword" class="form-control"
                                            placeholder="e.g. Transaction Password" required>
                                    </div>

                                    <div class="">
                                        <button class="btn btn-primary" data-bs-original-title="" title="Transfer"
                                            name="fundTransfer" value="Transfer">Transfer</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">View Fund Transfer</h4>
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped   nowrap">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Date</th>
                                                <th>User Id</th>
                                                <th>User Name</th>
                                                <th>From Wallet</th>
                                                <th>To Wallet Wallet</th>
                                                <th>Transfer Amount</th>


                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <?php
                                        $count = 0;
                                        $queryTransfer = mysqli_query($con, "SELECT a.transferAmount,a.transferDate,a.incomeWallet,a.fundWallet,b.user_id,b.name FROM meddolic_user_income_wallet_transfer a, meddolic_user_details b WHERE a.memberId='$memberId' AND a.memberId=b.member_id ORDER BY a.transferDate DESC");
                                        while ($valTransfer = mysqli_fetch_assoc($queryTransfer)) {
                                            $count++; ?>
                                            <tr>
                                                <td><?= $count ?></td>
                                                <td><?= $valTransfer['user_id'] ?></td>
                                                <td><?= $valTransfer['name'] ?></td>
                                                <td><span class="badge badge-danger"><i class="fa fa-usd"></i>
                                                        <?= $valTransfer['transferAmount'] ?></span></td>
                                                <td><i class="fa fa-clock-o"></i>
                                                    <?= date("d-m-Y H:i:s", strtotime($valTransfer['transferDate'])) ?></td>
                                            </tr>
                                        <?php } ?>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
     <?php include 'include/footer.php'; ?>
<script>
var d = document.getElementById("Fund");
    d.className += " active";
var d = document.getElementById("income-Wallet");
    d.className += " active";
</script>
</body>

</html>