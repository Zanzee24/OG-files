<?php include 'include/head.php';
require_once("loginCheck.php");
function totalInvest($con, $memberId)
{
    $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'");
    $valInvest = mysqli_fetch_array($queryInvest);
    if ($valInvest[0] != "") {
        return $valInvest[0];
    } else {
        return "0.00";
    }
}

?>

<body class="dark-mode">
   

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard.php" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard.php">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Direct Team</li>
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Direct Team</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Direct Team</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false"
                    src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
                <script src="https://www.bitcapitalx.com/application/libraries/iconify-icon.min.js"></script>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Referral Team</h4>
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped nowrap">
                                        <thead>
                                            <tr>
                                                <th>S.NO</th>
                                                <th>UserId</th>
                                                <th>Name</th>
                                                <th>EmailId</th>
                                                <th>Phone</th>
                                                <th>Register Date</th>
                                                <th>Active Status</th>
                                                <th>Active Date</th>
                                                <th>Total Invest</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryDirect = mysqli_query($con, "SELECT member_id,user_id,name,email_id,phone,date_time,topup_flag,activation_date FROM meddolic_user_details WHERE sponser_id='$memberId' ORDER BY date_time DESC");
                                            while ($valDirect = mysqli_fetch_assoc($queryDirect)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valDirect['user_id'] ?></td>
                                                    <td><?= $valDirect['name'] ?></td>
                                                    <td><?= $valDirect['email_id'] ?></td>
                                                    <td><?= $valDirect['phone'] ?></td>
                                                    <td><i class="bi bi-clock"></i>
                                                        <?= date("d-m-Y H:i:s", strtotime($valDirect['date_time'])); ?></td>
                                                    <td>
                                                        <?php if ($valDirect['topup_flag'] == 1): ?>
                                                            <span class="badge bg-success">Active</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">Inactive</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?= $valDirect['activation_date'] ?></td>
                                                    <td><span class="badge bg-success"><i class="bi bi-currency-rupee"></i>
                                                            <?= totalInvest($con, $valDirect['member_id']) ?></span></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include 'include/footer.php'; ?>
        </div>
    </div>
    <script>
  var d = document.getElementById("Team");
  d.className += " active";
  var d = document.getElementById("view_direct_downline.php");
  d.className += " active";
</script>
</body>

</html>