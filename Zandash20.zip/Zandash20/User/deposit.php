<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>

<div class="body-wrapper">
    <div class="container-fluid">
        <div class="card card-body">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="d-sm-flex align-items-center justify-space-between">
                        <h4 class="fw-semibold fs-4 mb-4 mb-md-0 card-title">Fund Add</h4>
                        <nav aria-label="breadcrumb" class="ms-auto">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item d-flex align-items-center">
                                    <a class="text-muted text-decoration-none d-flex" href="dashboard.php">
                                        <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                        Fund Add
                                    </span>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>

        <!-- Fund Transfer Form -->
        <div class="row">
            <div class="col-lg-12 d-flex align-items-stretch">
                <div class="card w-100">
                    <form action="process_fund_transfer.php" method="post">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <h4 class="card-title mb-0">Fund Add</h4>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="user_id" class="form-label">User ID</label>
                                        <input type="text" class="form-control" id="user_id" name="user_id" placeholder="Enter User ID">
                                    </div>
                                    <div class="mb-3">
                                        <label for="user_name" class="form-label">Name</label>
                                        <input type="text" class="form-control" id="user_name" name="user_name" placeholder="Full Name Here">
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="income_wallet">Income Wallet:</label>
                                        <input type="text" id="income_wallet" name="income_wallet" class="form-control" readonly value="$1000">
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                       <label class="form-label">Payment Slip*</label>
                                        <input type='file' name="transactionImage" required class="form-control" accept=".jpg, .png, .gif, .jpeg, .PNG, .GIF, .JPG, .JPEG"/>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="amount" class="form-label">Amount</label>
                                        <div class="input-group">
                                            <span class="input-group-text">$</span>
                                            <input type="number" step="0.01" name="amount" class="form-control" id="amount" placeholder="Amount" required>
                                            <span class="input-group-text">.00</span>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="trnPassword">Transaction Password *</label>
                                        <input type="password" name="trnPassword" id="trnPassword" class="form-control" placeholder="e.g. Transaction Password" required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="p-3 border-top text-center">
                            <button type="submit" class="btn btn-primary">Save</button>
                            <a href="dashboard.php" class="btn bg-danger-subtle text-danger ms-3 px-4">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Fund Transfer History</h4>
                        <div class="table-responsive">
                            <table id="history_table" class="table table-bordered table-striped">
                                <thead >
                                    <tr>
                                        <th>#</th>
                                        <th>Date</th>
                                        <th> User</th>
                                       
                                        <th>Amount</th>
                                        <th>Wallet Type</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Replace with real database query
                                    $transfers = [
                                        [
                                            'date' => '2025-10-15',
                                            'from_user' => 'john123',
                                           
                                            'amount' => 150.00,
                                            'wallet' => 'Income Wallet',
                                            'status' => 'Success',
                                        ],
                                        [
                                            'date' => '2025-10-14',
                                            'from_user' => 'john123',
                                            
                                            'amount' => 75.50,
                                            'wallet' => 'Purchase Wallet',
                                            'status' => 'Pending',
                                        ]
                                    ];

                                    $count = 1;
                                    foreach ($transfers as $transfer) {
                                        echo "<tr>
                                    <td>{$count}</td>
                                    <td>{$transfer['date']}</td>
                                    <td>{$transfer['from_user']}</td>
                                   
                                    <td>$" . number_format($transfer['amount'], 2) . "</td>
                                    <td>{$transfer['wallet']}</td>
                                    <td><span class='badge " . ($transfer['status'] == 'Success' ? 'bg-success' : 'bg-warning') . "'>{$transfer['status']}</span></td>
                                </tr>";
                                        $count++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- You can keep the table section below as it is, just ensure data is populated dynamically -->

        <?php include 'Include/Footer.php'; ?>