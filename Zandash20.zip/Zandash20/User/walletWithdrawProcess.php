<br><br><br>
<center>
	<h2>Processing your request!!!</h2>
	<h3>Please do not press back or refresh!!!</h3>
</center>
<?php


include("loginCheck.php");

if (isset($_POST['walletWithdraw'])) {
	$newToken = $_SESSION['withdrawTokenSet'];
	$goodFile = mysqli_real_escape_string($con, $_POST['goodFile']);
	if ($goodFile == $newToken) {
		$memberId = $_POST['member_id'];
		$withdrawAmount = $_POST['withdrawAmount'];
		$paymentId = $_POST['paymentId'];
		$trnPassword = $_POST['trnPassword'];
		$walletType = $_POST['walletType'];

		$d = date("Y-m-d H:i:s");
		$todayDate = date('Y-m-d');
?>


		<?php

		$currentDay = date("N"); // 1 (for Monday) through 7 (for Sunday)

		$currentTime = date("H:i:s");

// 		Check if time is between 08:00:00 and 12:00:00
		if (!($currentTime >= "08:00:00" && $currentTime <= "12:00:00")) {
		?>
			<script>
				alert("Withdrawals are only allowed between 08:00 AM and 12:00 PM (noon).");
				window.top.location.href = 'view_withdrwal';
			</script>
		<?php
			exit;
		}

		// if ($walletType == 'roiWallet') {
		// 	if ($todayDay != 5) {
		// 		echo "<script>alert('Withdrawals from ROI Wallet are allowed only on the 5th of every month.'); window.location.href='view_withdrwal.php';</script>";
		// 		exit;
		// 	}
		// }


		$queryCheck = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details where member_id='$memberId' AND trnPassword='$trnPassword'");
		$valCheck = mysqli_fetch_array($queryCheck);
		if ($valCheck[0] == 0) { ?>
			<script>
				alert("Incorrect Transaction Password!!!");
				window.top.location.href = 'view_withdrwal.php';
			</script>
		<?php
			exit;
		}


		if ($withdrawAmount == 0 || $withdrawAmount < 0) { ?>
			<script>
				alert("Invalid Withdraw Amount!!!");
				window.top.location.href = "view_withdrwal.php";
			</script>
		<?php
			exit;
		}

		?>

		<?php

		$queryWallet = mysqli_query($con, "SELECT " . $walletType . " FROM meddolic_user_details WHERE member_id='$memberId'");
		$valWallet = mysqli_fetch_array($queryWallet);
		$currentWallet = $valWallet[0];


		if ($currentWallet < $withdrawAmount) { ?>
			<script>
				alert("Insufficient Balance in Your Wallet To Withdraw");
				history.go(-1);
			</script>
		<?php
			exit;
		}




		$queryWallet = mysqli_query($con, "SELECT walletAddress FROM meddolic_user_wallet_address_details WHERE member_id='$memberId'");
		$valWallet = mysqli_fetch_array($queryWallet);
		$walletAddress = $valWallet[0];

		if ($walletAddress == "") { ?>
			<script>
				alert("fill Your Wallet Address ??");
				window.top.location.href = "view_withdrwal.php";
				
			</script>
		<?php
			exit;
		}


		$orderId = rand(11101, 99999) . $memberId . date('s') . date('h');

		$queryCharge = mysqli_query($con, "SELECT withdrawCharge FROM meddolic_config_misc_setting");
		$valCharge = mysqli_fetch_assoc($queryCharge);
		$withdrawCharge = $valCharge['withdrawCharge'];


		$charge = $withdrawAmount * $withdrawCharge / 100;
		$netAmount = $withdrawAmount - $charge;



		$queryIn = mysqli_query($con, "INSERT INTO meddolic_user_wallet_withdrawal_crypto (`member_id`,`date_time`,`amount`,`withdrawCharge`,`netAmount`,`paymentId`,`orderid`,`walletType`) VALUES ('$memberId','$d','$withdrawAmount','$withdrawCharge','$netAmount','$paymentId','$orderId','$walletType')");
		$lastWithdraw = $con->insert_id;

		mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`,`date_time`,`trn_id`) VALUES ('$memberId',10,1,'$withdrawAmount','$d','$lastWithdraw')");


		mysqli_query($con, "UPDATE meddolic_user_details SET $walletType= ($walletType - $withdrawAmount) WHERE member_id='$memberId'");



		unset($_SESSION['withdrawTokenSet']); ?>
		<script>
			alert("Wallet Withdraw Successfully");
			window.top.location.href = "view_withdrwal.php";
		</script>
	<?php } else { ?>
		<script>
			alert('Your Session Expired.Please re Submit your Request Again');
			window.top.location.href = "view_withdrwal.php";
		</script>
<?php }
}

?>

<?php include("../close-connection.php"); ?>