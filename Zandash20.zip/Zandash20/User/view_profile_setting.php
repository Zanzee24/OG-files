<?php include 'include/head.php'; 
include("loginCheck.php");
$queryProfile = mysqli_query($con, "SELECT countryId,date_time,sponser_id FROM meddolic_user_details WHERE user_id='$userId'");
if (!$queryProfile) {
    die("Error: " . mysqli_error($con));
}
$valProfile = mysqli_fetch_assoc($queryProfile);
$dateTime = $valProfile['date_time'];
$sponserId = $valProfile['sponser_id'];
$countryId = $valProfile['countryId'];
if ($countryId != '') {
    $queryCountry = mysqli_query($con, "SELECT countryName FROM meddolic_config_country_list WHERE country_id='$countryId'");
    if (!$queryCountry) {
        die("Error: " . mysqli_error($con));
    }
    $valCountry = mysqli_fetch_assoc($queryCountry);
    $countryName = $valCountry['countryName'];
}
?>
<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success">
                        <i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>
                
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Profile Settings</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Profile Settings</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row p-3">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="profile-header mb-4 text-center">
                                    <div class="profile-avatar mx-auto mb-3"><?= substr("", 0, 2) ?></div>
                                    <h2><?= $valProfile['userName'] ?></h2>
                                    <p class="text-muted">Your Profile</p>
                                </div>

                                <form class="form" action="my-profileupdate.php" method="POST">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h5 class="mb-3"><i class="bi bi-person-lines-fill"></i> Personal Information</h5>
                                            
                                            <!-- Full Name Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">Full Name *</label>
                                                <input class="form-control" data-val="true" data-val-regex="Please enter only alphabets" data-val-regex-pattern="^[a-zA-Z\s]+$" data-val-required="Name is Required" id="Memb_Name" name="userName" placeholder="Name" required type="text" value="<?= $userName ?>" readonly required type="text" />
                                                <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                            </div>
                                            
                                            <!-- Mobile No Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">Mobile No *</label>
                                                <input class="form-control" data-val-required="Mobile No is Required" id="MobNo" name="phone" placeholder="Mobile Number" type="number" value="<?= $phone ?>" onkeypress="return onlynum(event)" />
                                            </div>
                                            
                                            <!-- Email ID Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">Email ID *</label>
                                                <input class="form-control" data-val="true" data-val-regex="Enter Valid Email Id" data-val-regex-pattern="^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z\-])+\.)+([a-zA-Z]{2,6})$" data-val-required="Email Id is Required" id="EmailID" name="emailId" placeholder="Email ID" type="email" value="<?= $emailId ?>" />
                                            </div>
                                            
                                            <!-- Country Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label required-label">
                                                    <i class="bi bi-globe"></i> Country
                                                </label>
                                                <select class="form-control" required id="M_COUNTRY" name="countryId">
                                                    <option value="">Select Country</option>
                                                    <?php 
                                                    $queryCountry = "SELECT * FROM meddolic_config_country_list WHERE status=1 ORDER BY countryName ASC";
                                                    $resultCountry = mysqli_query($con, $queryCountry);
                                                    while ($valCountry = mysqli_fetch_assoc($resultCountry)) { ?>
                                                        <option value="<?= $valCountry['country_id'] ?>" <?php if ($valCountry['country_id'] == $countryId) echo "selected"; ?>>
                                                            <?= $valCountry['countryName'] ?>
                                                        </option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            
                                            <!-- Buttons placed below email field -->
                                            <div class="mt-4 pt-2">
                                                <button type="submit" name="profileUpdate"class="btn btn-primary">Update Profile</button>
                                                <button type="reset" class="btn btn-secondary ms-2">Reset</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include 'include/footer.php'; ?>
        </div>
    </div>
</body>
</html>