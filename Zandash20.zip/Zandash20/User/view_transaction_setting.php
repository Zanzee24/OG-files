<?php include 'include/head.php';
require_once("loginCheck.php");

$queryProfile = mysqli_query($con, "SELECT date_time,sponser_id FROM meddolic_user_details WHERE user_id='$userId'");
$valProfile = mysqli_fetch_assoc($queryProfile);
$dateTime = $valProfile['date_time'];
$sponserId = $valProfile['sponser_id'];

if ($countryId != '') {
    $queryCountry = mysqli_query($con, "SELECT countryName FROM meddolic_config_country_list WHERE country_id='$countryId'");
    $valCountry = mysqli_fetch_assoc($queryCountry);
    $countryName = $valCountry['countryName'];
}



?>

<body class="dark-mode">
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <?php include 'include/header.php'; ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Transaction Security</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Transaction Security</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row p-3">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <form class="form" action="my-profileupdate.php" method="POST">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <!-- Current Transaction Password Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">Current Transaction Password *</label>
                                                <div class="password-input-container">
                                                    <input type="password" class="form-control" id="currentPass" placeholder="Enter current password" data-rule-required="true" name="password">
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                </div>
                                                <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                            </div>

                                            <!-- New Transaction Password Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">New Transaction Password *</label>
                                                <div class="password-input-container">
                                                    <input type="password" class="form-control" id="loginPassword" placeholder="Enter new password"
                                                        onkeyup="checkPasswordStrength(this.value)" data-rule-required="true" name="password1">
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                </div>
                                                <div class="password-strength mt-2">
                                                    <div class="strength-meter" id="strengthMeter"></div>
                                                </div>
                                               
                                            </div>

                                            <!-- Confirm Transaction Password Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">Retype Transaction Password *</label>
                                                <div class="password-input-container">
                                                    <input type="password" class="form-control" id="confirmLoginPassword"
                                                        placeholder="Confirm new password" onkeyup="checkPasswordMatch()" data-rule-required="true" name="password2">
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                </div>
                                                <div id="passwordMatchMsg" class="mt-2"></div>
                                            </div>

                                            <div class="form-group mt-4">
                                                <button type="submit" class="btn btn-primary" name="changeTrn">Update Transaction Password</button>
                                                <button type="reset" class="btn btn-secondary ms-2">Reset</button>
                                            </div>
                                        </div>
                                        <div class="col-md-6" style="margin-top: 20px;">
                                           
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                // Password strength checker
                function checkPasswordStrength(password) {
                    const strengthMeter = document.getElementById('strengthMeter');
                    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,15}$/;
                    const errorDiv = document.getElementById("passwordError");

                    if (regex.test(password)) {
                        errorDiv.style.display = "none";
                        strengthMeter.style.width = '100%';
                        strengthMeter.style.backgroundColor = 'green';
                    } else {
                        errorDiv.style.display = "block";
                        strengthMeter.style.width = '30%';
                        strengthMeter.style.backgroundColor = 'red';
                    }
                }

                // Password match checker
                function checkPasswordMatch() {
                    const password = document.getElementById('loginPassword').value;
                    const confirmPassword = document.getElementById('confirmLoginPassword').value;
                    const message = document.getElementById('passwordMatchMsg');

                    if (password === confirmPassword && password !== '') {
                        message.innerHTML = '<span class="text-success"><i class="bi bi-check-circle-fill"></i> Passwords match!</span>';
                    } else if (confirmPassword !== '') {
                        message.innerHTML = '<span class="text-danger"><i class="bi bi-exclamation-circle-fill"></i> Passwords do not match!</span>';
                    } else {
                        message.innerHTML = '';
                    }
                }

                // Toggle password fields visibility
                document.querySelectorAll('.password-toggle').forEach(function(toggle) {
                    toggle.addEventListener('click', function() {
                        const input = this.parentElement.querySelector('input');
                        if (input.type === 'password') {
                            input.type = 'text';
                            this.innerHTML = '<i class="bi bi-eye-slash"></i>';
                        } else {
                            input.type = 'password';
                            this.innerHTML = '<i class="bi bi-eye"></i>';
                        }
                    });
                });
                var d = document.getElementById("Profile");
                d.className += " active";
                var d = document.getElementById("transaction.php");
                d.className += " active";
            </script>

            <?php include 'include/footer.php'; ?>
        </div>
    </div>
</body>

</html>