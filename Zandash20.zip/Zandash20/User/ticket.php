<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>

<div class="body-wrapper">
    <div class="container-fluid">
        <div class="card card-body">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="d-sm-flex align-items-center justify-space-between">
                        <h4 class="fw-semibold fs-4 mb-4 mb-md-0 card-title">Support </h4>
                        <nav aria-label="breadcrumb" class="ms-auto">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item d-flex align-items-center">
                                    <a class="text-muted text-decoration-none d-flex" href="dashboard.php">
                                        <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                        Support
                                    </span>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        

        <!-- Fund Transfer Form -->
        <div class="row">
            <div class="row mb-3">
                        <div class="col-12">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#ticketModal">
                                <i class="mdi mdi-plus-circle-outline"></i> Create New Ticket
                            </button>
                        </div>
                    </div>
            
        </div>
        <div class="row mt-4">
            <div class="col-12">
                                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">All Outbox Tickets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped"
                                            id="tickets-table">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th width="5%">#</th>
                                                    <th width="15%">Ticket No</th>
                                                    <th width="15%">Subject</th>
                                                    <th width="25%">Message</th>
                                                    <th width="10%">Priority</th>
                                                    <th width="10%">Raise Date</th>
                                                    <th width="10%">Last Update</th>
                                                    <th width="10%">Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">All Inbox Tickets</h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-hover table-striped" id="inbox-table">
                                            <thead class="thead-dark">
                                                <tr>
                                                    <th width="5%">#</th>
                                                    <th width="25%">Subject</th>
                                                    <th width="50%">Message</th>
                                                    <th width="20%">Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
         <div class="modal fade" id="ticketModal" tabindex="-1" role="dialog" aria-labelledby="ticketModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <form action="SupportProcess" method="POST" enctype="multipart/form-data">
                            <div class="modal-header bg-primary text-white">
                                <h5 class="modal-title">Create New Support Ticket</h5>
                                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row mb-3">
                                    <div class="col-md-6">
                                        <label for="subjectId" class="form-label">Subject</label>
                                        <select class="form-select" id="subjectId" name="subjectId" required>
                                            <option value="" selected disabled>Select Subject</option>
                                            
                                        </select>
                                        <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="priorityId" class="form-label">Priority</label>
                                        <select class="form-select" id="priorityId" name="priorityId" required>
                                            <option value="" selected disabled>Select Priority</option>
                                           
                                        </select>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="ticketMessage" class="form-label">Message</label>
                                    <textarea class="form-control" id="ticketMessage" name="ticketMessage" rows="6"
                                        placeholder="Describe your issue in detail..."
                                        style="color: #000000; background-color: #ffffff;" required></textarea>
                                </div>

                                <div class="mb-3">
                                    <label for="ticketAttachment" class="form-label">Attachment (Optional)</label>
                                    <input class="form-control" type="file" id="ticketAttachment"
                                        name="ticketAttachment">
                                    <div class="form-text">Max file size: 5MB (JPEG, PNG, PDF only)</div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary" name="supportTicket">Submit
                                    Ticket</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        <!-- You can keep the table section below as it is, just ensure data is populated dynamically -->

        <?php include 'Include/Footer.php'; ?>