
<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="dark" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Favicon icon-->
  <link rel="shortcut icon" type="image/png" href="assets/assets/images/logos/favicon.png" />

  <!-- Core Css -->
  <link rel="stylesheet" href="assets/assets/css/styles.css" />
  <title>Zanthium</title>
</head>
<Style>
     .input-group-text {
            background-color: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #fff;
            cursor: pointer;
        }
</Style>
<body>
  <!-- Preloader -->
  <div class="preloader">
    <img src="assets/assets/images/logos/favicon.png" alt="loader" class="lds-ripple img-fluid" />
  </div>
  <div id="main-wrapper">
    <div class="position-relative overflow-hidden radial-gradient min-vh-100 w-100">
      <div class="position-relative z-index-5">
        <div class="row">
          <div class="col-lg-6 col-xl-7 col-xxl-6 position-relative overflow-hidden bg-dark d-none d-lg-block">
            <div class="circle-top"></div>
            <div>
              <img src="assets/assets/images/logos/logo-icon.png" class="circle-bottom" alt="Logo-Dark" />
            </div>
            <div class="d-lg-flex align-items-center z-index-5 position-relative h-n80">
              <div class="row justify-content-center w-100">
                <div class="col-lg-7">
                  <h2 class="text-white fs-10 mb-3">
                    Welcome to
                    <br />
                    Zanthium
                  </h2>
                  <span class="opacity-75 fs-4 text-white d-block mb-3">Zanthium helps developers to build organized
                    and well
                    coded dashboards full of beautiful and rich modules.
                  </span>
                  <!-- <a href="../landingpage/index.html" class="btn btn-primary">Learn More</a> -->
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-xl-5 col-xxl-6">
            <div class="min-vh-100 bg-body row justify-content-center justify-content-lg-start align-items-center p-5">
              <div class="col-sm-8 col-md-9 col-xxl-6 auth-card">
                <a href="../index.html" class="text-nowrap logo-img d-block w-100">
                  <img src="assets/assets/images/logos/logo-icon.png" class="dark-logo" alt="Logo-Dark" />
                </a>
                <h2 class="mb-2 mt-4 fs-7 fw-bolder">Sign In</h2>
                
               
                <div class="position-relative text-center my-4">
                  <p class="mb-0 fs-4 px-3 d-inline-block bg-body text-dark z-index-5 position-relative">
                     sign in
                  </p>
                  <span class="border-top w-100 position-absolute top-50 start-50 translate-middle"></span>
                </div>
                <form class="form-signin" method="post">
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Username</label>
                   <input type="text" id="inputUserId"  class="form-control" data-val="true" 
                                    data-val-required="User ID is Required" placeholder="User ID" required
                                    value="ZT112233" />
                  </div>
                  <div class="mb-4">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                    <input type="password" class="form-control" 
                                        data-val="true" data-val-required="Password is Required" 
                                        id="inputPassword" name="password" placeholder="Password" required 
                                        onkeypress="return catchEnter(event)"
                                        value="123456" />
                                   
                  </div>
                  <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1" 
                                        <?php if (isset($_COOKIE['memberUserId'])) { echo 'checked'; } ?>>
                      <label class="form-check-label text-dark" for="flexCheckChecked">
                        Remeber this Device
                      </label>
                    </div>
                    <a class="text-primary fw-medium" href="forgot_password.php">Forgot Password ?</a>
                  </div>
                  <button type="button" id="loginSubmit"  class="btn btn-primary w-100 py-8 mb-4 rounded-2" onclick="LoginValidate()">Login </button>
                  <div class="d-flex align-items-center justify-content-center">
                    <p class="fs-4 mb-0 fw-medium">New to Zanthium?</p>
                    <a class="text-primary fw-medium ms-2" href="../registration.php">Create an
                      account</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="dark-transparent sidebartoggler"></div>
  <!-- Import Js Files -->
  <script src="assets/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/assets/libs/simplebar/dist/simplebar.min.js"></script>
  <script src="assets/assets/js/theme/app.dark.init.js"></script>
  <script src="assets/assets/js/theme/theme.js"></script>
  <script src="assets/assets/js/theme/app.min.js"></script>

  <!-- solar icons -->
  <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
   <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/third_party/custom.js"></script>
    <script src="custom.js"></script>
   <script>
        function send_otp_user_email(id) {
            var txtuserid = $('#' + id).val();
            if (txtuserid != '') {
                var result = confirm("Want to send otp");
                if (result) {
                    $.ajax({
                        type: "POST",
                        url: "https://bitcapitalx.com/get_details/send_otp_user_email",
                        dataType: 'json',
                        data: {
                            'txtintuserid': txtuserid
                        },
                        success: function (msg) {
                            $("#divtotp").html(msg);
                        }
                    });
                }
            } else {
                alert("Please Enter USER ID");
            }
        }

        function togglePasswordVisibility() {
            var passwordInput = document.getElementById("inputPassword");
            var eyeIcon = document.getElementById("eyeIcon");
        
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            } else {
                passwordInput.type = "password";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            }
        }
        
        function catchEnter(e) {
            if(e.keyCode === 13) {
                LoginValidate();
                return false;
            }
            return true;
        }
    </script>
</body>

</html>