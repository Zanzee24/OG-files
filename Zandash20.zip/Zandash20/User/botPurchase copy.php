<?php include 'include/head.php';
require_once("loginCheck.php");
$queryDetails = mysqli_query($con, "SELECT member_id,name,user_id FROM meddolic_user_details WHERE user_id='$userId'");
$valUser = mysqli_fetch_array($queryDetails);
$name1 = $valUser['name'];
$memberId1 = $valUser['member_id'];
$userId1 = $valUser['user_id'];
?>

<?php
$querySponser = mysqli_query($con, "SELECT packageId,packageStart FROM meddolic_config_bot_package_type WHERE packageStatus='1'");
$valSponser = mysqli_fetch_array($querySponser);
$botPackage = $valSponser['packageStart'];
$packageId = $valSponser['packageId'];
?>
</body>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard.php" class="btn btn-success"><i class="mdi mdi-archive"></i><span>P2P
                            Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard.php" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>
                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <form class="theme-form" action="botPurchaseProcess" method="post">
                                    <div class="mb-3">
                                        <label>UserId *</label>
                                        <input type="text" name="sponser_id" id="sponser_id" class="form-control" readonly value="<?= $userId ?>"
                                            placeholder="Enter User Id" onblur="sponser_valid(this.value)" required>
                                        <input type="hidden" name="loginMemberId" value="<?= $memberId ?>">
                                        <input type="hidden" name="packageId" value="<?= $packageId ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Name </label>
                                        <input type="text" id="sponser_name" class="form-control" value="<?= $userName ?>"
                                            placeholder="e.g. Name" disabled readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label>Fund Wallet </label>
                                        <input type="text" id="current_wallet" name="current_wallet"
                                            class="form-control" readonly value="<?= $fundWallet ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Package </label>
                                        <input type="text" id="botPackage" name="botPackage"
                                            class="form-control" readonly value="<?= $botPackage ?>">

                                    </div>
                                    <div class="mb-3">
                                        <label>Transaction Password *</label>
                                        <input type="password" name="trnPassword" class="form-control" required
                                            placeholder="Enter Transaction Password">
                                    </div>
                                    <div class="">
                                        <button type="submit" class="btn btn-primary" title="Purchase Now"
                                            name="botpurchase" value="Purchase Now">Purchase Now</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>



                <script src="https://www.bitcapitalx.com/application/third_party/js/depositeusdt.js?v=1.2"
                    type="module"></script>

                <script>
                    function get_token(id) {

                        if (id > 0) {
                            $.ajax({
                                type: "POST",
                                url: baseUrl + "get_details/get_token",
                                dataType: 'json',
                                data: {
                                    "package": id
                                },
                                // beforeSend: function() {
                                // opblockUI();
                                // },
                                // complete: function() {
                                // $.unblockUI();
                                // },
                                success: function(res) {
                                    $('#zp_token').val(res);

                                }
                            });
                        }
                    }
                </script>
            </div>
        </div>
        <?php include 'include/footer.php'; ?>
        <script>
            function checkUserDetails(userId) {
                if (userId != "") {
                    window.top.location.href = "botPackage?userId=" + userId;
                }
            }
            var d = document.getElementById("botPackage");
            d.className += " active";
        </script>