<?php
require_once("loginCheck.php");
include 'include/header.php';
include 'include/head.php';


?>
</body>

<body class="dark-mode">
    <!-- Modal -->

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Reward Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Reward Income</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>


                <!-- Referral Team Section -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Reward Income</h4>
                            <div class="table-responsive">
                                <table class="table dataTable table-border w-100 table-striped nowrap" id="export-button">
                                     <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>User Id</th>
                                                <th>Name</th>
                                                <th>Amount</th>
                                                <th>Release Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryDeal = mysqli_query($con, "SELECT a.rewardIncome,a.dateTime,b.user_id,b.name FROM meddolic_user_reward_income a, meddolic_user_details b WHERE a.summaryId='$_GET[summaryId]' AND a.memberId=b.member_id AND releaseStatus=1 ORDER BY a.dateTime DESC");
 
                                            while ($valDeal = mysqli_fetch_assoc($queryDeal)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valDeal['user_id'] ?></td>
                                                    <td><?= $valDeal['name'] ?></td>
                                                    <td><span class="badge badge-success"><i class="fa fa-usd"></i> <?= $valDeal['rewardIncome'] ?></span></td>
                                                    <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valDeal['dateTime'])); ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>

                                   

                                </table>
                            </div>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var d = document.getElementById("mlm_reports");
        d.className += " active";
        var d = document.getElementById("rewardIncome.php");
        d.className += " active";
    </script>

    <?php include 'include/footer.php'; ?>