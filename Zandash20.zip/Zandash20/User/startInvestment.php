<?php include 'include/head.php';
require_once("loginCheck.php");
$queryDetails = mysqli_query($con, "SELECT member_id,name,user_id FROM meddolic_user_details WHERE user_id='$userId'");
$valUser = mysqli_fetch_array($queryDetails);
$name1 = $valUser['name'];
$memberId1 = $valUser['member_id'];
$userId1 = $valUser['user_id'];
?>
</body>

<body class="dark-mode">
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard.php" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>
                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <form class="theme-form" action="startInvestmentAuth" method="post">
                                    <div class="mb-3">
                                        <label>UserId *</label>
                                        <input type="text" name="sponser_id" id="sponser_id" class="form-control" readonly value="<?= $userId ?>"
                                            placeholder="Enter User Id" onblur="sponser_valid(this.value)" required>
                                        <input type="hidden" name="loginMemberId" value="<?= $memberId ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Name </label>
                                        <input type="text" id="sponser_name" class="form-control" value="<?= $userName ?>"
                                            placeholder="e.g. Name" disabled readonly>
                                    </div>
                                    <div class="mb-3">
                                        <label>Fund Wallet </label>
                                        <input type="text" id="current_wallet" name="current_wallet"
                                            class="form-control" readonly value="<?= $fundWallet ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Package </label>
                                        <select class="form-control" name="packageId" required>
                                            <!-- <option value=""> Select One </option> -->
                                            <?php $queryMode = mysqli_query($con, "SELECT * FROM  meddolic_config_package_type WHERE packageStatus=1 ORDER BY packageId ASC");
                                            while ($valMode = mysqli_fetch_assoc($queryMode)) { ?>
                                                <option value="<?= $valMode['packageId'] ?>"> <?= $valMode['startPackage'] ?> $ <?= $valMode['endPackage'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <div class="mb-3">
                                        <label>Package Amount *</label>
                                        <input type="text" id="packageAmount" name="packageAmount" required class="form-control" placeholder="Enter Package Amount">
                                    </div>
                                    <div class="mb-3">
                                        <label>Transaction Password *</label>
                                        <input type="password" name="trnPassword" class="form-control" required placeholder="Enter Transaction Password">
                                    </div>
                                    <div class="">
                                        <button type="submit" class="btn btn-primary" title="Purchase Now" name="startInvest" value="Purchase Now">Purchase Now</button>
                                    </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>



            
            </div>
        </div>
        <?php include 'include/footer.php'; ?>
        <script>
            // function checkUserDetails(userId) {
            //     if (userId != "") {
            //         window.top.location.href = "startInvestment?userId=" + userId;
            //     }
            // }
            var d = document.getElementById("startInvestment");
            d.className += " active";
        </script>