<?php 
include("loginCheck.php");
include("../conection.php");
if(isset($_POST['profileUpdate'])){
    $userName=$_POST['userName'];
    $phone=$_POST['phone'];
    $emailId=$_POST['emailId'];
    $countryId=$_POST['countryId'];
    // $dateofBirth =$_POST['dateofBirth'];
    // $address=$_POST['address'];
    // $nomineeName=$_POST['nomineeName'];
    // $nomineeRelation=$_POST['nomineeRelation'];
    $d=date("Y-m-d H:i:s");

    mysqli_query($con,"UPDATE meddolic_user_details SET name='$userName',email_id='$emailId',countryId='$countryId',phone='$phone' WHERE user_id='$userId'"); ?>
    <script>
      alert("Profile Updated Successfully!!!");
      window.top.location.href="view_profile_setting.php";
    </script>
    <?php }

    
   if(isset($_POST['addWalletAddress'])){
    $currencyId=$_POST['currencyId'];
    $memberId=$_POST['memberId'];
    $trnPassword=$_POST['trnPassword'];
    $walletAddress=$_POST['walletAddress'];
    $d=date("Y-m-d H:i:s");
    $queryCheck=mysqli_query($con,"SELECT COUNT(1) FROM meddolic_user_details where   trnPassword='$trnPassword'");
	$valCheck=mysqli_fetch_array($queryCheck);
	if($valCheck[0]==0) { ?>
	    <script>
	      alert("Incorrect Transaction Password!!!");
		  history.go(-1);
	    </script>
	    <?php
	    exit;
	}
     $queryIn=mysqli_query($con,"INSERT INTO meddolic_user_wallet_address_details (`currency_id`,`member_id`,`walletAddress`,`addDate`) VALUES ('$currencyId','$memberId','$walletAddress','$d')");
    if($queryIn){  ?>
        <script>
            alert('Wallet Address Added Successfully');
            window.top.location.href="walletAddressAdd";
        </script>
        <?php
        exit;
    }else{ ?>
        <script>
            alert('Wallet Address Not Added...Try Again');
            window.top.location.href="walletAddressAdd";
        </script>
        <?php
        exit;
    } }
  
    
  if(isset($_POST['changeLogin'])){    
    $memberId=$_POST['memberId'];
    $password=$_POST['password'];
    $password1=$_POST['password1'];
    $password2=$_POST['password2'];
    $d=date("Y-m-d H:i:s");

    if($password2!=$password1){ ?>
        <script>
        alert("New Login passwords do not match!!!");
         window.top.location.href='view_security_setting.php';
        </script>
        <?php
        exit;   
    }

    $result=mysqli_query($con,"SELECT count(*) FROM meddolic_user_details WHERE member_id='$memberId' AND password='$password'");
    $val=mysqli_fetch_array($result);
    if($val[0]==0) { ?>
        <script>
            alert("Incorrect Current Login password!!!");
            window.top.location.href='view_security_setting.php';
        </script>
        <?php
        exit;
    }

    $result1=mysqli_query($con,"UPDATE meddolic_user_details SET password='$password1' WHERE member_id='$memberId'");
    if($result1){
        unset($_SESSION['user_member_id']);
        unset($_SESSION['member_user_id']);
        unset($_SESSION['member_password']); ?>
        <script>
            alert("Login Password Updated Successfully!!!\nNow please login again with new password. ");
            window.top.location.href='auth.php';
        </script>
         <?php
    } }
if(isset($_POST['changeTrn'])){
    $memberId=$_POST['memberId'];
    $password=$_POST['password'];
    $password1=$_POST['password1'];
    $password2=$_POST['password2'];
    $d=date("Y-m-d H:i:s");
    if($password2!=$password1){ ?>
        <script>
        alert("New Login passwords do not match!!!");
         window.top.location.href='view_security_setting.php';
        </script>
        <?php
        exit;
        
     }

    $result=mysqli_query($con,"SELECT count(*) FROM meddolic_user_details WHERE member_id='$memberId' AND trnPassword='$password'");
     $val=mysqli_fetch_array($result);
     if($val[0]==0) { ?>
        <script>
        alert("Incorrect Current Transaction password!!!");
         window.top.location.href='view_security_setting.php';
        </script>
        <?php
        exit;
     }
   
    $result1=mysqli_query($con,"UPDATE meddolic_user_details SET trnPassword='$password1' WHERE member_id='$memberId'");
    if($result1){ ?>
        <script>
            alert("Transaction Password Updated Successfully!!!");
            window.top.location.href='view_security_setting.php';
        </script>
         <?php
    } } ?>
<?php include("../close-connection.php"); ?>