<?php include 'include/head.php'; ?>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="https://www.bitcapitalx.com/p2p_exchnange/dashboard" class="btn btn-success">
                        <i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
				<img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="https://www.bitcapitalx.com/Userprofile/dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Rank AND Reward Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Rank AND Reward Income</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Rank AND Reward Income</h4>
                                <form action="https://www.bitcapitalx.com/user_report/view_level_report/6/Rank AND Reward" 
                                      class="cmxform form-horizontal" id="signupForm" method="post" accept-charset="utf-8">
                                    <div class="row">
                                        <div class="col-sm-2 col-6">
                                            <div class="form-group">
                                                <input type="date" placeholder="Date" value="" class="form-control" 
                                                       placeholder="From Date" name="start" id="start">
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-6">
                                            <div class="form-group">
                                                <input type="date" placeholder="Date" value="" class="form-control" 
                                                       placeholder="To Date" name="end" id="end">
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-6">
                                            <div class="form-group">
                                                <button class="btn btn-success" type="submit">Search</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Rank AND Reward Income</h4>
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped nowrap">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Date</th>
                                                <th>User Id</th>
                                                <th>User Name</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td style="text-align: right;"><b>Total :</b></td>
                                                <td></td>
                                                <td></td>
                                                <td style="text-align: right;"><b>0</b></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="main-cres">
                            <h4>
                                <img src="https://www.bitcapitalx.com/application/libraries/assets/icons/sahibzada_nobg.png" alt=""> 
                                Rewards Achievements
                            </h4>
                            <div class="reward_boes">
                                <ul class="reward_heading">
                                    <li>
                                        <h5>
                                            <img src="https://www.bitcapitalx.com/application/libraries/assets/icons/reward-1.png" alt=""> 
                                            Target
                                        </h5>
                                    </li>
                                    <li>
                                        <h5>
                                            <img src="https://www.bitcapitalx.com/application/libraries/assets/icons/reward-2.png" alt=""> 
                                            Designation
                                        </h5>
                                    </li>
                                    <li>
                                        <h5>
                                            <img src="https://www.bitcapitalx.com/application/libraries/assets/icons/reward-3.png" alt=""> 
                                            Reward
                                        </h5>
                                    </li>
                                    <li>
                                        <h5>
                                            <img src="https://www.bitcapitalx.com/application/libraries/assets/icons/reward-4.png" alt=""> 
                                            Status
                                        </h5>
                                    </li>
                                </ul>
                                <ul class="reward-dae">
                                    <li>
                                        <span>1. $5000.</span>
                                        <p>Challenger.</p>
                                        <span class="spene-2">$100</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>2. $25000.</span>
                                        <p>Performer.</p>
                                        <span class="spene-2">$600</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>3. $100k</span>
                                        <p>Champion.</p>
                                        <span class="spene-2">$2000</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>4. $500k.</span>
                                        <p>Prince.</p>
                                        <span class="spene-2">$8000</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>5. $1M.</span>
                                        <p>Titan.</p>
                                        <span class="spene-2">$25000</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>6. $5M.</span>
                                        <p>Legend.</p>
                                        <span class="spene-2">$125000</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>7. $10M.</span>
                                        <p>Crown Legend.</p>
                                        <span class="spene-2">$250000</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>8. $50M</span>
                                        <p>king</p>
                                        <span class="spene-2">$1Million</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>9. $100M.</span>
                                        <p>Royal king</p>
                                        <span class="spene-2">$2Million</span>
                                        <button>Pending</button>
                                    </li>
                                    <li>
                                        <span>10. $250M.</span>
                                        <p>Tycoon</p>
                                        <span class="spene-2">$10 Million</span>
                                        <button>Pending</button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include 'include/footer.php'; ?>
        </div>
    </div>
</body>
</html>