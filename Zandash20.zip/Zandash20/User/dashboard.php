<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>



 

        <!--  Page Wrapper Start -->
            <div class="body-wrapper">
                <div class="container-fluid">
                    <!-- ROW -->
                    <div class="row">
                        <div class="col-lg-12 col-xl-6">
                            <div class="card w-100 bg-primary">
                                <div class="card-body position-relative">
                                    <div>
                                        <h4 class="mb-1 text-white">Welcome Jonathan Deo</h4>
                                        <p class="fs-3 mb-3 text-white opacity-70">
                                            Check all the statastics
                                        </p>
                                        <div class="rounded-pill bg-lightest d-inline-flex align-items-center">
                                            <div class="px-4 py-6 text-center border-end border-white border-opacity-10">
                                                <h5 class="text-white mb-0 text-white">573</h5>
                                                <p class="card-subtitle fs-2 mb-0 text-white opacity-80">
                                                    New Leads
                                                </p>
                                            </div>
                                            <div class="px-4 py-6 text-center">
                                                <h5 class="mb-0 text-white">
                                                    87<span class="fs-3">%</span>
                                                </h5>
                                                <p class="fs-2 mb-0 text-white opacity-80">
                                                    Conversion
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="make-social-media d-none d-sm-block">
                                        <img src="assets/assets/images/backgrounds/make-social-media.png" class="img-fluid" alt="MaterialM-img" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl-6">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="card bg-danger-subtle danger-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-danger rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:pie-chart-2-broken" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                2358
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+23%</span>
                                            </h5>
                                            <p class="mb-0">Fund Wallet</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="card bg-secondary-subtle secondary-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-secondary rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:refresh-circle-line-duotone" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                434
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">-12%</span>
                                            </h5>
                                            <p class="mb-0">Income Wallet</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="card bg-success-subtle success-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-success rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:dollar-minimalistic-linear" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                $245k
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+8%</span>
                                            </h5>
                                            <p class="mb-0">Roi Wallet</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl2">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="card bg-danger-subtle danger-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-danger rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:pie-chart-2-broken" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                2358
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+23%</span>
                                            </h5>
                                            <p class="mb-0">Total Earning</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="card bg-secondary-subtle secondary-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-secondary rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:refresh-circle-line-duotone" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                434
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">-12%</span>
                                            </h5>
                                            <p class="mb-0">Total Withdrawal</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="card bg-success-subtle success-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-success rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:dollar-minimalistic-linear" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                $245k
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+8%</span>
                                            </h5>
                                            <p class="mb-0">Total Business</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl2">
                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="card bg-danger-subtle danger-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-danger rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:pie-chart-2-broken" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                2358
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+23%</span>
                                            </h5>
                                            <p class="mb-0"> ROI Income</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card bg-secondary-subtle secondary-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-secondary rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:refresh-circle-line-duotone" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                434
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">-12%</span>
                                            </h5>
                                            <p class="mb-0">Referral Income</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card bg-success-subtle success-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-success rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:dollar-minimalistic-linear" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                $245k
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+8%</span>
                                            </h5>
                                            <p class="mb-0">Reward Income</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card bg-success-subtle success-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-success rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:dollar-minimalistic-linear" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                $245k
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+8%</span>
                                            </h5>
                                            <p class="mb-0">Team</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl2">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="card bg-danger-subtle danger-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-danger rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:pie-chart-2-broken" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                2358
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+23%</span>
                                            </h5>
                                            <p class="mb-0">Sales</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="card bg-secondary-subtle secondary-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-secondary rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:refresh-circle-line-duotone" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                434
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">-12%</span>
                                            </h5>
                                            <p class="mb-0">Refunds</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="card bg-success-subtle success-card w-100 shadow-none">
                                        <div class="card-body">
                                            <div class="bg-success rounded-circle-shape mb-7 rounded-pill d-inline-flex align-items-center justify-content-center">
                                                <iconify-icon icon="solar:dollar-minimalistic-linear" class="fs-7 text-white"></iconify-icon>
                                            </div>
                                            <h5 class="fs-5 text-nowrap d-flex align-items-center gap-1 pt-1">
                                                $245k
                                                <span class="badge rounded-pill border border-muted fw-bold text-muted fs-2 py-1">+8%</span>
                                            </h5>
                                            <p class="mb-0">Earnings</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                       </div>
                    </div>
                    <!-- row end -->
                </div>
            </div>
        <!--  Page Wrapper End -->

           
   <?php include 'Include/Footer.php'; ?>