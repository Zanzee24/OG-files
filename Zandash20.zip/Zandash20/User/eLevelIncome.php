<?php
require_once("loginCheck.php");
include 'include/header.php';
include 'include/head.php';

?>
</body>

<body class="dark-mode">
    <!-- Modal -->

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">E-Level Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">E-Level Income</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>


                <!-- Referral Team Section -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">E-Level  Income</h4>
                            <div class="table-responsive">
                                <table class="table dataTable table-border w-100 table-striped nowrap" id="export-button">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Level</th>
                                            <th>Level Income</th>
                                            <th>Date</th>
                                            <th>Child Name</th>
                                            <th>Child ID</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $count = 0;
                                        $queryLevel = mysqli_query($con, "SELECT b.name,b.user_id,a.dateTime,a.levelIncome,a.level,a.status,c.user_id AS childID,c.name AS childName FROM meddolic_user_bot_level_income a, meddolic_user_details b, meddolic_user_details c WHERE  a.memberId=b.member_id AND a.childId=c.member_id AND a.memberId='$memberId' AND a.status=1 ORDER BY a.dateTime DESC");
                                        while ($valLevel = mysqli_fetch_assoc($queryLevel)) {
                                            $count++; ?>
                                            <tr>
                                                <td><?= $count ?></td>

                                                <td>Level <?= $valLevel['level'] ?></td>
                                                <td><span class="badge badge-success">$ <?= $valLevel['levelIncome'] ?></span></td>
                                                <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valLevel['dateTime'])); ?></td>
                                                <td><?= $valLevel['childName'] ?></td>
                                                <td><?= $valLevel['childID'] ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var d = document.getElementById("income_reports");
        d.className += " active";
        var d = document.getElementById("eLevelIncome.php");
        d.className += " active";
    </script>

    <?php include 'include/footer.php'; ?>