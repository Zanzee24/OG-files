<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>


<div class="body-wrapper">
    <div class="container-fluid">
        <div class="card card-body">
            <div class="row align-items-center">
                <div class="col-12">
                    <div class="d-sm-flex align-items-center justify-space-between">
                        <h4 class="fw-semibold fs-4 mb-4 mb-md-0 card-title">Wallet Address</h4>
                        <nav aria-label="breadcrumb" class="ms-auto">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item d-flex align-items-center">
                                    <a class="text-muted text-decoration-none d-flex" href="dashboard.php">
                                        <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                                        Wallet Address
                                    </span>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <!-- ----------------------------------------- -->
                <!-- 1. Basic Form -->
                <!-- ----------------------------------------- -->
                <!-- start Basic Form -->
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-3">Add Wallet Address</h4>
                        <form>
                            <div class="row">
                                <div class="mb-3">
                                    <label class="form-label">Input Select</label>
                                    <select class="form-select" id="inlineFormCustomSelect">
                                        <option selected="">Choose...</option>
                                        <option value="1">One</option>
                                        <option value="2">Two</option>
                                        <option value="3">Three</option>
                                    </select>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-floating mb-3">
                                        <input type="password" class="form-control" id="tb-pwd" placeholder="Password">
                                        <label for="tb-pwd">Wallet Address </label>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <div class="d-md-flex align-items-center">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Remember me
                                            </label>
                                        </div>
                                        <div class="ms-auto mt-3 mt-md-0">
                                            <button type="submit" class="btn btn-primary hstack gap-6">
                                                Submit
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- end Basic Form -->
            </div>
             <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-3">Wallet Address List</h4>
            <table class="table text-nowrap mb-0 align-middle">
                <thead class="text-dark fs-4">
                    <tr>
                        <th>
                            <h6 class="fs-4 fw-semibold mb-0">Customer</h6>
                        </th>
                        <th>
                            <h6 class="fs-4 fw-semibold mb-0">Status</h6>
                        </th>
                        <th>
                            <h6 class="fs-4 fw-semibold mb-0">Email Address</h6>
                        </th>
                        <th>
                            <h6 class="fs-4 fw-semibold mb-0">Teams</h6>
                        </th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <img src="assets/assets/images/profile/user-2.jpg" class="rounded-circle" width="40" height="40">
                                <div class="ms-3">
                                    <h6 class="fs-4 fw-semibold mb-0">Olivia Rhye</h6>
                                    <span class="fw-normal">@rhye</span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-success-subtle text-success fw-semibold fs-2 gap-1 d-inline-flex align-items-center"><i class="fa fa-circle fs-3"></i>active</span>
                        </td>
                        <td>
                            <p class="mb-0 fw-normal">olivia@ui.com</p>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge text-bg-primary">Design</span>
                                <span class="badge text-bg-secondary">Product</span>
                            </div>
                        </td>
                        <td>
                            <div class="dropdown dropstart">
                                <a href="javascript:void(0)" class="text-muted" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fa-solid fa-ellipsis"></i>
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                    <li>
                                        <a class="dropdown-item d-flex align-items-center gap-3" href="javascript:void(0)"><i class="fs-4 fa fa-plus"></i>Add</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item d-flex align-items-center gap-3" href="javascript:void(0)"><i class="fs-4 fa fa-edit"></i>Edit</a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item d-flex align-items-center gap-3" href="javascript:void(0)"><i class="fs-4 fa fa-trash"></i>Delete</a>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                   
                </tbody>
            </table>
                    </div>
                    </div>






        </div>
    </div>
</div>
<?php include 'Include/Footer.php'; ?>