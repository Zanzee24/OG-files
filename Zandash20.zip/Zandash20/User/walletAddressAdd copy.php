<?php include 'include/head.php';
require_once("loginCheck.php");

?>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success"><i class="mdi mdi-archive"></i><span>P2P Exchange</span></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard.php" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>
                
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard.php">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Wallet Address</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Wallet Address</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Wallet Address Form Section -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <form class="form theme-form" action="userProfileAuthProcess" method="POST">
                                    <div class="row">
                                        <div class="form-group col-md-6 col-sm-6">
                                            <label>Select Currency *</label>
                                            <select class="form-control" name="currencyId" required id="currencyId">
                                                <option value=""> Select One </option>
                                                <?php $queryCoin = mysqli_query($con, "SELECT * FROM meddolic_config_currency_list WHERE status=1 ORDER BY currencyName ASC");
                                                while ($valCoin = mysqli_fetch_assoc($queryCoin)) { ?>
                                                    <option value="<?= $valCoin['currency_id'] ?>"> <?= $valCoin['currencyName'] ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label>Wallet Address *</label>
                                                <input class="form-control" name="walletAddress" id="walletAddress" type="text" required placeholder="Enter Wallet Address">
                                                <input type="hidden" name="memberId" value="<?= $memberId ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group col-md-6 col-sm-6">
                                            <label>Transaction Password *</label>
                                            <input type="password" name="trnPassword" class="form-control" placeholder="e.g. Transaction Password" required>
                                        </div>

                                        <div class="form-group">
                                            <button type="submit" name="addWalletAddress" class="btn btn-primary" style="margin-top: 15px;">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Wallet Address History Section -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Wallet Address History</h4>
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped nowrap">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Currency Name</th>
                                                <th>Wallet Address</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryWallet = mysqli_query($con, "SELECT a.payment_id,a.walletAddress,a.addDate,b.currencyName FROM meddolic_user_wallet_address_details a, meddolic_config_currency_list b WHERE a.member_id='$memberId' AND a.currency_id=b.currency_id AND a.status=1 ORDER BY a.addDate DESC");
                                            while ($valWallet = mysqli_fetch_assoc($queryWallet)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valWallet['currencyName'] ?></td>
                                                    <td><?= $valWallet['walletAddress'] ?></td>
                                                    <td><a href="javascript:void(0)" class="btn btn-danger btn-sm" onclick="deleteWalletAddress(<?= $valWallet['payment_id'] ?>)"><i class="fa fa-trash"></i> Delete</a></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>

                 <script>
        function deleteWalletAddress(paymentId) {
            if (paymentId != "") {
                if (confirm('Are you sure to Delete this Wallet Address?')) {
                    $.ajax({
                        type: "POST",
                        url: 'ajaxCalls/deleteWalletAddressAjax',
                        data: {
                            paymentId: paymentId
                        },
                        cache: false,
                        success: function(data) {
                            // alert(data);
                            if (data) {
                                alert('Wallet Address Deleted Successfully');
                                location.reload();
                            }
                        }
                    });
                }
            }
        }
    </script>

            </div>
        </div>
        
        <?php include 'include/footer.php'; ?>