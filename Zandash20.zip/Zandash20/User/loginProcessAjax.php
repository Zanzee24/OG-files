<?php
	require_once('../conection.php');

	$d=date("Y-m-d H:i:s");
	$userId=mysqli_real_escape_string($con,$_POST['userId']);
	$password=mysqli_real_escape_string($con,$_POST['password']);
	//echo $_POST['username']."<br>".$_POST['password'];

	$querySql=mysqli_query($con,"SELECT name,member_id,user_id,user_type,password FROM meddolic_user_details WHERE user_id='$userId' AND password='$password' AND user_type=2 AND account_status=1");
	$num_rows=mysqli_num_rows($querySql);
	$valDetails=mysqli_fetch_assoc($querySql);
	if($num_rows) {
		switch ($valDetails['user_type']){
          case '2':
          	if($valDetails){
          		session_start();
          		unset($_SESSION['user_member_id']);
				unset($_SESSION['member_user_id']);
				unset($_SESSION['member_password']);
				unset($_COOKIE['memberUserId']);
				unset($_COOKIE['memberPassKey']);
    			setcookie('memberUserId', null, -1, '/');
    			setcookie('memberPassKey', null, -1, '/');
				$_SESSION['user_member_id']=$valDetails['member_id'];
				$_SESSION['member_user_id']=$valDetails['user_id'];
				$_SESSION['member_password']=$valDetails['password'];
				setcookie ("memberUserId",$valDetails["user_id"],time()+ 3600);
				setcookie ("memberPassKey",$valDetails["password"],time()+ 3600);
				echo "/dashboard";
			} else {
				return false ;
			}
			break;
	    }
	} else {
		return false;
	} ?>

