<?php include 'include/head.php';
include 'loginCheck.php';
?>

</body>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success"><i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>
                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Daily ROI Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Daily ROI Income</h4>
                            </div>
                        </div>
                    </div>
                </div>


                <script data-cfasync="false"src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
                <script src="https://www.bitcapitalx.com/application/libraries/iconify-icon.min.js"></script>
                <!-- <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Daily ROI Income</h4>
                                <form class="row row-cols-sm-3 theme-form mt-3 form-bottom" >
            <div class="col-md-3 mb-3 d-flex">
              <div class="input-group">
                <input type="text" class="form-control pull-right" name="fromDate" id="fromDate" value="<?= $showDate ?>" readonly><span class="input-group-text"><i class="fa fa-calendar"></i></span>
              </div>
            </div>
            <div class="col-md-3 mb-3 d-flex">
              <div class="input-group">
                <input type="text" class="form-control pull-right" name="toDate" id="toDate" value="<?= $showDate1 ?>" readonly><span class="input-group-text"><i class="fa fa-calendar"></i></span>
              </div>
            </div>
            <div class="mb-3 d-flex">
              <button class="btn btn-primary btn-sm" data-bs-original-title="" title="">Search</button>
            </div>
          </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Daily ROI Income</h4>
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped   nowrap">
                                        <thead>
                                            <tr>
                                                <th>S.NO</th>
                                                <th>User Id</th>
                                                <th>Name</th>
                                                <th>Direct Package</th>
                                                <th>Income Release</th>
                                                <th>Release Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryInvest = mysqli_query($con, "SELECT a.member_id,a.incomeAmount,a.packageAmount,a.date_time,b.user_id,b.name FROM meddolic_user_cashback_income_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.member_id=b.member_id ORDER BY a.date_time DESC");

                                            while ($valInvest = mysqli_fetch_assoc($queryInvest)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valInvest['user_id'] ?></td>
                                                    <td><?= $valInvest['name'] ?></td>
                                                    <td><span class="badge badge-success"><i class="fa fa-dollar"></i>
                                                            <?= $valInvest['packageAmount'] ?></span></td>
                                                    <td><span class="badge badge-success"><i class="fa fa-dollar"></i>
                                                            <?= $valInvest['incomeAmount'] ?></span></td>
                                                    <td><i class="fa fa-clock-o"></i>
                                                        <?= date("d-m-Y H:i:s", strtotime($valInvest['date_time'])); ?></td>
                                                </tr>
                                            <?php } ?>

                                        </tbody>

                                    </table>

                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 <?php include 'include/footer.php'; ?>
     <script>
        var d = document.getElementById("Report");
        d.className += " active";
        var d = document.getElementById("Daily-ROI.php");
        d.className += " active";
    </script>
