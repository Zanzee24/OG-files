<?php include 'include/head.php';
require_once("loginCheck.php");

?>
<?php
$queryDirect = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE sponser_id='$memberId' AND topup_flag=1");
$valDirect = mysqli_fetch_array($queryDirect);
$totalDirect = $valDirect[0];

$queryAmount = mysqli_query($con, "SELECT withdrawCharge,minimumWithdraw FROM meddolic_config_misc_setting");
$valAmount = mysqli_fetch_assoc($queryAmount);
$withdrawCharge = $valAmount['withdrawCharge'];
$minimumWithdraw = $valAmount['minimumWithdraw'];

unset($_SESSION['withdrawTokenSet']);
$randToken = rand(1111, 9999) . time() . date('s');
$newToken = md5($randToken);
$_SESSION['withdrawTokenSet'] = $newToken;
$todayDay = date('w');
?>

<body class="dark-mode">
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <h4 class="page-title">Fund Request</h4>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                         <div class="col-sm-6">
                            <div class="card">
                                <div class="card-body">
                                    <form class="theme-form" action="fundRequestBack" method="post" enctype="multipart/form-data" onsubmit="return confirm('Are You Sure to Submit?')">
                                    <div class="mb-3">
                                        <label class="form-label">User ID</label>
                                        <input type="text" name="user_id" class="form-control" placeholder="e.g. john12345" readonly value="<?=$userId?>">
                                        <input type="hidden" name="member_id" value="<?=$memberId?>">
                                        <input type="hidden" name="name" value="<?=$userName?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Fund Need *</label>
                                        <input type="number" name="requestFund" class="form-control" placeholder="e.g. Fund Need" required onkeypress="return onlynum(event)">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Payment Mode*</label>
                                        <select class="form-control" name="payment_id" required onchange="showAddressQR(this.value)">
                                                <option value=""> Select One </option>
                                            <?php $queryMode=mysqli_query($con,"SELECT * FROM meddolic_config_payment_details WHERE status=1 ORDER BY payment_id ASC");
                                                while($valMode=mysqli_fetch_assoc($queryMode)){ ?>
                                                <option value="<?=$valMode['payment_id']?>" data-address="<?=$valMode['paymentAddress']?>"> <?= $valMode['paymentName']?> </option>
                                            <?php } ?>
                                        </select>
                                    </div> 
                                    <div class="mb-3">
                                        <label class="form-label">Payment Slip*</label>
                                        <input type='file' name="transactionImage" required class="form-control" accept=".jpg, .png, .gif, .jpeg, .PNG, .GIF, .JPG, .JPEG"/>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Transaction ID *</label>
                                        <textarea type="text" class="form-control" required placeholder="Transaction Hash" name="paymentHash"></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Transaction Password *</label>
                                        <input type="password" name="trnPassword" class="form-control" placeholder="e.g. Transaction Password" required>
                                    </div>
                                    <div class="text-end">
                                        <button class="btn btn-primary" name="fundRequest">Submit</button>
                                    </div>
                                </form>
                                </div>
                                
                                <div class="col-md-6" id="paymentDetails" style="display: none;"></div>
                    </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped nowrap">
                                        <thead>
                                            <tr>
                                                <th>S.NO</th>          
                                                <th>User ID</th>
                                                <th>Name</th>
                                                <th>Requested Amount</th>
                                                <th>Request Date</th>
                                                <th>Payment Mode</th>
                                                <th>Transaction ID</th>
                                                <th>Transaction Slip</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $count=0;
                                            $queryRequest=mysqli_query($con,"SELECT a.*,b.paymentName from meddolic_user_fund_request a, meddolic_config_payment_details b where a.member_id='$memberId' AND a.payment_id=b.payment_id order by date_time desc");
                                            while($valRequest=mysqli_fetch_array($queryRequest)){
                                            $count++;
                                        ?>
                                            <tr>
                                                <td><?= $count;?></td>
                                                <td><?= $valRequest['user_id']; ?></td>
                                                <td><?= $valRequest['name']; ?></td>
                                                <td><i class="mdi mdi-currency-usd"></i> <?= $valRequest['requestFund'] ?></td>
                                                <td><i class="mdi mdi-clock-outline"></i> <?= $valRequest['date_time']; ?></td>
                                                <td><?= $valRequest['paymentName']; ?></td>
                                                <td><?= $valRequest['paymentHash']; ?></td>
                                                <td><img src="<?=$valRequest['transactionImage']?>" height="150px" width="150px" ></td>
                                                <td><?php if($valRequest['status']==1) echo "Approved";
                                                    else if($valRequest['status']==2) echo "Rejected";
                                                    else if($valRequest['status']==0) echo "Pending";?></td>
                                            </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php include 'include/footer.php'; ?>
        </div>
    </div>

    
<!-- Include QR code library -->
<!--<script src="assets/js/qrcode.min.js"></script>-->

<script>
  function showAddressQR(paymentId) {
    var showDiv = document.getElementById("paymentDetails");
    if (paymentId != "") {
      $.ajax({
        type: "POST",
        url: 'fetchPaymentDetailsAjax',
        data: {
          paymentId: paymentId
        },
        cache: false,
        success: function(data) {
          showDiv.style.display = "block";
          if (data) {
            $('#paymentDetails').html(data);
          }
        }
      });
    } else {
      showDiv.style.display = "none";
    }
  }
  </script>
<script>
function copyTronLink(){
  var copyText = document.getElementById("tronLink");
  copyText.select();
  document.execCommand("Copy");
  alert("Payment Details Copied Successfully!!!");
}

function copyPaymentAddress() {
  var copyText = document.getElementById("paymentAddress");
  copyText.select();
  document.execCommand("Copy");
  alert("Payment address copied to clipboard!");
}

var d = document.getElementById("Fund");
    d.className += " active";
var d = document.getElementById("deposit");
    d.className += " active";
</script>
</body>

</html>