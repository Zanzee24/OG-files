<?php
require_once("loginCheck.php");
include 'include/header.php';
include 'include/head.php';

?>
</body>

<body class="dark-mode">
    <!-- Modal -->

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Monthly ROI Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Monthly ROI Income</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>


                <!-- Referral Team Section -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Monthly ROI Income</h4>
                            <div class="table-responsive">
                                <table class="table dataTable table-border w-100 table-striped nowrap" id="export-button">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>UserId</th>
                                            <th>Name</th>
                                            <th>Invest Amount</th>
                                            <th>Cashback Received</th>
                                            <th>Invest Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        function roiReceived($con, $memberId, $summaryId)
                                        {
                                            $query = mysqli_query($con, "SELECT sum(incomeAmount) from meddolic_user_cashback_income_details WHERE summary_id='$summaryId' AND member_id='$memberId' AND status=1");
                                            $val1 = mysqli_fetch_array($query);
                                            $total = $val1[0];
                                            if ($total != "") {
                                                echo "<span class='badge badge-success'>$ " . $total . "</span>";
                                            } else {
                                                echo "<span class='badge badge-danger'>$ 0.00</span>";
                                            }
                                        }
                                        $count = 0;
                                        $queryInvest = mysqli_query($con, "SELECT a.summary_id,a.member_id,a.packagePrice,a.date_Time,a.status,b.user_id,b.name FROM meddolic_user_cashback_income_summary a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.member_id=b.member_id ORDER BY a.date_Time DESC");
                                        while ($valInvest = mysqli_fetch_assoc($queryInvest)) {
                                            $count++; ?>
                                            <tr>
                                                <td><?= $count ?></td>
                                                <td><?= $valInvest['user_id'] ?></td>
                                                <td><?= $valInvest['name'] ?></td>
                                                <td><span class="badge badge-success">$ <?= $valInvest['packagePrice'] ?></span></td>

                                                <td><?= roiReceived($con, $memberId, $valInvest['summary_id']) ?></td>
                                                <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valInvest['date_Time'])); ?></td>
                                                <td><?php if ($valInvest['status'] == 1) echo "<span class='badge badge-primary'>RUNNING</span>";
                                                    else if ($valInvest['status'] == 0) echo "<span class='badge badge-success'>COMPLETED</span>";
                                                    else if ($valInvest['status'] == 2) echo "<span class='badge badge-success'>COMPLETED</span>"; ?></td>
                                                <td><a href="monthlyRoiIncomeDetails?summary_id=<?= $valInvest['summary_id'] ?>" class="btn btn-success btn-xs"><i class="fa fa-eye"></i> More </a></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var d = document.getElementById("mlm_reports");
        d.className += " active";
        var d = document.getElementById("monthlyRoi.php");
        d.className += " active";
    </script>

    <?php include 'include/footer.php'; ?>