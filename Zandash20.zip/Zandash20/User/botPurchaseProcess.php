<?php
require_once("loginCheck.php");
require_once("startInvestmentFunction.php");
error_reporting(E_ALL);
if (isset($_POST['botpurchase'])) {
    $user_id1 = mysqli_real_escape_string($con, $_POST['sponser_id']);
    $loginMemberId = mysqli_real_escape_string($con, $_POST['loginMemberId']);
    $trnPassword = mysqli_real_escape_string($con, $_POST['trnPassword']);
    $packageId = mysqli_real_escape_string($con, $_POST['packageId']);
    $d = date("Y-m-d H:i:s");
    $todayDate = date("Y-m-d");

    $queryCheck = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE member_id='$loginMemberId' AND trnPassword='$trnPassword'");
    $valCheck = mysqli_fetch_array($queryCheck);
    if ($valCheck[0] == 0) { ?>
        <script>
            alert("Incorrect Transaction Password!!!");
            window.top.location.href = 'botPurchase';
        </script>
    <?php
        exit;
    }

    $resultUser = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE user_id='$user_id1' AND user_type=2");
    if (!mysqli_num_rows($resultUser)) { ?>
        <script>
            alert("Invalid User Id!!!");
            window.top.location.href = "botPurchase";
        </script>
    <?php
        exit;
    }

    $queryIncome = mysqli_query($con, "SELECT packageStart FROM meddolic_config_bot_package_type WHERE packageId='$packageId'");
    $valIncome = mysqli_fetch_assoc($queryIncome);
    $packageAmount = $valIncome['packageStart'];

    $queryWallet = mysqli_query($con, "SELECT fundWallet FROM meddolic_user_details WHERE member_id='$loginMemberId'");
    $valWallet = mysqli_fetch_array($queryWallet);
    $currentWallet = $valWallet[0];
    if ($currentWallet <= 0) { ?>
        <script>
            alert("Insufficient Balance in Wallet to Purchase");
            window.top.location.href = "botPurchase";
        </script>
    <?php
        exit;
    }
    if ($currentWallet < $packageAmount) { ?>
        <script>
            alert("Insufficient Balance in Wallet to Purchase");
            window.top.location.href = "botPurchase";
        </script>
    <?php
        exit;
    }

    $queryDetails = mysqli_query($con, "SELECT a.member_id,a.sponser_id,a.topup_flag,b.activation_date,b.topup_flag AS sponserTop FROM meddolic_user_details a, meddolic_user_details b WHERE a.user_id='$user_id1' AND a.sponser_id=b.member_id");
    $valDetails = mysqli_fetch_assoc($queryDetails);
    $memberId = $valDetails['member_id'];
    $sponserId = $valDetails['sponser_id'];
    $topupFlag = $valDetails['topup_flag'];
    $sponActDate = $valDetails['activation_date'];
    $sponserTopup = $valDetails['sponserTop'];


//     $queryOld = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_invest_history WHERE memberId='$memberId' AND investAmount>='$packageAmount' AND investStatus= 1");
//     $valOld = mysqli_fetch_array($queryOld);
//     if ($valOld[0] >= 1) {

//     ?>
//         <script>
//             alert("Already Purchased this Bot...");
//             window.top.location.href = "botPurchase";
//         </script>
// <?php
//         exit;
//     }

    //Activation & Update Code Starts
    if ($topupFlag == 0) {
        mysqli_query($con, "UPDATE meddolic_user_details SET topup_flag=1,activation_date='$d' WHERE member_id='$memberId'");

        mysqli_query($con, "UPDATE meddolic_user_child_ids SET topup_status=1,topup_date='$d' WHERE child_id='$memberId'");
    }
    //Activation & Update Code Ends

    mysqli_query($con, "INSERT INTO meddolic_user_invest_history (memberId,sponserId,loginMemberId,investAmount,packageId,dateTime,investStatus) VALUES ('$memberId','$sponserId','$loginMemberId','$packageAmount','$packageId','$d','1')");
     $purchaseId = $con->insert_id;
    // Add invest history code ends

    //Invest Amount History Code Ends
    mysqli_query($con, "UPDATE meddolic_user_details SET fundWallet=fundWallet-'$packageAmount' WHERE member_id='$loginMemberId'");

    mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`, `date_time`,`trn_id`) VALUES ('$loginMemberId',8,1,'$packageAmount','$d','$purchaseId')");


    // Referral Income Code Starts
    if ($sponserTopup == 1) {
        botReferralIncome($con, $sponserId, $memberId, $packageAmount, $packageId, $d);
    }
    // Referral Income Code Ends

    // Bot Level Income Code Starts
    releaseBotLevelIncome($con, $memberId, $packageAmount, $packageId, $d);
    // Bot Level Income Code Ends

    // Reward income code start
    relayBotRewardLoop($con, $memberId, $d);
    // reward income code end

    echo "<script>alert('Bot Purchased Successfully!!!');window.top.location.href='botPurchase.php';</script>";
} ?>
<?php include("../close-connection.php"); ?>