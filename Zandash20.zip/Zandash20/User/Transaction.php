<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bit Global - Forgot Password</title>

    <!-- site favicon -->
    <link rel="icon" type="image/png" href="assets/img/favicon/favicon.png">

    <!-- font awesome cdn links -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- google font -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
        :root {
            --primary-color: #FE723F;
            --secondary-color: #F0B71F;
            --dark-bg: #2b2b2b;
            --light-text: #ffffff;
            --input-bg: rgba(255, 255, 255, 0.1);
            --input-border: rgba(255, 255, 255, 0.2);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background-color: var(--dark-bg);
            color: var(--light-text);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            line-height: 1.6;
        }

        .login-section {
            position: relative;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            overflow: hidden;
        }

        .login-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1;
        }

        .login-section video {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: 0;
            opacity: 0.5;
        }

        .container {
            position: relative;
            z-index: 2;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 15px;
        }

        .login_box {
            background: rgba(0, 0, 0, 0.85);
            border-radius: 15px;
            padding: 2.5rem;
            max-width: 450px;
            margin: 0 auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(254, 114, 63, 0.3);
            text-align: center;
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login_box img {
            max-width: 180px;
            margin-bottom: 1.5rem;
            height: auto;
        }

        .login_box p {
            margin-bottom: 1.5rem;
            opacity: 0.8;
            font-size: 0.95rem;
        }

        .formes {
            margin-bottom: 1.25rem;
            text-align: left;
        }

        .formes input {
            width: 100%;
            padding: 0.75rem 1rem;
            background: var(--input-bg);
            border: 1px solid var(--input-border);
            border-radius: 8px;
            color: white;
            font-family: 'Montserrat', sans-serif;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }

        .formes input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(254, 114, 63, 0.2);
        }

        .formes input::placeholder {
            color: rgba(255, 255, 255, 0.6);
        }

        .btn_login {
            margin-top: 0.5rem;
        }

        .btn_login button {
            background: linear-gradient(45deg, var(--secondary-color), var(--primary-color));
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 30px;
            font-weight: 600;
            width: 100%;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .btn_login button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(254, 114, 63, 0.4);
        }

        .sign_now {
            margin-top: 1.5rem;
            font-size: 0.9rem;
        }

        .sign_now a {
            color: var(--secondary-color);
            text-decoration: none;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
        }

        .sign_now a:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }

        /* Responsive adjustments */
        @media (max-width: 576px) {
            .login-section {
                padding: 1rem;
            }

            .login_box {
                padding: 1.5rem;
            }

            .login_box img {
                max-width: 150px;
            }
        }
    </style>
</head>

<?php require('../conection.php');
error_reporting(1);
unset($_SESSION['passTokenSet']);
$randToken = rand(1111, 9999) . time() . date('s');
$_SESSION['passTokenSet'] = md5($randToken); ?>

<body>
    <section class="login-section">
        <video loop autoplay muted playsinline>
            <source type="video/mp4" src="assets/img/lo-bg.mp4">
            <source type="video/ogg" src="assets/img/lo-bg.mp4">
        </video>

        <div class="container">
            <div class="login_box">
                <a href="index"><img src="assets/img/logo/whitelogo.png" alt="Bit Global Logo"></a>
                <p>Please enter the User-ID and Email associated with your account and we will email you your Transaction password.</p>

                <form method="POST" class="check" id="user_forgot" novalidate>
                    <div class="formes">
                        <input type="text" class="form-control mb-4" style="background-color: #fff0;color: #ffffff;" data-val="true" data-val-required="User ID is Required" id="inputUserId" name="inputUserId" placeholder="Username" required value="<?php if (isset($_COOKIE["memberUserId"])) {
                                                                                                                                                                                                                                                            echo $_COOKIE["memberUserId"];
                                                                                                                                                                                                                                                        } ?>" />
                    </div>

                    <div class="formes">
                        <!-- <input type="email" placeholder="Email ID" name="inputEmailId" id="txtemail" required> -->


                        <span class="field-validation-valid" data-valmsg-for="username" data-valmsg-replace="true"></span>
                      <input id="inputEmailId" name="inputEmailId" class="form-control mb-4" style="background-color: #fff0;color: #ffffff;" type="text" placeholder="Email Id">
                      <span class="field-validation-valid" data-valmsg-for="mpwd" data-valmsg-replace="true"></span>

                    </div>

                    <div class="btn_login">
                         <button type="button" class="btn-primary btn4" id="passSubmit" onclick="forgotTrnPassValidate('<?= $_SESSION['passTokenSet'] ?>')">Reset</button>
                          <button disabled style="display: none;" class="btn btn-danger loadingMore">Validating Data...</button>
                    </div>

                    <div class="col-12 text-center">
                          <h6 id="success"></h6>
                        </div>

                    <div class="sign_now">
                        <a href="auth.php"><i class="fas fa-arrow-left"></i> Back to Login</a>
                    </div>
                </form>
            </div>
        </div>
    </section>


    <!-- JavaScript Libraries -->
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
      <script src="custom.js"></script>
</body>

</html>