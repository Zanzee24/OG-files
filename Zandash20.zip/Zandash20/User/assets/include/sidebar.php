<?php include 'include/header.php'; ?>


<div class="" id="leftside-menu-container" data-simplebar>
    <ul class="side-nav">
        <h6 class="text-menu">MAIN MENU</h6>
        <li class="side-nav-item">
            <a href="dashboard.php" class="side-nav-link">
                <iconify-icon icon="solar:widget-add-line-duotone" class=""></iconify-icon>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="side-nav-item">
            <a data-bs-toggle="collapse" href="#sidebarreport12" aria-expanded="false" aria-controls="sidebarreport" class="side-nav-link">
                <iconify-icon icon="solar:user-circle-line-duotone"></iconify-icon><span>Profile</span> <span class="menu-arrow"></span>
            </a>
            <div class="collapse" id="sidebarreport12">
                <ul class="side-nav-second-level">
                    <li><a href="view_profile_setting.php">my-Profile</a></li>
                    <li><a href="view_security_setting.php">Change Password</a></li>
                    <li><a href="view_transaction_setting.php">Transaction Password</a></li>
                    <li><a href="walletAddressAdd.php">Add Wallet Address</a></li>

                </ul>
            </div>
        </li>




        <li class="side-nav-item">
            <a data-bs-toggle="collapse" href="#Recent_Partners_fund" aria-expanded="false" aria-controls="Recent_Partners_fund" class="side-nav-link">
                <iconify-icon icon="solar:dollar-line-duotone"></iconify-icon><span>Deposit </span> <span class="menu-arrow"></span>
            </a>
            <div class="collapse" id="Recent_Partners_fund">
                <ul class="side-nav-second-level">

                    <li><a href="income-wallet.php"><i class="icon-arrow-down"></i>
                            Swap To Topup Wallet </a>
                    </li>

                    <!--li><a href="https://www.bitcapitalx.com/Userprofile/view_fund_request"><i
									class="icon-arrow-down"></i>Add
								Fund Request </a></li-->
                    <li><a href="deposit.php"><i
                                class="icon-arrow-down"></i>
                            Fund Deposit </a></li>
                    <li><a href="p2p.php"><i
                                class="icon-arrow-down"></i>P2P Trarnsfer</a>
                    </li>
                </ul>
            </div>
        </li>

        <?php
        $querySponser = mysqli_query($con, "SELECT investStatus FROM meddolic_user_invest_history WHERE memberId='$memberId'");
        $valSponser = mysqli_fetch_array($querySponser);
        $botStatus = $valSponser['investStatus'];
        ?>

        <li class="side-nav-item">
            <a data-bs-toggle="collapse" href="#Recent_topup" aria-expanded="false" aria-controls="Recent_topup" class="side-nav-link">
                <iconify-icon icon="solar:hand-money-linear"></iconify-icon><span> Investment Packages </span> <span class="menu-arrow"></span>
            </a>
            <div class="collapse" id="Recent_topup">
                <ul class="side-nav-second-level">

                     <?php
                    if ($botStatus == 0) {
                    ?>
                    <li><a href="botPurchase.php" id="botPurchase"><i
                                class="icon-arrow-down"></i>Bot Purchase </a></li>
                                <?php
                    }
                    ?>

                    <?php
                    if ($botStatus == 1 || $botStatus == 2) {
                    ?>
                     <li><a href="botPurchase.php"  id="botPurchase"><i
                                class="icon-arrow-down"></i>Bot Purchase </a></li>
                        <li><a href="startInvestment.php"><i
                                    class="icon-arrow-down"></i> Package Purchase </a></li>
                    <?php
                    }
                    ?>
                    <li><a href="view_topup_report1.php"><i
                                class="icon-arrow-down"></i>Packge Purchase Report</a></li>

                </ul>
            </div>
        </li>

        <li class="side-nav-item">
            <a data-bs-toggle="collapse" href="#Recent_Partners" aria-expanded="false" aria-controls="Recent_Partners" class="side-nav-link">
                <iconify-icon icon="solar:chart-square-line-duotone"></iconify-icon><span>Team Network</span> <span class="menu-arrow"></span>
            </a>
            <div class="collapse" id="Recent_Partners">
                <ul class="side-nav-second-level">

                    <li><a href="view_direct_downline.php"><i
                                class="icon-arrow-down"></i>Referral Team</a></li>
                    <li><a href="myLevelTeam.php"><i
                                class="icon-arrow-down"></i>Level Team</a></li>
                    <!-- <li><a href="view_user_downline.php"><i
                                class="icon-arrow-down"></i>Downline Team</a></li> -->
                    <!-- <li><a href="tree_view_level.php"><i
									class="icon-arrow-down"></i>Genealogy  -->
                    </a>
        </li>
    </ul>
</div>
</li>


<li class="side-nav-item">
    <a data-bs-toggle="collapse" href="#income_reports" aria-expanded="false" aria-controls="income_reports" class="side-nav-link">
        <iconify-icon icon="solar:hand-money-linear"></iconify-icon><span>Bot Financial Reports </span> <span class="menu-arrow"></span>
    </a>
    <div class="collapse" id="income_reports">
        <ul class="side-nav-second-level">
            <li><a href="botReferralIncome.php">E-Referral Income
                </a>
            </li>
            <li><a href="levelQualify.php">Level Qualify Income
                </a>
            </li>
            <li><a href="eLevelIncome.php">E-Level Income
                </a>
            </li>
        </ul>

    </div>
</li>


<li class="side-nav-item">
    <a data-bs-toggle="collapse" href="#mlm_reports" aria-expanded="false" aria-controls="mlm_reports" class="side-nav-link">
        <iconify-icon icon="solar:hand-money-linear"></iconify-icon><span> Financial Report</span> <span class="menu-arrow"></span>
    </a>
    <div class="collapse" id="mlm_reports">


        <ul class="side-nav-second-level">
            <li><a href="monthlyRoi.php">Monthly Roi Income
                </a>
            </li>
            <li><a href="referralIncome.php">Referral Income
                </a>
            </li>
            <li><a href="teamLevelIncome.php">Team Level Income
                </a>
            </li>
            <li><a href="rewardIncome.php">Reward Income
                </a>
            </li>
            <!-- <li><a href="Regal-Profit-Share-Pool.php">Regal Profit Share Pool
								</a>
                                </li>

                                <li><a href="Performance-Dividend-Level-Income.php">Performance Dividend Level Income
								</a>
                                </li>
                                <li><a href="Rank-AND-Reward.php  ">Rank-Based Rewards & Achievements
								</a>
                                </li> -->
        </ul>

    </div>
</li>

<!-- <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="#ml_reports" aria-expanded="false" aria-controls="ml_reports" class="side-nav-link">
                            <iconify-icon icon="solar:hand-money-linear"></iconify-icon><span> Regal Profit Share Pool  </span> <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse" id="ml_reports">


                            <ul class="side-nav-second-level">
                                <li><a href="Weekly-Bonus.php">Weekly Bonus 
								</a>
                                </li>
                                li><a href="https://www.bitcapitalx.com/user_report/view_level_report/8/Supreme Elite Bonus ">Supreme Elite Bonus 
									</a>
									</li>
									<li><a href="https://www.bitcapitalx.com/user_report/view_level_report/9/Legacy Fortune Bonus ">Legacy Fortune Bonus 
									</a>
									</li>
									<li><a href="https://www.bitcapitalx.com/user_report/view_level_report/10/Empire Legacy Bonus ">Empire Legacy Bonus 
									</a>
								</li
                            </ul>

                        </div>
                    </li> -->
<!-- <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="#Wallet" aria-expanded="false" aria-controls="Wallet" class="side-nav-link"><i class="mdi mdi-wallet"></i><span>Wallet </span> <span
						class="menu-arrow"></span></a>
                        <div class="collapse" id="Wallet">
                            <ul class="side-nav-second-level">
                                <li><a href="Income.php">Income Wallet</a></li>
                                <li><a href="Topup-Wallet.php">Topup
								Wallet</a></li>

                            </ul>
                        </div>
                    </li> -->
<li class="side-nav-item">
    <a href="view_withdrwal.php" class="side-nav-link">
        <iconify-icon icon="solar:archive-line-duotone"></iconify-icon><span>Withdrawal</span>
    </a>
</li>





<li class="side-nav-item">
    <a href="ticket.php" class="side-nav-link">
        <iconify-icon icon="solar:iphone-line-duotone"></iconify-icon><span>Support</span>
    </a>
</li>
<!-- <li class="side-nav-item">
                        <a href="view_mt5_broker.php" class="side-nav-link">
                            <iconify-icon icon="solar:iphone-line-duotone"></iconify-icon><span>Terms & Condition</span>
                        </a>
                    </li> -->
<li class="side-nav-item">
    <a href="authSignDash.php" class="side-nav-link">
        <iconify-icon icon="solar:login-3-line-duotone"></iconify-icon><span>Logout</span>
    </a>
</li>
</ul>
<div class="clearfix"></div>
</div>
</div>