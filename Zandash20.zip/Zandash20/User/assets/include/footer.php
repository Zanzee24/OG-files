<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                Copyright <?= date('Y') ?> <a href="javascript:void(0);">BIT GLOBAL</a> All Rights Reserved.
            </div>
        </div>
    </div>
</footer>


<input type="hidden" id="baseUrl" name="baseUrl" value="https://bitglobal.trade/">
<div class="rightbar-overlay"></div>
 <script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/check.js?v=250819021211"></script>
<!-- <script src="assets/js/custom.js?v=250819021211"></script> -->
<script src="assets/js/vendor.min.js"></script>
<script src="assets/js/app.min.js"></script>

<input type="hidden" id="baseUrl" name="baseUrl" value="https://bitglobal.trade/">


<script>
    // var baseUrl = $("#baseurl").val();
    var txtmethod = $("#txtmethod").val();
    var txtclass = $("#txtclass").val();
</script>
<!--input type="hidden" id="baseurl" value="https://bitglobal.trade/" / -->
<input type="hidden" id="txtmethod" value="dashboard" />
<input type="hidden" id="txtclass" value="Userprofile" />
<input type="hidden" id="txttron" value="TRX" />

<script src="assets/js/TronWeb.js"></script>

<link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.css">


<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>

<script src="https://cdn.datatables.net/2.0.3/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.1/js/dataTables.buttons.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js
	https://cdn.datatables.net/buttons/3.0.1/js/buttons.html5.min.js"></script>


<script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.html5.min.js"></script>




<script>
    new DataTable('.dataTable', {
        layout: {
            topStart: {
                buttons: ['pageLength', 'copyHtml5', 'excelHtml5', 'csvHtml5']
            }
        },
        lengthMenu: [
            [50, 100, 200, 500],
            [50, 100, 200, 500]
        ]
    });
</script>


<script type="text/javascript">
    $(document).ready(function() {
        $('.dataTable').DataTable();
    });
</script>

<script src="assets/js/check.js"></script>
<script src="assets/js/jquery.blockUI.js"></script>

<script>
    function message(msg) {
        $.NotificationApp.send("Success !", msg, "top-right", "rgba(0,0,0,0.2)", "success");
    }
</script>


<script>
    $(function() {
        $(this).bind("contextmenu", function(e) {
            //e.preventDefault();
        });
    });
</script>
<script src="custom.js"></script>


  

