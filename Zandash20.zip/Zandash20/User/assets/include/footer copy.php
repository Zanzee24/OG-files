<footer class="footer">
    <div class="container">
        <ul class="nav nav-pills nav-justified">

            <li class="nav-item">
                <a class="nav-link" href="https://www.bitcapitalx.com/userprofile/join_member">
                    <i class="nav-icon mdi mdi-format-list-text"></i><span> Add Member</span>
                </a>
            </li>

            <li class="nav-item center-item">
                <a class="nav-link active" href="https://www.bitcapitalx.com/Userprofile/dashboard">
                    <i class="nav-icon uil-home"></i><span> Dashboard</span>
                </a>
            </li>
            <li class="nav-item">


                <a class="nav-link" href="https://www.bitcapitalx.com/User_action/tree_view_level/13681"><i
                        class="nav-icon mdi mdi-file-tree"></i><span> Level Tree</span></a>
            </li>

            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://www.bitcapitalx.com/userprofile/view_member_details">
                    <i class="nav-icon uil-user"></i><span> Profile</span>
                </a>
            </li>
        </ul>
    </div>
</footer>
<input type="hidden" id="baseUrl" name="baseUrl" value="https://www.bitcapitalx.com/">
<div class="rightbar-overlay"></div>

<script src="assets/third_party/check.js?v=250724091001"></script>
<script src="assets/third_party/custom.js?v=250724091001"></script>
<script src="assets/js/vendor.min.js"></script>
<script src="assets/js/app.min.js"></script>





<input type="hidden" id="baseUrl" name="baseUrl" value="https://www.bitcapitalx.com/">

<!-- <script src="https://www.bitcapitalx.com/application/third_party/js/check.js?v=250724094253"></script>
<script src="https://www.bitcapitalx.com/application/third_party/js/custom.js?v=250724094253"></script>
<script src="https://www.bitcapitalx.com/application/libraries/assets/js/vendor.min.js"></script>
<script src="https://www.bitcapitalx.com/application/libraries/assets/js/app.min.js"></script> -->



<script src="custom.js"></script>
<script>
    // var baseUrl = $("#baseurl").val();
    var txtmethod = $("#txtmethod").val();
    var txtclass = $("#txtclass").val();
</script>
<!--input type="hidden" id="baseurl" value="https://www.bitcapitalx.com/" / -->
<input type="hidden" id="txtmethod" value="dashboard" />
<input type="hidden" id="txtclass" value="Userprofile" />
<input type="hidden" id="txttron" value="TRX" />

<script src="assets/js/third_party/TronWeb.js"></script>

<link rel="stylesheet" type="text/css" href="assets/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>

<script src="https://cdn.datatables.net/2.0.3/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.1/js/dataTables.buttons.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js
    https://cdn.datatables.net/buttons/3.0.1/js/buttons.html5.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>


<script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.html5.min.js"></script>


<script type="text/javascript">
    $(document).ready(function () {
        $('.dataTable').DataTable();
    });
</script>

<script src="assets/js/check.js"></script>
<script src="assets/third_party/jquery.blockUI.js"></script>

<script>
    function message(msg) {
        $.NotificationApp.send("Success !", msg, "top-right", "rgba(0,0,0,0.2)", "success");
    }
</script>


<script>
    $(function () {
        $(this).bind("contextmenu", function (e) {
            //e.preventDefault();
        });
    });
</script>
<script src="https://www.bitcapitalx.com/application/third_party/js/check.js?v=250724094643"></script>
<script src="https://www.bitcapitalx.com/application/third_party/js/custom.js?v=250724094643"></script>
<script src="https://www.bitcapitalx.com/application/libraries/assets/js/vendor.min.js"></script>
<script src="https://www.bitcapitalx.com/application/libraries/assets/js/app.min.js"></script>





<input type="hidden" id="baseUrl" name="baseUrl" value="https://www.bitcapitalx.com/">



<script>
    var txtmethod = $("#txtmethod").val();
    var txtclass = $("#txtclass").val();
</script>
<input type="hidden" id="txtmethod" value="view_topup_report" />
<input type="hidden" id="txtclass" value="user_action" />
<input type="hidden" id="txttron" value="TRX" />

<script src="https://www.bitcapitalx.com/application/third_party/js/TronWeb.js"></script>

<link rel="stylesheet" type="text/css"
    href="https://www.bitcapitalx.com/application/libraries/assets/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>

<script src="https://cdn.datatables.net/2.0.3/js/dataTables.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.1/js/dataTables.buttons.js"></script>
<script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.dataTables.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js
    https://cdn.datatables.net/buttons/3.0.1/js/buttons.html5.min.js"></script>


<script src="https://cdn.datatables.net/buttons/3.0.1/js/buttons.html5.min.js"></script>



<script>
    new DataTable('.dataTable', {
        layout: {
            topStart: {
                buttons: ['pageLength', 'copyHtml5', 'excelHtml5', 'csvHtml5']
            }
        },
        lengthMenu: [
            [50, 100, 200, 500],
            [50, 100, 200, 500]
        ]
    });
</script>


<script type="text/javascript">
    $(document).ready(function () {
        $('.dataTable').DataTable();
    });
</script>

<script src="https://www.bitcapitalx.com/application/libraries/assets/js/check.js"></script>
<script src="https://www.bitcapitalx.com/application/third_party/js/jquery.blockUI.js"></script>

<script>
    function message(msg) {
        $.NotificationApp.send("Success !", msg, "top-right", "rgba(0,0,0,0.2)", "success");
    }
</script>


<script>
    $(function () {
        $(this).bind("contextmenu", function (e) {
            //e.preventDefault();
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src='assets/js/apexcharts.min.js'></script>
<script src='assets\js\app.min.js'></script>

</body>

</html>