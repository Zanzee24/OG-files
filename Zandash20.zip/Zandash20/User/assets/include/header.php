<?php
$queryAccess = mysqli_query($con, "SELECT roiWallet,name,user_id,member_id,topup_flag,wallet,fundWallet,email_id,phone FROM meddolic_user_details WHERE user_id='$_SESSION[member_user_id]'");
if ($valAccess = mysqli_fetch_array($queryAccess)) {
    $userName = $valAccess['name'];
    $userId = $valAccess['user_id'];
    $memberId = $valAccess['member_id'];
    $topupFlag = $valAccess['topup_flag'];
    $incomeWallet = $valAccess['wallet'];
    $roiWallet = $valAccess['roiWallet'];

    $fundWallet = $valAccess['fundWallet'];
    $emailId = $valAccess['email_id'];
    $phone = $valAccess['phone'];
} ?>
<!-- Topbar Start -->
<div class="navbar-custom navnar_tops">
    <div>

        <div class="userName-top">
            <p>Welcome <img src="assets/img/morning.png" alt=""></p>
            <h5>Hi, <?= $userName ?></h5>
            <h3 class="copyUserId" style="cursor:pointer;" title="Tap to copy"><?= $userId ?></h3>
            <span class="copyMsg" style="display:none;color:green;font-size:12px;">Copied!</span>
        </div>
    </div>
    <ul class="list-inline float-end mb-0">
        <div class="main_top_bare">

            <li class="nav-item dropdown">
                <a class="nav-link user_profiles" href="javascript:void(0)" id="drop1" aria-expanded="false">
                    <div class="lh-base">
                        <img src="assets/img/user-1.jpg" alt="matdash-img" />
                    </div>
                </a>
                <div class="dropdown-menu profile-dropdown dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop1">
                    <div class="position-relative ">
                        <div class="profile_imgnes">
                            <img src="assets/img/user-1.jpg" class="rounded-circle" width="56" height="56" alt="matdash-img" />
                            <div class="media-body" style="color: #fff;"><span><?= $userName ?></span>
                                <p class="mb-0 font-roboto"><?= $userId ?> <i class="middle fa fa-angle-down"></i></p>
                            </div>
                        </div>

                    </div>
                </div>
            </li>
            <button class="button-menu-mobile open-left">
                <i class="mdi mdi-menu"></i>
            </button>
        </div>
    </ul>
</div>



<script>
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('copyUserId')) {
            const text = e.target.textContent.trim();

            // Try modern clipboard API first (works on mobile Chrome, Safari)
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text)
                    .then(() => showMessage(e.target))
                    .catch(() => fallbackCopy(text, e.target));
            } else {
                // Fallback for older browsers or HTTP pages
                fallbackCopy(text, e.target);
            }
        }
    });

    function fallbackCopy(text, element) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed'; // prevent scrolling
        document.body.appendChild(textarea);
        textarea.focus();
        textarea.select();

        try {
            document.execCommand('copy');
            showMessage(element);
        } catch (err) {
            console.error('Failed to copy', err);
            alert('Could not copy, please copy manually.');
        }

        document.body.removeChild(textarea);
    }

    function showMessage(element) {
        const msg = element.nextElementSibling;
        if (msg && msg.classList.contains('copyMsg')) {
            msg.style.display = 'inline';
            setTimeout(() => {
                msg.style.display = 'none';
            }, 1000);
        }
    }
</script>