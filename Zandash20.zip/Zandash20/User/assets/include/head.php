<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<!-- /Added by HTTrack -->

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>BIT GLOBAL </title>
    <!-- favicons Icons -->
    <link rel="icon" type="image/png" href="assets/img/favicon/favicon.png">
    <link href="assets/css/app.min.css?v=250724091001" rel="stylesheet" type="text/css" id="light-style" />
    <link href="assets/css/dashboard.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap" rel="stylesheet">
    <!-- font awesome cdn links -->
    <link rel="stylesheet" href="assets/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/translate.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.jsdelivr.net/npm/web3@1.6.1/dist/web3.min.js"></script>
    <link href="assets/css/tree.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/themify-icons.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/dataTables.dataTables.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/buttons.dataTables.css" rel="stylesheet" type="text/css" />
    <script src="assets/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>

    <style>
    .card-header {
        padding: .75rem 1.5rem;
        margin-bottom: 0;
        background-color: #303030; /* Dark background for card header */
        color: #ffffff; /* White text */
    }
    
    /* Style for the ticket modal in dark mode */
    #ticketModal .modal-content {
        background-color: #2a2a2a;
        color: #ffffff;
    }
    
    #ticketModal .modal-header {
        border-bottom: 1px solid #444;
    }
    
    #ticketModal .modal-footer {
        border-top: 1px solid #444;
    }
    
    #ticketModal .form-control, 
    #ticketModal .form-select {
        background-color: #333;
        color: #fff;
        border: 1px solid #444;
    }
    
    #ticketModal .form-control:focus, 
    #ticketModal .form-select:focus {
        background-color: #333;
        color: #fff;
        border-color: #555;
    }
    
    #ticketModal .form-text {
        color: #aaa;
    }
    
    /* Table styling for dark mode */
    #tickets-table {
        background-color: #2a2a2a;
        color: #2b2a2aff;
    }
    
    #tickets-table thead {
        background-color: #303030;
    }
    
    #tickets-table tbody tr:hover {
        background-color: #333;
    }

        .tk_countdown_time {
            background-color: #5957cd;
            border-radius: 9px;
        }

        .tk_countdown {
            background-position: right center;
            background-repeat: no-repeat;
        }

        .bgfixed {
            margin: auto;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            position: fixed;
            z-index: 0;
        }
        li.notification a {
    border: 1px solid #ffffff3b;
    width: 45px;
    height: 45px;
    display: flex
;
    justify-content: center;
    align-items: center;
    border-radius: 8px;
    color: #fff;
        }


    </style>
    

    <script src="assets/js/sweetalert.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Splash&display=swap" rel="stylesheet">
    <script src="assets/js/jquery-3.6.0.min.js"></script>
    <link href="assets/css/app.min.css" rel="stylesheet" />

</head>