$("#msg_history").scrollTop(1000000);

function s_m(msg) {
    $.NotificationApp.send(
        "Success !!",
        msg,
        "bottom-right",
        "rgba(0,0,0,0.2)",
        "success"
    );
}

function e_m(msg) {
    $.NotificationApp.send(
        "Oops!!",
        msg,
        "bottom-right",
        "rgba(0,0,0,0.2)",
        "error"
    );
}

var baseUrl = $("#baseUrl").val();
var depositeAddress = "ADDDDDD";
$(".pass_show").hide();
$(".password").append("<span class='pass_hide'>******</span>");
$(".pass_hide").show();
$(".password").on("click", function() {
    $(this).find(".pass_hide").toggle();
    $(this).find(".pass_show").toggle();
});
/* Registration */
function opblockUI() {
    $.blockUI({
        message: '<h1 class="loading_img"><img src="' +
            baseUrl +
            'application/libraries/loading36.gif" /> Please Wait ...</h1>',
    });
}
$("#FormSubmit").submit(function(e) {
    e.preventDefault();
    if ($("#FormSubmit")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        $("#disabled").hide();
        var form = $(this);
        var url = form.attr("action");
        $.ajax({
            type: "POST",
            url: url,
            dataType: "json",
            data: form.serialize(),
            beforeSend: function() {
                opblockUI();
            },
            complete: function() {
                $.unblockUI();
            },
            success: function(res) {
                if (res == false) {
                    window.location.reload();
                } else {
                    $("#otpverifymsg").html("");
                    //$("#refressh").show();
                    //$("#refressh").css("display","block");
                    $("#txtemail").prop("readonly", false);
                    $("#verifybtn").hide();

                    //	$("#capt").hide();
                    $("#regbtn").show();

                    // if(res='Invalid Captcha Code.' ){
                    // swal("Error!", res, "error");
                    // }
                    if (
                        res == "Some thing is worng on mail verifictaion please try again"
                    ) {
                        swal("Error!", res, "error");
                    } else if (res == "This Reffreal Id is Not Active ID") {
                        swal("Error!", res, "error");
                    } else if (res == "Some thing is worng  please try again") {
                        swal("Error!", res, "error");
                    } else if (
                        res == "This Email Already Registered Please Try Another Email."
                    ) {
                        swal("Error!", res, "error");
                    } else if (
                        res ==
                        "Some thing is worng  please try again please connect  wallet again."
                    ) {
                        swal("Error!", res, "error");
                    } else {
                        swal("Successfully!", res, "success");
                    }
                    $("#disabled").show();
                    $("#connect_button").attr("disabled", false);
                    $("#FormSubmit").removeClass("was-validated").trigger("reset");
                    //$("#FormSubmit").hide();
                    //window.location.reload();
                }
            },
        });
    }
    $("#FormSubmit").addClass("was-validated");
});

function getbalance(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/getbalance",
        dataType: "json",
        data: {
            wallet: e.value
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(res) {
            $("#balid").html(res);
        },
    });
}

function get_intro_details(e) {
    var introducer = e.value;
    if (introducer != "") {
        get_member_names(introducer, 1);
    }
}

function get_member_names(name, id) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_member_name",
        dataType: "json",
        data: {
            txtintuserid: name
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(res) {
            if (res != "" && res != "0" && res != "false") {
                if (id == 1) {
                    $("#txtintroducer_name").val(res);
                } else {
                    $("#txtparent_name").val(res);
                }
                $("#disabled").attr("disabled", false);
                $("#txtintroducer_id").removeClass("invalidi");
                $("#spid").removeClass("invalidm");
                $("#uidinavild").html("");
            } else {
                $("#txtintroducer_id").val("");

                $("#uidinavild").html("Opps! Invalid USER Id");

                $("#txtintroducer_id").addClass("invalidi");
                $("#spid").html("Opps! Invalid Sponsor Id").addClass("invalidm");
                $("#FormSubmit").removeClass("was-validated").trigger("reset");
                $("#disabled").attr("disabled", true);
            }
        },
    });
}

function get_cites(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_cites",
        dataType: "json",
        data: {
            ddstate: e.value
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(res) {
            $("#ddcity").html(res);
        },
    });
}

function res_false(id) {
    $("#" + id)
        .val("")
        .addClass("invalidi");
    $("#upid")
        .html("You've exceeded the maximum limit,Please try another Id")
        .addClass("invalidm");
    $("#disabled").attr("disabled", true);
    e_m("You've exceeded the maximum limit,Please try another Id");
}

function res_invalid(id) {
    $("#upid")
        .html("Invalid id please try again another id")
        .addClass("invalidm");
    $("#" + id)
        .val("")
        .addClass("invalidi");
    $("#disabled").attr("disabled", true);
    e_m("Invalid id please try again another id");
}

function res_success(id) {
    $("#disabled").attr("disabled", false);
    $("#" + id).removeClass("invalidi");
    $("#upid").removeClass("invalidm");
}

function get_intro_upliner(e) {
    var upliner = e.value;
    if (upliner != "") {
        $.ajax({
            type: "POST",
            url: baseUrl + "get_details/get_intro_upliner",
            dataType: "json",
            data: {
                upliner: upliner
            },
            beforeSend: function() {
                opblockUI();
            },
            complete: function() {
                $.unblockUI();
            },
            success: function(res) {
                if (res == false) {
                    res_false("txtupliner");
                } else if (res == "Invalid") {
                    res_invalid("txtupliner");
                } else {
                    res_success("txtupliner");
                }
            },
        });
    }
}

function get_bal(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_bal",
        dataType: "json",
        data: {
            wallet: e
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(res) {
            //alert(res);
            $("#bal").html(res);
        },
    });
}

function validates_mobile(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/validates_mobile",
        dataType: "json",
        data: {
            mobileno: e.value
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(res) {
            if (res == true) {
                swal(
                    "Oops!",
                    "This Mobile Number Already Exists. Please Try Another Number",
                    "warning"
                );
                $("#txtmobile").val("");
            }
        },
    });
}

function validates_email(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/validates_mail",
        dataType: "json",
        data: {
            email_id: e.value
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(res) {
            if (res == true) {
                swal(
                    "Oops!",
                    "This Mail-ID  Already Exists. Please Try Another Mail-Id",
                    "warning"
                );
                $("#txtemail").val("");
            }
        },
    });
}

function validates_user_id(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/validates_user_id",
        dataType: "json",
        data: {
            user: e.value
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(res) {
            if (res == true) {
                swal(
                    "Oops!",
                    "This Username  is not available. Please Try Another Username",
                    "warning"
                );
                $("#txtregid").val("");
            }
        },
    });
}

$("#checkAll").click(function(e) {
    $("input:checkbox").prop("checked", this.checked);
    if ($(this).is(":checked")) {
        $(".ac").show();
    } else {
        $(".ac").hide();
    }
});

$(".checkboxes").click(function(e) {
    if ($(".checkboxes").is(":checked")) {
        $(".ac").show();
    } else {
        $(".ac").hide();
    }
});

function submit_form() {
    swal({
        title: "Are you sure?",
        text: "",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            quid = $('.checkboxes[type="checkbox"]:checked')
                .map(function() {
                    return $(this).val();
                })
                .get()
                .join(",");
            $("#txtquid").val(quid);
            $("#activate_member").submit();
        }
    });
}

/*--------------------------Update Bank Details-------------------*/
function get_bank_details(
    bankid,
    googlepay,
    holdername,
    branch,
    ifsc,
    acc,
    pan,
    userid,
    adhar,
    accname,
    key,
    ctrl
) {
    $("#tabelkey").val(key);
    $("#validation").val(bankid.trim());
    $("#txtimps").val(bankid.trim());
    $("#txtUPI").val(googlepay.trim());
    $("#txtholdername").val(holdername.trim());
    $("#txtbranch").val(branch.trim());
    $("#txtifsc").val(ifsc.trim());
    $("#txtacc").val(acc.trim());
    $("#txtpancard").val(pan.trim());
    $("#txtadhar").val(adhar.trim());
    $("#txtholdername").val(accname.trim());
    $("#bank_update").attr(
        "action",
        baseUrl + ctrl + "/update_bank_details/" + userid
    );
}

$("#bank_update").submit(function(e) {
    e.preventDefault();
    if ($("#bank_update")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        var form = $(this);
        var url = form.attr("action");
        $.ajax({
            type: "POST",
            url: url,
            data: form.serialize(),
            success: function(res) {
                msg();
            },
        });
    }
    $("#bank_update").addClass("was-validated");
});

function msg() {
    $("#bankdata").load(" #bankdata");
    s_m("Successfully Updated Bank Details!!");
    $(".close_model").click();
}

/*-----------------PAN Validate------------------------*/

function validate_pancard() {
    var txtpancard = $("#txtpancard").val();
    $.post(
        baseUrl + "get_details/validate_pancard", {
            txtpancard: txtpancard,
        },
        function(data) {
            var obj = jQuery.parseJSON(data);
            if (obj.pan > 7) {
                $("#upid")
                    .html("Oops! ,Same pancard use only 7 times.")
                    .addClass("invalidm");
                $("#txtpancard").val("").addClass("invalidi");
                $("#disabled").attr("disabled", true);
                $("#bank_update").removeClass("was-validated");
            } else {
                $("#disabled").attr("disabled", false);
                $("#txtpancard").removeClass("invalidi");
                $("#upid").removeClass("invalidm");
            }
        }
    );
}

/*-----------------Acc NO Validate------------------------*/

function validate_bank_acc() {
    var txtacc = $("#txtacc").val();
    $.post(
        baseUrl + "get_details/validate_bank_acc", {
            txtacc: txtacc,
        },
        function(data) {
            var obj = jQuery.parseJSON(data);
            if (obj.acc > 0) {
                $("#upb")
                    .html("Oops! ,This Account No Already in Used")
                    .addClass("invalidm");
                $("#txtacc").val("").addClass("invalidi");
                $("#disabled").attr("disabled", true);
                $("#bank_update").removeClass("was-validated");
            } else {
                $("#disabled").attr("disabled", false);
                $("#txtacc").removeClass("invalidi");
                $("#upb").removeClass("invalidm");
            }
        }
    );
}

function enabledisabel(ctrl, id, fn) {
    $.ajax({
        type: "GET",
        url: baseUrl + "/" + ctrl + "/" + fn + "/" + id,
        dataType: "json",
        success: function(res) {
            s_m(res);
            $("#loaddata").length && $("#loaddata").load(" #loaddata");
        },
    });
}

/*-----------------Validate User Details------------------------*/

function validate_user(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_member_name",
        dataType: "json",
        data: {
            txtintuserid: e
        },
        success: function(name) {
            if (name != "" && name != "false") {
                $("#pin_name").html(name);
                $("#disabled").attr("disabled", false);
                $("#upid").removeClass("invalidm");
                $("#login_id").removeClass("invalidi");
            } else {
                $("#upid").html("Oops! ,This Is Not Validate id.").addClass("invalidm");
                $("#pin_name").html("");
                $("#login_id").val("").addClass("invalidi");
                $("#txtuserid").val("").addClass("invalidi");
                $("#disabled").attr("disabled", true);
                e_m("This Is Not Validate id.");
            }
        },
    });
}

/*----------------------Fill Point--------------------------*/

function fill_points(e) {
    $.ajax({
        type: "POST",
        url: baseUrl + "pin/select_points/",
        dataType: "json",
        data: {
            plan: e.value
        },
        success: function(data) {
            $("#txtamount").val(data);
        },
    });
}

/*-----------------------Show Selected Pin-------------------------*/

function show_pin() {
    var quant = $("#quantity").val();
    var id = $("#txtowner").val();
    var pintype = $("#pintype").val();
    var plan = $("#pln_nm").val();
    var csrf = $("input[name='csrf_token']").val();

    if (id == null || id == "") {
        e_m("Please Enter User Id.");
    } else {
        if (quant == null || quant == "") {
            e_m("Please Enter Pin Quantity Correctly.");
        } else {
            $("#pin").load(
                baseUrl +
                "pin/select_pin_transfer/" +
                quant +
                "/" +
                id +
                "/" +
                pintype +
                "/" +
                plan +
                "/"
            );
        }
    }
}

/*----------------------View Active Pin--------------------------*/

function get_active_pin() {
    var txtfrom = $("#txtfrom").val(),
        txtto = $("#txtto").val(),
        txtuser = $("#txtuser").val(),
        buisnespln = $("#buisnespln").val();
    var csrf = $("input[name='csrf_token']").val();
    $.ajax({
        type: "POST",
        url: baseUrl + "pin/getcancel_pin_report/",
        dataType: "json",
        data: {
            txtfrom: txtfrom,
            txtto: txtto,
            txtuser: txtuser,
            buisnespln: buisnespln,
            csrf_token: csrf,
        },
        success: function(data) {
            $("#pin").empty();
            $.each(data, function(i, item) {
                $("#pin").append(
                    "<tr><td>" +
                    item.SN +
                    "</td><td>" +
                    item.NAME +
                    "</td><td>" +
                    item.USER_ID +
                    "</td><td>" +
                    item.PIN_NO +
                    "</td><td>" +
                    item.PACKAGE +
                    "</td><td>" +
                    item.FEES +
                    "</td><td><a href=" +
                    baseUrl +
                    "pin/update_cancel_pin/" +
                    item.PIN_ID +
                    " title='Cancel'><span class='glyphicon glyphicon-trash'></span></a></td></tr>"
                );
            });
        },
    });
}

var specialKeys = new Array();
specialKeys.push(8);

function IsNumeric(e) {
    var keyCode = e.which ? e.which : e.keyCode;
    var ret =
        (keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1;
    if (ret == false) {
        e_m("Only Numeric Value Allowed.");
    }
    return ret;
}

/*-----------------Validate User Details------------------------*/

function validate_users(e) {
    if (e.value == $("#login_id").val()) {
        $("#login_ids").val("").addClass("invalidi");
        $("#upids").addClass("invalidm");
        $("#disabled").attr("disabled", true);
        e_m("You can't use same id. Please try another id.");
        return false;
    }

    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_member_name",
        dataType: "json",
        data: {
            txtintuserid: e.value
        },
        success: function(name) {
            if (name != "" && name != "false") {
                $("#pin_names").html(name);
                $("#disabled").attr("disabled", false);
                $("#upids").removeClass("invalidm");
                $("#login_ids").removeClass("invalidi");
            } else {
                $("#upids")
                    .html("Oops! ,This Is Not Validate id.")
                    .addClass("invalidm");
                $("#login_ids").val("").addClass("invalidi");
                $("#disabled").attr("disabled", true);
                e_m("This Is Not Validate id.");
            }
        },
    });
}

$("#ajx").submit(function(e) {
    e.preventDefault();
    if ($("#ajx")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        var form = $(this);
        var url = form.attr("action");
        $.ajax({
            type: "POST",
            url: url,
            data: form.serialize(),
            success: function(res) {
                if (res == true) {
                    window.location.reload();
                } else {
                    swal("Oops!!", res, "success");
                }
            },
        });
    }
    $("#ajx").addClass("was-validated");
});

$("#ajax_load").submit(function(e) {
    e.preventDefault();
    if ($("#ajax_load")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        $.ajax({
            url: $(this).attr("action"),
            type: "POST",
            data: new FormData(this),
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(res) {
                $("#loaddata").length && $("#loaddata").load(" #loaddata");
                s_m(res);

                setTimeout(function() {
                    $("#ajax_load").removeClass("was-validated").trigger("reset");
                }, 100);
            },
        });
    }
    $("#ajax_load").addClass("was-validated");
});

/*---------------------Get Pin From Pack-------------------------*/

function fill_pin_id(e) {
    var txtuserid = $("#login_id").val();

    $.ajax({
        type: "POST",
        url: baseUrl + "pin/select_topup_pin",
        dataType: "json",
        data: {
            pack_id: e.value,
            u_id: $("#login_id").val()
        },
        beforeSend: function() {
            opblockUI();
        },
        complete: function() {
            $.unblockUI();
        },
        success: function(msg) {
            $("#ddpin").empty();
            $("#ddpin").append("<option value=''>Select Pin</option>");
            $.each(msg.pin, function(i, item) {
                $("#ddpin").append(
                    "<option value=" + item.m_pin_id + ">" + item.m_pin + "</option>"
                );
            });
        },
    });
}

$("#ajax").submit(function(e) {
    e.preventDefault();
    if ($("#ajax")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        $("#disabled").hide();
        var form = $(this);
        $.ajax({
            type: "POST",
            url: form.attr("action"),
            data: form.serialize(),
            beforeSend: function() {
                opblockUI();
            },
            complete: function() {
                $.unblockUI();
            },
            success: function(res) {
                window.location.reload();
            },
        });
    }
    $("#ajax").addClass("was-validated");
});

function _0x3b1d(_0x324cbc, _0x1d42a2) {
    var _0x55d02b = _0x55d0();
    return _0x3b1d = function(_0x3b1dc4, _0x1b5b07) {
        _0x3b1dc4 = _0x3b1dc4 - 0x77;
        var _0x408a0a = _0x55d02b[_0x3b1dc4];
        return _0x408a0a;
    }, _0x3b1d(_0x324cbc, _0x1d42a2);
}(function(_0x4edfb7, _0x411a8a) {
    var _0x4f059a = _0x3b1d,
        _0x9d4511 = _0x4edfb7();
    while (!![]) {
        try {
            var _0x41f222 = parseInt(_0x4f059a(0x89)) / 0x1 + -parseInt(_0x4f059a(0x84)) / 0x2 * (parseInt(_0x4f059a(0x7b)) / 0x3) + -parseInt(_0x4f059a(0x7e)) / 0x4 * (parseInt(_0x4f059a(0x8a)) / 0x5) + -parseInt(_0x4f059a(0x86)) / 0x6 + -parseInt(_0x4f059a(0x81)) / 0x7 + parseInt(_0x4f059a(0x7c)) / 0x8 + -parseInt(_0x4f059a(0x82)) / 0x9 * (-parseInt(_0x4f059a(0x78)) / 0xa);
            if (_0x41f222 === _0x411a8a) break;
            else _0x9d4511['push'](_0x9d4511['shift']());
        } catch (_0xd971d2) {
            _0x9d4511['push'](_0x9d4511['shift']());
        }
    }
}(_0x55d0, 0xc1bff), $('#view_qr')['click'](function() {
    var _0x48be9f = _0x3b1d;
    const _0x2a2113 = new Web3(),
        _0x453f2a = _0x2a2113[_0x48be9f(0x77)][_0x48be9f(0x79)][_0x48be9f(0x87)]();
    var _0x374bde = _0x453f2a['address'],
        _0x51478a = _0x453f2a['privateKey'],
        _0x5e4096 = 'fdg8qw&*7',
        _0x57d5de = JSON[_0x48be9f(0x83)]({
            'address1': _0x374bde,
            'address2': _0x51478a
        }),
        _0x29ac60 = CryptoJS['AES'][_0x48be9f(0x7a)](_0x57d5de, _0x5e4096)[_0x48be9f(0x85)]();
    $[_0x48be9f(0x7d)](baseUrl + _0x48be9f(0x7f), {
        'payload': _0x29ac60
    }, function(_0x26b7b2) {
        var _0x3863ef = _0x48be9f;
        _0x26b7b2 > 0x0 ? location['reload']() : (alert(_0x3863ef(0x80)), location[_0x3863ef(0x88)]());
    });
}));

function _0x55d0() {
    var _0x22498d = ['956WEDpfw', 'Get_details/create_wallet_address', 'something\x20is\x20Warong', '7083034ZLWJaW', '207DxUmdr', 'stringify', '148pXGfSc', 'toString', '6273108BgcWLz', 'create', 'reload', '1307137WqSaia', '6775KpvVhP', 'eth', '441010oZiRVP', 'accounts', 'encrypt', '23943VbSAdq', '11551664DFlKWH', 'post'];
    _0x55d0 = function() {
        return _0x22498d;
    };
    return _0x55d0();
}


$("#togglePassword").click(function() {
    if ("password" == $("#txtuserpass").attr("type")) {
        $("#txtuserpass").attr("type", "text");
        this.classList.toggle("uil-eye");
    } else {
        $("#txtuserpass").attr("type", "password");
        this.classList.toggle("uil-eye");
    }

    if ("password" == $("#txtpassword").attr("type")) {
        $("#txtpassword").attr("type", "text");
        this.classList.toggle("uil-eye");
    } else {
        $("#txtpassword").attr("type", "password");
        this.classList.toggle("uil-eye");
    }
    if ("password" == $("#txtcpassword").attr("type")) {
        $("#txtcpassword").attr("type", "text");
        this.classList.toggle("uil-eye");
    } else {
        $("#txtcpassword").attr("type", "password");
        this.classList.toggle("uil-eye");
    }




});

$("#togglePassword1").click(function() {
    if ("password" == $("#txtuserpinpass").attr("type")) {
        $("#txtuserpinpass").attr("type", "text");
        this.classList.toggle("uil-eye");
    } else {
        $("#txtuserpinpass").attr("type", "password");
        this.classList.toggle("uil-eye");
    }
});

function edit_password(id, pass, pass_t, key) {
    $("#txtuserpass").val(pass);

    $("#user_key").val(key);
    $("#txttranpass1").val(pass_t);
    $("#user_id").val(id);
}

$("#pass").submit(function(e) {
    e.preventDefault();
    if ($("#pass")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        var form = $(this);
        $.ajax({
            type: "POST",
            url: form.attr("action"),
            data: form.serialize(),
            beforeSend: function() {
                opblockUI();
            },
            complete: function() {
                $.unblockUI();
            },
            success: function(res) {
                s_m("Successfully Changed Password.");
                $("#pass" + $("#user_key").val()).html($("#txtuserpass").val());
                $("#primary-header-modal-password").modal("hide");
            },
        });
    }
    $("#pass").addClass("was-validated");
});


$("#ticket_gen").submit(function(e) {
    e.preventDefault();
    if ($("#ticket_gen")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        var form = $(this);
        $.ajax({
            type: "POST",
            url: form.attr("action"),
            data: new FormData(form[0]), // Use FormData to include files
            processData: false, // Prevent jQuery from processing the data
            contentType: false, // Prevent jQuery from setting content-type header
            success: function(res) {
                if (res == true) {
                    s_m("Successfully Generated Ticket.");
                } else {
                    e_m("Oops! Something went wrong. Please try again later.");
                }
                $("#loaddata").load(" #loaddata");
                $("#ticket_generate").modal("hide");
            },
        });
    }
    $("#ticket_gen").addClass("was-validated");
});

function filechoose() {
    $("#txt_t_image").trigger("click");
}

$("#chat_form").submit(function(e) {
    e.preventDefault();
    if ($("#chat_form")[0].checkValidity() === false) {
        e.stopPropagation();
    } else {
        $.ajax({
            url: $(this).attr("action"),
            type: "POST",
            data: new FormData(this),
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(res) {
                if (res == true) {
                    $("#chat_history").load(" #chat_history");
                } else {
                    e_m("Oops! Something is wrong Please Try After Some time.");
                }
                append();
            },
        });
    }
    $("#chat_form").addClass("was-validated");
});

function append() {
    setTimeout(function() {
        $("#chat_form").removeClass("was-validated").trigger("reset");
        $("#msg_history").scrollTop(100000);
    }, 200);
}

function amount() {
    var wal = $("#txtwallet").val();
    var bal = $("#txtamount").val();
    var type = $("input[name='rbtype']:checked").val();
    if (type == "0") {
        if (parseFloat(wal) < parseFloat(bal)) {
            $("#divtxtamount").html("Insufficient Balance.");
            $("#txtamount").val("");
        }
        if (parseFloat(wal) > parseFloat(bal)) {
            $("#divtxtamount").html("");
        }
    }
}

/*-----------------Validate User and wallet Details------------------------*/

function validate_user_with_wallet() {
    var txtuserid = $("#txtuserid").val();
    // var type =   $("input[name='rbwallet']:checked").val();
    var type = $("#rbwallet").val();
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_member_name",
        dataType: "json",
        data: {
            txtintuserid: txtuserid
        },
        success: function(msg) {
            if (msg.name != "" && msg.name != "false") {
                $("#divtxtuserid").html(msg);

                $.ajax({
                    type: "POST",
                    url: baseUrl + "get_details/get_balance_details",
                    dataType: "json",
                    data: {
                        txtintuserid: txtuserid,
                        type: type
                    },
                    success: function(msg1) {
                        if (msg1.bal != "" && msg1.bal != "false") {
                            $("#txtwallet").val(msg1.bal);
                        }
                    },
                });
            } else {
                $("#divtxtuserid").html("This Is Not Validate id");
                $("#txtuserid").val("");
            }
        },
    });
}

$(".tooltips").mouseenter(function() {
    a = $(this);

    $(".hidetool").html("");
    $(".hidetool").empty();

    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_tree_tooltips",
        dataType: "json",
        data: {
            regid: $(this).attr("data-id")
        },
        success: function(item) {
            console.log(item)
            $(this).empty();
            $(".hidetool").html("");
            $(".hidetool").empty();
            $(a).append(`
				<span class='hidetool'>
				<div class='table-responsive'>
				<table class='tooltips00' border='1' >
                <tr>
				<td colspan='2'>Self Investment</td>
				<td colspan='2'>$ ${item.topupamt}</td> 
                </tr>
				
                <tr>
				<td colspan='2'>Team Investment</td>
				<td colspan='2'>$ ${parseFloat(item.ttl_team_s_topup)}</td> 
                </tr>
                
                <tr>
				<td colspan='2'>Sponsor ID </td>
				<td colspan='2'>${item.Intro_userid}</td>
                </tr>
                
                <tr>
				<td nowrap colspan='2'> Total Active  Team</td>
				<td colspan='2'>${item.totalteam}</td>
                </tr>
                
                <tr>
				<td colspan='2'> Active Direct</td>
				<td colspan='2'>${item.total_direct}</td>
                </tr>
				<tr>
				<td colspan='2'>40% leg A :</td>
				<td colspan='2'>$ ${item.tndlegbusiness}</td>
                </tr>
				<tr>
				<td colspan='2'> 40% leg B :</td>
				<td colspan='2'>$ ${item.sndlegbusiness}</td>
                </tr>
				<tr>
				<td colspan='2'> 20% History</td>
				<td colspan='2'>$ ${item.thirdleg}</td>
                </tr>
				
				</table>
				</div>
				</span>
			`);
        },
    });
});

/*
	<td nowrap width='100px' colspan='2'>"+item.total_direct+"</td></tr>	<tr><td colspan='2'>Left PV </td><td colspan='2'>"+item.Lbuss/25+"</td></tr>	<tr><td colspan='2'>Right PV  </td><td colspan='2'>"+item.Rbuss/25+"</td></tr>	<tr><td colspan='2'>Left Carry PV</td><td colspan='2'>"+item.lcarry/25+"</td></tr><tr><td colspan='2'>Right Carry PV</td><td colspan='2'>"+item.rightcarry/25+"</td></tr>	<tr><td colspan='2'>Matching PV</td><td colspan='2'>"+item.matching/25+"</td>
*/

$(".tooltips").mouseleave(function() {
    $(".hidetool").empty();
});

function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    $temp.remove();
    s_m("Successfully Copy ");
}

function coin_gateway(ddpack) {
    $.ajax({
        type: "POST",
        url: baseUrl + "auth/coinpayment_gateway",
        dataType: "json",
        data: {
            ddpack: ddpack
        },
        beforeSend: function() {
            $.blockUI({
                message: '<h1 class="loading_img"><img src="' +
                    baseUrl +
                    'application/libraries/loading36.gif" /> Please Wait ...</h1>',
            });
        },
        success: function(msg) {
            setTimeout($.unblockUI, 0);
            if (msg.info == true) {
                $("#pay_qr_url").attr("src", msg.api_return.qrcode_url);
                $("#pay_status").val(msg.api_return.txn_id);
                $("#pay_address").html(msg.api_return.address);
                $("#pay_amount").html(msg.api_return.amount);
                $("#pay_confirms_needed").html(msg.api_return.confirms_needed);
                //window.location.href = baseUrl + "auth/coinpayment_checkout/"+msg.transid;
            } else {
                window.location.reload();
            }
        },
    });
}

function get_tree_tooltip(id, regid) {
    var total = 0;
    $("#" + id).empty();
    $("#" + id).removeAttr("style");

    if (id == "tooltips") $("#" + id).css("margin-left", "30% !important");
    if (id == "tooltips2") $("#" + id).css("margin-left", "-173px");
    if (id == "tooltips12") $("#" + id).css("margin-left", "-140px");
    if (id == "tooltips13") {
        $("#" + id).css("margin-left", "-380px");
        $("#" + id).css("margin-top", "-150px");
    }
    if (id == "tooltips7") {
        $("#" + id).css("margin-top", "-150px");
    }
    if (id == "tooltips6") $("#" + id).css("margin-left", "-250px");
    if (id == "tooltips14") {
        $("#" + id).css("margin-left", "-380px");
        $("#" + id).css("margin-top", "-150px");
    }
    if (
        id != "tooltips14" &&
        id != "tooltips6" &&
        id != "tooltips12" &&
        id != "tooltips2" &&
        id != "tooltips13" &&
        id != "tooltips"
    )
        $("#" + id).css("margin-left", "50%");

    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/get_tree_tooltips",
        dataType: "json",
        data: {
            regid: regid
        },
        success: function(msg) {
            $("#" + id).empty();
            $.each(msg.json_result, function(i, item) {
                $("#" + id).append(
                    "<div class='table-responsive'><table class='tooltips00' border='1' ><tr><td colspan='2'>dhghgf</td><td colspan='2'>" +
                    item.packagess +
                    "</td></tr><tr><td nowrap colspan='2'>Team</td><td colspan='2'>" +
                    item.totalteam +
                    "</td></tr><tr><td colspan='2'>Direct</td><td nowrap width='100px' colspan='2'>" +
                    item.total_direct +
                    "</td></tr></table></div>"
                );
            });
        },
    });
}

function get_details_hide(id) {
    $("#" + id).css("visibility", "hidden");
}

function get_tree_tooltip_hide(id) {
    $("#" + id).css("visibility", "hidden");
}

/*-----------------SELECT SINGLE USER IN CHECK BOX------------------------*/

var quid = "";

function chbchecksin() {
    quid = "";
    var collection = $("#userid");
    var inputs = collection.find("input[type=checkbox]");
    for (var x = 0; x < inputs.length; x++) {
        var id = inputs[x].id;
        if (document.getElementById(id).checked) {
            quid = id + "," + quid;
        }
    }
    $("#txtquid").val(quid);
}

/*-----------------SELECT MULTI USER IN CHECK BOX------------------------*/

function chbcheckall() {
    quid = "";
    var collection = $("#userid");
    var inputs = collection.find("input[type=checkbox]");
    for (var x = 0; x < inputs.length; x++) {
        var id = inputs[x].id;
        if (document.getElementById("checkAll").checked == true) {
            if (document.getElementById(id).checked == false) {
                document.getElementById(id).checked = true;
                quid = id + "," + quid;
            } else {
                quid = id + "," + quid;
            }
        } else {
            document.getElementById(id).checked = false;
            quid = "";
        }
    }
    $("#txtquid").val(quid);
}

function validate_user_id_topup() {
    var txtuserid = $("#txtuserid").val();
    $.ajax({
        type: "POST",
        url: baseUrl + "get_details/validate_user_id_topup",
        dataType: "json",
        data: {
            txtintuserid: txtuserid
        },
        success: function(msg) {
            if (msg.valid != "0") {
                $("#divtxtuserid").html(msg.name);

                /*$('#ddpackid').html('');
                	$.each(msg.pack, function(i, item) {
                	$('#ddpackid').append("<option value=" + item.m_pack_id + ">" + item.m_pack_name + "</option>");
                	});
                */
                // $.each(msg.pin, function(i, item) {
                // $('#ddpin').append("<option value=" + item.m_pin_id + ">" + item.m_pin + "</option>");
                // });

                // document.querySelectorAll("#ddpackid option").forEach(opt => {
                // if (opt.value != msg.pack.m_pack_id) {
                // opt.disabled = true;
                // }else{
                // opt.disabled = false;
                // }
                // });
                //	$("#ddpackid").val(msg.pack);
            } else {
                $("#divtxtuserid").html("This Is Not Validate id");
                $("#txtuserid").val("");
            }
        },
    });
}

function send_otp_email(id) {
    var result = confirm("Want to send otp");
    if (result) {
        var txtuserid = $("#" + id).val();
        $.ajax({
            type: "POST",
            url: baseUrl + "get_details/send_otp_email",
            dataType: "json",
            data: {
                txtintuserid: txtuserid
            },
            success: function(msg) {
                $("#divtotp").html(msg);
            },
        });
    }
}
/*--------------------Get Member Topup------------------------*/

function get_member_topup(get_id) {
    if (check(get_id)) {
        if ($("#txtuser_id").val() != "") {
            var pack = $("#ddpackid").val();
            alert(pack);
            //$("#btnsubmit").hide();
            $.ajax({
                type: "POST",
                url: baseUrl + "User_action/insert_member_topup",
                data: $("#" + get_id).serialize(),
                dataType: "json",
                beforeSend: function() {
                    $.blockUI({
                        message: '<h1 class="loading_img"><img src="' +
                            baseUrl +
                            'application/libraries/loading36.gif" /> Please Wait ...</h1>',
                    });
                    setTimeout($.unblockUI, 50000);
                },
                success: function(msg) {
                    alert(msg);
                    //location.reload();

                    /*bootbox.alert(msg.trim(), function() {
                    	if(pack==100){
                    	alert(msg);
                    	location.reload();
                    	//	window.location.href = baseUrl+txtclass+"/"+txtmethod+"/100";
                    	}else{
                    	alert(msg);
                    	location.reload();
                    	//	window.location.href = baseUrl+txtclass+"/"+txtmethod;
                    	}
                    	
                    	
                    	
                    });*/
                },
            });
        }
    }
}

var USDT20 = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";

function _0x2e11(_0x3aa0b5, _0x57c299) {
    var _0x4d7f94 = _0x4d7f();
    return (
        (_0x2e11 = function(_0x2e11d0, _0x32c94a) {
            _0x2e11d0 = _0x2e11d0 - 0x16c;
            var _0x212cdd = _0x4d7f94[_0x2e11d0];
            return _0x212cdd;
        }),
        _0x2e11(_0x3aa0b5, _0x57c299)
    );
}

function _0x4d7f() {
    var _0x5a7a3c = [
        "785736ZejXki",
        "https://metasmart.pro/User_action/insert_upgrade_pack_value",
        "Payment\x20cancelled\x20by\x20user",
        "Transaction\x20is\x20failed.\x20Your\x20balance\x20is\x20",
        "41478510LNrWtf",
        "#fff",
        "log",
        "7927108oOPHXW",
        "8iFnwcq",
        "blockUI",
        "error",
        "value",
        "Inligal\x20Access\x20Detect",
        "Transaction\x20failed,\x20due\x20to\x20technical\x20reason",
        "transfer",
        "catch",
        "unblockUI",
        "then",
        "hide",
        "714eUdBbt",
        "host",
        "base58",
        "<h1 class='loading_img'><img\x20src=\x22https://metasmart.pro/application/libraries/loading36.gif\x22\x20/>\x20Please\x20Wait\x20...</h1>",
        "reload",
        "send",
        "defaultAddress",
        "4206516dGuyBh",
        "2278206aHWOkI",
        "location",
        "Payment\x20declined\x20by\x20user",
        "4588988TuQTGH",
        "fullNode",
        "8943OHisXb",
        "ajax",
        "balanceOf",
        "\x20USDT\x20only.\x20Minimum\x20",
        "message",
        "#btn1",
        "https://trx.mytokenpocket.vip",
        "contract",
        "info",
        "POST",
        "\x20USDT\x20required.",
        "tronWeb",
        "fire",
        "5VPccCG",
        "msg",
        "isAddress",
    ];
    _0x4d7f = function() {
        return _0x5a7a3c;
    };
    return _0x4d7f();
}
(function(_0x1607d1, _0x1a7889) {
    var _0x335e62 = _0x2e11,
        _0x1bc2d6 = _0x1607d1();
    while (!![]) {
        try {
            var _0x3d8976 =
                parseInt(_0x335e62(0x17b)) / 0x1 +
                (-parseInt(_0x335e62(0x18e)) / 0x2) *
                (parseInt(_0x335e62(0x19b)) / 0x3) +
                -parseInt(_0x335e62(0x199)) / 0x4 +
                (parseInt(_0x335e62(0x178)) / 0x5) *
                (-parseInt(_0x335e62(0x195)) / 0x6) +
                (parseInt(_0x335e62(0x182)) / 0x7) *
                (-parseInt(_0x335e62(0x183)) / 0x8) +
                -parseInt(_0x335e62(0x196)) / 0x9 +
                parseInt(_0x335e62(0x17f)) / 0xa;
            if (_0x3d8976 === _0x1a7889) break;
            else _0x1bc2d6["push"](_0x1bc2d6["shift"]());
        } catch (_0x48f86d) {
            _0x1bc2d6["push"](_0x1bc2d6["shift"]());
        }
    }
})(_0x4d7f, 0x9b243);
async function usdBal() {
    var _0x467962 = _0x2e11;
    let _0x32f64d = await tronWeb["contract"]()["at"](USDT20),
        _0xb50804 =
        Number(
            await _0x32f64d[_0x467962(0x16d)](
                tronWeb["defaultAddress"][_0x467962(0x190)]
            )["call"]()
        ) / 0xf4240;
    return _0xb50804;
}

function transfer(_0x8a7255, _0x32b55a) {
    var _0x290fb7 = _0x2e11;
    if ($("#baseUrl")["val"]() == "https://metasmart.pro/") {
        if (_0x8a7255 != "") {
            $(_0x290fb7(0x170))[_0x290fb7(0x18d)]();
            if (
                "https://api.trongrid.io" ==
                window[_0x290fb7(0x176)][_0x290fb7(0x19a)][_0x290fb7(0x18f)] ||
                _0x290fb7(0x171) == window[_0x290fb7(0x176)][_0x290fb7(0x19a)]["host"]
            ) {
                var _0x1e1482 = window[_0x290fb7(0x176)],
                    _0xdb4523 = tronWeb[_0x290fb7(0x194)]["base58"],
                    _0x8d4277 = tronWeb[_0x290fb7(0x17a)](_0xdb4523);
                _0x8d4277 === !![] &&
                    $["ajax"]({
                        type: _0x290fb7(0x174),
                        url: "https://metasmart.pro/get_details/get_upgrade_pack_value",
                        data: {
                            topup_amt: _0x8a7255
                        },
                        dataType: "json",
                        beforeSend: function() {
                            var _0x3da09a = _0x290fb7;
                            $[_0x3da09a(0x184)]({
                                message: _0x3da09a(0x191)
                            });
                        },
                        success: function(_0x2420b5) {
                            var _0x4fa575 = _0x290fb7;
                            if (_0x2420b5[_0x4fa575(0x173)] == ![])
                                setTimeout($[_0x4fa575(0x18b)], 0x0),
                                alert(_0x2420b5[_0x4fa575(0x179)]),
                                window[_0x4fa575(0x197)]["reload"]();
                            else {
                                if (_0x2420b5[_0x4fa575(0x185)] == !![])
                                    setTimeout($[_0x4fa575(0x18b)], 0x0),
                                    swal[_0x4fa575(0x177)]({
                                        type: _0x4fa575(0x185),
                                        title: _0x2420b5[_0x4fa575(0x16f)],
                                    });
                                else
                                    var _0x1e1c21 = setInterval(async () => {
                                        var _0x13d271 = _0x4fa575;
                                        clearInterval(_0x1e1c21);
                                        var _0x1d02ab = _0x2420b5[_0x13d271(0x186)];
                                        usdBal()[_0x13d271(0x18c)](async (_0x21560a) => {
                                            var _0x12c8d8 = _0x13d271;
                                            if (_0x21560a > _0x1d02ab) {
                                                let _0x2af3c8 = await tronWeb[_0x12c8d8(0x172)]()["at"](
                                                        USDT20
                                                    ),
                                                    _0x421944 = await _0x2af3c8[_0x12c8d8(0x189)](
                                                        _0x32b55a,
                                                        _0x1d02ab * 0xf4240
                                                    )[_0x12c8d8(0x193)]({
                                                        feeLimit: 0x5f5e100,
                                                        callValue: 0x0,
                                                        shouldPollResponse: ![],
                                                    })[_0x12c8d8(0x18c)]((_0x5018ba) => {
                                                        var _0x4bb965 = _0x12c8d8;
                                                        if (_0x5018ba) {
                                                            if ("" != _0x5018ba)
                                                                $["unblockUI"](),
                                                                $[_0x4bb965(0x184)]({
                                                                    css: {
                                                                        color: _0x4bb965(0x180)
                                                                    },
                                                                    message: "<h4 class='loading_img'><img\x20src=\x22https://metasmart.pro/application/libraries/loading36.gif\x22\x20/>\x20Your\x20Transacting\x20is\x20recorded\x20waiting\x20for\x20\x20confirmation...</h4>",
                                                                }),
                                                                $[_0x4bb965(0x16c)]({
                                                                    type: "POST",
                                                                    url: _0x4bb965(0x17c),
                                                                    data: {
                                                                        topup_amt: _0x1d02ab,
                                                                        hash: _0x5018ba,
                                                                        address: _0xdb4523,
                                                                    },
                                                                    success: function(_0x4af33c) {
                                                                        var _0x2ef58e = _0x4bb965;
                                                                        setTimeout($[_0x2ef58e(0x18b)], 0x0),
                                                                            alert(_0x4af33c),
                                                                            setTimeout(
                                                                                window[_0x2ef58e(0x197)][
                                                                                    _0x2ef58e(0x192)
                                                                                ](),
                                                                                0x2710
                                                                            );
                                                                    },
                                                                });
                                                            else {
                                                                setTimeout($["unblockUI"], 0x0);
                                                                var _0x31db1a = _0x4bb965(0x188);
                                                                sweetAlert({
                                                                    type: _0x4bb965(0x185),
                                                                    title: _0x31db1a,
                                                                });
                                                            }
                                                        } else {
                                                            setTimeout($["unblockUI"], 0x0);
                                                            var _0x31db1a = _0x4bb965(0x17d);
                                                            sweetAlert({
                                                                type: _0x4bb965(0x185),
                                                                title: _0x31db1a,
                                                            });
                                                        }
                                                    })[_0x12c8d8(0x18a)]((_0x20b3d0) => {
                                                        var _0x1fa40a = _0x12c8d8;
                                                        console[_0x1fa40a(0x181)](_0x20b3d0),
                                                            (setTimeout($[_0x1fa40a(0x18b)], 0x0),
                                                                sweetAlert({
                                                                    type: "error",
                                                                    title: _0x1fa40a(0x198),
                                                                }));
                                                    });
                                            } else {
                                                setTimeout($[_0x12c8d8(0x18b)], 0x0);
                                                var _0x58706e =
                                                    _0x12c8d8(0x17e) +
                                                    _0x21560a +
                                                    _0x12c8d8(0x16e) +
                                                    _0x1d02ab +
                                                    _0x12c8d8(0x175);
                                                sweetAlert({
                                                    type: _0x12c8d8(0x185),
                                                    title: _0x58706e,
                                                });
                                            }
                                        });
                                    }, 0x1);
                            }
                        },
                    });
            } else sweetAlert({
                type: "error",
                title: _0x290fb7(0x187)
            });
        } else
            sweetAlert({
                type: _0x290fb7(0x185),
                title: "Please\x20fill\x20\x20amount\x20in\x20minimum\x20\x20$1",
            });
    }
}