
            $(function () {
  "use strict";

  const chartConfigs = [
    { id: "chart1", name: "Total Sales", color: "#F59E0B", gradient: "#FCD34D", data: [10, 15, 30, 25, 40, 20, 60, 35, 20] },
    { id: "chart2", name: "New Users", color: "#10B981", gradient: "#6EE7B7", data: [2, 5, 10, 15, 12, 18, 24, 28, 30] },
    { id: "chart3", name: "Revenue", color: "#6366F1", gradient: "#A5B4FC", data: [20, 25, 35, 45, 30, 50, 60, 80, 70] },
    { id: "chart4", name: "Registrations", color: "#EC4899", gradient: "#F9A8D4", data: [5, 10, 15, 10, 20, 15, 25, 30, 35] },
    { id: "chart5", name: "Withdrawals", color: "#EF4444", gradient: "#FCA5A5", data: [3, 8, 5, 12, 7, 15, 20, 10, 9] },
    { id: "chart6", name: "Referrals", color: "#8B5CF6", gradient: "#C4B5FD", data: [1, 4, 9, 14, 12, 10, 18, 22, 25] },
    { id: "chart7", name: "Active Users", color: "#14B8A6", gradient: "#99F6E4", data: [6, 12, 18, 16, 22, 24, 28, 26, 30] },
    { id: "chart8", name: "Clicks", color: "#F97316", gradient: "#FDBA74", data: [30, 28, 32, 35, 40, 42, 38, 44, 48] },
    { id: "chart9", name: "Transactions", color: "#0EA5E9", gradient: "#7DD3FC", data: [15, 20, 18, 25, 30, 28, 35, 40, 38] },
    { id: "chart10", name: "Earnings", color: "#22C55E", gradient: "#86EFAC", data: [1000, 1200, 1500, 1400, 1700, 2000, 2100, 2300, 2500] },
    { id: "chart11", name: "Referrals", color: "#8B5CF6", gradient: "#C4B5FD", data: [1, 4, 9, 14, 12, 10, 18, 22, 25] },
     { id: "chart12", name: "Registrations", color: "#EC4899", gradient: "#F9A8D4", data: [5, 10, 15, 10, 20, 15, 25, 30, 35] },
      { id: "chart13", name: "Clicks", color: "#F97316", gradient: "#FDBA74", data: [30, 28, 32, 35, 40, 42, 38, 44, 48] }
  ];

  chartConfigs.forEach(cfg => {
    var options = {
      series: [{ name: cfg.name, data: cfg.data }],
      chart: {
        height: 105,
        type: 'area',
        sparkline: { enabled: true },
        zoom: { enabled: false }
      },
      dataLabels: { enabled: false },
      stroke: {
        width: 3,
        curve: 'smooth'
      },
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'dark',
          gradientToColors: [cfg.gradient],
          shadeIntensity: 1,
          type: 'vertical',
          opacityFrom: 0.5,
          opacityTo: 0.0
        }
      },
      colors: [cfg.color],
      tooltip: {
        theme: "dark",
        fixed: { enabled: false },
        x: { show: false },
        y: {
          title: {
            formatter: () => ''
          }
        },
        marker: { show: false }
      },
      xaxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep']
      }
    };

    const chart = new ApexCharts(document.querySelector(`#${cfg.id}`), options);
    chart.render();
  });

});