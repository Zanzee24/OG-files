<?php
require_once("loginCheck.php");
include 'include/header.php';
include 'include/head.php';

?>
</body>

<body class="dark-mode">
    <!-- Modal -->

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Level Qualify Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Level Qualify Income</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>


                <!-- Referral Team Section -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Level Qualify Income</h4>
                            <div class="table-responsive">
                                <table class="table dataTable table-border w-100 table-striped nowrap" id="export-button">
                                   <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>UserId</th>
                                                <th>Name</th>
                                                <th>Reward Income</th>
                                                <th>DateTime</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryReward = mysqli_query($con, "SELECT a.rewardIncome,a.dateTime,a.status,b.user_id,b.name FROM meddolic_user_bot_reward_income a, meddolic_user_details b WHERE a.memberId='$memberId' AND a.memberId=b.member_id AND a.status =1 ORDER BY a.dateTime ASC");
                                            while ($valReward = mysqli_fetch_assoc($queryReward)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valReward['user_id'] ?></td>
                                                    <td><?= $valReward['name'] ?></td>
                                                    <td><i class="fa-solid fa fa-usd"></i> <?= $valReward['rewardIncome'] ?></td>
                                                    <td><i class="fa-regular fa-clock"></i> <?= date("d-m-Y H:i:s", strtotime($valReward['dateTime'])) ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var d = document.getElementById("income_reports");
        d.className += " active";
        var d = document.getElementById("levelQualify.php");
        d.className += " active";
    </script>

    <?php include 'include/footer.php'; ?>