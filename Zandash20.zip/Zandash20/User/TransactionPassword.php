<?php include 'Include/Head.php'; ?>
<?php include 'Include/Menu.php'; ?>
<?php include 'Include/Header.php'; ?>


<div class="body-wrapper">
        <div class="container-fluid">
          <div class="card card-body">
            <div class="row align-items-center">
              <div class="col-12">
                <div class="d-sm-flex align-items-center justify-space-between">
                  <h4 class="fw-semibold fs-4 mb-4 mb-md-0 card-title">Change Transaction Password </h4>
                  <nav aria-label="breadcrumb" class="ms-auto">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item d-flex align-items-center">
                        <a class="text-muted text-decoration-none d-flex" href="dashboard.php">
                          <iconify-icon icon="solar:home-2-line-duotone" class="fs-6"></iconify-icon>
                        </a>
                      </li>
                      <li class="breadcrumb-item" aria-current="page">
                        <span class="badge fw-medium fs-2 bg-primary-subtle text-primary">
                         Change Transaction Password
                        </span>
                      </li>
                    </ol>
                  </nav>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-12">
              <!-- ----------------------------------------- -->
              <!-- 1. Basic Form -->
              <!-- ----------------------------------------- -->
              <!-- start Basic Form -->
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title mb-3">Change Transaction Password</h4>
                  <form>
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-floating mb-3">
                          <input type="text" class="form-control" id="tb-fname" placeholder="Enter Password here">
                          <label for="tb-fname">Current Transaction Password</label>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-floating mb-3">
                          <input type="password" class="form-control" id="tb-email" placeholder="Password">
                          <label for="tb-email">New Transaction Password </label>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="form-floating mb-3">
                          <input type="password" class="form-control" id="tb-pwd" placeholder="Password">
                          <label for="tb-pwd">Retype Transaction Password </label>
                        </div>
                      </div>
                     
                      <div class="col-12">
                        <div class="d-md-flex align-items-center">
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                            <label class="form-check-label" for="flexCheckDefault">
                              Remember me
                            </label>
                          </div>
                          <div class="ms-auto mt-3 mt-md-0">
                            <button type="submit" class="btn btn-primary hstack gap-6">
                              Submit
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!-- end Basic Form -->
            </div>
          

           
           
          </div>
        </div>
      </div>
<?php include 'Include/Footer.php'; ?>