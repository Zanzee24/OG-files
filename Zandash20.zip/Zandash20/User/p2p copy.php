<?php include 'include/head.php';
require_once("loginCheck.php");

?>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success">
                        <i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard.php" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Manage Fund</li>
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Fund Transfer</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Fund Transfer</h4>
                            </div>
                        </div>
                    </div>
                </div>

              
                <script src="assets/js/iconify-icon.min.js"></script>
                <script src="assets/iconify-icon.min.js"></script>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <form class="theme-form" action="fundTransferProcess.php" method="post">
                                    <div class="mb-3">
                                        <label>UserId </label>
                                        <input type="text" name="sponser_id" id="sponser_id" class="form-control"
                                            placeholder="e.g. xxxxxxxxxx" onblur="sponser_valid(this.value)" required>
                                        <input type="hidden" name="loginMemberId" value="<?= $memberId ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Name </label>
                                        <input type="text" id="sponser_name" class="form-control" 
                                            placeholder="e.g. John Doe" disabled="">
                                    </div>
                                    <div class="mb-3">
                                        <label>Fund Wallet (Min Transfer <?= $minTransfer ?> )</label>
                                        <input type="text" id="current_wallet" name="current_wallet"
                                            class="form-control" readonly value="<?= $fundWallet ?>">
                                        <input type="hidden" name="minTransfer" readonly value="<?= $minTransfer ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label>Amount To Transfer -:</label>
                                        <input type="number" id="amount" name="amount" class="form-control"
                                            placeholder="e.g. Transfer Amount" onkeypress="return onlynum(event)"
                                            required>

                                    </div>
                                    <div class="mb-3">
                                        <label>Transaction Password *</label>
                                        <input type="password" name="trnPassword" id="trnPassword" class="form-control"
                                            placeholder="e.g. Transaction Password" required>
                                    </div>

                                    <div class="">
                                        <button class="btn btn-primary" data-bs-original-title="" title="Transfer"
                                            name='fundTransfer' value="Transfer">Transfer</button>
                                    </div>
                                </form>

                                <div class="row mt-3">
                                    <!--<div class="col-sm-6">-->
                                    <!--    <div class="form-group row">-->
                                    <!--        <div class="col-sm-9">-->
                                    <!--            <label class="label-on-left">OTP <span-->
                                    <!--                    style="color:red">*</span></label>-->
                                    <!--            <input type="text" class="form-control empty" id="txtotp" name="txtotp"-->
                                    <!--                placeholder="Enter OTP" autocomplete="off" required>-->
                                    <!--            <span id="divtxtotp" class="text-danger"></span>-->
                                    <!--            <span id="divtotp" class="text-success"></span>-->
                                    <!--        </div>-->
                                    <!--        <div class="col-sm-3">-->
                                    <!--            <label class="label-on-left">&nbsp;</label>-->
                                    <!--            <button type="button" class="btn-info btn mt-2"-->
                                    <!--                onclick="send_otp_email()">Send OTP</button>-->
                                    <!--        </div>-->
                                    <!--    </div>-->
                                    <!--</div>-->

                                    <!--<div class="col-md-3">-->
                                    <!--    <label class="control-label">&nbsp;</label>-->
                                    <!--    <button class="btn btn-success" type="button"-->
                                    <!--        onclick="conwv2('fundtransfer')">Submit</button>-->
                                    <!--</div>-->
                                </div>
                                </form>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 mt-4">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">View Fund Transfer</h4>
                                <div class="table-responsive">
                                    <table class="table dataTable w-100 table-striped nowrap">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Date</th>
                                                <th>User Id</th>
                                                <th>User Name</th>
                                                <th>From Wallet</th>
                                                <th>To Wallet</th>
                                                <th>Transfer Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryTransfer = mysqli_query($con, "SELECT a.amount,a.date_time,b.user_id AS senderId,b.name AS senderName,c.user_id AS receiverId,c.name AS receiverName FROM meddolic_user_fund_transfer_history a, meddolic_user_details b, meddolic_user_details c WHERE a.sender_member_id='$memberId' AND a.sender_member_id=b.member_id AND a.receiver_member_id=c.member_id ORDER BY a.date_time DESC");
                                            while ($valTransfer = mysqli_fetch_assoc($queryTransfer)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valTransfer['senderId'] ?></td>
                                                    <td><?= $valTransfer['senderName'] ?></td>
                                                    <td><?= $valTransfer['receiverId'] ?></td>
                                                    <td><?= $valTransfer['receiverName'] ?></td>
                                                    <td><span class="badge badge-danger"><i class="fa fa-usd"></i>
                                                            <?= $valTransfer['amount'] ?></span></td>
                                                    <td><i class="fa fa-clock-o"></i>
                                                        <?= date("d-m-Y H:i:s", strtotime($valTransfer['date_time'])) ?>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="card-arrow">
                                <div class="card-arrow-top-left"></div>
                                <div class="card-arrow-top-right"></div>
                                <div class="card-arrow-bottom-left"></div>
                                <div class="card-arrow-bottom-right"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include 'include/footer.php'; ?>
        <script>
            var d = document.getElementById("Fund");
            d.className += " active";
            var d = document.getElementById("p2p");
            d.className += " active";
        </script>
        

    </div>
</body>

</html>