<?php include 'include/head.php'; ?>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="https://www.bitcapitalx.com/p2p_exchnange/dashboard" class="btn btn-success">
                        <i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
				<img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid d-none">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="https://www.bitcapitalx.com/Userprofile/dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item">
                                            <a href="javascript: void(0);">Performance Dividend Level Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Performance Dividend Level Income</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Performance Dividend Level Income</h4>
                                <form action="https://www.bitcapitalx.com/user_report/view_level_income_report/8/Performance Dividend Level Income" 
                                      method="get" class="cmxform form-horizontal" id="signupForm" accept-charset="utf-8">
                                    <div class="row">
                                        <div class="col-sm-2 col-6">
                                            <div class="form-group">
                                                <input type="date" class="form-control" name="start" value="" placeholder="From Date">
                                            </div>
                                        </div>
                                        <div class="col-sm-2 col-6">
                                            <div class="form-group">
                                                <input type="date" class="form-control" name="end" value="" placeholder="To Date">
                                            </div>
                                        </div>
                                        <div class="col-md-2 col-6">
                                            <div class="form-group">
                                                <button class="btn btn-success" type="submit">Search</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Performance Dividend Level Income</h4>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered nowrap w-100">
                                        <thead>
                                            <tr>
                                                <th>S No.</th>
                                                <th>Date</th>
                                                <th>User Id</th>
                                                <th>User Name</th>
                                                <th>Description</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="4" class="text-right"><strong>Total:</strong></td>
                                                <td class="text-right"><strong>$0.00</strong></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>

                                <!-- Pagination Links -->
                                <div class="d-flex justify-content-center mt-3">
                                    <style>
                                        .pagination {
                                            display: flex;
                                            justify-content: center;
                                            padding-left: 0;
                                            list-style: none;
                                            border-radius: 0.25rem;
                                        }
                                        .pagination li a,
                                        .pagination li span {
                                            position: relative;
                                            display: block;
                                            padding: 8px 14px;
                                            margin-left: -1px;
                                            line-height: 1.25;
                                            color: #f7941d;
                                            background-color: #000;
                                            border: 1px solid #444;
                                            text-decoration: none;
                                        }
                                        .pagination li.active span {
                                            z-index: 1;
                                            color: white;
                                            background-color: #f7941d;
                                            border-color: #f7941d;
                                        }
                                        .pagination li.disabled span {
                                            color: #666;
                                            pointer-events: none;
                                            background-color: #111;
                                            border-color: #444;
                                        }
                                    </style>
                                    <nav>
                                        <ul class="pagination">
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php include 'include/footer.php'; ?>
        </div>
    </div>
</body>
</html>