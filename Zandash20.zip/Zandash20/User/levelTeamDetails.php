<!DOCTYPE html>
<html lang="en">
<?php
require_once("loginCheck.php");
require_once('include/head.php');

?>
<?php
if ($_GET) {
  if ($_GET['fromDate']) {
    $showDate = $_GET['fromDate'];
    $calDate = date("Y-m-d", strtotime($showDate));
  }
  if ($_GET['toDate']) {
    $showDate1 = $_GET['toDate'];
    $calDate1 = date("Y-m-d", strtotime($showDate1));
  }
} else {
  $showDate = date("d-m-Y");
  $showDate1 = date("d-m-Y");
  $calDate = date("Y-m-d");
  $calDate1 = date("Y-m-d");
}
?>

<body class="dark-mode">
  <div class="wrapper">
    <div class="leftside-menu">
      <a href="dashboard" class="main_sidebar_logo">
        <span>
          <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
        </span>
      </a>
      <?php include 'include/sidebar.php'; ?>
    </div>
    <div class="content-page">
      <div class="content">
        <!-- Topbar Start -->
        <?php include 'include/header.php'; ?>

        <div class="container-fluid">
          <div class="row">
            <div class="col-12">
              <div class="page-title-box">
                <div class="page-title-right">
                  <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="Dashboard">Dashboard</a></li>
                    <li class="breadcrumb-item active">Team & Network</li>
                  </ol>
                </div>
                <h4 class="card-title ">Level <?= $_GET['LevelID'] ?> View</h4>
              </div>
            </div>
          </div>
    

          <div class="col-12">
            <div class="card">
              <div class="card-body">
               <h4 class="card-title ">Level <?= $_GET['LevelID'] ?> View</h4>
                <div class="table-responsive">
                  <table class="table dataTable w-100 table-striped nowrap">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>UserId</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Join Date</th>
                        <th>Account Status</th>
                        <th>Active Date</th>
                        <th>Total Invest</th>
                        <th>Total Withdrawal</th>

                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      function totalWithdrawl($con, $memberId)
                      {
                        $queryWithdrawl = mysqli_query($con, "SELECT SUM(amount) FROM meddolic_user_wallet_withdrawal_crypto WHERE member_id='$memberId' AND released=1");
                        $valWithdrawl = mysqli_fetch_array($queryWithdrawl);
                        if ($valWithdrawl[0] != "") {
                          return $valWithdrawl[0];
                        } else {
                          echo "0.00";
                        }
                      }
                      function totalInvest($con, $memberId)
                      {
                        $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'");
                        $valInvest = mysqli_fetch_array($queryInvest);
                        if ($valInvest[0] != "") {
                          return $valInvest[0];
                        } else {
                          echo "0.00";
                        }
                      }
                      $count = 0;
                      $queryTeam = mysqli_query($con, "SELECT a.member_id,a.user_id,a.name,a.date_time,a.activation_date,a.topup_flag,a.phone FROM meddolic_user_details a, meddolic_user_child_ids b WHERE a.member_id=b.child_id AND b.member_id='$memberId' AND b.level='$_GET[LevelID]' ORDER BY b.date_time DESC");
                      while ($valTeam = mysqli_fetch_assoc($queryTeam)) {
                        $count++; ?>
                        <tr>
                          <td><?= $count ?></td>
                          <td><?= $valTeam['user_id'] ?></td>
                          <td><?= $valTeam['name'] ?></td>
                          <td><?= $valTeam['phone'] ?></td>
                          <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valTeam['date_time'])); ?></td>
                          <td><?php if ($valTeam['topup_flag'] == 1) echo "<span class='badge badge-success'>Active</span>";
                              else echo "<span class='badge badge-danger'>In-Active</span>"; ?></td>
                          <td><?= $valTeam['activation_date'] ?></td>
                          <td><span class="badge badge-success">$ <?= totalInvest($con, $valTeam['member_id']) ?></span></td>
                          <td>$ <?= totalWithdrawl($con, $valTeam['member_id']) ?></td>

                        </tr>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="card-arrow">
                <div class="card-arrow-top-left"></div>
                <div class="card-arrow-top-right"></div>
                <div class="card-arrow-bottom-left"></div>
                <div class="card-arrow-bottom-right"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>

  <?php include 'include/footer.php'; ?>

  <script>
    var d = document.getElementById("Team");
    d.className += " active";
    var d = document.getElementById("myLevelTeam");
    d.className += " active";
  </script>
</body>

</html>