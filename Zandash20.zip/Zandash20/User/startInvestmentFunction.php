<?php
//Wallet Add & Statement Add Code Starts//

function incomeEntry($con, $memberId, $trnId, $incomeAmount, $statementId, $d)
{
  mysqli_query($con, "INSERT INTO meddolic_user_wallet_statement (`member_id`,`wallet_statement_id`,`deb_cr`,`amount`,`date_time`,`trn_id`) VALUES ('$memberId','$statementId',2,'$incomeAmount','$d','$trnId')");

  mysqli_query($con, "UPDATE meddolic_user_details SET wallet=wallet+'$incomeAmount' WHERE member_id='$memberId'");
}
// //Wallet Add & Statement Add Code Ends//


// Bot Direct Income Code Start
function botReferralIncome($con, $sponserId, $memberId, $packageAmount, $packageId, $d)
{
  $queryConfig = mysqli_query($con, "SELECT botReferralPercent FROM meddolic_config_misc_setting WHERE id=1");
  $valConfig = mysqli_fetch_assoc($queryConfig);
  $referralPercent = $valConfig['botReferralPercent'];
  $referralIncome = $packageAmount * $referralPercent / 100;

  $queryInsert = mysqli_query($con, "INSERT INTO meddolic_user_bot_sponsor_income (memberId,childId,referralIncome,packagePrice,packageId,dateTime,referralPercent) VALUES ('$sponserId', '$memberId', '$referralIncome','$packageAmount', '$packageId', '$d', '$referralPercent')");
  $directInId = $con->insert_id;
  incomeEntry($con, $sponserId, $directInId, $referralIncome, 3, $d);
}

//Bot Direct Income Code Ends

//Bot Level Income Code Starts
function releaseBotLevelIncome($con, $memberId, $packagePrice, $packageId, $d)
{
  // Initial query to get the first parent
  $queryNew = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND  a.sponser_id = b.member_id AND b.topup_flag = 1 AND b.account_status = 1");

  $valNew = mysqli_fetch_assoc($queryNew);
  $parentId = $valNew['sponser_id'];
  $topupFlag = $valNew['topup_flag'];

  $level = 1;
  while ($parentId  && $level <= 5) {
    if ($topupFlag == 1) {
      $queryConfig = mysqli_query($con, "SELECT levelPercent FROM meddolic_config_bot_level_income WHERE level='$level' AND status=1");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $levelPercent = $valConfig['levelPercent'];

      $levelIncome = $packagePrice * $levelPercent / 100;

      $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_bot_level_income (`memberId`,`childId`,`levelPercent`,`level`,`packageId`,`levelIncome`,`packageAmount`,`dateTime`) VALUES ('$parentId','$memberId','$levelPercent','$level','$packageId','$levelIncome','$packagePrice','$d')");

      $levelInId = $con->insert_id;
      incomeEntry($con, $parentId, $levelInId, $levelIncome, 1, $d);
    }

    $queryUser = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$parentId'  AND a.sponser_id=b.member_id ");
    $valUser = mysqli_fetch_assoc($queryUser);
    $parentId = $valUser['sponser_id'];
    $topupFlag = $valUser['topup_flag'];
    $level++;
  }
}

//bot Level Income Code Ends

//reward Income Code Ends
function relayBotRewardLoop($con, $memberId, $d)
{

  $queryMain = mysqli_query($con, "SELECT member_id,currentBotReward FROM meddolic_user_details WHERE member_id IN (SELECT member_id FROM meddolic_user_child_ids WHERE child_id='$memberId') AND currentBotReward<5 AND topup_flag=1 AND account_status=1");
  while ($valReward = mysqli_fetch_assoc($queryMain)) {
    $parentId = $valReward['member_id'];
    $currentReward = $valReward['currentBotReward'];
    $nextReward = $currentReward + 1;

    if ($nextReward <= 5) {
      $queryConfig = mysqli_query($con, "SELECT rewardId,teamNeed,rewardIncome FROM meddolic_config_bot_reward_income WHERE rewardId ='$nextReward'");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $rewardId = $valConfig['rewardId'];
      $teamNeed = $valConfig['teamNeed'];
      $rewardIncome = $valConfig['rewardIncome'];

      releaseBotRewardIncome($con, $parentId, $rewardId, $teamNeed, $rewardIncome, $d);
    }
  }
}

function releaseBotRewardIncome($con, $parentId, $rewardId, $teamNeed, $rewardIncome, $d)
{

  // $queryTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE memberId IN ( SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$parentId' AND topup_status=1 AND level==1)");
  // $valTeam = mysqli_fetch_array($queryTeam);
  // $teamLevel1 = $valTeam[0];

  // Loop through level 1 to 5
  $totalTeam = 0;
  for ($level = 1; $level <= 5; $level++) {
    $queryTeam = mysqli_query($con, "SELECT COUNT(1) FROM meddolic_user_details WHERE member_id IN (SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$parentId' AND topup_status=1 AND level=$rewardId)");
    $valTeam = mysqli_fetch_array($queryTeam);
    $teamCount = (int)$valTeam[0];

    // Add to total team count
    $totalTeam += $teamCount;
  }

  if ($totalTeam >= $teamNeed) {
    mysqli_query($con, "UPDATE meddolic_user_details SET currentBotReward = '$rewardId' WHERE member_id = '$parentId'");

    mysqli_query($con, "INSERT INTO meddolic_user_bot_reward_income (`memberId`, `rewardId`, `rewardIncome`, `dateTime`, `status`) VALUES  ('$parentId', '$rewardId', '$rewardIncome', '$d', 1)");
    $rewardInId = $con->insert_id;
    incomeEntry($con, $parentId, $rewardInId, $rewardIncome, 1, $d);
    $nextReward = $rewardId + 1;
    if ($nextReward <= 5) {
      $queryConfig = mysqli_query($con, "SELECT rewardId,teamNeed,rewardIncome FROM meddolic_config_bot_reward_income WHERE rewardId ='$nextReward'");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $rewardId = $valConfig['rewardId'];
      $teamNeed = $valConfig['teamNeed'];
      $rewardIncome = $valConfig['rewardIncome'];

      releaseBotRewardIncome($con, $parentId, $rewardId, $teamNeed, $rewardIncome, $d);
    }
  }
}

//reward Income Code Ends

// ====================================================================================================================================================================================================================

// Bot Direct Income Code Start
function releaseReferralIncome($con, $sponserId, $memberId, $packageAmount, $packageId, $d)
{
  $queryConfig = mysqli_query($con, "SELECT referralPercent FROM meddolic_config_misc_setting WHERE id=1");
  $valConfig = mysqli_fetch_assoc($queryConfig);
  $referralPercent = $valConfig['referralPercent'];
  $referralIncome = $packageAmount * $referralPercent / 100;

  $queryInsert = mysqli_query($con, "INSERT INTO meddolic_user_sponsor_income (memberId,childId,referralIncome,packagePrice,packageId,dateTime,referralPercent) VALUES ('$sponserId', '$memberId', '$referralIncome','$packageAmount', '$packageId', '$d', '$referralPercent')");
  $directInId = $con->insert_id;
  incomeEntry($con, $sponserId, $directInId, $referralIncome, 3, $d);
}

//Bot Direct Income Code Ends




// Level Income Code Starts
function releaseLevelIncome($con, $memberId, $packageId, $roiAmount, $packagePrice, $d)
{
  // Initial query to get the first parent
  $queryNew = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND  a.sponser_id = b.member_id AND b.topup_flag = 1 AND b.account_status = 1");

  $valNew = mysqli_fetch_assoc($queryNew);
  $parentId = $valNew['sponser_id'];
  $topupFlag = $valNew['topup_flag'];

  $level = 1;
  while ($parentId  && $level <= 25) {
    if ($topupFlag == 1) {
      // Query for configuration
      $queryConfig = mysqli_query($con, "SELECT levelPercent, directNeed FROM meddolic_config_level_income WHERE level='$level' AND status=1");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $levelPercent = $valConfig['levelPercent'];
      $directNeed = $valConfig['directNeed'];

      // Query for direct count
      $directCountQuery = mysqli_query($con,  "SELECT COUNT(*) AS directCount FROM meddolic_user_details WHERE sponser_id='$parentId' AND user_type=2 AND topup_flag=1");
      $directCountResult = mysqli_fetch_assoc($directCountQuery);
      $directCount = $directCountResult['directCount'];

      if ($directCount >= $directNeed) {
        $levelIncome = $roiAmount * $levelPercent / 100;

        $queryIn = mysqli_query($con, "INSERT INTO meddolic_user_level_income (`memberId`,`childId`,`levelPercent`,`roiIncome`,`level`,`packageId`,`levelIncome`,`packageAmount`,`dateTime`) VALUES ('$parentId','$memberId','$levelPercent','$roiAmount','$level','$packageId','$levelIncome','$packagePrice','$d')");

        $levelInId = $con->insert_id;
        incomeEntry($con, $parentId, $levelInId, $levelIncome, 1, $d);
      }
    }

    $queryUser = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$parentId'  AND a.sponser_id=b.member_id ");
    $valUser = mysqli_fetch_assoc($queryUser);
    $parentId = $valUser['sponser_id'];
    $topupFlag = $valUser['topup_flag'];
    $level++;
  }
}



// Level Income Code Ends

// Booster Income

//Reward Income Code Starts
function releaseRewardIncome($con, $parentId, $rewardId, $totalBusiness, $rewardIncome, $oneLeg, $twoLeg, $otherLeg, $d, $tokenRate)
{
  $items = array();
  $totalBus = 0;
  $queryBusss = mysqli_query($con, "SELECT member_id FROM meddolic_user_details WHERE sponser_id='$parentId' ORDER BY activation_date ASC");
  while ($valDirect = mysqli_fetch_assoc($queryBusss)) {
    $directId = $valDirect['member_id'];

    $queryOwn = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$directId'");
    $valOwn = mysqli_fetch_array($queryOwn);

    $queryBus = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId IN ( SELECT child_id FROM meddolic_user_child_ids WHERE member_id='$directId' AND topup_status=1)");
    $valBus = mysqli_fetch_array($queryBus);
    $netBus = $valBus[0] + $valOwn[0];
    $totalBus += $netBus;
    $items[] = $netBus;
  }

  rsort($items);
  $restLeg = 0;
  $arrlength = count($items);
  for ($countLoop = 0; $countLoop < $arrlength; $countLoop++) {
    if ($countLoop == 0) {
      $firstLeg = $items[$countLoop];
    } else if ($countLoop == 1) {
      $secondLeg = $items[$countLoop];
    } else {
      $restLeg += $items[$countLoop];
    }
  }
  $allBus = $firstLeg + $secondLeg + $restLeg;
  $queryDebit = mysqli_query($con, "SELECT SUM(totalBusiness),SUM(oneLeg),SUM(twoLeg),SUM(otherLeg) FROM meddolic_user_reward_summary WHERE memberId='$parentId'");
  $valDebit = mysqli_fetch_array($queryDebit);
  $totalDebit = $valDebit[0];
  $oneDebit = $valDebit[1];
  $twoDebit = $valDebit[2];
  $restDebit = $valDebit[3];

  $netPrimary = $allBus - $totalDebit;
  $netOneLeg = $firstLeg - $oneDebit;
  $netTwoLeg = $secondLeg - $twoDebit;
  $netRest = $restLeg - $restDebit;
  $totalrewardcoins = $rewardIncome / $tokenRate;

  if ($netOneLeg >= $oneLeg && $netTwoLeg >= $twoLeg && $netRest >= $otherLeg && $netPrimary >= $totalBusiness) {

    $queryLd = mysqli_query($con, "INSERT INTO meddolic_user_reward_summary (`memberId`,`rewardId`,`rewardIncome`,`totalBusiness`,`oneLeg`,`twoLeg`,`otherLeg`,`dateTime`) VALUES ('$parentId','$rewardId','$rewardIncome','$totalBusiness','$oneLeg','$twoLeg','$otherLeg','$d')");

    mysqli_query($con, "UPDATE meddolic_user_details SET rewardRank=rewardRank+1 WHERE member_id='$parentId'");
    $nextRank = $rewardId + 1;
    if ($nextRank <= 10) {
      $queryCo = mysqli_query($con, "SELECT rewardId,totalBusiness,rewardIncome,firstLeg,secondLeg,otherLeg FROM meddolic_config_reward_income WHERE rewardId='$nextRank'");
      $valCo = mysqli_fetch_assoc($queryCo);
      $newRewardId = $valCo['rewardId'];
      $totalBusiness = $valCo['totalBusiness'];
      $rewardIncome = $valCo['rewardIncome'];
      $oneLeg = $valCo['firstLeg'];
      $twoLeg = $valCo['secondLeg'];
      $otherLeg = $valCo['otherLeg'];
      releaseRewardIncome($con, $parentId, $newRewardId, $totalBusiness, $rewardIncome, $oneLeg, $twoLeg, $otherLeg, $d, $tokenRate);
    }
  }
}

function relaySalaryLoop($con, $memberId, $d, $tokenRate)
{
  $queryReward = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag,b.rewardRank,b.account_status FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$memberId' AND a.sponser_id=b.member_id");
  $valReward = mysqli_fetch_assoc($queryReward);
  $parentId = $valReward['sponser_id'];
  $topupFlag = $valReward['topup_flag'];
  $currentReward = $valReward['rewardRank'];
  $nextReward = $currentReward + 1;
  $acctStatus = $valReward['account_status'];
  while ($parentId) {
    if ($nextReward <= 10 && $topupFlag == 1 && $acctStatus == 1) {
      $queryConfig = mysqli_query($con, "SELECT rewardId,totalBusiness,rewardIncome,firstLeg,secondLeg,otherLeg FROM meddolic_config_reward_income WHERE rewardId='$nextReward'");
      $valConfig = mysqli_fetch_assoc($queryConfig);
      $rewardId = $valConfig['rewardId'];
      $totalBusiness = $valConfig['totalBusiness'];
      $rewardIncome = $valConfig['rewardIncome'];
      $oneLeg = $valConfig['firstLeg'];
      $twoLeg = $valConfig['secondLeg'];
      $otherLeg = $valConfig['otherLeg'];

      releaseRewardIncome($con, $parentId, $rewardId, $totalBusiness, $rewardIncome, $oneLeg, $twoLeg, $otherLeg, $d, $tokenRate);
    }
    $query_monthly = mysqli_query($con, "SELECT a.sponser_id,b.topup_flag,b.rewardRank,b.account_status FROM meddolic_user_details a, meddolic_user_details b WHERE a.member_id='$parentId' AND a.sponser_id=b.member_id");
    $val_monthly = mysqli_fetch_assoc($query_monthly);
    $parentId = $val_monthly['sponser_id'];
    $topupFlag = $val_monthly['topup_flag'];
    $currentReward = $val_monthly['rewardRank'];
    $nextReward = $currentReward + 1;
    $acctStatus = $val_monthly['account_status'];
  }
}
//Reward Income Code end
