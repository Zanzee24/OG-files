<?php include 'include/head.php';
include("loginCheck.php");
$queryProfile = mysqli_query($con, "SELECT date_time, sponser_id FROM meddolic_user_details WHERE user_id='$userId'");
$valProfile = mysqli_fetch_assoc($queryProfile);
$dateTime = $valProfile['date_time'];
$sponserId = $valProfile['sponser_id'];

if ($countryId != '') {
    $queryCountry = mysqli_query($con, "SELECT countryName FROM meddolic_config_country_list WHERE country_id='$countryId'");
    $valCountry = mysqli_fetch_assoc($queryCountry);
    $countryName = $valCountry['countryName'];
}



?>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success">
                        <i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>

        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Change Password</li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Change Password</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>

                <div class="row p-3">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <form action="my-profileupdate.php" method="post">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <!-- Current Password Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">Current Password *</label>
                                                <div class="password-input-container">
                                                    <input type="password" class="form-control" name="password"
                                                        id="currentPass" placeholder="Enter current password">
                                                    <input type="hidden" name="memberId" value="<?= $memberId ?>">
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                </div>
                                            </div>

                                            <!-- New Password Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">New Password *</label>
                                                <div class="password-input-container">
                                                    <input type="password" class="form-control" id="loginPassword"
                                                        name="password1" placeholder="Enter new password"
                                                        onkeyup="checkPasswordStrength(this.value)">
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                </div>
                                                <div class="password-strength mt-2">
                                                    <div class="strength-meter" id="strengthMeter"></div>
                                                </div>
                                              
                                            </div>

                                            <!-- Confirm Password Field -->
                                            <div class="form-group mb-3">
                                                <label class="form-label">Confirm New Password *</label>
                                                <div class="password-input-container">
                                                    <input type="password" class="form-control" id="txt_repeat_pass"
                                                        name="password2" required
                                                        placeholder="Confirm new password"
                                                        onkeyup="checkPasswordMatch()">
                                                    <span class="password-toggle"><i class="bi bi-eye"></i></span>
                                                </div>
                                                <div id="passwordMatchMsg" class="mt-2"></div>
                                            </div>

                                            <div class="form-group mt-4">
                                                <button type="submit" name="changeLogin" class="btn btn-primary">Update Password</button>
                                                <button type="reset" class="btn btn-secondary ms-2">Reset</button>
                                            </div>
                                        </div>
                                        <div class="col-md-6" style="margin-top: 20px;">
                                           
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>
            <script>
                // Password strength checker
                function checkPasswordStrength(password) {
                    const strengthMeter = document.getElementById('strengthMeter');
                    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,15}$/;
                    const errorDiv = document.getElementById("passwordError");

                    if (regex.test(password)) {
                        errorDiv.style.display = "none";
                        strengthMeter.style.width = '100%';
                        strengthMeter.style.backgroundColor = 'green';
                    } else {
                        errorDiv.style.display = "block";
                        strengthMeter.style.width = '30%';
                        strengthMeter.style.backgroundColor = 'red';
                    }
                }

                // Password match checker
                function checkPasswordMatch() {
                    const password = document.getElementById('txtpass').value;
                    const confirmPassword = document.getElementById('txt_repeat_pass').value;
                    const message = document.getElementById('passwordMatchMsg');

                    if (password === confirmPassword && password !== '') {
                        message.innerHTML = '<span class="text-success"><i class="bi bi-check-circle-fill"></i> Passwords match!</span>';
                    } else if (confirmPassword !== '') {
                        message.innerHTML = '<span class="text-danger"><i class="bi bi-exclamation-circle-fill"></i> Passwords do not match!</span>';
                    } else {
                        message.innerHTML = '';
                    }
                }

                // Toggle password fields visibility
                document.querySelectorAll('.password-toggle').forEach(function (toggle) {
                    toggle.addEventListener('click', function () {
                        const input = this.parentElement.querySelector('input');
                        if (input.type === 'password') {
                            input.type = 'text';
                            this.innerHTML = '<i class="bi bi-eye-slash"></i>';
                        } else {
                            input.type = 'password';
                            this.innerHTML = '<i class="bi bi-eye"></i>';
                        }
                    });
                });
            </script>

            <?php include 'include/footer.php'; ?>
        </div>
    </div>
</body>

</html>