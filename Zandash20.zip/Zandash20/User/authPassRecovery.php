<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - Bit Global</title>

    <!-- site favicon -->
    <link rel="icon" type="image/png" href="assets/img/favicon/favicon.png">

    <!-- font awesome cdn links -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- google font -->
    <!-- <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400..900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet"> -->

    <!-- All stylesheet and icons css -->
    <!-- <link rel="stylesheet" href="https://www.bitcapitalx.com/assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://www.bitcapitalx.com/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://www.bitcapitalx.com/assets/css/style.css">
    <link rel="stylesheet" href="https://www.bitcapitalx.com/assets/css/responsive.css">
    <link rel="stylesheet" href="https://www.bitcapitalx.com/assets/css/login.css">
     -->
    <style>
        .login-section {
            position: relative;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        
        video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -1;
        }
        
        .login_box {
            background: rgba(0, 0, 0, 0.7);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5);
            color: #fff;
            width: 100%;
            max-width: 450px;
            margin: 0 auto;
        }
        
        .login_box img {
            display: block;
            margin: 0 auto 20px;
        }
        
        .login_box p {
            text-align: center;
            margin-bottom: 30px;
            font-size: 16px;
        }
        
        .form-control {
            background-color: rgba(255, 255, 255, 0.1) !important;
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff !important;
            height: 45px;
            border-radius: 5px;
        }
        
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.2) !important;
            color: #fff !important;
            border-color: #fff;
            box-shadow: none;
        }
        
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            width: 100%;
            padding: 12px;
            font-weight: 600;
            border-radius: 5px;
            margin-top: 20px;
        }
        
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        
        .loadingMore {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        
        .text-center {
            text-align: center;
        }
        
        .mt-4 {
            margin-top: 1.5rem;
        }
        
        .mb-0 {
            margin-bottom: 0;
        }
        
        a {
            color: #007bff;
            text-decoration: none;
        }
        
        a:hover {
            color: #0056b3;
            text-decoration: underline;
        }
    </style>
</head>

<?php require('../conection.php');
error_reporting(1);
unset($_SESSION['passTokenSet']);
$randToken=rand(1111,9999).time().date('s');
$_SESSION['passTokenSet']=md5($randToken); ?>

<body>
    <section class="login-section">
        <video loop="" autoplay="" muted="" playsinline>
                <source type="video/mp4" src="assets/img/lo-bg.mp4" >
                <source type="video/ogg" src="assets/img/lo-bg.mp4">
        </video>
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-6 col-md-8 mx-auto">
                    <div class="login_box">
                        <a href="https://www.bitcapitalx.com/index">
                            <img src="assets/img/logo/whitelogo.png" alt="logo" style="width:70%;">
                        </a>
                        <p>Reset your password to regain access to your account</p>
                        
                        <form class="form-signin" id="forgotPassForm">
                            <div class="form-group mb-4">
                                <input type="text" class="form-control" id="inputUserId" name="inputUserId" 
                                    placeholder="Enter User Id" required 
                                    value="<?php if(isset($_COOKIE["memberUserId"])) { echo $_COOKIE["memberUserId"]; }?>">
                            </div>
                            
                            <div class="form-group mb-4">
                                <input type="email" class="form-control" id="inputEmailId" name="inputEmailId" 
                                    placeholder="Enter Email Id" required>
                            </div>
                            
                            <div class="form-group mb-0">
                                <button class="btn btn-primary" type="button" id="passSubmit" 
                                    onclick="forgotPassValidate('<?=$_SESSION['passTokenSet']?>')">
                                    Reset Password
                                </button>
                                <button disabled style="display: none;" class="btn btn-primary loadingMore">
                                    Validating Data...
                                </button>
                            </div>
                            
                            <p class="mt-4 mb-0 text-center">
                                Remember your password? <a href="../User">Sign in</a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script src="https://www.bitcapitalx.com/application/third_party/js/custom.js?a=1.24"></script>
    <script src="custom.js"></script>
</body>
</html>