<?php

use PHPMailer\PHPMailer\PHPMailer;

require_once('../conection.php');
// require('../PHPMailer/EncrptyModel.php');
$d = date("Y-m-d H:i:s");
$userId = mysqli_real_escape_string($con, $_POST['userId']);
$d = date('Y-m-d H:i:s');
$queryDetails = mysqli_query($con, "SELECT member_id,name,phone,user_id,email_id FROM meddolic_user_details WHERE user_id='$userId' AND user_type=2 AND account_status=1");
if ($valDetails = mysqli_fetch_array($queryDetails)) {
  $email_id = $valDetails['email_id'];
  $memberId = $valDetails['member_id'];
  $name = $valDetails['name'];
  $phone = $valDetails['phone'];
  $user_id = $valDetails['user_id'];

  function trnPassword($length = 6)
  {
    $chars = "0123456789";
    $password = substr(str_shuffle($chars), 0, $length);
    return $password;
  }

  $trnPassword = trnPassword(6);
  // $passObj= new passEncrypt();

  // $encTrnPass= $passObj -> twoPassEncrypt($trnPassword);

  $queryupdate = mysqli_query($con, "UPDATE meddolic_user_details SET  trnPassword='$trnPassword' WHERE member_id='$memberId'");

  require_once "../PHPMailer/PHPMailer.php";
  require_once "../PHPMailer/SMTP.php";
  require_once "../PHPMailer/Exception.php";
  require_once "../PHPMailer/OAuthCredential.php";

  $mailSubject = "Bit Global | Transaction Password Recovery";
  $newMsg = '
<html>
<head>
  <title>Transaction Password Recovery - Bit Global</title>
  <meta charset="UTF-8">
  <style>
    body { font-family: Arial, sans-serif; background: #f2f2f2; margin: 0; padding: 0; }
    .container { background: #fff; max-width: 500px; margin: 30px auto; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.07); padding: 32px 24px; }
    .header { color: #ff670a; font-size: 22px; font-weight: bold; margin-bottom: 18px; }
    .content { color: #222; font-size: 16px; }
    .details { background: #f8f9fa; border-radius: 6px; padding: 12px 18px; margin: 18px 0; }
    .details li { margin-bottom: 6px; }
    .footer { color: #888; font-size: 13px; margin-top: 30px; border-top: 1px solid #eee; padding-top: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">Transaction Password Recovery</div>
    <div class="content">
      <p>Dear ' . htmlspecialchars($name) . ',</p>
      <p>We have received a request to reset your transaction password for your Bit Global account. Please find your new transaction password below:</p>
      <ul class="details">
        <li><strong>User ID:</strong> ' . htmlspecialchars($userId) . '</li>
        <li><strong>Transaction Password:</strong> ' . htmlspecialchars($trnPassword) . '</li>
      </ul>
      <p>If you did not request this change or need further assistance, please contact our support team immediately.</p>
      <p>Thank you for choosing Bit Global.</p>
      <p>Best regards,<br>
      <strong>Bit Global Support Team</strong></p>
    </div>
    <div class="footer">
      This is an automated message. Please do not reply to this email.<br>
      &copy; ' . date('Y') . ' Bit Global. All rights reserved.
    </div>
  </div>
</body>
</html>
';
  $mail = new PHPMailer();
  $mail->isSMTP();
  // $mail->SMTPDebug = 4;  //Keep It commented this is used for debugging                          
  $mail->Host = smtpServer; // smtp address of your email
  $mail->SMTPAuth = true;
  $mail->Username = EmailCode;
  $mail->Password = addCode;
  $mail->Port = smtpPort;
  $mail->SMTPSecure = "tls";
  $mail->smtpConnect([
    'ssl' => [
      'verify_peer' => false,
      'verify_peer_name' => false,
      'allow_self_signed' => true
    ]
  ]);

  //Email Settings
  $mail->isHTML(true);
  $mail->setFrom(EmailCode, mailerName);
  $mail->addAddress($email_id); // enter email address whom you want to send
  $mail->Subject = ("$mailSubject");
  $mail->Body = $newMsg;
  $mail->send();
  echo "../../";
} else {
  return false;
}
