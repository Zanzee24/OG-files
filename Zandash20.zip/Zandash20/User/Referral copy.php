<?php include 'include/head.php';
require_once("loginCheck.php");
?>
</body>

<body class="dark-mode">
    <!-- Modal -->
    <div class="modal fade" id="p2p_exchnange2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <h3>Notice</h3>
                    <p>
                        Do not release the crypto without receiving the payment. Please be aware of scammers who share
                        fake/spoofed proof of payments. Make sure to check your bank account and release the crypto only
                        if you have received the payment.
                    </p>
                    <p>
                        I have read and agree to the above content.
                    </p>
                    <a href="dashboard" class="btn btn-success"><i class="mdi mdi-archive"></i><span>P2P Exchange</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Referral Income</a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Referral Income & Team</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>


                <!-- Referral Team Section -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Referral Income</h4>
                            <div class="table-responsive">
                                <table class="table dataTable w-100 table-striped nowrap" id="export-button">
                                    <thead>
                                        <tr>
                                            <th>S.NO</th>
                                            <th>Direct Member</th>
                                            <th>Direct Member Name </th>
                                            <th>Direct Package</th>
                                            <th>Direct Income</th>
                                            <th>Release Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        function totalInvest($con, $memberId)
                                        {
                                            $queryInvest = mysqli_query($con, "SELECT SUM(investAmount) FROM meddolic_user_invest_history WHERE memberId='$memberId'");
                                            $valInvest = mysqli_fetch_array($queryInvest);
                                            if ($valInvest[0] != "") {
                                                return $valInvest[0];
                                            } else {
                                                echo "0.00";
                                            }
                                        }
                                        $count = 0;
                                        $queryReferral = mysqli_query($con, "SELECT a.referralIncome,a.packagePrice,a.dateTime,b.name,b.user_id,c.user_id AS childID,c.name AS childName FROM meddolic_user_sponsor_income a, meddolic_user_details b, meddolic_user_details c WHERE a.memberId=b.member_id AND a.childId=c.member_id AND a.memberId='$memberId'  ORDER BY a.dateTime DESC");
                                        while ($valReferral = mysqli_fetch_assoc($queryReferral)) {
                                            $count++; ?>
                                            <tr>
                                                <td><?= $count ?></td>
                                                <td><?= $valReferral['childID'] ?></td>
                                                <td><?= $valReferral['childName'] ?></td>
                                                <td><span class="badge badge-success fa fa-usd">
                                                        <?= $valReferral['packagePrice'] ?> </span></td>
                                                <td><span class="badge badge-success fa fa-usd">
                                                        <?= $valReferral['referralIncome'] ?> </span></td>
                                                <td><i class="fa fa-clock-o"></i>
                                                    <?= date("d-m-Y H:i:s", strtotime($valReferral['dateTime'])) ?></td>
                                                <!-- <td><?= $valReferral['referralPercent'] ?> <i class="fa fa-percent"></i> </td> -->

                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var d = document.getElementById("Team");
        d.className += " active";
        var d = document.getElementById("Referral.php");
        d.className += " active";
    </script>

    <?php include 'include/footer.php'; ?>