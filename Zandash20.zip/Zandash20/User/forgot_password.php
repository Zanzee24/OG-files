<?php
require('../conection.php');
error_reporting(1);
unset($_SESSION['passTokenSet']);
$randToken = rand(1111, 9999) . time() . date('s');
$_SESSION['passTokenSet'] = md5($randToken);
?>

<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="dark" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Favicon icon-->
  <link rel="shortcut icon" type="image/png" href="assets/assets/images/logos/favicon.png" />

  <!-- Core Css -->
  <link rel="stylesheet" href="assets/assets/css/styles.css" />
  <title>Zanthium</title>
</head>

<body>
  <!-- Preloader -->
  <div class="preloader">
    <img src="assets/assets/images/logos/favicon.png" alt="loader" class="lds-ripple img-fluid" />
  </div>
  <div id="main-wrapper">
    <div class="position-relative overflow-hidden radial-gradient min-vh-100 w-100">
      <div class="position-relative z-index-5">
        <div class="row">
          <div class="col-lg-6 col-xl-7 col-xxl-6 position-relative overflow-hidden bg-dark d-none d-lg-block">
            <div class="circle-top"></div>
            <div>
              <img src="assets/assets/images/logos/logo-icon.png" class="circle-bottom" alt="Logo-Dark" />
            </div>
            <div class="d-lg-flex align-items-center z-index-5 position-relative h-n80">
              <div class="row justify-content-center w-100">
                <div class="col-lg-7">
                  <h2 class="text-white fs-10 mb-3">
                    Welcome to
                    <br />
                    Zanthium
                  </h2>
                  <span class="opacity-75 fs-4 text-white d-block mb-3">Zanthium helps developers to build organized
                    and well
                    coded dashboards full of beautiful and rich modules.
                  </span>
                 
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-xl-5 col-xxl-6">
            <div class="min-vh-100 bg-body row justify-content-center justify-content-lg-start align-items-center p-5">
              <div class="col-sm-8 col-md-9 col-xxl-6 auth-card">
                <a href="index" class="text-nowrap logo-img d-block w-100">
                  <img src="assets/assets/images/logos/logo-icon.png" class="dark-logo" alt="Logo-Dark" />
                </a>
                <h2 class="mb-2 mt-4 fs-7 fw-bolder">Forgot Password</h2>
                <p class="mb-9">Please enter the email address associated with your account and We will email you a link
                  to reset your password.</p>

                <form method="POST" class="check" id="user_forgot" novalidate>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">User ID</label>
                     <input type="text" class="form-control mb-4" style="background-color: #fff0;color: #ffffff;" data-val="true" data-val-required="User ID is Required" id="inputUserId" name="inputUserId" placeholder="Username" required value="<?php if (isset($_COOKIE["memberUserId"])) {
                            echo $_COOKIE["memberUserId"];
                         } ?>" />
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                    <span class="field-validation-valid" data-valmsg-for="username" data-valmsg-replace="true"></span>
                        <input id="inputEmailId" name="inputEmailId" class="form-control mb-4" style="background-color: #fff0;color: #ffffff;" type="text" placeholder="Email Id">
                        <span class="field-validation-valid" data-valmsg-for="mpwd" data-valmsg-replace="true"></span>
                  </div>
                  <button type="button" class="btn btn-primary w-100 py-8 mb-3" id="passSubmit" onclick="forgotPassValidate('<?= $_SESSION['passTokenSet'] ?>')">Reset</button>
                        <button disabled style="display: none;" class="btn btn-danger loadingMore">Validating Data...</button>
                  <a href="auth.php" class="btn bg-primary-subtle text-primary w-100 py-8">Back to Login</a>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="dark-transparent sidebartoggler"></div>
  <!-- Import Js Files -->
  <script src="assets/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/assets/libs/simplebar/dist/simplebar.min.js"></script>
  <script src="assets/assets/js/theme/app.dark.init.js"></script>
  <script src="assets/assets/js/theme/theme.js"></script>
  <script src="assets/assets/js/theme/app.min.js"></script>

  <!-- solar icons -->
  <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
</body>

</html>