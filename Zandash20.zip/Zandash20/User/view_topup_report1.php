<?php
require_once("loginCheck.php");
include 'include/header.php';
include 'include/head.php';

?>
</body>

<body class="dark-mode">
    <!-- Modal -->

    <div class="wrapper">
        <div class="leftside-menu">
            <a href="dashboard" class="main_sidebar_logo">
                <span>
                    <img src="assets/img/logo/whitelogo.png" class="img-responsive" style="width:70%;">
                </span>
            </a>
            <?php include 'include/sidebar.php'; ?>
        </div>
        <div class="content-page">
            <div class="content">
                <!-- Topbar Start -->
                <?php include 'include/header.php'; ?>

                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item">
                                            <a href="dashboard">Dashboard</a>
                                        </li>
                                        <li class="breadcrumb-item active">Report</li>
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Activation Hisrtory </a>
                                        </li>
                                    </ol>
                                </div>
                                <h4 class="page-title">Activation History </h4>
                            </div>
                        </div>
                    </div>
                </div>

                <script data-cfasync="false" src="assets/js/cdn-cgi/email-decode.min.js"></script>
                <script src="assets/js/iconify-icon.min.js"></script>


                <!-- Referral Team Section -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Activation History </h4>
                            <div class="table-responsive">
                                <table class="table dataTable table-border w-100 table-striped nowrap" id="export-button">
                                    <thead>
                                            <tr>
                                                <th>S.NO</th>
                                                <th>User Id</th>
                                                <th>Name</th>
                                                <th>Package Amount</th>
                                                <th>Purchase Date</th>
                                                <th>Purchase By</th>
                                                <th>Purchase Type </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 0;
                                            $queryBuy = mysqli_query($con, "SELECT a.investStatus,a.dateTime,a.investAmount,b.user_id,b.name,c.user_id AS activerId,c.name AS activerName FROM meddolic_user_invest_history a, meddolic_user_details b, meddolic_user_details c WHERE (a.loginMemberId='$memberId' OR a.memberId='$memberId') AND a.memberId=b.member_id AND a.loginMemberId=c.member_id ORDER BY a.dateTime DESC");
                                            while ($valBuy = mysqli_fetch_assoc($queryBuy)) {
                                                $count++; ?>
                                                <tr>
                                                    <td><?= $count ?></td>
                                                    <td><?= $valBuy['user_id'] ?></td>
                                                    <td><?= $valBuy['name'] ?></td>
                                                    <td><span class="badge badge-success"><i class="fa fa-usd"></i> <?= $valBuy['investAmount'] ?></span></td>
                                                    <td><i class="fa fa-clock-o"></i> <?= date("d-m-Y H:i:s", strtotime($valBuy['dateTime'])); ?></td>
                                                    <td><?= $valBuy['activerName'] . " (User ID:" . $valBuy['activerId'] . ")"; ?></td>
                                                    <td><?php if ($valBuy['investStatus'] == 1) echo "<span class='badge badge-primary'>BOT</span>";
                                                        else if ($valBuy['investStatus'] == 2) echo "<span class='badge badge-success'>PACKAGE</span>"; ?></td>
                                                </tr>
                                            <?php } ?>
                                            <!-- Table content will be loaded here -->
                                        </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-arrow">
                            <div class="card-arrow-top-left"></div>
                            <div class="card-arrow-top-right"></div>
                            <div class="card-arrow-bottom-left"></div>
                            <div class="card-arrow-bottom-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        var d = document.getElementById("startInvestment");
        d.className += " active";
        var d = document.getElementById("view_topup_report.php");
        d.className += " active";
    </script>

    <?php include 'include/footer.php'; ?>