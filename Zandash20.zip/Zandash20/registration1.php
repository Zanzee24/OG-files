<?php
// session_start();
require_once('conection.php');
unset($_SESSION['tokenSet']);
$randToken = rand(1111, 9999) . time() . date('s');
$newToken = md5($randToken);
$_SESSION['tokenSet'] = $newToken; ?>
<!DOCTYPE html>
<html lang="en" dir="ltr" data-bs-theme="dark" data-color-theme="Blue_Theme" data-layout="vertical">

<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Favicon icon-->
  <link rel="shortcut icon" type="image/png" href="User/assets/assets/images/logos/favicon.png" />

  <!-- Core Css -->
  <link rel="stylesheet" href="User/assets/assets/css/styles.css" />
  <title>Zanthium </title>
</head>

<body>
  <!-- Preloader -->
  <div class="preloader">
    <img src="User/assets/assets/images/logos/favicon.png" alt="loader" class="lds-ripple img-fluid" />
  </div>
  <div id="main-wrapper">
    <div class="position-relative overflow-hidden radial-gradient min-vh-100 w-100">
      <div class="position-relative z-index-5">
        <div class="row">
          <div class="col-lg-6 col-xl-7 col-xxl-6 position-relative overflow-hidden bg-dark d-none d-lg-block">
            <div class="circle-top"></div>
            <div>
              <img src="User/assets/assets/images/logos/logo-icon.png" class="circle-bottom" alt="Logo-Dark" />
            </div>
            <div class="d-lg-flex align-items-center z-index-5 position-relative h-n80">
              <div class="row justify-content-center w-100">
                <div class="col-lg-7">
                  <h2 class="text-white fs-10 mb-3">
                    Welcome to
                    <br />
                    Zanthium
                  </h2>
                  <span class="opacity-75 fs-4 text-white d-block mb-3">Zanthium helps developers to build organized
                    and well
                    coded dashboards full of beautiful and rich modules.
                  </span>
                 
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-xl-5 col-xxl-6">
            <div class="authentication-login min-vh-100 bg-body row justify-content-center justify-content-lg-start align-items-center p-5">
              <div class="col-sm-8 col-md-9 col-xxl-6 auth-card">
                <a href="../index.html" class="text-nowrap logo-img d-block w-100">
                  <img src="User/assets/assets/images/logos/logo-icon.svg" class="dark-logo" alt="Logo-Dark" />
                </a>
                <h2 class="mb-2 mt-4 fs-7 fw-bolder">Sign Up</h2>
               
                <div class="position-relative text-center my-4">
                  <p class="mb-0 fs-4 px-3 d-inline-block bg-body text-dark z-index-5 position-relative">
                     sign up 
                  </p>
                  <span class="border-top w-100 position-absolute top-50 start-50 translate-middle"></span>
                </div>
                      <form method="post" action="authRegisterProcess.php">
                         <?php
        if (!empty($_GET['affiliateCode'])) {
          $query1 = "SELECT name FROM meddolic_user_details WHERE user_id='" . mysqli_real_escape_string($con, $_GET['affiliateCode']) . "'";
          $result1 = mysqli_query($con, $query1);
          $val1 = mysqli_fetch_assoc($result1);
          $sponser_name = $val1['name'];
        ?>

                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Sponsor ID</label>
                     <input class="form-control" name="sponser_id1" disabled value="<?= htmlspecialchars($_GET['affiliateCode']) ?>">
            <input type="hidden" name="sponser_id" value="<?= htmlspecialchars($_GET['affiliateCode']) ?>">
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Sponsor Name</label>
                    <input class="form-control mt-2" disabled value="<?= htmlspecialchars($sponser_name) ?>" placeholder="Sponsor Name">
                  </div>
                  <?php } else { ?>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Sponsor ID</label>
                    <input class="form-control" name="sponser_id" required id="sponser_id" onblur="sponserNewValid(this.value)"
              placeholder="Enter Sponsor ID">
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Sponsor Name</label>
                   <input class="form-control mt-2" readonly disabled id="sponsorName" placeholder="Sponsor Name">
                  </div>
                          <?php } ?>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Full Name </label>
                    <input type="text" name="username" class="form-control" placeholder="Full Name" required>
          <input type="hidden" name="goodFile" value="<?= $newToken ?>">
                  </div>
                  <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Email address</label>
                     <input type="email" name="email" class="form-control" placeholder="Email Address" required>
                  </div>
                  <div class="mb-4">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
 <span id="phoneCode"></span>
            <input type="text" id="MobPhone" name="phone" class="form-control" placeholder="Enter mobile number" required>
                  </div>
                  <div class="mb-4">
                    <label for="exampleInputPassword1" class="form-label">Select Country</label>
                   <select class="form-control" required id="M_COUNTRY" name="countryId">
            <option value="">Select Country</option>
            <?php $queryCountry = "SELECT * FROM meddolic_config_country_list WHERE status=1 ORDER BY countryName ASC";
            $resultCountry = mysqli_query($con, $queryCountry);
            while ($valCountry = mysqli_fetch_assoc($resultCountry)) { ?>
              <option value="<?= $valCountry['country_id'] ?>"
                data-phone-code="<?= $valCountry['country_code'] ?>">
                <?= $valCountry['countryName'] ?>
              </option>
            <?php } ?>
          </select>
                  </div>
                  <div class="mb-4">
                    <label for="exampleInputPassword1" class="form-label">Password</label>
                     <input type="text" name="password" class="form-control" placeholder="Password" required>
                  </div>
                   <button type="submit" name="submitRegister" class="btn btn-primary w-100 py-8 mb-4 rounded-2">Sign Up</button>
                  <div class="d-flex align-items-center">
                    <p class="fs-4 mb-0 text-dark">Already have an Account?</p>
                    <a class="text-primary fw-medium ms-2" href="User/auth.php">Sign In</a>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="dark-transparent sidebartoggler"></div>
   <script>
    document.addEventListener('DOMContentLoaded', function() {
      const countrySelect = document.getElementById('M_COUNTRY');
      const phoneCodeSpan = document.getElementById('phoneCode');
      const phoneInput = document.querySelector('input[name="phone"]');

      countrySelect.addEventListener('change', function() {
        const selectedCountry = countrySelect.options[countrySelect.selectedIndex];
        const countryPhoneCode = selectedCountry.getAttribute('data-phone-code');
        phoneCodeSpan.textContent = '+' + countryPhoneCode;
      });
    });
  </script>

  <script>
    function togglePasswordVisibility() {
      var passwordInput = document.getElementById("inputPassword");
      var eyeIcon = document.getElementById("eyeIcon");
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
      } else {
        passwordInput.type = "password";
        eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
      }
    }

    function toggleConfirmPasswordVisibility() {
      var passwordInput = document.getElementById("confirmPassword");
      var eyeIcon = document.getElementById("eyeIconConfirm");
      if (passwordInput.type === "password") {
        passwordInput.type = "text";
        eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
      } else {
        passwordInput.type = "password";
        eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
      }
    }
  </script>


  <script>
    function sponserNewValid(sponser_id) {
      document.getElementById("sponsorName").value = "";
      if (sponser_id != "") {
        const xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
          if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            let res = xmlhttp.responseText.trim();
            if (res !== "") {
              document.getElementById("sponsorName").value = res;
            } else {
              alert("Invalid Sponsor ID");
              document.getElementById("sponser_id").value = "";
            }
          }
        }
        xmlhttp.open("GET", "getSponserNameAjax?sponserId=" + sponser_id, true);
        xmlhttp.send();
      }
    }
  </script>
  <!-- Import Js Files -->
  <script src="User/assets/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="User/assets/assets/libs/simplebar/dist/simplebar.min.js"></script>
  <script src="User/assets/assets/js/theme/app.dark.init.js"></script>
  <script src="User/assets/assets/js/theme/theme.js"></script>
  <script src="User/assets/assets/js/theme/app.min.js"></script>

  <!-- solar icons -->
  <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
</body>

</html>